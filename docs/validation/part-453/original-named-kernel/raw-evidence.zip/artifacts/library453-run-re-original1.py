from pathlib import Path
import hashlib,importlib.util,json,os
r=Path.cwd();out=r/'artifacts/library453-re-original-run1';assert not out.exists();out.mkdir()
root=r/'artifacts/library453-re-unicode-original';admission=json.loads((r/'artifacts/library376-official-compiler/official-admission.json').read_bytes());installed=Path(admission['InstalledOtpRoot']);assert admission['SourceCommit']=='ad05823719d77c8faee87348ea39513d4e2f99c5'
p=r/'artifacts/spawn-priority351-preparation/execute-root.py';s=importlib.util.spec_from_file_location('owned453re',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
p=r/'artifacts/library426-trace-low-memory-original-proposal1/bounded_inventory.py';s=importlib.util.spec_from_file_location('inventory453re',p);inventory=importlib.util.module_from_spec(s);s.loader.exec_module(inventory)
expected={x['Path']:x['Sha256'] for x in json.loads(Path(admission['ExecutionManifestPath']).read_bytes())};assert inventory.inventory(installed)==expected
env=dict(os.environ);ebin=out/'ebin';ebin.mkdir();m.owned([str(installed/'bin/erlc.exe'),'+deterministic','-o',str(ebin),str(root/'beam_re_unicode453.erl')],out,'compile',90,env,str(r))
expression='ok=file:write_file("values.etf",term_to_binary(beam_re_unicode453:run())),ok=file:write_file("stacks.etf",term_to_binary(beam_re_unicode453:run_stacks())),halt().'
m.owned([str(installed/'bin/erl.exe'),'+S','1:1','-noshell','-noinput','-pa',str(ebin),'-eval',expression],out,'original',90,env,str(out))
assert inventory.inventory(installed)==expected
receipt={'Passed':True,'PinnedCommit':admission['SourceCommit'],'ProviderFiles':len(expected),'ProviderBeforeAfterEqual':True,'Cases':35,'Profiles':5,'CompleteRows':210,'Bindings':{str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest().upper() for p in [root/'beam_re_unicode453.erl',ebin/'beam_re_unicode453.beam',out/'values.etf',out/'stacks.etf']}}
(out/'completion.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
