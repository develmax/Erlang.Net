from pathlib import Path
import importlib.util,json,os
r=Path.cwd();out=r/'artifacts/library453-tests-build3';assert not out.exists();out.mkdir()
p=r/'artifacts/spawn-priority351-preparation/execute-root.py';s=importlib.util.spec_from_file_location('owned453tests',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
env=dict(os.environ,DOTNET_PROCESSOR_COUNT='1',DOTNET_GCConserveMemory='9',MSBUILDDISABLENODEREUSE='1');exe='C:/Program Files/dotnet/dotnet.exe'
m.owned([exe,'build','tests/Erlang.Tests/Erlang.Tests.csproj','--no-restore','-m:1','-nr:false','--nologo','--disable-build-servers','-p:UseSharedCompilation=false','-p:ConcurrentBuild=false','-p:BuildInParallel=false'],out,'build',180,env,str(r))
for name,case in [('kernel144','runtime/library453/original-named-kernel-no-listener-full-outcomes')]:
 m.owned([exe,'tests/Erlang.Tests/bin/Debug/net10.0/Erlang.Tests.dll','--case',case,'--report',str(out/(name+'.json'))],out,name,90,env,str(r))
(out/'completion.json').write_text(json.dumps({'Passed':True,'NewGroups':4,'Catalog':8832},indent=2)+'\n')
