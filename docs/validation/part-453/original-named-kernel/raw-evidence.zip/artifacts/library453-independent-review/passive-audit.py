from pathlib import Path
import struct,json,hashlib,collections
R=Path.cwd();O=R/'artifacts/library453-independent-review'
class Reader:
 def __init__(self,b):self.b=b;self.p=0
 def take(self,n):v=self.b[self.p:self.p+n];assert len(v)==n;self.p+=n;return v
 def uint(self,n):return int.from_bytes(self.take(n),'big')
 def node(self):
  start=self.p;t=self.uint(1)
  if t==97:k,v='integer',self.uint(1)
  elif t==98:k,v='integer',int.from_bytes(self.take(4),'big',signed=True)
  elif t in (110,111):
   n=self.uint(1 if t==110 else 4);sgn=self.uint(1);k,v='integer',int.from_bytes(self.take(n),'little')*(-1 if sgn else 1)
  elif t in (100,115,118,119):k,v='atom',self.take(self.uint(1 if t in (115,119) else 2)).decode('utf8' if t in (118,119) else 'latin1')
  elif t in (104,105):k,v='tuple',[self.node() for _ in range(self.uint(1 if t==104 else 4))]
  elif t==106:k,v='list',[]
  elif t==107:
   k,v='list',[{'k':'integer','v':x,'raw':''} for x in self.take(self.uint(2))]
  elif t==108:
   k,v='list',[self.node() for _ in range(self.uint(4))];tail=self.node()
   if tail['k']=='list':v+=tail['v']
   else:k,v='improper-list',(v,tail)
  elif t==109:k,v='binary',self.take(self.uint(4)).hex()
  elif t==77:
   n=self.uint(4);bits=self.uint(1);k,v='bits',(bits,self.take(n).hex())
  elif t in (101,114,90):
   n=1 if t==101 else self.uint(2);node=self.node();creation=self.uint(4 if t==90 else 1);words=[self.uint(4) for _ in range(n)];k,v='reference',(node['v'],creation,words)
  elif t==116:k,v='map',[(self.node(),self.node()) for _ in range(self.uint(4))]
  elif t==70:k,v='float',struct.unpack('>d',self.take(8))[0]
  elif t in (103,88):k,v='pid',(self.node()['v'],self.uint(4),self.uint(4),self.uint(4 if t==88 else 1))
  else:raise ValueError((t,self.p-1))
  return {'k':k,'v':v,'raw':self.b[start:self.p].hex()}
def read(p):
 r=Reader(p.read_bytes());assert r.uint(1)==131;n=r.node();assert r.p==len(r.b);return n
def eq(x,y,b,pattern_ref=False):
 if x['k']!=y['k']:return False
 if x['k']=='reference':
  if not pattern_ref:return x['v']==y['v']
  l,r=json.dumps(x['v']),json.dumps(y['v']);assert x['v'][0:2]==y['v'][0:2]
  if l in b:return b[l]==r
  if r in b.values():return False
  b[l]=r;return True
 if x['k'] in ('list','tuple'):
  pattern=x['k']=='tuple' and len(x['v'])==5 and x['v'][0]['k']=='atom' and x['v'][0]['v']=='re_pattern'
  return len(x['v'])==len(y['v']) and all(eq(a,c,b,pattern and i==4) for i,(a,c) in enumerate(zip(x['v'],y['v'])))
 if x['k']=='improper-list':return len(x['v'][0])==len(y['v'][0]) and all(eq(a,c,b) for a,c in zip(x['v'][0],y['v'][0])) and eq(x['v'][1],y['v'][1],b)
 if x['k']=='map':return len(x['v'])==len(y['v']) and all(eq(a,c,b) and eq(d,e,b) for (a,d),(c,e) in zip(x['v'],y['v']))
 return x['v']==y['v']
base=R/'artifacts/library453-re-original-run1';managed=R/'artifacts/library453-re-managed-run3';counts=collections.Counter();rows=[]
def compare(route,profile,expected,actual):
 assert expected['k']==actual['k']=='list' and len(expected['v'])==len(actual['v'])==35
 for i,(x,y) in enumerate(zip(expected['v'],actual['v'])):
  binding={};assert eq(x,y,binding),(route,profile,i);raw=x['raw']==y['raw'];counts['Rows']+=1;counts['RawEqual']+=raw;counts['OwnReferenceRows']+=not raw
  assert raw or binding,(route,profile,i)
  rows.append({'Route':route,'Profile':profile,'Index':i,'Case':x['v'][0]['v'],'RawEqual':raw,'ReferenceBindings':binding})
compare('run','default',read(base/'values.etf'),read(managed/'observations/actual-values.etf'))
exp=read(base/'stacks.etf');act=read(managed/'observations/actual-stacks.etf');assert len(exp['v'])==len(act['v'])==5
for x,y in zip(exp['v'],act['v']):
 assert eq(x['v'][0],y['v'][0],{});compare('run_stacks',x['v'][0]['v'],x['v'][1],y['v'][1])
assert dict(counts)=={'Rows':210,'RawEqual':162,'OwnReferenceRows':48}
completion=json.loads((base/'completion.json').read_text());assert completion['Passed'] and completion['PinnedCommit']=='ad05823719d77c8faee87348ea39513d4e2f99c5'
for p,h in completion['Bindings'].items():assert hashlib.sha256((R/p).read_bytes()).hexdigest().upper()==h
for p in [base/'original.exit.json',managed/'managed.exit.json']:
 e=json.loads(p.read_text());assert e['Settled'] and not e['TimedOut'] and e['ExitCode']==0 and not e['Failures']
assert json.loads((managed/'observations/cleanup.json').read_text())['Passed']
report={'Passed':True,'Counts':dict(counts),'Profiles':['run default','run_stacks default',0,1,2,8],'Scope':'complete ETF rows; re_pattern final-field reference bijections only, same node/creation required; no fields removed','Rows':rows}
(O/'passive-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'Passed':True,'Counts':dict(counts)}))
