from pathlib import Path
import json,collections,hashlib
R=Path.cwd();O=R/'artifacts/library453-independent-review'
# Reuse only passive ETF parser definitions, not its regex audit execution.
exec((O/'passive-audit.py').read_text().split("base=R/'artifacts/library453-re-original-run1'")[0])
def only_map_order(x,y):
 if x['raw']==y['raw']:return True
 if x['k']!=y['k']:return False
 if x['k']=='map':
  if len(x['v'])!=len(y['v']) or x['raw'][:10]!=y['raw'][:10]:return False
  keys={k['raw']:v for k,v in y['v']}
  return len(keys)==len(y['v']) and all(k['raw'] in keys and only_map_order(v,keys[k['raw']]) for k,v in x['v'])
 if x['k'] in ('tuple','list'):
  # Container encoding remains the same; map value ordering is the only relaxed detail.
  header=4 if x['raw'].startswith('68') else 10 if x['raw'].startswith(('69','6c')) else None
  if header is None or x['raw'][:header]!=y['raw'][:header] or len(x['v'])!=len(y['v']):return False
  return all(only_map_order(l,r) for l,r in zip(x['v'],y['v']))
 return False
original=R/'tests/Erlang.Tests/Resources/KernelBootOriginal453';actual=R/'artifacts/library453-kernel-permanent/342f6e1858af4215a63d40271a93e63f';counts=collections.Counter();rows=[];files=[]
manifest=json.loads((original/'manifest.json').read_text());assert all(hashlib.sha256((original/f).read_bytes()).hexdigest().upper()==h for f,h in manifest.items())
for f in ['values.etf','stacks.etf']:
 e=read(original/f);a=read(actual/('actual-'+f));strict=e['raw']==a['raw'];files.append({'File':f,'StrictOriginalBytesEqual':strict,'ExpectedSha256':hashlib.sha256((original/f).read_bytes()).hexdigest().upper(),'ActualSha256':hashlib.sha256((actual/('actual-'+f)).read_bytes()).hexdigest().upper()})
 if f=='values.etf':profiles=[('default',e,a)]
 else:
  assert len(e['v'])==len(a['v'])==5;profiles=[]
  for label,x,y in zip(['default',0,1,2,8],e['v'],a['v']):
   assert x['k']==y['k']=='tuple' and len(x['v'])==len(y['v'])==2 and x['v'][0]['v']==y['v'][0]['v']==label;profiles.append((label,x['v'][1],y['v'][1]))
 for profile,x,y in profiles:
  assert x['k']==y['k']=='list' and len(x['v'])==len(y['v'])==24
  for index,(l,r) in enumerate(zip(x['v'],y['v'])):
   raw=l['raw']==r['raw'];assert only_map_order(l,r),(f,profile,index);counts['Rows']+=1;counts['StrictOriginalRawRows']+=raw;counts['MapOrderOnlyRows']+=not raw
   rows.append({'File':f,'Profile':profile,'Index':index,'Case':l['v'][0]['v'],'StrictOriginalRawEqual':raw,'MapOrderOnly':not raw,'WholeFramesAndLabelsPreserved':True})
assert counts['Rows']==144
receipt=json.loads((actual/'comparison.json').read_text());assert receipt['Examined']==144 and not receipt['Passed'] and all(r['Passed'] for r in receipt['Comparisons']) and receipt['Cleanup']
out={'Passed':True,'Counts':dict(counts),'MapsOnlyRelaxation':'reorder identical raw keys with recursively identical values; all non-map leaf bytes and list/tuple headers unchanged','Files':files,'Rows':rows,'OriginalReceiptPreservedFailed':True,'RuntimeSha256':receipt['RuntimeSha256']}
(O/'kernel-map-order-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'Passed':True,'Counts':dict(counts),'MapOrderCases':sorted(set(r['Case'] for r in rows if r['MapOrderOnly'])),'Files':files}))
