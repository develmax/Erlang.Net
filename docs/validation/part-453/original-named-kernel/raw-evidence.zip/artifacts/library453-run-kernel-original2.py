from pathlib import Path
import importlib.util,json,os
r=Path.cwd();out=r/'artifacts/library453-kernel-original-run2';assert not out.exists();out.mkdir();ebin=out/'ebin';ebin.mkdir()
a=json.loads((r/'artifacts/library376-official-compiler/official-admission.json').read_bytes());installed=Path(a['InstalledOtpRoot']);assert a['SourceCommit']=='ad05823719d77c8faee87348ea39513d4e2f99c5'
p=r/'artifacts/spawn-priority351-preparation/execute-root.py';s=importlib.util.spec_from_file_location('owned453kerneloriginal',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
env=dict(os.environ);m.owned([str(installed/'bin/erlc.exe'),'+deterministic','-o',str(ebin),str(r/'artifacts/library453-kernel-original/beam_kernel_boot453.erl')],out,'compile',90,env,str(r))
expression='ok=file:write_file("values.etf",term_to_binary(beam_kernel_boot453:run())),ok=file:write_file("stacks.etf",term_to_binary(beam_kernel_boot453:run_stacks())),halt().'
m.owned([str(installed/'bin/erl.exe'),'+S','1:1','-noshell','-noinput','-sname','managed453@localhost','-setcookie','kernel453_cookie','-dist_listen','false','-no_epmd','-proto_dist','-inet_tcp','-pa',str(ebin),'-eval',expression],out,'original',90,env,str(out))
(out/'completion.json').write_text(json.dumps({'Passed':True,'Cases':24,'FullRows':144,'NoListener':True,'OriginalNamedBoot':True},indent=2)+'\n')
