from pathlib import Path
import importlib.util,json,os
r=Path.cwd();out=r/'artifacts/library453-tests-build2';assert not out.exists();out.mkdir()
p=r/'artifacts/spawn-priority351-preparation/execute-root.py';s=importlib.util.spec_from_file_location('owned453tests',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
env=dict(os.environ,DOTNET_PROCESSOR_COUNT='1',DOTNET_GCConserveMemory='9',MSBUILDDISABLENODEREUSE='1');exe='C:/Program Files/dotnet/dotnet.exe'
m.owned([exe,'build','tests/Erlang.Tests/Erlang.Tests.csproj','--no-restore','-m:1','-nr:false','--nologo','--disable-build-servers','-p:UseSharedCompilation=false','-p:ConcurrentBuild=false','-p:BuildInParallel=false'],out,'build',180,env,str(r))
for name,case in [('active-cancel','runtime/library453/unicode-trap-active-conversion-cancel-and-close')]:
 m.owned([exe,'tests/Erlang.Tests/bin/Debug/net10.0/Erlang.Tests.dll','--case',case,'--report',str(out/(name+'.json'))],out,name,90,env,str(r))
(out/'completion.json').write_text(json.dumps({'Passed':True,'NewGroups':3,'Catalog':8831},indent=2)+'\n')
