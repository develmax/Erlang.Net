from pathlib import Path
import json,hashlib,zipfile,subprocess,importlib.util
r=Path.cwd();out=r/'docs/validation/part-453/original-named-kernel';assert not out.exists() or not any(out.iterdir());out.mkdir(parents=True,exist_ok=True)
read=lambda p:json.loads((r/p).read_bytes())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
runtime=sha(r/'tests/Erlang.Tests/bin/Debug/net10.0/Erlang.Runtime.dll');assert runtime=='F39E2D87B336CC45D2706B5B63F097E269C594A775233B52DBE12156CA87D7C1'
assert read('artifacts/library453-tests-build7/completion.json')['Passed']
initial=read('artifacts/library453-affected-run1/completion.json');assert not initial['Passed'] and initial['Examined']==607 and initial['ExactCoverage'] and initial['ImmutableInputs']
failed=[case for s in initial['Shards'] for case in s['FailedCases']];assert len(failed)==1
repeat=read('artifacts/library453-port-block-recheck1/completion.json');assert repeat['Passed'] and repeat['ImmutableInputs'] and repeat['AcceptedUnionIfPassed']==607
gates=read('artifacts/library453-gates1/completion.json');assert not gates['Passed'];assert all(x['Passed'] for x in gates['Stages'] if x['Name']!='affected')
assert read('artifacts/library453-kernel-original-run4/completion.json')['ProviderBeforeAfterEqual']
assert read('artifacts/library453-native-retained-managed1/completion.json')['Passed']
assert read('artifacts/library453-standard79-final1/completion.json')['ChildPassed']
assert read('artifacts/library453-style-readiness1/completion.json')['Passed']
ledger=read('docs/mfa-compatibility.json');old=json.loads(subprocess.check_output(['git','show','HEAD:docs/mfa-compatibility.json']));assert ledger['Entries']==old['Entries'] and len(ledger['VerifiedSourceFiles'])==1623
for row in ledger['VerifiedSourceFiles']:assert sha(r/row['Path'])==row['Sha256']
def latest_receipt(folder):
 candidates=[p for p in (r/folder).glob('*/comparison.json') if json.loads(p.read_bytes()).get('Passed') and json.loads(p.read_bytes()).get('RuntimeSha256')==runtime]
 assert candidates,folder
 return max(candidates,key=lambda p:p.stat().st_mtime)
regex=latest_receipt('artifacts/library453-re-unicode-permanent');kernel=latest_receipt('artifacts/library453-kernel-permanent')
assert json.loads(regex.read_bytes())['AuthenticatedSameResourcePatterns']==48
assert json.loads(kernel.read_bytes())['Examined']==144
# Reuse independent parser definitions, with no execution of its old selected-run checks.
review=r/'artifacts/library453-independent-review';scope={};source=(review/'passive-audit.py').read_text();exec(source[:source.index('base=R/')],scope)
source=(review/'kernel-map-order-audit.py').read_text();exec(source[source.index('def only_map_order'):source.index('original=R/')],scope)
parse=scope['read'];eq=scope['only_map_order'];raw=order=0
for file in ['values.etf','stacks.etf']:
 e=parse(r/'artifacts/library453-kernel-original-run4'/file);a=parse(kernel.parent/('actual-'+file))
 profiles=[(e,a)] if file=='values.etf' else [(x['v'][1],y['v'][1]) for x,y in zip(e['v'],a['v'])]
 assert eq(e,a)
 for ep,ap in profiles:
  for x,y in zip(ep['v'],ap['v']):
   if x['raw']==y['raw']:raw+=1
   else:assert x['v'][0]['v']==y['v'][0]['v']=='state';order+=1
assert (raw,order)==(138,6)
report={'Passed':True,'PinnedCommit':ledger['Commit'],'RuntimeSha256':runtime,'DefaultApis':708,'VerifiedFullContracts':118,'ApiDelta':0,'FullContractDelta':0,'SourceGuards':1623,'Catalog':8833,'FinalFocusGroups':5,'AcceptedAffectedUnion':607,'InitialAffectedGreen':False,'InitialChildCoreClrOutOfMemory':True,'Whole20CaseBlockRepeatedTwice':True,'Native8AndRetained36Passed':True,'StandardBoot79AndCleanupPassed':True,'OriginalUnicodeRows':210,'OriginalUnicodeRawRows':162,'AuthenticatedResourceReferenceRows':48,'OriginalKernelRows':144,'StrictOriginalKernelRawRows':138,'KernelMapOrderOnlyRows':6,'BothKernelStrictWholeFilesEqual':False,'NoListener':True,'Epmd':False,'FullTcpBootAccepted':False,'WiderOriginalKernelPeerRacesAccepted':False,'OriginalProviderFilesVerifiedBeforeAfter':6427,'FinalRegexReceipt':str(regex.relative_to(r)).replace('\\','/'),'FinalKernelReceipt':str(kernel.relative_to(r)).replace('\\','/'),'ExactPublicationHeadFullCiRequired':True}
(out/'acceptance.json').write_bytes((json.dumps(report,indent=2)+'\n').encode())
directories=['library453-re-original-run1','library453-re-managed-run1','library453-re-managed-run2','library453-re-managed-run3','library453-re-unicode-original','library453-kernel-original','library453-kernel-original-run1','library453-kernel-original-run2','library453-kernel-original-run3','library453-kernel-original-run4','library453-independent-review','library453-pinned-source','library453-kernel-probe','library453-owned-style1','library453-driver-package1','library453-gates1','library453-affected-selection1','library453-affected-run1','library453-port-block-recheck1','library453-native-retained-managed1','library453-standard79-final1','library453-style-readiness1','library453-re-unicode-permanent','library453-kernel-permanent','library453-unicode-cancellation','library453-merged-branch-cleanup']
directories += ['library453-tests-build'+str(i) for i in range(1,8)]+['library453-kernel-run'+str(i) for i in range(1,14)]
files=set()
suffixes={'.json','.log','.txt','.py','.cs','.csproj','.c','.h','.erl','.beam','.etf','.md','.nul'}
for directory in directories:
 for p in (r/'artifacts'/directory).rglob('*'):
  if p.is_file() and p.suffix in suffixes and not {'bin','obj','build','__pycache__'}.intersection(p.relative_to(r/'artifacts'/directory).parts):files.add(p)
files.update((r/'artifacts').glob('library453-*.py'));files.update((r/'artifacts').glob('library453-*.json'))
rows=[]
with zipfile.ZipFile(out/'raw-evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):
  relative=str(p.relative_to(r)).replace('\\','/');data=p.read_bytes();z.writestr(relative,data);rows.append({'Path':relative,'Bytes':len(data),'Sha256':hashlib.sha256(data).hexdigest().upper()})
with zipfile.ZipFile(out/'raw-evidence.zip') as z:
 for row in rows:assert hashlib.sha256(z.read(row['Path'])).hexdigest().upper()==row['Sha256']
(out/'files.json').write_bytes((json.dumps({'ArchiveSha256':sha(out/'raw-evidence.zip'),'Files':rows},indent=2)+'\n').encode())
for name in ['review.md','kernel-map-order-review.md','kernel-map-order-audit.json','passive-audit.json']:(out/name).write_bytes((review/name).read_bytes())
print(json.dumps({'Passed':True,'Files':len(rows),'ArchiveBytes':(out/'raw-evidence.zip').stat().st_size,'RuntimeSha256':runtime,'AcceptedAffectedUnion':607}))
