from pathlib import Path
import importlib.util,json,os,sys,hashlib
r=Path.cwd();out=r/'artifacts/library453-port-block-recheck1';assert not out.exists();out.mkdir()
sys.path.insert(0,str(r/'artifacts/library413-final-regression-proposal1'))
from common import snapshot
selection=json.loads((r/'artifacts/library453-affected-selection1/selection.json').read_bytes());before=snapshot(r);assert before==selection['Bindings']
failed=json.loads((r/'artifacts/library453-affected-run1/block-09/report.json').read_bytes());assert failed['Passed']==19 and failed['Failed']==1
assert '0x8007000E' in (r/'artifacts/library453-affected-run1/block-09/execution.stderr.log').read_text()
p=r/'artifacts/spawn-priority351-preparation/execute-root.py';s=importlib.util.spec_from_file_location('owned453portblock',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
names=next(x['ExactCases'] for x in selection['Shards'] if x['Name']=='block-09');assert len(names)==20
command=['C:/Program Files/dotnet/dotnet.exe','tests/Erlang.Tests/bin/Debug/net10.0/Erlang.Tests.dll']
for name in names:command += ['--case',name]
rows=[]
for index in [1,2]:
 report=out/('report'+str(index)+'.json');passed=False
 try:
  m.owned(command+['--report',str(report)],out,'block'+str(index),120,dict(os.environ,DOTNET_PROCESSOR_COUNT='2',DOTNET_GCConserveMemory='9',MSBUILDDISABLENODEREUSE='1'),str(r));a=json.loads(report.read_bytes());passed=a['Passed']==a['SelectedCount']==20 and a['Failed']==0 and a['TotalCount']==8833
 except Exception as error:rows.append({'Iteration':index,'Passed':False,'Failure':repr(error)});continue
 rows.append({'Iteration':index,'Passed':passed})
assert snapshot(r)==before
passed=all(x['Passed'] for x in rows) and len(rows)==2
report={'Passed':passed,'ImmutableInputs':True,'InitialAffectedPassed':606,'InitialAffectedFailed':1,'InitialChildCoreClrOutOfMemory':True,'RecheckedWholeBlock':20,'IndependentBlockRuns':rows,'AcceptedUnionIfPassed':607 if passed else None,'OriginalFailurePreserved':True,'Original607RunGreen':False}
(out/'completion.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps(report));raise SystemExit(0 if passed else 1)
