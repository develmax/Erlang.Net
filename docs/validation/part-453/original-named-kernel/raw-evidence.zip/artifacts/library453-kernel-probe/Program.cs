using System.Reflection;
using System.Text;
using System.Text.Json;
using Erlang;

string repository = Path.GetFullPath(args[0]);
string admission = Path.GetFullPath(args[1]);
string output = Path.GetFullPath(args[2]);
Directory.CreateDirectory(output);
var failures = new System.Collections.Concurrent.ConcurrentQueue<string>();
AppDomain.CurrentDomain.FirstChanceException += (_, item) =>
{
    if (item.Exception is not OperationCanceledException && failures.Count < 2048)
        failures.Enqueue(item.Exception.ToString() + (item.Exception is ErlangException e ? "\nGUEST=" + e.StackTraceTerm : ""));
};
void Save(string name, object value) => File.WriteAllText(Path.Combine(output, name), JsonSerializer.Serialize(value, new JsonSerializerOptions { WriteIndented = true }));
using var diagnostic = new Timer(_ => Save("live-failures.json", failures.ToArray()), null, TimeSpan.FromSeconds(3), TimeSpan.FromSeconds(3));
ProcessRuntime? runtime = null;
try
{
    Assembly tests = Assembly.LoadFrom(Path.Combine(repository, "tests/Erlang.Tests/bin/Debug/net10.0/Erlang.Tests.dll"));
    MethodInfo create = tests.GetType("Erlang.Tests.StandardBootOriginal412Runtime", true)!.GetMethod("Create", BindingFlags.Static | BindingFlags.NonPublic)!;
    runtime = await (Task<ProcessRuntime>)create.Invoke(null, [admission, true, true])!;
    await runtime.InitializeModulesAsync(registry =>
    {
        using var resource = tests.GetManifestResourceStream("Erlang.Tests.RegexThreeOriginal413.re.beam")!;
        using var raw = new MemoryStream();
        resource.CopyTo(raw);
        using var imports = tests.GetManifestResourceStream("Erlang.Tests.StandardBootOriginal412.dependencies.json")!;
        string[] modules = JsonSerializer.Deserialize<string[]>(imports)!;
        PreparedBeamImage image = registry.PrepareBeam(raw.ToArray(), new BeamDependencySelection(modules));
        var prepared = new List<PreparedBeamImage> { image };
        if (args.Length <= 3 || args[3] != "regex")
        {
            RuntimeBootstrapInternalPorts416.Register(runtime, registry);
            RuntimeBootstrapAtomics.Register(runtime, registry);
            RuntimeBootstrapEtsInspection420.Register(runtime, registry);
            string installedEarly = JsonDocument.Parse(File.ReadAllBytes(admission)).RootElement.GetProperty("InstalledOtpRoot").GetString()!;
            foreach (string module in new[] { "erts_internal", "erts_code_purger" })
            {
                string file = Directory.GetFiles(installedEarly, module + ".beam", SearchOption.AllDirectories).Single();
                byte[] nativeBytes = File.ReadAllBytes(file);
                try { prepared.Add(registry.PrepareBeam(nativeBytes, new BeamDependencySelection(modules))); }
                catch (NotSupportedException)
                {
                    Assembly assembly = typeof(ProcessRuntime).Assembly;
                    const BindingFlags flags = BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic;
                    object structure = assembly.GetType("Erlang.BeamStructureReader")!.GetMethod("Read", flags)!.Invoke(null, [(ReadOnlyMemory<byte>)nativeBytes, null])!;
                    object code = assembly.GetType("Erlang.BeamLinkedCodeReader")!.GetMethod("Read", flags)!.Invoke(null, [structure])!;
                    PropertyInfo functions = code.GetType().GetProperty("Functions")!;
                    MethodInfo stub = assembly.GetType("Erlang.BeamNativePrimitives")!.GetMethod("IsStub", flags)!;
                    MethodInfo capture = typeof(ModuleRegistry).GetMethod("CaptureBeamPrimitives", BindingFlags.Instance | BindingFlags.NonPublic)!;
                    var entries = new List<object>();
                    foreach (object function in (System.Collections.IEnumerable)functions.GetValue(code)!)
                    {
                        if (!(bool)stub.Invoke(null, [code,function])!) continue;
                        object copy = typeof(object).GetMethod("MemberwiseClone", BindingFlags.Instance | BindingFlags.NonPublic)!.Invoke(code, null)!;
                        Array one = Array.CreateInstance(function.GetType(),1); one.SetValue(function,0); functions.SetValue(copy,one);
                        string? error = null;
                        try { _ = capture.Invoke(registry, [copy]); } catch (TargetInvocationException e) { error = e.InnerException?.ToString(); }
                        entries.Add(new { Function = function.ToString(), Passed = error is null, Failure = error });
                    }
                    Save("native-preload-diagnostic.json",entries);
                    throw;
                }
            }
            Save("extra-preloads.json", prepared.Select(x => new { x.Name, NativeBodies = x.NativePrimitiveExports.Count }));
        }
        if (registry.PublishPreparedBeam(prepared.ToArray()).Status != BeamPublicationStatus.Published)
            throw new InvalidOperationException("Original re publication failed");
    });
    Save("created.json", new { runtime.Node, Loaded = runtime.Modules.LoadedModules.ToArray() });
    ProcessRuntime owner = runtime;
    if (args.Length > 3 && args[3] == "regex")
    {
        string original = args[4];
        await runtime.InitializeModulesAsync(registry =>
        {
            using var imports = tests.GetManifestResourceStream("Erlang.Tests.StandardBootOriginal412.dependencies.json")!;
            string[] modules = JsonSerializer.Deserialize<string[]>(imports)!;
            PreparedBeamImage image = registry.PrepareBeam(File.ReadAllBytes(Path.Combine(original, "ebin/beam_re_unicode453.beam")), new BeamDependencySelection(modules.Append("beam_re_unicode453")));
            if (registry.PublishPreparedBeam(image).Status != BeamPublicationStatus.Published)
                throw new InvalidOperationException("Worker publication failed");
        });
        var comparisons = new List<object>();
        bool equal = true;
        int examined = 0, rawRows = 0, ownRows = 0;
        bool Same(Term expected, Term actual, Dictionary<ReferenceTerm,ReferenceTerm> bindings)
        {
            if (expected is TupleTerm e && actual is TupleTerm a)
            {
                if (e.Items.Count != a.Items.Count) return false;
                if (e.Items.Count == 5 && e.Items[0].Equals(Term.A("re_pattern")) && e.Items[4] is ReferenceTerm)
                {
                    if (!e.Items.Take(4).SequenceEqual(a.Items.Take(4)) || e.Items[4] is not ReferenceTerm er || a.Items[4] is not ResourceReferenceTerm ar) return false;
                    if (bindings.TryGetValue(er, out ReferenceTerm? previous)) return previous.Equals(ar);
                    if (bindings.Values.Contains(ar)) return false;
                    bindings.Add(er, ar);
                    return true;
                }
                return e.Items.Zip(a.Items).All(pair => Same(pair.First,pair.Second,bindings));
            }
            if (expected is Cons ec && actual is Cons ac) return Same(ec.Head,ac.Head,bindings) && Same(ec.Tail,ac.Tail,bindings);
            return expected.Equals(actual);
        }
        foreach (string route in new[] { "run", "run_stacks" })
        {
            var value = new TaskCompletionSource<Term>(TaskCreationOptions.RunContinuationsAsynchronously);
            ProcessHandle capture = runtime.Spawn(async context =>
            {
                try { value.TrySetResult(await owner.Modules.Call(context, "beam_re_unicode453", route)); }
                catch (Exception error) { value.TrySetException(error); }
                return Nil.Value;
            });
            Term result = await value.Task.WaitAsync(TimeSpan.FromSeconds(40));
            await capture.Completion.WaitAsync(TimeSpan.FromSeconds(10));
            byte[] bytes = ExternalTermFormat.Encode(result);
            string file = route == "run" ? "values.etf" : "stacks.etf";
            File.WriteAllBytes(Path.Combine(output, "actual-" + file), bytes);
            byte[] expected = File.ReadAllBytes(Path.Combine(original, file));
            Term originalTerm = ExternalTermFormat.Decode(expected);
            bool termEqual = result.Equals(originalTerm), rawEqual = bytes.AsSpan().SequenceEqual(expected);
            var expectedProfiles = route == "run" ? new[] { originalTerm } : Cons.Items(originalTerm).Cast<TupleTerm>().Select(x => x.Items[1]).ToArray();
            var actualProfiles = route == "run" ? new[] { result } : Cons.Items(result).Cast<TupleTerm>().Select(x => x.Items[1]).ToArray();
            if (expectedProfiles.Length != actualProfiles.Length) throw new InvalidOperationException("Missing profiles");
            for (int profile = 0; profile < expectedProfiles.Length; profile++)
            {
                Term[] expectedRows = Cons.Items(expectedProfiles[profile]).ToArray(), actualRows = Cons.Items(actualProfiles[profile]).ToArray();
                if (expectedRows.Length != 35 || actualRows.Length != 35) throw new InvalidOperationException("Missing cases");
                for (int index = 0; index < expectedRows.Length; index++)
                {
                    var bindings = new Dictionary<ReferenceTerm,ReferenceTerm>();
                    bool passed = Same(expectedRows[index],actualRows[index],bindings);
                    bool rowRawEqual = ExternalTermFormat.Encode(expectedRows[index]).AsSpan().SequenceEqual(ExternalTermFormat.Encode(actualRows[index]));
                    if (bindings.Count == 0) { rawRows++; passed &= rowRawEqual; } else ownRows++;
                    comparisons.Add(new { Route = route, Profile = profile, Index = index, Passed = passed, WholeRawEqual = rowRawEqual, ReferenceBindings = bindings.Select(x => new { Original = x.Key.ToString(), Managed = x.Value.ToString() }).ToArray(), Expected = passed ? null : expectedRows[index].ToString(), Actual = passed ? null : actualRows[index].ToString() });
                    equal &= passed; examined++;
                }
            }
            if (!termEqual)
            {
                File.WriteAllText(Path.Combine(output, "expected-" + file + ".txt"), originalTerm.ToString());
                File.WriteAllText(Path.Combine(output, "actual-" + file + ".txt"), result.ToString());
            }
        }
        Save("comparison.json", new { Passed = equal, Examined = examined, RawRows = rawRows, OwnReferenceRows = ownRows, Comparisons = comparisons });
        if (!equal) Environment.ExitCode = 1;
        return;
    }
    ProcessHandle prepare = runtime.Spawn(context => owner.Modules.Call(context, "prim_file", "on_load"));
    await prepare.Completion.WaitAsync(TimeSpan.FromSeconds(30));
    string installed = JsonDocument.Parse(File.ReadAllBytes(admission)).RootElement.GetProperty("InstalledOtpRoot").GetString()!;
    string[] bootArgs = ["-root", installed, "-bindir", Path.Combine(installed, "erts-17.1/bin"),
        "-boot", Path.Combine(installed, "bin/no_dot_erlang"), "-mode", "interactive", "-noshell", "-noinput",
        "-setcookie", "kernel453_cookie", "-start_epmd", "false", "-dist_listen", "false", "-no_epmd", "-proto_dist", "inet_tcp"];
    bool bootNamed = args.Length > 3 && args[3] is "startup" or "kernel-observe";
    if (bootNamed) bootArgs = bootArgs.Concat(["-sname", "managed453@localhost"]).ToArray();
    Save("arguments.json", bootArgs);
    using var stop = new CancellationTokenSource(TimeSpan.FromSeconds(60));
    RuntimeOtpBootSession session = await runtime.StartOtpBootAsync(bootArgs.Select(x => new BitString(Encoding.UTF8.GetBytes(x))), stop.Token);
    Save("boot-started.json", new { runtime.Node, session.InitializationProcess, Ended = session.Completion.IsCompleted });
    var queried = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
    ProcessHandle query = runtime.Spawn(async context =>
    {
        try
        {
        Term startup = bootNamed ? Term.Tuple(Term.A("ok"), owner.WhereIs("net_kernel"))
            : await owner.Modules.Call(context, "net_kernel", "start", Term.A("managed453@localhost"),
                new MapTerm(new Dictionary<Term,Term> { [Term.A("name_domain")] = Term.A("shortnames"), [Term.A("dist_listen")] = Term.A("false") }));
        Save("kernel-start-result.json", new { Result = startup.ToString() });
        Term pid = await owner.Modules.Call(context, "erlang", "whereis", Term.A("net_kernel"));
        Term alive = await owner.Modules.Call(context, "erlang", "is_alive");
        bool original = owner.Modules.SourceOwner("net_kernel", "init", 1) is PreparedBeamImage;
        Save("kernel-query.json", new { Pid = pid.ToString(), IsAlive = alive.ToString(), Node = owner.Node, OriginalKernel = original });
        if (pid is not Pid || !alive.Equals(Term.A("true")) || !original || owner.Node != "managed453@localhost")
            throw new InvalidOperationException("Original named kernel did not actually start");
        queried.TrySetResult();
        }
        catch (Exception error)
        {
            Save("kernel-query-failure.json", new { Failure = error.ToString() });
            queried.TrySetException(error);
        }
        return Nil.Value;
    });
    await queried.Task.WaitAsync(TimeSpan.FromSeconds(60));
    await query.Completion.WaitAsync(TimeSpan.FromSeconds(30));
    if (args.Length > 3 && args[3] == "kernel-observe")
    {
        string original = args[4];
        await runtime.InitializeModulesAsync(registry =>
        {
            using var imports = tests.GetManifestResourceStream("Erlang.Tests.StandardBootOriginal412.dependencies.json")!;
            string[] modules = JsonSerializer.Deserialize<string[]>(imports)!;
            PreparedBeamImage image = registry.PrepareBeam(File.ReadAllBytes(Path.Combine(original, "ebin/beam_kernel_boot453.beam")), new BeamDependencySelection(modules.Append("beam_kernel_boot453")));
            if (registry.PublishPreparedBeam(image).Status != BeamPublicationStatus.Published)
                throw new InvalidOperationException("Observer publication failed");
        });
        var rows = new List<object>();
        foreach (string route in new[] { "run", "run_stacks" })
        {
            var captured = new TaskCompletionSource<Term>(TaskCreationOptions.RunContinuationsAsynchronously);
            ProcessHandle observer = runtime.Spawn(async context =>
            {
                try { captured.TrySetResult(await owner.Modules.Call(context, "beam_kernel_boot453", route)); }
                catch (Exception error) { captured.TrySetException(error); }
                return Nil.Value;
            });
            Term actual = await captured.Task.WaitAsync(TimeSpan.FromSeconds(45));
            await observer.Completion.WaitAsync(TimeSpan.FromSeconds(10));
            string file = route == "run" ? "values.etf" : "stacks.etf";
            File.WriteAllBytes(Path.Combine(output,"actual-"+file), ExternalTermFormat.Encode(actual));
            Term expected = ExternalTermFormat.Decode(File.ReadAllBytes(Path.Combine(original,file)));
            Term[] expectedProfiles = route == "run" ? [expected] : Cons.Items(expected).Cast<TupleTerm>().Select(x=>x.Items[1]).ToArray();
            Term[] actualProfiles = route == "run" ? [actual] : Cons.Items(actual).Cast<TupleTerm>().Select(x=>x.Items[1]).ToArray();
            if (expectedProfiles.Length != actualProfiles.Length) throw new InvalidOperationException("Missing profiles");
            for (int profile=0;profile<expectedProfiles.Length;profile++)
            {
                Term[] er = Cons.Items(expectedProfiles[profile]).ToArray(), ar = Cons.Items(actualProfiles[profile]).ToArray();
                if (er.Length != 24 || ar.Length != 24) throw new InvalidOperationException("Missing rows");
                for (int index=0;index<er.Length;index++)
                    rows.Add(new { Route=route,Profile=profile,Index=index,Passed=er[index].Equals(ar[index]) && ExternalTermFormat.Encode(er[index]).AsSpan().SequenceEqual(ExternalTermFormat.Encode(ar[index])),Expected=er[index].ToString(),Actual=ar[index].ToString() });
            }
        }
        bool passed = rows.Count == 144 && rows.All(x=>(bool)x.GetType().GetProperty("Passed")!.GetValue(x)!);
        Save("comparison.json",new { Passed=passed,Examined=rows.Count,Comparisons=rows });
        if (!passed) throw new InvalidOperationException("Original kernel comparison differs");
    }
    Save("completion.json", new { Passed = true });
}
catch (Exception error)
{
    Save("failure.json", new { Failure = error.ToString() });
    if (runtime?.HaltCompletion.IsCompletedSuccessfully == true)
        Save("halt.json", runtime.HaltCompletion.Result);
    Environment.ExitCode = 1;
}
finally
{
    Save("first-chance.json", failures.ToArray());
    if (runtime is not null)
    {
        if (runtime.HaltCompletion.IsCompletedSuccessfully)
        {
            RuntimeHaltResult halt = runtime.HaltCompletion.Result;
            Save("halt.json", new { halt.Status, halt.Kind, halt.Slogan, LogicalStack = halt.LogicalStack?.ToString() });
        }
        try { await runtime.DisposeAsync().AsTask().WaitAsync(TimeSpan.FromSeconds(30)); Save("cleanup.json", new { Passed = true }); }
        catch (Exception error) { Save("cleanup.json", new { Passed = false, Failure = error.ToString() }); Environment.ExitCode = 1; }
    }
}
