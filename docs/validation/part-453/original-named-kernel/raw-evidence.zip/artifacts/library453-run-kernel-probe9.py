from pathlib import Path
import importlib.util,os
r=Path.cwd();out=r/'artifacts/library453-kernel-run9';assert not out.exists();out.mkdir()
p=r/'artifacts/spawn-priority351-preparation/execute-root.py';s=importlib.util.spec_from_file_location('owned453probe',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
env=dict(os.environ,DOTNET_PROCESSOR_COUNT='1',DOTNET_GCConserveMemory='9',MSBUILDDISABLENODEREUSE='1');exe='C:/Program Files/dotnet/dotnet.exe'
m.owned([exe,'build','artifacts/library453-kernel-probe/Probe.csproj','-m:1','-nr:false','--nologo','--disable-build-servers','-p:UseSharedCompilation=false','-p:ConcurrentBuild=false','-p:BuildInParallel=false'],out,'build',180,env,str(r))
m.owned([exe,'artifacts/library453-kernel-probe/bin/Debug/net10.0/Probe.dll',str(r),str(r/'artifacts/library376-official-compiler/official-admission.json'),str(out/'observations')],out,'probe',150,env,str(r))
