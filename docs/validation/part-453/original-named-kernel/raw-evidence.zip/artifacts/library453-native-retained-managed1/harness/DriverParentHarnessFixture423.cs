namespace Erlang;

internal sealed class DriverParentHarnessFixture423 : IAsyncDisposable
{
    internal ProcessRuntime Runtime { get; }
    internal RuntimeOsEnvironment Environment { get; }
    internal DriverParentHarnessActor423? Actor;
    internal PreparedBeamImage? Image;
    internal PortTerm? Port;
    internal string Directory { get; }

    private DriverParentHarnessFixture423(DriverParentHarnessInput423 input,string directory)
    {
        Directory=directory;
        Runtime=new(input.SystemInfo.SchedulerThreads);
        Environment=Runtime.RequireOsEnvironment();
    }

    internal static async Task<DriverParentHarnessFixture423> Create(DriverParentHarnessInput423 input,
        string name,bool open=true)
    {
        string directory=Path.Combine(input.OutputDirectory,name);
        System.IO.Directory.CreateDirectory(directory);
        foreach(string path in System.IO.Directory.GetFiles(input.DriverDirectory,"*.dll"))
            File.Copy(path,Path.Combine(directory,Path.GetFileName(path)),false);
        var fixture=new DriverParentHarnessFixture423(input,directory);
        try
        {
            DriverParentHarnessAccess423.SetBefore(fixture.Environment);
            await RuntimeBootstrapDriverFrontend422.Register(fixture.Runtime,fixture.Runtime.Modules,
                DriverParentHarnessAccess423.Configuration(input),CancellationToken.None);
            await fixture.Runtime.InitializeModulesAsync(registry=>
            {
                DriverParentHarnessAccess423.Require(!registry.Exports.Any(export=>export.Module==DriverParentHarnessNames423.Module));
                var declared=new BeamDependencySelection(input.DeclaredModules);
                var image=registry.PrepareBeam(File.ReadAllBytes(Path.Combine(input.OriginalDirectory,"stock/erl_ddll.beam")),declared);
                DriverParentHarnessAccess423.Require(image.NativePrimitiveExports.Count==7);
                fixture.Image=image;
                foreach(var signature in DriverParentHarnessNames423.Signatures)
                    DriverParentHarnessAccess423.Require(image.NativePrimitiveExports.Contains(new(signature.Function,signature.Arity)));
                DriverParentHarnessAccess423.Require(registry.PublishPreparedBeam([image]).Status==BeamPublicationStatus.Published);
                foreach(var export in registry.Exports.Where(export=>export.Module==DriverParentHarnessNames423.Module))
                    DriverParentHarnessAccess423.Require(ReferenceEquals(registry.SourceOwner(export.Module,export.Function,export.Arity),image));
            });
            var actor=new DriverParentHarnessActor423(fixture.Runtime);
            fixture.Actor=actor;
            if(open)
            {
                Term loaded=await actor.Invoke(async context=>await fixture.Runtime.Modules.Call(context,
                    DriverParentHarnessNames423.Module,"try_load",Cons.From(directory.Select(c=>Term.I(c))),Term.A(DriverParentHarnessNames423.Driver),Nil.Value));
                DriverParentHarnessAccess423.Require(loaded.Equals(Term.Tuple(Term.A("ok"),Term.A("loaded"))));
                fixture.Port=(PortTerm)await actor.Invoke(async context=>await fixture.Runtime.Modules.Call(context,
                    "erlang","open_port",Term.Tuple(Term.A(DriverOpenNames422.SpawnDriver),Term.A(DriverParentHarnessNames423.Driver)),Term.List(Term.A("binary"))));
            }
            return fixture;
        }
        catch(Exception initial)
        {
            try { await fixture.DisposeAsync(); }
            catch(Exception cleanup) { throw new AggregateException(initial,cleanup); }
            throw;
        }
    }

    public async ValueTask DisposeAsync()
    {
        var failures=new List<Exception>();
        try { await Runtime.DisposeAsync(); } catch(Exception failure) { failures.Add(failure); }
        try { if(Actor is not null)await Actor.DisposeAsync(); } catch(Exception failure) { failures.Add(failure); }
        if(failures.Count!=0)throw new AggregateException(failures);
    }
}
