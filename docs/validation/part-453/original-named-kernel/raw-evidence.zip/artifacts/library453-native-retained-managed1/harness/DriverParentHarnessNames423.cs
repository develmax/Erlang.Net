using System.Reflection;

namespace Erlang;

internal static class DriverParentHarnessNames423
{
    internal const BindingFlags Members = BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public;
    internal const string Module = "erl_ddll";
    internal const string Driver = "driver_parent423";
    internal const string EnvironmentKey = "ERLANG423_DRIVER_LATE";
    internal const string Before = "before";
    internal const string Witness = "before=0:before;write=0;after=0:after";
    internal const string Frontend = "driverFrontend422";
    internal const string Dispatcher = "actorDispatcher";
    internal const string DriverOwners = "driverOwners422";
    internal const string DriverLeases = "driverLeases422";
    internal const string Released = "driverStorageReleased422";
    internal const string Initializer = "initializer";
    internal const string Processes = "processes";
    internal static readonly TimeSpan Deadline = TimeSpan.FromSeconds(60);
    internal static readonly (string Function, int Arity)[] Signatures =
    [ ("try_load",3),("try_unload",2),("info",2),("monitor",2),("demonitor",1),("loaded_drivers",0),("format_error_int",1) ];
}
