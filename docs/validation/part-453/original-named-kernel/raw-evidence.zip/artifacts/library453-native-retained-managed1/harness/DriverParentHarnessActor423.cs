using System.Threading.Channels;

namespace Erlang;

internal sealed class DriverParentHarnessActor423 : IAsyncDisposable
{
    private readonly Channel<Func<ProcessContext,Task>> commands = Channel.CreateUnbounded<Func<ProcessContext,Task>>();
    private readonly TaskCompletionSource<ProcessContext> ready = new(TaskCreationOptions.RunContinuationsAsynchronously);
    internal ProcessHandle Process { get; }
    internal Task<ProcessContext> Ready => ready.Task;

    internal DriverParentHarnessActor423(ProcessRuntime runtime)
    {
        Process = runtime.Spawn(async context =>
        {
            ready.TrySetResult(context);
            try
            {
                await foreach (var command in commands.Reader.ReadAllAsync(context.Cancellation)) await command(context);
            }
            finally { commands.Writer.TryComplete(); }
            return Nil.Value;
        });
    }

    internal async Task<T> Invoke<T>(Func<ProcessContext,Task<T>> body)
    {
        var result = new TaskCompletionSource<T>(TaskCreationOptions.RunContinuationsAsynchronously);
        await commands.Writer.WriteAsync(async context =>
        {
            try { result.TrySetResult(await body(context)); }
            catch (Exception failure) { result.TrySetException(failure); }
        });
        return await result.Task.WaitAsync(DriverParentHarnessNames423.Deadline);
    }

    public async ValueTask DisposeAsync()
    {
        commands.Writer.TryComplete();
        await Process.Completion.WaitAsync(DriverParentHarnessNames423.Deadline);
    }
}
