namespace Erlang;

internal sealed record DriverParentHarnessInput423(string PackageManifest, string PackageSha256,
    ErlDriverSystemInfo422 SystemInfo, string ErrnoManifest, string ErrnoSha256,
    string DriverDirectory, string OutputDirectory, string OriginalDirectory,
    IReadOnlyDictionary<string,string> ExpectedInputs, IReadOnlyList<string> DeclaredModules);
