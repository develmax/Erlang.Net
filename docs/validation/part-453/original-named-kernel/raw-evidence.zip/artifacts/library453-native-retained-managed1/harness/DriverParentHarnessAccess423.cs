using System.Reflection;
using System.Security.Cryptography;
using System.Text;

namespace Erlang;

internal static class DriverParentHarnessAccess423
{
    internal static void Require(bool value)
    {
        if (!value) throw new InvalidDataException(DriverParentWireNames422.Invalid);
    }

    internal static object Field(object owner,string name)
        => owner.GetType().GetField(name,DriverParentHarnessNames423.Members)!.GetValue(owner)!;

    internal static DriverFrontendConfiguration422 Configuration(DriverParentHarnessInput423 input,
        ErlDriverHostLaunchOptions420? launch = null)
        => new(ErlDriverHostPackage420.Read(input.PackageManifest,input.PackageSha256),input.SystemInfo,
            Environment.CurrentDirectory,DriverFrontendConfiguration422.ReadErrnoManifest(input.ErrnoManifest,input.ErrnoSha256),
            launch ?? new(TimeSpan.FromSeconds(15),TimeSpan.FromSeconds(15),16*1024*1024));

    internal static void VerifyInputs(DriverParentHarnessInput423 input)
    {
        foreach(var row in input.ExpectedInputs)
            Require(Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(row.Key)))==row.Value);
    }

    internal static void ZeroLeases(ProcessRuntime runtime,RuntimeOsEnvironment environment,bool closed)
    {
        Require((int)Field(Field(runtime,DriverParentHarnessNames423.Dispatcher),DriverParentHarnessNames423.DriverOwners)==0);
        Require((int)Field(environment,DriverParentHarnessNames423.DriverLeases)==0);
        Require((bool)Field(environment,DriverParentHarnessNames423.Released)==closed);
    }

    internal static void SetBefore(RuntimeOsEnvironment environment)
        => Require(environment.WriteDriver422(Encoding.ASCII.GetBytes(DriverParentHarnessNames423.EnvironmentKey),
            Encoding.ASCII.GetBytes(DriverParentHarnessNames423.Before))==0);

    internal static void PublicClosed(RuntimeOsEnvironment environment)
    {
        bool refused=false;
        try { environment.ReadDriver422(Encoding.ASCII.GetBytes(DriverParentHarnessNames423.EnvironmentKey)); }
        catch(ObjectDisposedException) { refused=true; }
        Require(refused);
    }
}
