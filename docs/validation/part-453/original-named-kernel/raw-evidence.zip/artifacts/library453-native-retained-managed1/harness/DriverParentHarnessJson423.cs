using System.Text.Json;

namespace Erlang;

internal static class DriverParentHarnessJson423
{
    internal static readonly JsonSerializerOptions Options=new(){WriteIndented=true,MaxDepth=256};
}
