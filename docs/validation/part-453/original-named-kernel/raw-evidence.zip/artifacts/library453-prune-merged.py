from pathlib import Path
import hashlib,json,subprocess
r=Path.cwd();out=r/'artifacts/library453-merged-branch-cleanup';assert not out.exists();out.mkdir()
data=json.loads((r/'artifacts/library453-branch-inventory.json').read_bytes());assert data['OpenPullRequests']==[] and data['Rulesets']==[]
def git(*args):return subprocess.check_output(['git',*args],text=True).strip()
base=data['MergedMain'];assert git('rev-parse','origin/main')==base==git('rev-parse','HEAD')
worktrees=git('worktree','list','--porcelain');active={line.removeprefix('branch refs/heads/') for line in worktrees.splitlines() if line.startswith('branch refs/heads/')}
selected=[];kept=[]
for branch in data['Branches']:
 name=branch['name'];head=branch['commit']['sha'];reason=None
 if name=='main' or branch['protected']:reason='main or protected'
 elif name in active:reason='active worktree'
 elif subprocess.run(['git','merge-base','--is-ancestor',head,base],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode:reason='not merged into current main'
 if reason:kept.append({'Name':name,'Reason':reason});continue
 assert git('rev-parse','refs/heads/'+name)==head==git('rev-parse','refs/remotes/origin/'+name)
 selected.append({'Name':name,'Sha256Commit':head})
assert all(x['Name']!='main' for x in selected) and len(selected)>=12
bundle=out/'merged-branches.bundle';subprocess.run(['git','bundle','create',str(bundle),*[x['Name'] for x in selected]],check=True,stdout=subprocess.DEVNULL)
subprocess.run(['git','bundle','verify',str(bundle)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
plan={'Main':base,'Delete':selected,'Keep':kept,'OpenPullRequests':[],'Rulesets':[],'Archive':str(bundle),'ArchiveSha256':hashlib.sha256(bundle.read_bytes()).hexdigest().upper(),'VerifiedBundle':True}
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps(plan),flush=True)
command=['git','push','--atomic',*[f"--force-with-lease=refs/heads/{x['Name']}:{x['Sha256Commit']}" for x in selected],'origin',*[':refs/heads/'+x['Name'] for x in selected]]
done=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(out/'remote-delete.log').write_text(done.stdout);assert done.returncode==0,done.stdout
subprocess.run(['git','branch','-d','--',*[x['Name'] for x in selected]],check=True,stdout=subprocess.DEVNULL)
remote=git('ls-remote','--heads','origin');assert all('refs/heads/'+x['Name']+'\n' not in remote+'\n' for x in selected)
(out/'completion.json').write_text(json.dumps({'Passed':True,'DeletedRemoteAndLocal':selected,'Kept':kept,'Main':base,'BundleVerified':True,'RemoteLeasesEnforced':True},indent=2)+'\n');print('Deleted merged branches:',len(selected))
