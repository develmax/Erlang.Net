from pathlib import Path
import hashlib,json
r=Path.cwd();candidate=r/'artifacts/library453-independent-review/test-candidate';target=r/'tests/Erlang.Tests';accepted={}
for p in sorted(candidate.glob('*.cs')):
 data=p.read_bytes();accepted[p.name]=hashlib.sha256(data).hexdigest().upper();destination=target/p.name;assert not destination.exists();destination.write_bytes(data)
out=target/'Resources/ReUnicodeOriginal453';assert not out.exists();out.mkdir()
sources={'worker.erl':r/'artifacts/library453-re-unicode-original/beam_re_unicode453.erl','worker.beam':r/'artifacts/library453-re-original-run1/ebin/beam_re_unicode453.beam','values.etf':r/'artifacts/library453-re-original-run1/values.etf','stacks.etf':r/'artifacts/library453-re-original-run1/stacks.etf'}
for name,p in sources.items():(out/name).write_bytes(p.read_bytes())
(out/'manifest.json').write_text(json.dumps({name:hashlib.sha256(p.read_bytes()).hexdigest().upper() for name,p in sources.items()},indent=2)+'\n')
p=target/'RegexThreeOriginal413Checks.cs';data=p.read_bytes();assert data.count(b'private static async Task<ProcessRuntime> Start(')==1;p.write_bytes(data.replace(b'private static async Task<ProcessRuntime> Start(',b'internal static async Task<ProcessRuntime> Start('))
p=target/'Erlang.Tests.csproj';data=p.read_bytes();suffix=b'\r\n<ItemGroup><EmbeddedResource Include="Resources/ReUnicodeOriginal453/*" LogicalName="Erlang.Tests.ReUnicodeOriginal453.%(Filename)%(Extension)" /></ItemGroup>\r\n';assert data.count(b'</Project>')==1;p.write_bytes(data.replace(b'</Project>',suffix+b'</Project>'))
p=target/'Program.cs';data=p.read_bytes();needle=b'Test(Erlang.Tests.RegexThreeOriginal413Names.Test, Erlang.Tests.RegexThreeOriginal413Checks.Whole);\n';assert data.count(needle)==1;p.write_bytes(data.replace(needle,needle+b'Test(Erlang.Tests.ReUnicodeOriginal453Names.Test, Erlang.Tests.ReUnicodeOriginal453Checks.Whole);\nTest(Erlang.Tests.ReUnicodeOriginal453Names.RefusalTest, Erlang.Tests.ReUnicodeTrap453OwnerHostChecks.Run);\n'))
(r/'artifacts/library453-regex-integration.json').write_text(json.dumps({'CandidateHashes':accepted,'FixtureSource':{k:str(v.relative_to(r)) for k,v in sources.items()},'Parent': 'b161ea9b421d71673f7d9550b2de9426c38dbd06','NoExpectedValuesGeneratedBySdk':True},indent=2)+'\n');print('Integrated original210 and owner-refusal test candidates')
