from pathlib import Path
r=Path.cwd();source=(r/'artifacts/library453-run-kernel-probe1.py').read_text().replace('library453-kernel-run1','library453-kernel-run2');(r/'artifacts/library453-run-kernel-probe2.py').write_bytes(source.encode())
