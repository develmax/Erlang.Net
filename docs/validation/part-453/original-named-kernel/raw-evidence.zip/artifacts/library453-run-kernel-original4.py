from pathlib import Path
import importlib.util,json,os,hashlib
r=Path.cwd();out=r/'artifacts/library453-kernel-original-run4';assert not out.exists();out.mkdir();ebin=out/'ebin';ebin.mkdir()
a=json.loads((r/'artifacts/library376-official-compiler/official-admission.json').read_bytes());installed=Path(a['InstalledOtpRoot']);assert a['SourceCommit']=='ad05823719d77c8faee87348ea39513d4e2f99c5'
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
inventory=load('inventory453final',r/'artifacts/library426-trace-low-memory-original-proposal1/bounded_inventory.py')
owned=load('owned453finalkernel',r/'artifacts/spawn-priority351-preparation/execute-root.py')
expected={x['Path']:x['Sha256'] for x in json.loads(Path(a['ExecutionManifestPath']).read_bytes())}
assert len(expected)==6427 and inventory.inventory(installed)==expected
(out/'provider-before.json').write_bytes((json.dumps(expected,indent=2)+'\n').encode())
passed=False
try:
 owned.owned([str(installed/'bin/erlc.exe'),'+deterministic','-o',str(ebin),str(r/'artifacts/library453-kernel-original/beam_kernel_boot453.erl')],out,'compile',90,dict(os.environ),str(r))
 expression='ok=file:write_file("values.etf",term_to_binary(beam_kernel_boot453:run())),ok=file:write_file("stacks.etf",term_to_binary(beam_kernel_boot453:run_stacks())),halt().'
 owned.owned([str(installed/'bin/erl.exe'),'+S','1:1','-noshell','-noinput','-sname','managed453@localhost','-setcookie','kernel453_cookie','-dist_listen','false','-no_epmd','-proto_dist','inet_tcp','-pa',str(ebin),'-eval',expression],out,'original',90,dict(os.environ),str(out))
 for file in ['ebin/beam_kernel_boot453.beam','values.etf','stacks.etf']:
  assert (out/file).read_bytes()==(r/'artifacts/library453-kernel-original-run3'/file).read_bytes(),file
 passed=True
finally:
 after=inventory.inventory(installed);unchanged=after==expected
 (out/'provider-after.json').write_bytes((json.dumps(after,indent=2)+'\n').encode())
 files={str(p.relative_to(r)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest().upper() for p in [r/'artifacts/library453-kernel-original/beam_kernel_boot453.erl',out/'ebin/beam_kernel_boot453.beam',out/'values.etf',out/'stacks.etf'] if p.exists()}
 (out/'completion.json').write_bytes((json.dumps({'Passed':passed and unchanged,'PinnedCommit':a['SourceCommit'],'ProviderFiles':len(expected),'ProviderBeforeAfterEqual':unchanged,'Cases':24,'WholeRows':144,'NoListener':True,'Epmd':False,'ExactRepeatOfRun3':passed,'Bindings':files},indent=2)+'\n').encode())
assert passed and unchanged
