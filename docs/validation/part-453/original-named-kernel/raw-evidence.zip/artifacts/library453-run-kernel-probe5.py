from pathlib import Path
import importlib.util,os
r=Path.cwd();out=r/'artifacts/library453-kernel-run5';assert not out.exists();out.mkdir()
p=r/'artifacts/spawn-priority351-preparation/execute-root.py';s=importlib.util.spec_from_file_location('owned453api',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
env=dict(os.environ,DOTNET_PROCESSOR_COUNT='1',DOTNET_GCConserveMemory='9',MSBUILDDISABLENODEREUSE='1')
m.owned(['C:/Program Files/dotnet/dotnet.exe','artifacts/library453-kernel-probe/bin/Debug/net10.0/Probe.dll',str(r),str(r/'artifacts/library376-official-compiler/official-admission.json'),str(out/'observations')],out,'probe',120,env,str(r))
