from pathlib import Path
r=Path.cwd();p=r/'artifacts/library453-kernel-probe/Program.cs';s=p.read_text()
s=s.replace('"-dist_listen", "false", "-no_epmd"]','"-dist_listen", "false", "-no_epmd", "-proto_dist", "inet_tcp"]')
s=s.replace('args[3] == "startup"','args[3] is "startup" or "kernel-observe"')
needle='    Save("completion.json", new { Passed = true });'
insert='''    if (args.Length > 3 && args[3] == "kernel-observe")
    {
        string original = args[4];
        await runtime.InitializeModulesAsync(registry =>
        {
            using var imports = tests.GetManifestResourceStream("Erlang.Tests.StandardBootOriginal412.dependencies.json")!;
            string[] modules = JsonSerializer.Deserialize<string[]>(imports)!;
            PreparedBeamImage image = registry.PrepareBeam(File.ReadAllBytes(Path.Combine(original, "ebin/beam_kernel_boot453.beam")), new BeamDependencySelection(modules.Append("beam_kernel_boot453")));
            if (registry.PublishPreparedBeam(image).Status != BeamPublicationStatus.Published)
                throw new InvalidOperationException("Observer publication failed");
        });
        var rows = new List<object>();
        foreach (string route in new[] { "run", "run_stacks" })
        {
            var captured = new TaskCompletionSource<Term>(TaskCreationOptions.RunContinuationsAsynchronously);
            ProcessHandle observer = runtime.Spawn(async context =>
            {
                try { captured.TrySetResult(await owner.Modules.Call(context, "beam_kernel_boot453", route)); }
                catch (Exception error) { captured.TrySetException(error); }
                return Nil.Value;
            });
            Term actual = await captured.Task.WaitAsync(TimeSpan.FromSeconds(45));
            await observer.Completion.WaitAsync(TimeSpan.FromSeconds(10));
            string file = route == "run" ? "values.etf" : "stacks.etf";
            File.WriteAllBytes(Path.Combine(output,"actual-"+file), ExternalTermFormat.Encode(actual));
            Term expected = ExternalTermFormat.Decode(File.ReadAllBytes(Path.Combine(original,file)));
            Term[] expectedProfiles = route == "run" ? [expected] : Cons.Items(expected).Cast<TupleTerm>().Select(x=>x.Items[1]).ToArray();
            Term[] actualProfiles = route == "run" ? [actual] : Cons.Items(actual).Cast<TupleTerm>().Select(x=>x.Items[1]).ToArray();
            if (expectedProfiles.Length != actualProfiles.Length) throw new InvalidOperationException("Missing profiles");
            for (int profile=0;profile<expectedProfiles.Length;profile++)
            {
                Term[] er = Cons.Items(expectedProfiles[profile]).ToArray(), ar = Cons.Items(actualProfiles[profile]).ToArray();
                if (er.Length != 24 || ar.Length != 24) throw new InvalidOperationException("Missing rows");
                for (int index=0;index<er.Length;index++)
                    rows.Add(new { Route=route,Profile=profile,Index=index,Passed=er[index].Equals(ar[index]) && ExternalTermFormat.Encode(er[index]).AsSpan().SequenceEqual(ExternalTermFormat.Encode(ar[index])),Expected=er[index].ToString(),Actual=ar[index].ToString() });
            }
        }
        bool passed = rows.Count == 144 && rows.All(x=>(bool)x.GetType().GetProperty("Passed")!.GetValue(x)!);
        Save("comparison.json",new { Passed=passed,Examined=rows.Count,Comparisons=rows });
        if (!passed) throw new InvalidOperationException("Original kernel comparison differs");
    }
'''
assert needle in s;s=s.replace(needle,insert+needle);p.write_bytes(s.encode())
p=r/'artifacts/library453-run-kernel-probe12.py';s=p.read_text().replace('library453-kernel-run12','library453-kernel-run13').replace("'startup']","'kernel-observe',str(r/'artifacts/library453-kernel-original-run3')]")
(r/'artifacts/library453-run-kernel-probe13.py').write_bytes(s.encode())
