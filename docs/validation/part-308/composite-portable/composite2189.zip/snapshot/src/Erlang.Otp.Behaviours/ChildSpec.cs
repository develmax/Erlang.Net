using System.Diagnostics;

namespace Erlang.Otp;

public sealed record ChildSpec(
    Term Id,
    Func<ProcessContext, ValueTask<ProcessHandle>> Start,
    RestartPolicy Restart = RestartPolicy.Permanent,
    TimeSpan? Shutdown = null,
    Func<ProcessContext, ValueTask<ProcessHandle?>>? OptionalStart = null,
    Term? Type = null,
    Term? Modules = null,
    bool InfiniteShutdown = false,
    bool BrutalKill = false
)
{
    public bool Significant { get; init; }
    internal Func<ProcessContext, ValueTask<Term>>? StartResult { get; init; }
    internal Term? StartMfa { get; init; }
}
