namespace Erlang;

public enum DistributionPendingState
{
    Idle,
    Pending,
    Closed,
    Connected,
    Exiting
}
