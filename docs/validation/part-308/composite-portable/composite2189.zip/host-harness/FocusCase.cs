using System.Text.Json;

public sealed record FocusCase(
    string Name,
    string Type,
    string Method,
    JsonElement[] Arguments
);
