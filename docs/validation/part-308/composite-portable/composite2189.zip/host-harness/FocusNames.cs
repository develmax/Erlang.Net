internal static class FocusNames
{
    internal const string Passed = "PASS ";
    internal const string Failed = "FAIL ";
    internal const string ErrorSeparator = ": ";
    internal const string Arguments = "Expected test DLL, case plan and fresh report path.";
    internal const string InvalidPlan = "Invalid or empty reviewed focus plan.";
    internal const string UnknownArgument = "Unsupported reviewed focus argument.";
    internal const string NonTask = "Focused HOST must return Task.";
    internal const string Nonzero = "Focused HOST returned a nonzero result.";
    internal const string TestNamespace = "Erlang.Tests.";
    internal const int ArgumentCount = 3;
    internal static readonly TimeSpan PerCaseDeadline = TimeSpan.FromSeconds(30);
}
