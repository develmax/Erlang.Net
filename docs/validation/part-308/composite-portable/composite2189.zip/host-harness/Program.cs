using System.Diagnostics;
using System.Reflection;
using System.Runtime.Loader;
using System.Text.Json;

if (args.Length != FocusNames.ArgumentCount)
    throw new ArgumentException(FocusNames.Arguments);
string testPath = Path.GetFullPath(args[0]);
string report = Path.GetFullPath(args[2]);
if (File.Exists(report))
    throw new InvalidOperationException(FocusNames.InvalidPlan);
if (args[1] == "--case-source-inventory")
{
    var inventoryResolver = new AssemblyDependencyResolver(testPath);
    AssemblyLoadContext.Default.Resolving += (context, name) => inventoryResolver.ResolveAssemblyToPath(name) is { } dependency
        ? context.LoadFromAssemblyPath(dependency)
        : null;
    _ = AssemblyLoadContext.Default.LoadFromAssemblyPath(testPath);
    Assembly differential = AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.Combine(Path.GetDirectoryName(testPath)!, "Erlang.Differential.dll"));
    Type catalog = differential.GetType("Erlang.Differential.CompiledModuleCases", true)!;
    var sourceCases = (System.Collections.IEnumerable)catalog.GetProperty("All")!.GetValue(null)!;
    var inventory = new List<object>();
    foreach (object fixture in sourceCases)
    {
        Type type = fixture.GetType();
        string name = (string)type.GetProperty("Name")!.GetValue(fixture)!;
        string source = (string)type.GetProperty("Source")!.GetValue(fixture)!;
        byte[] bytes = System.Text.Encoding.UTF8.GetBytes(source.Replace("\r\n", "\n"));
        inventory.Add(new
        {
            Name = name,
            SourceSha256 = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(bytes)),
            Expected = name.StartsWith("erlang-load-nif-indirect-", StringComparison.Ordinal)
                ? type.GetProperty("Expected")!.GetValue(fixture)!.ToString()
                : null
        });
    }
    await File.WriteAllTextAsync(report, JsonSerializer.Serialize(inventory, new JsonSerializerOptions { WriteIndented = true }));
    Console.WriteLine("INVENTORY " + inventory.Count);
    return 0;
}
FocusCase[] cases = JsonSerializer.Deserialize<FocusCase[]>(File.ReadAllBytes(args[1]))
    ?? throw new InvalidOperationException(FocusNames.InvalidPlan);
if (cases.Length == 0 || cases.Select(test => test.Name).Distinct(StringComparer.Ordinal).Count() != cases.Length)
    throw new InvalidOperationException(FocusNames.InvalidPlan);
var resolver = new AssemblyDependencyResolver(testPath);
AssemblyLoadContext.Default.Resolving += (context, name) => resolver.ResolveAssemblyToPath(name) is { } dependency
    ? context.LoadFromAssemblyPath(dependency)
    : null;
Assembly assembly = AssemblyLoadContext.Default.LoadFromAssemblyPath(testPath);
var results = new List<FocusResult>();
foreach (FocusCase test in cases)
{
    var watch = Stopwatch.StartNew();
    try
    {
        Type type = assembly.GetType(test.Type, true)!;
        MethodInfo method = type.GetMethods(BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.Public)
            .Single(value => value.Name == test.Method && value.GetParameters().Length == test.Arguments.Length);
        object?[] values = test.Arguments.Select<JsonElement, object?>(value => value.ValueKind switch
        {
            JsonValueKind.String => value.GetString(),
            JsonValueKind.Number => value.GetInt32(),
            _ => throw new InvalidOperationException(FocusNames.UnknownArgument)
        }).ToArray();
        object? returned = await Task.Run(() => method.Invoke(null, values)).WaitAsync(FocusNames.PerCaseDeadline);
        if (returned is not Task invocation)
            throw new InvalidOperationException(FocusNames.NonTask);
        await invocation.WaitAsync(FocusNames.PerCaseDeadline);
        if (invocation is Task<int> exit && exit.Result != 0)
            throw new InvalidOperationException(FocusNames.Nonzero);
        results.Add(new(
            test.Name,
            true,
            watch.ElapsedMilliseconds,
            null
        ));
        Console.WriteLine(FocusNames.Passed + test.Name);
    }
    catch (Exception failure)
    {
        results.Add(new(
            test.Name,
            false,
            watch.ElapsedMilliseconds,
            failure.ToString()
        ));
        Console.Error.WriteLine(FocusNames.Failed + test.Name + FocusNames.ErrorSeparator + failure);
        break;
    }
}
var output = new
{
    Expected = cases.Length,
    Actual = results.Count,
    Passed = results.Count(result => result.Passed),
    Failed = results.Count(result => !result.Passed),
    MainEdited = false,
    NativeExecuted = false,
    OriginalExecuted = false,
    Cases = results
};
await File.WriteAllTextAsync(report, JsonSerializer.Serialize(output, new JsonSerializerOptions { WriteIndented = true }));

return results.Count == cases.Length && results.All(result => result.Passed) ? 0 : 1;
