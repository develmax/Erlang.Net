public sealed record FocusResult(
    string Name,
    bool Passed,
    long Milliseconds,
    string? Error
);
