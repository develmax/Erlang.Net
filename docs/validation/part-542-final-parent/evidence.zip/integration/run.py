from pathlib import Path
import subprocess,json,os
r=Path.cwd();errors=[]
for cfg in ['Debug','Release']:
 command=['py','-3','artifacts/resource542/run542.py','--configuration',cfg,'--label','parent-final-'+cfg.lower()+'141','--names','artifacts/resource542/final-parent-integration/cases.json'];j=subprocess.run(command,env=dict(os.environ,DOTNET_GCConserveMemory='9'))
 if j.returncode:errors.append({'Configuration':cfg,'Exit':j.returncode})
(r/'artifacts/resource542/final-parent-integration/run-summary.json').write_text(json.dumps({'Passed':not errors,'Errors':errors},indent=2));raise SystemExit(1 if errors else 0)
