from pathlib import Path
import json,hashlib,zipfile
r=Path.cwd();base=r/'artifacts/resource542/final-parent-integration';out=r/'docs/validation/part-542-final-parent';out.mkdir(exist_ok=False);profiles=[]
for cfg in ['Debug','Release']:
 unit=json.loads((r/f'artifacts/resource542/parent-final-{cfg.lower()}141/result.json').read_bytes());oracle=json.loads((base/f'original-{cfg.lower()}/completion.json').read_bytes());assert unit['Report']['Passed']==141 and unit['Report']['Failed']==0 and oracle['Passed'] and len(oracle['Equal'])==10 and all(oracle['Equal'].values());profiles.append({'Configuration':cfg,'Cases':141,'RawWholeStacks':6,'RawWholeNonopaqueOutcomes':4,'CleanupCompletedModes':oracle['CleanupCompletedModes'],'OpaqueFunctionIdsCompared':False,'PlanSha256':oracle['InputPlanSha256'],'Assemblies':unit['Assemblies']})
rows=json.loads((base/'source.json').read_bytes())['Rows']
for row in rows:assert hashlib.sha256((r/row['Path']).read_bytes()).hexdigest().upper()==row['Sha256']
meta=r/'artifacts/resource542-parentfinal101-metadata';membership=json.loads((meta/'final-membership.json').read_bytes());assert membership['ExactMembers']==4029
(out/'summary.json').write_text(json.dumps({'Passed':True,'Profiles':profiles,'FrozenSources':101,'SourceRows':rows,'DescriptorSha256':'F3D272E570996A61164E1869CED33542084ABBC6C367F4389F97DDA9A144B06B','ParentCommit':'d97ad11a342a2b5a613c2ce840e11d4540a3b571','ExpectedCatalog':9438,'LocalFull511Claimed':False,'Parent378DifferentCompositionSeparate':True,'Metadata':membership,'FullCiPending':True,'ApiDelta':0,'WholeContractDelta':0},indent=2));files=[]
for prefix,folder in [('integration',base),('metadata',meta),('debug141',r/'artifacts/resource542/parent-final-debug141'),('release141',r/'artifacts/resource542/parent-final-release141')]:
 for p in sorted(folder.rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:files.append((prefix+'/'+p.relative_to(folder).as_posix(),p))
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in files:z.writestr(name,p.read_bytes())
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(files)==len(set(z.namelist()))
 for name,p in files:assert z.read(name)==p.read_bytes()
receipt={'Sha256':hashlib.sha256(archive.read_bytes()).hexdigest().upper(),'Bytes':archive.stat().st_size,'Members':len(files),'EveryMemberVerified':True};(out/'archive.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
