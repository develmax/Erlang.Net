from pathlib import Path
import hashlib
import json
import subprocess

r = Path.cwd()
out = r / 'artifacts/resource542-parentfinal101-metadata/bindings-final1'
out.mkdir(exist_ok=False)
sha = lambda b: hashlib.sha256(b).hexdigest().upper()
changed = set(subprocess.check_output(['git', 'diff', '--name-only', '7f565b5699df157541817b97172a81f760006cc2'], text=True).splitlines())
changed.update(subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], text=True).splitlines())
production = sorted(p for p in changed if p.startswith('src/') and p.endswith('.cs'))
changes = []

def save(path, value):
    p = r / path
    backup = out / 'before' / path
    backup.parent.mkdir(parents=True, exist_ok=True)
    backup.write_bytes(p.read_bytes())
    p.write_bytes((json.dumps(value, indent=2) + '\n').encode())

def actual(path, mode):
    data = (r / path).read_bytes()
    assert mode in ['Raw', 'TextLF', 'BinaryExact']
    return data.replace(b'\r\n', b'\n') if mode == 'TextLF' else data

workflow = r / '.github/workflows/validate.yml'
for name in ['Erlang.NifMapFamily504Observations', 'Erlang.NifMapMaterialized505Observations', 'Erlang.NifMapReentry505Observations']:
    rel = 'tools/Native/' + name + '/source-plan.json'
    p = r / rel
    before = sha(p.read_bytes())
    d = json.loads(p.read_bytes())
    paths = {x['Path'] for x in d['Dependencies']}
    for path in production:
        if path not in paths:
            d['Dependencies'].append(dict(Path=path, HashMode='TextLF', When='managed', Bytes=len(actual(path, 'TextLF')), Sha256=sha(actual(path, 'TextLF'))))
    for row in d['Dependencies']:
        data = actual(row['Path'], row['HashMode'])
        if row['Sha256'] != sha(data):
            assert row['Path'] in changed, (name, row['Path'])
            changes.append(dict(Plan=rel, Path=row['Path'], Before=row['Sha256'], After=sha(data)))
            row['Sha256'] = sha(data)
        if 'Bytes' in row:
            row['Bytes'] = len(data)
    save(rel, d)
    raw = workflow.read_bytes()
    assert raw.count(before.encode()) == 1
    workflow.write_bytes(raw.replace(before.encode(), sha(p.read_bytes()).encode()))

# Current evidence bindings only; historical evidence and correction records stay immutable.
rel = 'docs/native-infrastructure.json'
d = json.loads((r / rel).read_bytes())
for entry in d['Entries']:
    for row in entry['SourceBindings']:
        current = sha((r / row['Path']).read_bytes())
        if row['Sha256'] != current:
            assert row['Path'] in changed or row['Path'].endswith('/source-plan.json'), row['Path']
            changes.append(dict(Plan=rel, Path=row['Path'], Before=row['Sha256'], After=current))
            row['Sha256'] = current
save(rel, d)
for rel in ['docs/mfa-compatibility.json', 'docs/module-readiness.json']:
    d = json.loads((r / rel).read_bytes())
    before_statuses = [(x['Module'], x['Function'], x['Arity'], x['Status']) for x in d.get('Entries', [])]
    rows = d['VerifiedSourceFiles']
    known = {x['Path'] for x in rows}
    for row in rows:
        current = sha((r / row['Path']).read_bytes())
        if current != row['Sha256']:
            assert row['Path'] in changed, (rel, row['Path'])
            row['Sha256'] = current
    for path in production:
        if path not in known:
            rows.append(dict(Path=path, Sha256=sha((r / path).read_bytes())))
    rows.sort(key=lambda x: x['Path'])
    assert len(rows) == len({x['Path'] for x in rows})
    assert before_statuses == [(x['Module'], x['Function'], x['Arity'], x['Status']) for x in d.get('Entries', [])]
    save(rel, d)
(out / 'proof.json').write_text(json.dumps(dict(ProductionClosure=production, Changes=changes, ClassificationsChanged=False, WholeContractsClosed=0), indent=2) + '\n')
print('Refreshed exact current source guards; no classification promotion')
