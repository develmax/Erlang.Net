from pathlib import Path
import ast,json,hashlib,subprocess,shutil
r=Path.cwd();a=r/'artifacts/resource541';sha=lambda b:hashlib.sha256(b).hexdigest().upper();fraw=(a/'final-source-freeze.json').read_bytes();assert sha(fraw)=='72D89FD288DE297ABC8BB486362673A6E708E5EF6AD3C98E0B4FBE05B87949E9';f=json.loads(fraw);assert len(f['Rows'])==76
for row in f['Rows']:assert sha((r/row['Path']).read_bytes())==row['Sha256'],row['Path']
for path,h in [('Directory.Build.props','EDF92768B885A0B9B87D5711536684DDFAC508CBEA79E99D66CAF69C3A8F16D0'),('tests/Erlang.Tests/Erlang.Tests.csproj','7D7972DB8D3496D249AA306649ABD0BDA208E544586E188387991A431EA615FD')]:assert sha((r/path).read_bytes())==h
snap=a/'pre-seal-metadata-snapshot';assert not snap.exists();snap.mkdir();paths=set()
for folder in [r/'tools/Native',r/'tools/Runtime']:
 for p in folder.rglob('*'):
  if p.is_file() and p.name.lower() in ['source-plan.json','source-plan2.json','reviewed-source-plan.json'] and not {'bin','obj'}.intersection(p.parts):paths.add(p.relative_to(r).as_posix())
paths.update(['tools/Runtime/Erlang.OwnedGuest506Observations/seal.py','tools/Native/Erlang.NifPendingVarargsObservations/run-reviewed.py','tools/Native/Erlang.NifPendingVarargsObservations/seal-source-plan.py','.github/workflows/validate.yml','.github/workflows/nif-pending-native.yml','.github/workflows/nif-reallocation-native.yml','docs/mfa-compatibility.json','docs/module-readiness.json','docs/native-infrastructure.json'])
rows=[]
for name in sorted(paths):
 p=r/name;b=p.read_bytes();target=snap/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b);rows.append(dict(Path=name,Sha256=sha(b)))
(snap/'manifest.json').write_text(json.dumps(dict(Files=rows,SourceOnly=True),indent=2)+'\n');(snap/'git-status.txt').write_bytes(subprocess.check_output(['git','status','--porcelain=v1']));(snap/'git-index-diff.txt').write_bytes(subprocess.check_output(['git','diff','--cached','--name-status']))
extra=[row['Path'] for row in f['Rows']]+[p.relative_to(r).as_posix() for p in (r/'tools/Runtime/Erlang.MonitorOriginal645Observations').rglob('*') if p.is_file()]+['docs/validation/part-541/source-freeze.json']
p=r/'tools/Runtime/Erlang.OwnedGuest506Observations/seal.py';s=p.read_text();node=next(n for n in ast.parse(s).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='DEPENDENCIES' for t in n.targets));known=ast.literal_eval(node.value);ordered=known+sorted(set(extra)-set(known));lines=s.splitlines(keepends=True);lines[node.lineno-1:node.end_lineno]=['DEPENDENCIES = [\n'+''.join('    '+repr(x)+',\n' for x in ordered)+']\n'];p.write_bytes(''.join(lines).encode())
template=r.parent/'w504/artifacts/resource540/final-seals540.py';s=template.read_text().replace('resource540','resource541').replace('refresh540','refresh541').replace('plans540','plans541').replace('1a52eaf45b53cefed71465709851576a9a98dbe6','614c8e87e9fa321ef194655cbe190dc8c36db103').replace("'tools/Runtime/Erlang.EtsDispatch540Observations/'", "'tools/Runtime/Erlang.EtsDispatch540Observations/','tools/Runtime/Erlang.MonitorOriginal645Observations/'")
anchor="extra.update(x.relative_to(r).as_posix() for x in (r/'tests/Erlang.Tests/Fixtures/CountersOriginal421Debug').iterdir() if x.is_file())";assert anchor in s;s=s.replace(anchor,anchor+"\nextra.add('docs/validation/part-541/source-freeze.json')")
(a/'final-seals541.py').write_text(s,encoding='utf-8',newline='\n');s=(r.parent/'w504/artifacts/resource540/verify-final-membership.py').read_text().replace('resource540','resource541');(a/'verify-final-membership.py').write_text(s,encoding='utf-8',newline='\n');print('Snapshot',len(rows),'metadata inputs; preserved76C#/XML; enrolled current source/tool/freeze only')
