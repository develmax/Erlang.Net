from pathlib import Path
import subprocess,json,hashlib
r=Path.cwd();a=r/'artifacts/resource541-metadata';paths=json.loads((a/'changed-metadata-paths.json').read_bytes());assert len(paths)==18 and all(not p.endswith('.cs') and not p.startswith(('src/','tests/','docs/validation/')) for p in paths);before_index=subprocess.check_output(['git','diff','--cached','--name-only'],text=True).splitlines();aligned=[]
for offset in range(0,len(paths),30):subprocess.run(['git','add','--',*paths[offset:offset+30]],check=True)
for path in paths:
 p=r/path;working=p.read_bytes();index=subprocess.check_output(['git','show',':'+path])
 if working!=index:
  assert not path.startswith('tools/'),('Protected tool metadata differs',path)
  assert working.replace(b'\r\n',b'\n')==index.replace(b'\r\n',b'\n'),path
  p.write_bytes(index);aligned.append(path)
 assert p.read_bytes()==index,path
sha=lambda b:hashlib.sha256(b).hexdigest().upper()
for row in json.loads((r/'artifacts/resource541/final-source-freeze.json').read_bytes())['Rows']:assert sha((r/row['Path']).read_bytes())==row['Sha256'],row['Path']
proof=dict(SourceOnly=True,RuntimeBuildOrVmExecuted=False,Paths=paths,MetadataStaged=len(paths),AllMetadataIndexBytesEqual=True,MetadataEolAlignmentOnly=aligned,FrozenCSharpPreserved=76,RootFullCommitIndexAuditStillRequired=True,PriorStagedPaths=before_index)
(a/'metadata-index-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print('18 metadata paths staged/raw-equal;76C# preserved; root fullindex audit remains')
