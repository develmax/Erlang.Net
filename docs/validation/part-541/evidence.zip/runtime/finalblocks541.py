from pathlib import Path
import hashlib
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
repo = Path.cwd()
root = repo / 'artifacts/resource541'
output = root / 'final-blocks'
output.mkdir(exist_ok=False)
spec = importlib.util.spec_from_file_location('owned541', repo / 'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py')
owned = importlib.util.module_from_spec(spec)
spec.loader.exec_module(owned)
freeze_bytes = (root / 'final-source-freeze.json').read_bytes()
freeze = json.loads(freeze_bytes)
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest().upper()

def check_source():
    assert (root / 'final-source-freeze.json').read_bytes() == freeze_bytes
    for row in freeze['Rows']:
        assert digest(repo / row['Path']) == row['Sha256'], row['Path']

blocks = ['resource-a140.names.json', 'resource-b140.names.json', 'reader19.names.json', 'lifecycle-selected.json', 'new33.json']
profiles = []
check_source()
for configuration in ['Debug', 'Release']:
    seen = set()
    identity = None
    rows = []
    for index, block in enumerate(blocks):
        check_source()
        label = 'final-' + configuration.lower() + '-' + str(index)
        names = json.loads((root / block).read_bytes())
        assert not seen.intersection(names)
        seen.update(names)
        cmd = [sys.executable, str(root / 'run541.py'), '--label', label, '--names', str(root / block), '--configuration', configuration]
        owned.owned(cmd, output, label, 240, dict(os.environ, PYTHONDONTWRITEBYTECODE='1'), str(repo))
        result = json.loads((root / label / 'result.json').read_bytes())
        if identity is None:
            identity = result['Assemblies']
        assert result['Assemblies'] == identity
        check_source()
        rows.append(dict(Label=label, Names=names, ElapsedSeconds=result['Receipt']['ElapsedSeconds']))
        print(json.dumps(dict(Profile=configuration, Block=block, Passed=len(names), Cumulative=len(seen))), flush=True)
    assert len(seen) == 370 and seen == set(json.loads((root / 'all370.json').read_bytes()))
    profiles.append(dict(Configuration=configuration, Assemblies=identity, DistinctCases=370, Blocks=rows))
check_source()
(output / 'completion.json').write_text(json.dumps(dict(Passed=True, Profiles=profiles, ExplicitDisjointComposite=True, Single370Run=False, SourceFreezeSha256=hashlib.sha256(freeze_bytes).hexdigest().upper()), indent=2), encoding='utf-8')
print('Final affected composites: Debug370/370 and Release370/370', flush=True)
