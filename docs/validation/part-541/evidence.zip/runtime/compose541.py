import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PACKETS = ROOT.parent / 'Erlang.Net' / 'artifacts'
OUT = Path(__file__).resolve().parent / 'composition'
state = {}
original = {}
receipts = []

def sha(data):
    return hashlib.sha256(data).hexdigest().upper()

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def current(path):
    if path not in state:
        target = ROOT / path
        original[path] = target.read_bytes() if target.exists() else None
        state[path] = original[path]
    return state[path]

def check_files(folder, manifest):
    files = manifest.get('Files', {})
    rows = files.items() if isinstance(files, dict) else ((r['Path'], r['Sha256']) for r in files)
    for name, expected in rows:
        assert sha((folder / name).read_bytes()) == expected.upper(), ('packet corruption', name)

def hunks(rows):
    for row in rows:
        path = row['Path']
        data = current(path)
        assert data is not None, ('missing hunk target', path)
        before_hash = row.get('BeforePreparedPayloadSha256', row.get('BeforeSha256'))
        if before_hash:
            assert sha(data) == before_hash.upper(), ('hunk before hash', path, sha(data), before_hash)
        text = data.decode('utf-8')
        patches = row.get('Hunks', [row])
        for hunk in patches:
            before = hunk.get('BeforeText', hunk.get('Before'))
            after = hunk.get('AfterText', hunk.get('After'))
            assert text.count(before) == 1, ('nonunique hunk', path, text.count(before), before[:120])
            text = text.replace(before, after, 1)
        data = text.encode('utf-8')
        if row.get('AfterSha256'):
            assert sha(data) == row['AfterSha256'].upper(), ('hunk after hash', path, sha(data), row['AfterSha256'])
        state[path] = data

def packet(name, shared=None, registration=False):
    folder = PACKETS / name
    manifest = read(folder / 'manifest.json')
    check_files(folder, manifest)
    shared_rows = read(folder / shared) if shared else []
    shared_paths = {row['Path'] for row in shared_rows}
    for target in manifest.get('Targets', []):
        path = target['Path']
        if path in shared_paths:
            continue
        data = current(path)
        if target.get('MustBeAbsent', target.get('Absent', False)):
            assert data is None, ('expected absent', path)
        else:
            expected = target.get('BeforePreparedPayloadSha256', target.get('BeforeSha256'))
            if expected:
                assert data is not None and sha(data) == expected.upper(), ('target before', path, sha(data) if data else None, expected)
        payload = (folder / target['Payload']).read_bytes()
        assert sha(payload) == target['AfterSha256'].upper(), ('target after', path)
        state[path] = payload
    if shared:
        hunks(shared_rows)
    if registration:
        # Multiple independent hunks in the same base file share a base digest.
        rows = read(folder / 'runtime-registration-hunks.json')
        for path in {r['Path'] for r in rows}:
            assert sha(current(path)) == next(r['BeforeSha256'] for r in rows if r['Path'] == path)
        hunks([{k:v for k,v in row.items() if k != 'BeforeSha256'} for row in rows])
    receipts.append({'Packet': name, 'ManifestSha256': sha((folder / 'manifest.json').read_bytes())})

for suffix in ['shared-core', 'core-rollback-context-amendment', 'reserve-capture-amendment', 'context-failure-amendment', 'queue-stop-amendment', 'context-admission-amendment']:
    packet('batch641/process-payload-' + suffix)
packet('batch642/vm-source-root-reason-controls', registration=True)
packet('batch642/vm-root-rooted-inputs-amendment')
packet('batch642/vm-root-internal-dispatch-amendment')
packet('batch641/monitor-origin538', shared='shared-hunks.json')
packet('batch641/monitor-reason-envelope-amendment', shared='shared-hunks.json')

folder = ROOT.parent / 'artifacts/batch642/port-reason641'
manifest = read(folder / 'manifest.json')
check_files(folder, manifest)
for target in read(folder / 'composition.json')['Targets']:
    path = target['Path']
    assert sha(current(path)) == target['BeforeSha256'], ('port before', path)
    data = (folder / 'after' / path).read_bytes()
    assert sha(data) == target['AfterSha256'], ('port after', path)
    state[path] = data
receipts.append({'Packet':'port-reason641','ManifestSha256':sha((folder/'manifest.json').read_bytes())})
packet('batch643/local-reason-ingress-v7', shared='shared-hunks.json')

OUT.mkdir(parents=True, exist_ok=False)
targets = []
for path, data in state.items():
    if data == original[path]:
        continue
    destination = OUT / 'after' / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)
    if original[path] is not None:
        saved = OUT / 'before' / path
        saved.parent.mkdir(parents=True, exist_ok=True)
        saved.write_bytes(original[path])
    targets.append({'Path':path,'BeforeSha256':sha(original[path]) if original[path] is not None else None,'AfterSha256':sha(data)})
(OUT/'receipt.json').write_text(json.dumps({'Packets':receipts,'Targets':targets}, indent=2), encoding='utf-8')
print(json.dumps({'PreparedFiles':len(targets),'Packets':len(receipts),'ReceiptSha256':sha((OUT/'receipt.json').read_bytes())}))
