from pathlib import Path
import json,hashlib,subprocess,shutil,importlib.util,os
r=Path.cwd();out=r/'artifacts/resource543/parent689-integration/final162-build';out.mkdir(exist_ok=False)
for n in ['src','tools','tests','examples','benchmarks']:(out/n).mkdir()
f=r/'artifacts/resource543/parent689-integration/source162-final.json';v=json.loads(f.read_bytes());pairs=[]
for row in v['Rows']:
 p=r/row['Path'];assert hashlib.sha256(p.read_bytes()).hexdigest().upper()==row['Sha256'];a=out/'before'/row['Path'];b=out/row['Path'];a.parent.mkdir(parents=True,exist_ok=True);b.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,a);shutil.copyfile(p,b);pairs.append({'Path':row['Path'],'Before':str(a),'After':str(b)})
(out/'pairs.json').write_text(json.dumps(pairs,indent=2));subprocess.run(['dotnet','exec','--fx-version','10.0.11',str(r.parent/'w518repair/tools/Build/Erlang.Style/bin/Release/net10.0/Erlang.Style.dll'),'--write',str(out)],check=True);subprocess.run(['dotnet','exec','--fx-version','10.0.11',str(r.parent/'w518repair/artifacts/ci93-four/token-proof/bin/Release/net10.0/TokenProof.dll'),str(out/'pairs.json'),str(out/'token-proof.json')],check=True)
changed=[x['Path'] for x in v['Rows'] if (r/x['Path']).read_bytes()!=(out/x['Path']).read_bytes()];assert not changed,{'UnexpectedStyleChangesRequireSealReview':changed}
s=importlib.util.spec_from_file_location('owned',r/'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);results=[]
for cfg in ['Release','Debug']:
 for label,project in [('native','tools/Native/Erlang.NifNativeBackend/Erlang.NifNativeBackend.csproj'),('tests','tests/Erlang.Tests/Erlang.Tests.csproj')]:
  x=m.owned(['dotnet','build',project,'-c',cfg,'--no-restore','-m:1','-p:UseSharedCompilation=false','-p:BuildInParallel=false','-v:q'],out,'build-'+cfg+'-'+label,240,dict(os.environ,DOTNET_PROCESSOR_COUNT='1',DOTNET_GCConserveMemory='9',PYTHONDONTWRITEBYTECODE='1'),str(r));results.append({'Profile':cfg,'Project':label,'Seconds':x['ElapsedSeconds']});print(json.dumps(results[-1]),flush=True)
 for row in v['Rows']:assert hashlib.sha256((r/row['Path']).read_bytes()).hexdigest().upper()==row['Sha256']
(out/'completion.json').write_text(json.dumps({'Passed':True,'Source162Sha256':hashlib.sha256(f.read_bytes()).hexdigest().upper(),'Rows':results},indent=2))

for cfg in ['Release','Debug']:
 a=r/f'tools/Native/Erlang.NifNativeBackend/bin/{cfg}/net10.0';b=r/f'tests/Erlang.Tests/bin/{cfg}/net10.0';common={p.name for p in a.glob('*.dll')} & {p.name for p in b.glob('*.dll')};assert 'Erlang.NifNativeBackend.dll' in common;assert all(hashlib.sha256((a/n).read_bytes()).digest()==hashlib.sha256((b/n).read_bytes()).digest() for n in common);(out/(cfg+'-copied-dependencies.json')).write_text(json.dumps(dict(Compared=sorted(common),AllRawHashesEqual=True),indent=2));print(cfg+' copied native backend/dependencies verified',flush=True)
