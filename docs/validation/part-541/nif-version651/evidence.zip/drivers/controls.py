from pathlib import Path
import hashlib
import importlib.util
import json
import os
import sys

r = Path.cwd()
profile, label = sys.argv[1:]
out = r / 'artifacts/resource543' / label
out.mkdir(exist_ok=False)
fbytes = (r / 'artifacts/resource543/source-freeze.json').read_bytes()
rows = json.loads(fbytes)['Rows']
def guard():
    assert (r / 'artifacts/resource543/source-freeze.json').read_bytes() == fbytes
    for row in rows:
        assert hashlib.sha256((r / row['Path']).read_bytes()).hexdigest().upper() == row['Sha256']
host = r / f'tools/Native/Erlang.NifNativeBackend/bin/{profile}/net10.0/Erlang.NifNativeBackend.dll'
def inventory():
    return {p.name: hashlib.sha256(p.read_bytes()).hexdigest().upper() for p in host.parent.iterdir() if p.is_file() and (p.suffix == '.dll' or p.name.endswith(('.deps.json', '.runtimeconfig.json')))}
before = inventory()
guard()
spec = importlib.util.spec_from_file_location('owned', r / 'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py')
owned = importlib.util.module_from_spec(spec)
spec.loader.exec_module(owned)
receipts, errors = [], []
for name, args in [('base-and-version36', []), ('load-reason', ['--managed-load-reason-controls']), ('filename', ['--managed-filename-controls']), ('default-routes', ['--managed-default-routes'])]:
    try:
        receipt = owned.owned(['dotnet', 'exec', '--fx-version', '10.0.11', str(host), *args], out, name, 180, dict(os.environ, DOTNET_PROCESSOR_COUNT='2', DOTNET_GCConserveMemory='9'), str(r))
        receipts.append({'Name': name, 'Receipt': receipt})
    except Exception as error:
        errors.append({'Name': name, 'Error': repr(error)})
guard()
assert inventory() == before
result = {'Passed': not errors and len(receipts) == 4, 'Configuration': profile, 'ManagedGroups': receipts, 'NewVersionedPrefixControls': 36, 'DllAndConfig': before, 'Errors': errors, 'NativeNifOrOriginalExecutedByThisCheck': False}
(out / 'completion.json').write_text(json.dumps(result, indent=2))
print(json.dumps({'Passed': result['Passed'], 'ManagedGroups': len(receipts), 'Errors': errors}))
raise SystemExit(0 if result['Passed'] else 1)
