from pathlib import Path
import hashlib,json,os,importlib.util
r=Path.cwd();out=r/'artifacts/resource543/parent689-integration/release-red';out.mkdir(exist_ok=False)
v=json.loads((r.parent/'artifacts/batch689/n1-ff-integration/prospective161.json').read_bytes());rows=[{'Path':x['Path'],'Sha256':x['Sha256']} for x in v['Rows']];assert len(rows)==161
for x in rows:assert hashlib.sha256((r/x['Path']).read_bytes()).hexdigest().upper()==x['Sha256'],x['Path']
f=out/'source161.json';f.write_text(json.dumps({'Parent':'4de41c4fafce7ebcbd2cde41e53fa46bdf6ebd53','Accepted':False,'ModuleDisplayRedCandidate':True,'Rows':rows},indent=2))
s=importlib.util.spec_from_file_location('owned',r/'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
x=m.owned(['dotnet','build','tools/Native/Erlang.NifNativeBackend/Erlang.NifNativeBackend.csproj','-c','Release','-m:1','-p:UseSharedCompilation=false','-p:BuildInParallel=false','-v:q'],out,'build',240,dict(os.environ,DOTNET_PROCESSOR_COUNT='1',DOTNET_GCConserveMemory='9',PYTHONDONTWRITEBYTECODE='1'),str(r))
for row in rows:assert hashlib.sha256((r/row['Path']).read_bytes()).hexdigest().upper()==row['Sha256']
print(json.dumps({'ReleaseRedCandidateBuildPassed':True,'Seconds':x['ElapsedSeconds'],'BoundCSharp':161}))
