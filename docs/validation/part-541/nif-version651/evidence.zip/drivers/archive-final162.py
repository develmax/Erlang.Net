from pathlib import Path
import hashlib,json,zipfile
r=Path.cwd();base=r/'artifacts/resource543/parent689-integration';out=r/'docs/validation/part-541/nif-version651';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
freeze=r/'docs/validation/part-542-owned-correction/current-source-freeze-nif543.json';rows=json.loads(freeze.read_bytes())['Rows'];assert len(rows)==162
for x in rows:assert sha(r/x['Path'])==x['Sha256']
affected=json.loads((base/'affected639/completion.json').read_bytes());assert affected['Passed'] and not affected['Errors'] and affected['AcceptedTargetPerProfile']==639
for cfg in ['Release','Debug']:
 rr=[x for x in affected['Rows'] if x['Profile']==cfg];assert len(rr)==9 and sum(x['Passed'] for x in rr)==633 and not any(x['Failed'] for x in rr)
 raw=json.loads((base/f'affected639/original-{cfg}/completion.json').read_bytes());assert raw['Passed'] and len(raw['Equal'])==10 and all(raw['Equal'].values()) and len(raw['CleanupCompletedModes'])==6
 v=json.loads((r/f'artifacts/nif-version651/final162-{cfg}/completion.json').read_bytes());assert v['Passed'] and not v['Errors'] and len(v['Rows'])==42
 assert sum(sum(a['WholeTypedEquality'] and a['RawByteEquality'] for a in x['Comparisons'].values()) for x in v['Rows'])==84
 module=v['ModuleText690'];assert module['Passed'] and module['Count']==4 and len(module['Rows'])==4 and not module['Errors'];assert sum(sum(a['WholeTypedEquality'] and a['RawByteEquality'] for a in x['Comparisons'].values()) for x in module['Rows'])==8
 assert json.loads((r/f'artifacts/resource543/final162-controls-{cfg}/completion.json').read_bytes())['Passed']
 for name,h in json.loads((base/f'affected639/{cfg}/assemblies.json').read_bytes()).items():assert sha(r/f'tests/Erlang.Tests/bin/{cfg}/net10.0'/name)==h
c=json.loads((base/'counters610-fresh/completion.json').read_bytes());assert c['Passed'] and c['AdoptionPassed'] and c['CompletedManagedRoutes']==2 and all(x['Passed'] for x in c['ManagedRuns'])
meta=r/'artifacts/resource543-standard-metadata';membership=json.loads((meta/'final-membership.json').read_bytes());assert membership['ExactMembers']==4112 and membership['SourceGuards']==2226
native=r/'artifacts/nif-version651/sealed42-build/build-receipt.json';assert sha(native)=='ABA726664BA76456C0666BB228E64FF569FC39C928853A42392BFFB329305228';images=json.loads(native.read_bytes())['Images'];assert len(images)==42
for image in images:assert sha(Path(image['Library']['Path']))==image['Library']['Sha256']
assert sha(r/'.gitattributes')=='C129957CFB388237BD99888EA2AD7F7CD61B4056114D4AB7EFA7F6AA763E4325'
out.mkdir(exist_ok=False);files={}
extensions={'.json','.log','.txt','.py','.ps1','.cs','.csproj','.c','.cpp','.h','.erl','.etf','.stderr','.stdout','.trace','.beam','.md','.yml'}
def add(prefix,folder):
 for p in sorted(folder.rglob('*')):
  if p.is_file() and p.suffix.lower() in extensions and not any(a in p.parts for a in ['bin','obj','__pycache__']):files[prefix+'/'+p.relative_to(folder).as_posix()]=p
add('final-and-recovery',base)
for name in ['final162-Release','final162-Debug','module690-red-01','module690-red-02','module690-red-03','module690-green-01','sealed42-build','byte-text-red42','byte-text-green-debug42','byte-text-green-release42']:add(name,r/'artifacts/nif-version651'/name)
for cfg in ['Release','Debug']:add('managed-controls-'+cfg,r/f'artifacts/resource543/final162-controls-{cfg}')
for n in ['metadata-index-proof.json','preflight-final1.json','early13-after-index.json','final-membership.json','protected-n1-before.json']:files['metadata/'+n]=meta/n
for p in (r/'artifacts/resource543').glob('*.py'):files['drivers/'+p.name]=p
for n in ['batch690/nif-module-rendering538','batch690/project-reference-amendment538','batch690/passive-probe02','batch691/module-latin1-domain-amendment538','batch691/module690-passive-red-green','batch692/compiled-worker-context-amendment538','batch693/module-green-input-amendment538','batch695/module-permanent-integration538']:add('proposals/'+n,r.parent/'artifacts'/n)
for n in ['tools/Native/Erlang.NifVersion651Observations','tools/Native/Erlang.NifNativeBackend']:add('final-tool/'+n,r/n)
for x in rows:files['final-source/'+x['Path']]=r/x['Path']
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(files.items()):z.writestr(name,p.read_bytes())
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(files)==len(set(z.namelist()))
 for name,p in files.items():assert z.read(name)==p.read_bytes()
receipt={'Sha256':sha(archive),'Bytes':archive.stat().st_size,'Members':len(files),'EveryMemberReadbackVerified':True}
summary={'LocalAccepted':True,'Parent':'4de41c4fafce7ebcbd2cde41e53fa46bdf6ebd53','Current162DescriptorSha256':sha(freeze),'NativeCasesPerProfile':42,'WholeNativeComparisonsPerProfile':84,'ModuleCasesPerProfile':4,'WholeModuleComparisonsPerProfile':8,'Profiles':['Release','Debug'],'DistinctAffectedCasesPerProfile':639,'FreshFunctionComparisonsPerProfile':10,'FreshFunctionManagedCleanupPerProfile':6,'FinalRetries':0,'NewNativeBuildsDuringParentAndModuleIntegration':0,'ReusedNativeBuildReceiptSha256':sha(native),'ModuleMeaningfulRed':{'AsciiWholePassed':2,'NonAsciiWholeFailed':6},'ModuleGreenWhole':8,'InitialUnsupportedModuleAndContextAttemptsNotAccepted':True,'SourceGates':8,'EarlyGates':13,'ExactMembers':4112,'SourceGuards':2226,'ExpectedNormalCatalog':9451,'LocalFullSuiteClaimed':False,'Registered':708,'Verified':180,'Pending':504,'KnownDifferences':24,'ApiDelta':0,'FullContractDelta':0,'WholeLoadNifCompatible':False,'AllTlsFunctionsOrCppTlsProven':False,'LinuxFinalHeadAcceptancePending':['native84','module8','callback68','pthread bindings/create/join','ordinary-loader3','cleanup'],'CurrentHeadCiReviewMergePending':True,'Archive':receipt};(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(receipt))
