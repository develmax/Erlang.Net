from pathlib import Path
r=Path.cwd();src=r.parent/'w536/artifacts/parent683-regress.py';p=r/'artifacts/resource543/affected639-final162.py';assert not p.exists();s=src.read_text()
for before,after in [
 ("r/'artifacts/parent683-integration/regress'","r/'artifacts/resource543/parent689-integration/affected639'"),
 ("r/'artifacts/parent683-integration/source145.json'","r/'artifacts/resource543/parent689-integration/source162-final.json'"),
 ("r/'artifacts/resource542/final-parent-integration/cases.json'","r.parent/'w536/artifacts/resource542/final-parent-integration/cases.json'")
]:assert s.count(before)==1;s=s.replace(before,after)
p.write_text(s);print('Prepared633 regression +6 fresh original driver; not executed')
