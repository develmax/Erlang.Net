from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

r = Path.cwd()
freeze = r / 'artifacts/resource543/source-freeze.json'
root = r.parent / 'Erlang.Net'
profile = sys.argv[1]
assert profile in ['Debug', 'Release']
output = r / 'artifacts/nif-version651' / sys.argv[2]
assert not output.exists()
command = [
    sys.executable, str(r / 'tools/Native/Erlang.NifVersion651Observations/collect.py'),
    '--repository', str(r),
    '--official-admission', str(root / 'artifacts/library376-official-compiler/official-admission.json'),
    '--admission-sha256', '41CCC2FDE5493D85BEAA21996E12D0885D2919B0D4BF44137D0673DCDC9D5EA6',
    '--native-build-receipt', str(r / 'artifacts/nif-version651/byte42-build/build-receipt.json'),
    '--approved-native-build-sha256', 'BB6D20219130FB9FBC4E21C9535ABCCCA84983343F8AE0AE182EFFFC72EEE133',
    '--managed-host', str(r / f'tools/Native/Erlang.NifNativeBackend/bin/{profile}/net10.0/Erlang.NifNativeBackend.dll'),
    '--source-freeze', str(freeze),
    '--source-freeze-sha256', hashlib.sha256(freeze.read_bytes()).hexdigest().upper(),
    '--plan-sha256', '74E58B9B21C16A4E3FFA9E9CA0C58D40C4F23D1470550120EEA03ACECC99BC2C',
    '--framework-version', '10.0.11', '--output', str(output),
]
result = subprocess.run(command, env=dict(os.environ, DOTNET_PROCESSOR_COUNT='2', DOTNET_GCConserveMemory='9', PYTHONDONTWRITEBYTECODE='1'))
receipt = output / 'completion.json'
if receipt.is_file():
    value = json.loads(receipt.read_bytes())
    print(json.dumps({'Configuration': profile, 'Passed': value['Passed'], 'OriginalCases': len(value['Rows']), 'EqualWholeTypedAndRawRoutes': sum(sum(v.get('WholeTypedEquality', False) and v.get('RawByteEquality', False) for v in row.get('Comparisons', {}).values()) for row in value['Rows']), 'Errors': value['Errors']}))
raise SystemExit(result.returncode)
