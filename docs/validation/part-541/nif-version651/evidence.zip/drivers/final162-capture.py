from pathlib import Path
import json,hashlib,os,importlib.util
r=Path.cwd();freeze=r/'artifacts/resource543/parent689-integration/source162-final.json';raw=freeze.read_bytes();rows=json.loads(raw)['Rows'];assert len(rows)==162;out=r/'artifacts/resource543/parent689-integration/final162-capture';out.mkdir(exist_ok=False);s=importlib.util.spec_from_file_location('owned',r/'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);errors=[];results=[]
def check():
 assert freeze.read_bytes()==raw
 for x in rows:assert hashlib.sha256((r/x['Path']).read_bytes()).hexdigest().upper()==x['Sha256']
for cfg in ['Release','Debug']:
 check();host=r/f'tools/Native/Erlang.NifNativeBackend/bin/{cfg}/net10.0/Erlang.NifNativeBackend.dll';target=r/'artifacts/nif-version651'/('final162-'+cfg);d=out/cfg;d.mkdir();cmd=['py','-3','-B',str(r/'tools/Native/Erlang.NifVersion651Observations/collect.py'),'--repository',str(r),'--official-admission',str(r.parent/'Erlang.Net/artifacts/library376-official-compiler/official-admission.json'),'--admission-sha256','41CCC2FDE5493D85BEAA21996E12D0885D2919B0D4BF44137D0673DCDC9D5EA6','--native-build-receipt',str(r/'artifacts/nif-version651/sealed42-build/build-receipt.json'),'--approved-native-build-sha256','ABA726664BA76456C0666BB228E64FF569FC39C928853A42392BFFB329305228','--managed-host',str(host),'--source-freeze',str(freeze),'--source-freeze-sha256',hashlib.sha256(raw).hexdigest().upper(),'--plan-sha256','C07A3B6ADE9E6A2D9B1421987E2D3ED8DDF8ABF0182DED8CBFEBA0B4170A2D7A','--framework-version','10.0.11','--output',str(target)]
 try:m.owned(cmd,d,'capture',600,dict(os.environ,DOTNET_PROCESSOR_COUNT='2',DOTNET_GCConserveMemory='9',PYTHONDONTWRITEBYTECODE='1'),str(r))
 except Exception as e:errors.append({'Profile':cfg,'Error':repr(e)})
 if (target/'completion.json').exists():
  v=json.loads((target/'completion.json').read_bytes());module=v.get('ModuleText690');result={'Profile':cfg,'Passed':v.get('Passed'),'BaselineRows':len(v.get('Rows',[])),'BaselineEqual':sum(sum(x.get('WholeTypedEquality',False) and x.get('RawByteEquality',False) for x in row.get('Comparisons',{}).values()) for row in v.get('Rows',[])),'ModuleText690':module,'Errors':v.get('Errors')};results.append(result);print(json.dumps(result)[:14000],flush=True)
 else:errors.append({'Profile':cfg,'MissingCompletion':True})
 check()
(out/'completion.json').write_text(json.dumps({'Passed':not errors and len(results)==2 and all(x['Passed'] for x in results),'Rows':results,'Errors':errors,'SourceFreezeSha256':hashlib.sha256(raw).hexdigest().upper(),'NewNativeBuilds':0},indent=2));raise SystemExit(0 if not errors and len(results)==2 and all(x['Passed'] for x in results) else 1)
