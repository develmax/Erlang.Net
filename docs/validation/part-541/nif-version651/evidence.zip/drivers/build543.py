from pathlib import Path
import os,json,hashlib,importlib.util,sys
r=Path.cwd();out=r/'artifacts/resource543'/sys.argv[1];out.mkdir(exist_ok=False)
f=(r/'artifacts/resource543/source-freeze.json').read_bytes();rows=json.loads(f)['Rows']
for x in rows:assert hashlib.sha256((r/x['Path']).read_bytes()).hexdigest().upper()==x['Sha256']
(out/'source-before.json').write_bytes(f)
s=importlib.util.spec_from_file_location('owner',r/'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
cmd=['dotnet','build','tools/Native/Erlang.NifNativeBackend/Erlang.NifNativeBackend.csproj','-c','Debug','-m:1','-p:UseSharedCompilation=false','-p:BuildInParallel=false','-v:q']
a=m.owned(cmd,out,'build',240,dict(os.environ,DOTNET_PROCESSOR_COUNT='1',DOTNET_GCConserveMemory='9'),str(r));print(json.dumps(a));assert a['Settled']and a['ExitCode']==0
for x in rows:assert hashlib.sha256((r/x['Path']).read_bytes()).hexdigest().upper()==x['Sha256']
(out/'source-after.json').write_bytes(f)
