from pathlib import Path
import json,hashlib
r=Path.cwd();packet=r.parent/'artifacts/batch695/module-permanent-integration538';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper();mp=packet/'manifest.json';assert sha(mp)=='4CEA19D57E09DC8AB0E789EC5D88192466DB1160F18784738A2E0146162180B0';m=json.loads(mp.read_bytes());out=r/'artifacts/resource543/parent689-integration/apply695';out.mkdir(exist_ok=False)
for row in m['InvariantFiles']:assert sha(r/row['Path'])==row['Sha256'],row['Path']
for row in m['Targets']:
 p=r/row['Path'];assert p.exists()==row['BeforeExists'];assert not p.exists() or sha(p)==row['BeforeSha256'];assert sha(packet/row['Payload'])==row['AfterSha256']
for row in m['Targets']:
 p=r/row['Path']
 if p.exists():q=out/'before'/row['Path'];q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
 p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((packet/row['Payload']).read_bytes())
for row in m['InvariantFiles']:assert sha(r/row['Path'])==row['Sha256']
old=r/'artifacts/resource543/parent689-integration/source161-green.json';v=json.loads(old.read_bytes());paths={x['Path'] for x in v['Rows']}|{x['Path'] for x in m['Targets'] if x['Path'].endswith('.cs')};assert len(paths)==162;new=r/'artifacts/resource543/parent689-integration/source162-final.json';assert not new.exists();new.write_text(json.dumps({'Parent':v['Parent'],'Accepted':False,'Rows':[{'Path':p,'Sha256':sha(r/p)} for p in sorted(paths)]},indent=2));(out/'application.json').write_text(json.dumps({'Targets':m['Targets'],'NativeBuilds':0,'InvariantFilesPreserved':m['InvariantFiles'],'NewFreezeSha256':sha(new)},indent=2));print(json.dumps({'Applied':len(m['Targets']),'CSharp':len(paths),'FreezeSha256':sha(new)}))
