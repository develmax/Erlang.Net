from pathlib import Path
import json
r=Path.cwd();p=r/'artifacts/ci93-four/experimental683/affected-Release/completion.json';v=json.loads(p.read_bytes());fail=[x for e in v['Errors'] for x in e.get('Failures',[])];print(json.dumps({'Passed':sum(x['Passed'] for x in v['Rows']),'Failed':sum(x['Failed'] for x in v['Rows']),'Tests':fail})[:12500])
