from pathlib import Path
import json,hashlib,importlib.util,os
r=Path.cwd();out=r/'artifacts/ci93-four/final48-regress';out.mkdir(exist_ok=False)
s=importlib.util.spec_from_file_location('owned',r/'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
freeze=(r/'artifacts/ci93-four/experimental683/source-freeze.json').read_bytes();rows=json.loads(freeze)['Rows']
def check():
 assert freeze==(r/'artifacts/ci93-four/experimental683/source-freeze.json').read_bytes()
 for x in rows:assert hashlib.sha256((r/x['Path']).read_bytes()).hexdigest().upper()==x['Sha256']
blocks=[];seen=set()
for n in ['resource-a140.names.json','resource-b140.names.json','reader19.names.json','lifecycle-selected.json','new33.json','../ci93-four/extra20.json']:
 a=json.loads((r/'artifacts/resource541'/n).read_bytes());assert not seen.intersection(a);seen.update(a);blocks.append(a)
assert len(seen)==378
native=json.loads((r/'artifacts/ci93-four/mixed686/amendment687/native-Release/report.json').read_bytes());assert native['Passed']==174 and native['Failed']==0
a=[x['Name'] for x in native['Tests'] if x['Name'] not in seen];seen.update(a);blocks.append(a)
new=[]
for file in ['OrdinaryCounterMfa680Names.cs','OrdinaryOpaque682Names.cs','MixedNif686Names.cs','OrdinaryVm686Names.cs']:
 for line in (r/'tests/Erlang.Tests/Runtime/Storage/Counters'/file).read_text().splitlines():
  if 'const string Case' in line or 'Case =' in line:new.append(line.split('"')[1])
assert len(new)==13 and len(set(new))==13
a=[n for n in new if n not in seen];seen.update(a);blocks.append(a)
(out/'selected.json').write_text(json.dumps({'Distinct':len(seen),'Blocks':blocks},indent=2));allresults=[];errors=[]
for cfg in ['Release','Debug']:
 host=r/f'tests/Erlang.Tests/bin/{cfg}/net10.0/Erlang.Tests.dll';identity={p.name:hashlib.sha256(p.read_bytes()).hexdigest().upper() for p in host.parent.glob('*.dll')};d=out/cfg;d.mkdir();results=[]
 for i,names in enumerate(blocks):
  check();cmd=['dotnet','exec','--fx-version','10.0.11',str(host)]
  for n in names:cmd+=['--case',n]
  report=d/f'block{i}.json';cmd+=['--report',str(report)]
  try:m.owned(cmd,d,f'block{i}',180,dict(os.environ,DOTNET_PROCESSOR_COUNT='2',DOTNET_GCConserveMemory='9',PYTHONDONTWRITEBYTECODE='1'),str(r))
  except Exception as e:errors.append({'Profile':cfg,'Block':i,'Error':repr(e)})
  if report.exists():
   v=json.loads(report.read_bytes());assert {x['Name'] for x in v['Tests']}==set(names);row={'Profile':cfg,'Block':i,'Passed':v['Passed'],'Failed':v['Failed']};results.append(row);print(json.dumps(row),flush=True)
   if v['Failed']:errors.append({'Profile':cfg,'Block':i,'Failures':[x for x in v['Tests'] if x['Status']!='Passed']})
  else:errors.append({'Profile':cfg,'Block':i,'MissingReport':True})
  assert identity=={p.name:hashlib.sha256(p.read_bytes()).hexdigest().upper() for p in host.parent.glob('*.dll')}
 check();(d/'assemblies.json').write_text(json.dumps(identity,indent=2));allresults+=results
(out/'completion.json').write_text(json.dumps({'Passed':not errors,'DistinctPerProfile':len(seen),'Rows':allresults,'Errors':errors},indent=2));raise SystemExit(0 if not errors else 1)
