from pathlib import Path
import json,importlib.util,os
r=Path.cwd();out=r/'artifacts/ci93-four/mixed686';s=importlib.util.spec_from_file_location('owned',r/'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);names=['runtime/nif686/genuine-source-independent-ordinary-env-counter-host-export','runtime/nif516/pending-static-roots-independent-copy-magic-custody','runtime/nif516/ordinary-profile-preserves-existing-static-path'];cmd=['dotnet','exec','--fx-version','10.0.11',str(r/'tests/Erlang.Tests/bin/Release/net10.0/Erlang.Tests.dll')]
for n in names:cmd+=['--case',n]
cmd+=['--report',str(out/'red-report.json')]
try:m.owned(cmd,out,'red-tests',120,dict(os.environ,DOTNET_PROCESSOR_COUNT='2',DOTNET_GCConserveMemory='9',PYTHONDONTWRITEBYTECODE='1'),str(r))
except RuntimeError:pass
v=json.loads((out/'red-report.json').read_bytes());print(json.dumps({'Passed':v['Passed'],'Failed':v['Failed'],'Tests':v['Tests']})[:10000])
