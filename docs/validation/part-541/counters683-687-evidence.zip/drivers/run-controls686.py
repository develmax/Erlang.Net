from pathlib import Path
import json,hashlib,importlib.util,os
r=Path.cwd();out=r/'artifacts/ci93-four/controls686';out.mkdir(exist_ok=True)
s=importlib.util.spec_from_file_location('owned',r/'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
env=dict(os.environ,DOTNET_PROCESSOR_COUNT='2',DOTNET_GCConserveMemory='9',PYTHONDONTWRITEBYTECODE='1')
m.owned(['dotnet','build','tests/Erlang.Tests/Erlang.Tests.csproj','-c','Release','--no-restore','-m:1','-p:UseSharedCompilation=false','-p:BuildInParallel=false','-v:q'],out,'build-Release',240,dict(env,DOTNET_PROCESSOR_COUNT='1'),str(r))
host=r/'tests/Erlang.Tests/bin/Release/net10.0/Erlang.Tests.dll';before={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in host.parent.glob('*.dll')}
names=[]
for line in (r/'tests/Erlang.Tests/Runtime/Storage/Counters/OrdinaryVm686Names.cs').read_text().splitlines():
 if 'Case =' in line:names.append(line.split('"')[1])
assert len(names)==7
cmd=['dotnet','exec','--fx-version','10.0.11',str(host)]
for n in names:cmd+=['--case',n]
cmd+=['--report',str(out/'seven-report.json')]
try:m.owned(cmd,out,'seven',150,env,str(r))
except RuntimeError:pass
assert before=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in host.parent.glob('*.dll')}
v=json.loads((out/'seven-report.json').read_bytes());print(json.dumps({'Passed':v['Passed'],'Failed':v['Failed'],'Failures':[x for x in v['Tests'] if x['Status']!='Passed']})[:18000]);raise SystemExit(0 if v['Passed']==7 and v['Failed']==0 else 1)
