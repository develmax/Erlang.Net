from pathlib import Path
import json,hashlib
r=Path.cwd();s=r.parent/'artifacts/batch686/mixed-nif-environment-protocol';m=s/'source-hashes.json';assert hashlib.sha256(m.read_bytes()).hexdigest().upper()=='C23685DE6B376C2B655C5600B05B19E69741556FAEB08778B7E39587912A7672';out=r/'artifacts/ci93-four/mixed686';out.mkdir(exist_ok=False)
for row in json.loads(m.read_bytes()):
 p=Path(row['Path']);assert hashlib.sha256(p.read_bytes()).hexdigest().upper()==row['Hash']
 if p.suffix!='.cs':continue
 dest=r/'tests/Erlang.Tests/Runtime/Storage/Counters'/p.name;assert not dest.exists();data=p.read_bytes();(out/p.name).write_bytes(data)
 if p.name=='MixedNif686Names.cs':data=data.replace(b'\r\n',b'\n')
 if p.name=='MixedNif686Checks.cs':
  text=data.decode();needle='            Check(runtime.CountersStorage421.LiveArrays == 0);';assert text.count(needle)==1;text=text.replace(needle,'            await CountersOwnerAccounting683Checks.AwaitEmpty(runtime, Deadline);');data=text.encode()
 dest.write_bytes(data)
p=r/'tests/Erlang.Tests/Harness/Program.cs';data=p.read_bytes();needle=b'    Test(Erlang.Tests.OrdinaryOpaque682Names.CaptureCase, Erlang.Tests.OrdinaryOpaque682Checks.SourceFunctionCapture);';assert data.count(needle)==1;p.write_bytes(data.replace(needle,needle+b'\n    Test(Erlang.Tests.MixedNif686Names.Case, Erlang.Tests.MixedNif686Checks.Run);'))
(out/'applied.json').write_text(json.dumps({'DraftManifest':hashlib.sha256(m.read_bytes()).hexdigest().upper(),'NewFixtureLiteralLfPreparedExplicitly':True,'SameActualAccountingWaitAs683':True},indent=2));print('686actualprotocoltest added, productionunchanged')
