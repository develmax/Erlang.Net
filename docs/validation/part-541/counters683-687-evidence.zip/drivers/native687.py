from pathlib import Path
import json,os,importlib.util,hashlib
r=Path.cwd();out=r/'artifacts/ci93-four/mixed686/amendment687/native-Release';out.mkdir(exist_ok=False);host=r/'tests/Erlang.Tests/bin/Release/net10.0/Erlang.Tests.dll';before={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in host.parent.glob('*.dll')};s=importlib.util.spec_from_file_location('owned',r/'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
try:m.owned(['dotnet','exec','--fx-version','10.0.11',str(host),'--block','native','--report',str(out/'report.json')],out,'tests',180,dict(os.environ,DOTNET_PROCESSOR_COUNT='2',DOTNET_GCConserveMemory='9',PYTHONDONTWRITEBYTECODE='1'),str(r))
except RuntimeError:pass
assert before=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in host.parent.glob('*.dll')};v=json.loads((out/'report.json').read_bytes());print(json.dumps({'Passed':v['Passed'],'Failed':v['Failed'],'Failures':[x for x in v['Tests'] if x['Status']!='Passed']})[:10500]);raise SystemExit(0 if v['Failed']==0 else 1)
