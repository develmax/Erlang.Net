from pathlib import Path
import json,hashlib
r=Path.cwd();s=r.parent/'artifacts/batch680/two-cases-overlay';m=json.loads((s/'manifest.json').read_bytes());out=r/'artifacts/ci93-four/counters680/two-overlay';out.mkdir(exist_ok=False)
for row in m['Targets']:
 p=r/row['Path'];assert hashlib.sha256(p.read_bytes()).hexdigest().upper()==row['BeforeSha256'];q=s/p.name;assert hashlib.sha256(q.read_bytes()).hexdigest().upper()==row['AfterSha256'];(out/p.name).write_bytes(p.read_bytes());data=q.read_text()
 if p.name.endswith('Names.cs'):data=data.replace('const string Array =','const string ArrayField =')
 else:data=data.replace('Property(reference, Backing), Array)','Property(reference, Backing), ArrayField)')
 p.write_text(data,encoding='utf-8')
p=r/'tests/Erlang.Tests/Harness/Program.cs';data=p.read_bytes();needle=b'    Test(Erlang.Tests.OrdinaryCounterMfa680Names.Case, Erlang.Tests.OrdinaryCounterMfa680Checks.Run);';assert data.count(needle)==1;data=data.replace(needle,needle+b'\n    Test(Erlang.Tests.OrdinaryCounterMfa680Names.CaseHibernate, Erlang.Tests.OrdinaryCounterMfa680Checks.DictionaryHibernate);');p.write_bytes(data)
