from pathlib import Path
import json,hashlib,importlib.util,os
r=Path.cwd();packet=r.parent/'artifacts/batch680/ordinary-counter-mfa-regression';rows=json.loads((packet/'source-hashes.json').read_bytes());out=r/'artifacts/ci93-four/counters680';out.mkdir(exist_ok=False)
folder=r/'tests/Erlang.Tests/Runtime/Storage/Counters'
for row in rows:
 p=Path(row['Path']);assert hashlib.sha256(p.read_bytes()).hexdigest().upper()==row['Hash'];dest=folder/p.name;assert not dest.exists();dest.write_bytes(p.read_bytes())
p=r/'tests/Erlang.Tests/Harness/Program.cs';data=p.read_bytes();(out/'Program.before.cs').write_bytes(data);needle=b'    Test(Erlang.Tests.Nonblocking641Names.Case, Erlang.Tests.Nonblocking641Checks.Settlement);';assert data.count(needle)==1;data=data.replace(needle,needle+b'\n    Test(Erlang.Tests.OrdinaryCounterMfa680Names.Case, Erlang.Tests.OrdinaryCounterMfa680Checks.Run);');p.write_bytes(data)
s=importlib.util.spec_from_file_location('owned',r/'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);x=m.owned(['dotnet','build','tests/Erlang.Tests/Erlang.Tests.csproj','-c','Release','--no-restore','-m:1','-p:UseSharedCompilation=false','-p:BuildInParallel=false','-v:q'],out,'red-build',240,dict(os.environ,DOTNET_PROCESSOR_COUNT='1',DOTNET_GCConserveMemory='9',PYTHONDONTWRITEBYTECODE='1'),str(r));print(json.dumps(x))
