from pathlib import Path
import json,importlib.util,os,hashlib
r=Path.cwd();base=r/'artifacts/ci93-four/experimental683';v=json.loads((base/'affected-Release/completion.json').read_bytes());names=[x['Name'] for e in v['Errors'] for x in e.get('Failures',[])];assert len(names)==6;out=base/'affected-six-outside-Release';out.mkdir(exist_ok=False);host=r/'tests/Erlang.Tests/bin/Release/net10.0/Erlang.Tests.dll';before={p.name:hashlib.sha256(p.read_bytes()).hexdigest().upper() for p in host.parent.glob('*.dll')};s=importlib.util.spec_from_file_location('owned',r/'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);cmd=['dotnet','exec','--fx-version','10.0.11',str(host)]
for name in names:cmd+=['--case',name]
cmd+=['--report',str(out/'report.json')];error=None
try:m.owned(cmd,out,'tests',180,dict(os.environ,DOTNET_PROCESSOR_COUNT='2',DOTNET_GCConserveMemory='9',PYTHONDONTWRITEBYTECODE='1'),str(r))
except Exception as e:error=repr(e)
assert before=={p.name:hashlib.sha256(p.read_bytes()).hexdigest().upper() for p in host.parent.glob('*.dll')};v=json.loads((out/'report.json').read_bytes());(out/'same-assemblies.json').write_text(json.dumps(before,indent=2));print(json.dumps({'Passed':v['Passed'],'Failed':v['Failed'],'Error':error,'Failures':[x for x in v['Tests'] if x['Status']!='Passed']})[:8000]);raise SystemExit(0 if v['Passed']==6 and v['Failed']==0 else 1)
