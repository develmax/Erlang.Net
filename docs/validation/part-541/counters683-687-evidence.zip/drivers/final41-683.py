from pathlib import Path
import json,hashlib,os,importlib.util
r=Path.cwd();base=r/'artifacts/ci93-four/experimental683';freeze=(base/'source-freeze.json').read_bytes();rows=json.loads(freeze)['Rows'];out=base/'final41';out.mkdir(exist_ok=False);s=importlib.util.spec_from_file_location('owned',r/'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);errors=[];result=[]
def check():
 assert (base/'source-freeze.json').read_bytes()==freeze
 for row in rows:assert hashlib.sha256((r/row['Path']).read_bytes()).hexdigest().upper()==row['Sha256']
names=[]
for name in ['OrdinaryCounterMfa680Names.cs','OrdinaryOpaque682Names.cs']:
 for line in (r/'tests/Erlang.Tests/Runtime/Storage/Counters'/name).read_text().splitlines():
  if 'const string Case' in line or 'Case =' in line:names.append(line.split('"')[1])
assert len(names)==5
for cfg in ['Release','Debug']:
 host=r/f'tests/Erlang.Tests/bin/{cfg}/net10.0/Erlang.Tests.dll';identity={p.name:hashlib.sha256(p.read_bytes()).hexdigest().upper() for p in host.parent.glob('*.dll')};d=out/cfg;d.mkdir();cmd=['dotnet','exec','--fx-version','10.0.11',str(host)]
 for name in names:cmd+=['--case',name]
 cmd+=['--report',str(d/'five.json')];check()
 try:m.owned(cmd,d,'five',120,dict(os.environ,DOTNET_PROCESSOR_COUNT='2',DOTNET_GCConserveMemory='9',PYTHONDONTWRITEBYTECODE='1'),str(r))
 except Exception as e:errors.append({'Profile':cfg,'Stage':'five','Error':repr(e)})
 v=json.loads((d/'five.json').read_bytes());print(json.dumps({'Profile':cfg,'FivePassed':v['Passed'],'FiveFailed':v['Failed']}),flush=True);result.append({'Profile':cfg,'Five':{'Passed':v['Passed'],'Failed':v['Failed']}})
 for mode in ['ordinary','private-owned']:
  target=d/mode;target.mkdir();request=json.loads((r/'artifacts/ci93-four/counters610-authentic-red'/mode/'request.json').read_bytes());command=request['Command'];command[4]=str(host);command[-1]=str(target/'actual');check()
  try:m.owned(command,target,'managed',120,dict(os.environ,DOTNET_PROCESSOR_COUNT='1',DOTNET_GCConserveMemory='9',PYTHONDONTWRITEBYTECODE='1'),str(r))
  except Exception as e:errors.append({'Profile':cfg,'Stage':mode,'Error':repr(e)})
  comparison=json.loads((target/'actual/comparison.json').read_bytes());cleanup=json.loads((target/'actual/cleanup610.json').read_bytes());okay=comparison['Passed'] and comparison['OwnReferenceProtocolPassed'] and comparison['WholeRawValuesAndStacksCompared'] and cleanup['PhysicalClosed'];assert okay;print(json.dumps({'Profile':cfg,'Mode':mode,'OriginalWholeAndCleanup':okay}),flush=True)
 check();assert identity=={p.name:hashlib.sha256(p.read_bytes()).hexdigest().upper() for p in host.parent.glob('*.dll')}
passed=not errors and all(x['Five']['Passed']==5 and x['Five']['Failed']==0 for x in result);(out/'completion.json').write_text(json.dumps({'Passed':passed,'Rows':result,'Errors':errors,'FreshOriginalReferenceReusedFromPreFixAcquisition':True,'SourceRows':len(rows)},indent=2));raise SystemExit(0 if passed else 1)
