from pathlib import Path
import hashlib,json
r=Path.cwd();out=r/'artifacts/ci93-four/experimental683/fixture-lf-preparation';out.mkdir(exist_ok=False);rows=[]
for name in ['OrdinaryCounterMfa680Names.cs','OrdinaryOpaque682Names.cs']:
 p=r/'tests/Erlang.Tests/Runtime/Storage/Counters'/name;before=p.read_bytes();assert b'\r\n' in before;(out/name).write_bytes(before);after=before.replace(b'\r\n',b'\n');p.write_bytes(after);rows.append({'Path':p.relative_to(r).as_posix(),'BeforeSha256':hashlib.sha256(before).hexdigest().upper(),'AfterSha256':hashlib.sha256(after).hexdigest().upper(),'FixtureLiteralNewlinesDeliberatelyChangedBeforeFormatting':True})
(out/'receipt.json').write_text(json.dumps(rows,indent=2));f=r/'artifacts/ci93-four/experimental683/source-freeze.json';v=json.loads(f.read_bytes())
for row in v['Rows']:row['Sha256']=hashlib.sha256((r/row['Path']).read_bytes()).hexdigest().upper()
f.write_text(json.dumps(v,indent=2))
s=(r/'artifacts/ci93-four/style-build683.py').read_text().replace("experimental683/style41'","experimental683/style41b'");(r/'artifacts/ci93-four/style-build683b.py').write_text(s)
print('Two NEW fixture literal LF preparations recorded; not claimed token-preserving')
