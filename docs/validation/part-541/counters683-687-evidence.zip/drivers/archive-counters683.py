from pathlib import Path
import json,hashlib,zipfile
r=Path.cwd();base=r/'artifacts/ci93-four';out=r/'docs/validation/part-541';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
freeze=base/'experimental683/source-freeze.json';rows=json.loads(freeze.read_bytes())['Rows'];assert len(rows)==48
for x in rows:assert sha(r/x['Path'])==x['Sha256']
v=json.loads((base/'final48-regress/completion.json').read_bytes());assert v['Passed'] and v['DistinctPerProfile']==510 and not v['Errors']
for cfg in ['Release','Debug']:
 rr=[x for x in v['Rows'] if x['Profile']==cfg];assert len(rr)==8 and sum(x['Passed'] for x in rr)==510 and not any(x['Failed'] for x in rr)
 a=json.loads((base/f'final48-regress/{cfg}/assemblies.json').read_bytes())
 for name,h in a.items():assert sha(r/f'tests/Erlang.Tests/bin/{cfg}/net10.0'/name)==h
c=json.loads((base/'final48-counters610/completion.json').read_bytes());assert c['Passed'] and len(c['Rows'])==2
for x in c['Rows']:assert x['Passed'] and x['OwnReferenceProtocolPassed'] and x['WholeRawValuesAndStacksCompared'] and x['Cleanup']['PhysicalClosed']
summary={'LocalAccepted':True,'SourceFreezeSha256':sha(freeze),'ChangedCSharpCount':48,'FinalDistinctPerProfile':510,'FinalBlockSizes':[140,140,19,38,33,8,120,12],'FinalRetries':0,'FinalProfiles':['Release','Debug'],'FinalReleaseOriginalRoutes':['ordinary','private-owned'],'OriginalFreshPreFixCaptureReusedUnchanged':True,'WholeValuesAndStacksOutsideAuthenticatedSixRoleReferenceWords':True,'StrictRawEtfEqualityClaimed':False,'OriginalDebugOptProfileRefusalPreserved':True,'ExpectedCatalog':9445,'FullLocalSuiteClaimed':False,'ApiDelta':0,'FullContractDelta':0,'Registered':708,'Verified':180,'Pending':504,'KnownDifferences':24,'FreshCallbackActivationExtended':False,'CurrentHeadCiAndReviewPending':True}
files={}
def add(prefix,folder):
 for p in sorted(folder.rglob('*')):
  if not p.is_file() or any(x in p.parts for x in ['bin','obj','__pycache__']):continue
  if p.suffix.lower() not in {'.json','.log','.txt','.py','.cs','.erl','.etf','.stderr','.stdout','.trace','.beam'}:continue
  files[prefix+'/'+p.relative_to(folder).as_posix()]=p
for name in ['counters610-authentic-red','counters680','counters682','experimental683','mixed686','controls686','final48-regress','final48-counters610']:add(name,base/name)
for p in base.glob('*.py'):files['drivers/'+p.name]=p
ci=r.parent/'artifacts/delivery541-final20-ci'
for name in ['tests.json','artifact-provenance.json','final-audit.json']:files['failed-ci/'+name]=ci/name
add('failed-ci/counters610',ci/'owned506/counters610')
for x in rows:files['final-source/'+x['Path']]=r/x['Path']
archive=out/'counters683-687-evidence.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(files.items()):z.writestr(name,p.read_bytes())
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(files)==len(set(z.namelist()))
 for name,p in files.items():assert z.read(name)==p.read_bytes()
receipt={'Sha256':sha(archive),'Bytes':archive.stat().st_size,'Members':len(files),'EveryMemberReadbackVerified':True}
(out/'counters683-687-summary.json').write_text(json.dumps(dict(summary,Archive=receipt),indent=2)+'\n');print(json.dumps(receipt))
