from pathlib import Path
import json,hashlib
r=Path.cwd();s=r.parent/'Erlang.Net/artifacts/batch686/ordinary-vm-controls538';mp=s/'manifest.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
assert sha(mp)=='F0A135FB7381580BA053A51ED1412DBA21F578B5FB1345BF89FDB347C3623D5B'
m=json.loads(mp.read_bytes());h=s/m['HarnessHunk']['Path'];assert sha(h)==m['HarnessHunk']['Sha256'];hunk=json.loads(h.read_bytes());hp=r/hunk['Path'];assert sha(hp)==hunk['BeforeSha256'];b=hp.read_bytes();old=hunk['BeforeText'].encode();assert b.count(old)==1;updated=b.replace(old,hunk['AfterText'].encode());assert hashlib.sha256(updated).hexdigest().upper()==hunk['AfterSha256']
for row in m['Targets']:
 src=s/row['Payload'];dst=r/row['Path'];assert not dst.exists();assert sha(src)==row['AfterSha256']
for row in m['Targets']:(r/row['Path']).write_bytes((s/row['Payload']).read_bytes())
hp.write_bytes(updated)
freeze=r/'artifacts/ci93-four/experimental683/source-freeze.json';v=json.loads(freeze.read_bytes());paths={x['Path'] for x in v['Rows']}|{x['Path'] for x in m['Targets']};v['Rows']=[{'Path':p,'Sha256':sha(r/p)} for p in sorted(paths)];freeze.write_text(json.dumps(v,indent=2));print('Applied four controls files + seven registrations; frozen C#='+str(len(paths)))
