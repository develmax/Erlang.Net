from pathlib import Path
import json,os,importlib.util
r=Path.cwd();out=r/'artifacts/ci93-four/mixed686/amendment687';s=importlib.util.spec_from_file_location('owned',r/'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);names=[]
for file in ['OrdinaryCounterMfa680Names.cs','OrdinaryOpaque682Names.cs','MixedNif686Names.cs']:
 for line in (r/'tests/Erlang.Tests/Runtime/Storage/Counters'/file).read_text().splitlines():
  if 'const string Case' in line or 'Case =' in line:names.append(line.split('"')[1])
names+=['runtime/nif516/pending-static-roots-independent-copy-magic-custody','runtime/nif516/ordinary-profile-preserves-existing-static-path'];assert len(names)==8;cmd=['dotnet','exec','--fx-version','10.0.11',str(r/'tests/Erlang.Tests/bin/Release/net10.0/Erlang.Tests.dll')]
for n in names:cmd+=['--case',n]
cmd+=['--report',str(out/'eight-report.json')]
try:m.owned(cmd,out,'eight-tests',120,dict(os.environ,DOTNET_PROCESSOR_COUNT='2',DOTNET_GCConserveMemory='9',PYTHONDONTWRITEBYTECODE='1'),str(r))
except RuntimeError:pass
v=json.loads((out/'eight-report.json').read_bytes());print(json.dumps({'Passed':v['Passed'],'Failed':v['Failed'],'Failures':[x for x in v['Tests'] if x['Status']!='Passed']})[:9000]);raise SystemExit(0 if v['Passed']==8 and v['Failed']==0 else 1)
