from pathlib import Path
p=Path('artifacts/ci93-four/counters610-red.py');s=p.read_text();assert 'assert pin in workflow' in s;p.write_text(s.replace('assert pin in workflow','assert pin and raw'))
