from pathlib import Path
import json,importlib.util
r=Path.cwd();p=r/'artifacts/ci93-four/counters610-authentic-red/completion.json';v=json.loads(p.read_bytes());print('Keys',list(v));print(json.dumps({k:x for k,x in v.items() if k not in ['Profiles','ManagedInputsBefore','ManagedInputsAfter','Original']})[:1800])
s=importlib.util.spec_from_file_location('d',r/'tools/Distribution/Erlang.GuestConnectedSendObservations/passive_etf.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);p=p.parent/'ordinary/actual/observed.etf';print('Ordinary',repr(m.decode_exact(p.read_bytes()))[:700])
