from pathlib import Path
import json,hashlib
r=Path.cwd();folder=r/'tests/Erlang.Tests/Runtime/Storage/Counters';out=r/'artifacts/ci93-four/experimental683/accounting-test-correction';out.mkdir(exist_ok=False)
for name in ['OrdinaryCounterMfa680Checks.cs','OrdinaryOpaque682Checks.cs']:
 p=folder/name;text=p.read_text();needle='            Check(runtime.CountersStorage421.LiveArrays == 0);';assert text.count(needle)==1;(out/name).write_bytes(p.read_bytes());p.write_text(text.replace(needle,'            await CountersOwnerAccounting683Checks.AwaitEmpty(runtime, Deadline);'),encoding='utf-8')
p=folder/'CountersOwnerAccounting683Names.cs';assert not p.exists();p.write_text('''namespace Erlang.Tests;

internal static class CountersOwnerAccounting683Names
{
    internal static readonly TimeSpan PollInterval = TimeSpan.FromMilliseconds(1);
}
''',encoding='utf-8')
p=folder/'CountersOwnerAccounting683Checks.cs';assert not p.exists();p.write_text('''namespace Erlang.Tests;

internal static class CountersOwnerAccounting683Checks
{
    internal static async Task AwaitEmpty(ProcessRuntime runtime, TimeSpan deadline)
    {
        using var limit = new CancellationTokenSource(deadline);
        // Array retirement signals physical free before registry unlink and
        // owner accounting finish. Observe both actual states before VM close.
        while (true)
        {
            RuntimeCountersReport421 report = runtime.CountersStorage421;
            if (report.LiveArrays == 0 && report.OwnedNativeBytes == 0
                && report.ActiveInvocations == 0 && report.Created == report.Freed)
                return;

            await Task.Delay(CountersOwnerAccounting683Names.PollInterval, limit.Token);
        }
    }
}
''',encoding='utf-8')
f=r/'artifacts/ci93-four/experimental683/source-freeze.json';(out/'previous39.json').write_bytes(f.read_bytes());v=json.loads(f.read_bytes());paths={x['Path'] for x in v['Rows']}|{(folder/'CountersOwnerAccounting683Names.cs').relative_to(r).as_posix(),(folder/'CountersOwnerAccounting683Checks.cs').relative_to(r).as_posix()};v['Rows']=[{'Path':p,'Sha256':hashlib.sha256((r/p).read_bytes()).hexdigest().upper()} for p in sorted(paths)];f.write_text(json.dumps(v,indent=2));print('Same deadline, actual physical+owner states; frozen',len(paths))
