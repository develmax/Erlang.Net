from pathlib import Path
import json,hashlib
r=Path.cwd();packet=r.parent/'artifacts/batch682/ordinary-opaque-host-escape';overlay=packet/'third-case-overlay';m=json.loads((overlay/'manifest.json').read_bytes());out=r/'artifacts/ci93-four/counters682';out.mkdir(exist_ok=False)
for row in m['Targets']:
 original=packet/row['Path'];candidate=overlay/row['Path'];assert hashlib.sha256(original.read_bytes()).hexdigest().upper()==row['BeforeSha256'];assert hashlib.sha256(candidate.read_bytes()).hexdigest().upper()==row['AfterSha256'];dest=r/'tests/Erlang.Tests/Runtime/Storage/Counters'/row['Path'];assert not dest.exists();dest.write_bytes(candidate.read_bytes())
p=r/'tests/Erlang.Tests/Harness/Program.cs';data=p.read_bytes();(out/'Program.before.cs').write_bytes(data);needle=b'    Test(Erlang.Tests.OrdinaryCounterMfa680Names.CaseHibernate, Erlang.Tests.OrdinaryCounterMfa680Checks.DictionaryHibernate);';assert data.count(needle)==1
lines=[b'    Test(Erlang.Tests.OrdinaryOpaque682Names.RegisteredCase, Erlang.Tests.OrdinaryOpaque682Checks.RegisteredHost);',b'    Test(Erlang.Tests.OrdinaryOpaque682Names.FunctionCase, Erlang.Tests.OrdinaryOpaque682Checks.PublicOpaqueFunction);',b'    Test(Erlang.Tests.OrdinaryOpaque682Names.CaptureCase, Erlang.Tests.OrdinaryOpaque682Checks.SourceFunctionCapture);'];p.write_bytes(data.replace(needle,needle+b'\n'+b'\n'.join(lines)))
(out/'source-transfer.json').write_text(json.dumps(m,indent=2));print('Five focused regression registrations ready; production runtime unchanged')
