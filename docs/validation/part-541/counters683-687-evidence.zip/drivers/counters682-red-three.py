from pathlib import Path
import json,os,importlib.util
r=Path.cwd();out=r/'artifacts/ci93-four/counters682';s=importlib.util.spec_from_file_location('owned',r/'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
x=m.owned(['dotnet','build','tests/Erlang.Tests/Erlang.Tests.csproj','-c','Release','--no-restore','-m:1','-p:UseSharedCompilation=false','-p:BuildInParallel=false','-v:q'],out,'red-three-build',240,dict(os.environ,DOTNET_PROCESSOR_COUNT='1',DOTNET_GCConserveMemory='9',PYTHONDONTWRITEBYTECODE='1'),str(r));print(json.dumps({'BuildPassed':True,'Seconds':x['ElapsedSeconds']}),flush=True)
names=[]
for line in (r/'tests/Erlang.Tests/Runtime/Storage/Counters/OrdinaryOpaque682Names.cs').read_text().splitlines():
 if 'const string ' in line and 'Case =' in line:names.append(line.split('"')[1])
assert len(names)==3
args=['dotnet','exec','--fx-version','10.0.11',str(r/'tests/Erlang.Tests/bin/Release/net10.0/Erlang.Tests.dll')]
for name in names:args+=['--case',name]
args+=['--report',str(out/'red-three-report.json')]
try:m.owned(args,out,'red-three-tests',100,dict(os.environ,DOTNET_PROCESSOR_COUNT='2',DOTNET_GCConserveMemory='9',PYTHONDONTWRITEBYTECODE='1'),str(r))
except RuntimeError:pass
v=json.loads((out/'red-three-report.json').read_bytes());print(json.dumps({'Passed':v['Passed'],'Failed':v['Failed'],'Tests':v['Tests']})[:6000]);assert v['Failed']==3 and v['Passed']==0
