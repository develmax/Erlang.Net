from pathlib import Path
import json,hashlib
r=Path.cwd();out=r/'artifacts/ci93-four/experimental683/final41';rows=[]
for cfg in ['Release','Debug']:
 v=json.loads((out/cfg/'five.json').read_bytes());assert v['Passed']==5 and v['Failed']==0;rows.append({'Configuration':cfg,'ManagedChecksPassed':5,'ManagedChecksFailed':0})
for mode in ['ordinary','private-owned']:
 d=out/'Release'/mode/'actual';v=json.loads((d/'comparison.json').read_bytes());c=json.loads((d/'cleanup610.json').read_bytes());assert v['Passed'] and v['WholeRawValuesAndStacksCompared'] and v['OwnReferenceProtocolPassed'] and c['PhysicalClosed']
failure=out/'Debug/ordinary/actual/failure.txt';assert 'RequireProfile' in failure.read_text();value={'Status':'PASS_SCOPED_MANAGED_AND_OPT_ORIGINAL','Managed':rows,'OriginalAcceptedConfiguration':'Release','OriginalRuntimeProfiles':['ordinary','private-owned'],'OriginalReference':'Fresh pre-fix acquisition reused with unchanged admission and metadata','DebugOriginalConfigurationRefusedBeforeComparison':True,'DebugOriginalAccepted':False,'FailedAggregateAttemptRetained':True,'FullSuiteOrCiAccepted':False,'RemainingGates':['native hibernate args/reasons','activation and owner shutdown controls','mixed NIF env and dirty custody','affected final regressions','exact head CI review merge']};(out/'scoped-completion.json').write_text(json.dumps(value,indent=2));print(json.dumps(value))
