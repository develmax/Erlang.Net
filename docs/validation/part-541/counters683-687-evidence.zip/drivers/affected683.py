from pathlib import Path
import json,hashlib,importlib.util,os
r=Path.cwd();base=r/'artifacts/ci93-four/experimental683';out=base/'affected-Release';out.mkdir(exist_ok=False);spec=importlib.util.spec_from_file_location('owned',r/'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);host=r/'tests/Erlang.Tests/bin/Release/net10.0/Erlang.Tests.dll';identity={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in host.parent.glob('*.dll')};seen=set();errors=[];rows=[]
for i,name in enumerate(['resource-a140.names.json','resource-b140.names.json','reader19.names.json','lifecycle-selected.json','new33.json','../ci93-four/extra20.json']):
 names=json.loads((r/'artifacts/resource541'/name).read_bytes());assert not seen.intersection(names);seen.update(names);cmd=['dotnet','exec','--fx-version','10.0.11',str(host)]
 for n in names:cmd+=['--case',n]
 report=out/('block'+str(i)+'.json');cmd+=['--report',str(report)]
 try:m.owned(cmd,out,'block'+str(i),180,dict(os.environ,DOTNET_PROCESSOR_COUNT='2',DOTNET_GCConserveMemory='9',PYTHONDONTWRITEBYTECODE='1'),str(r))
 except Exception as e:errors.append({'Block':i,'Error':repr(e)})
 if report.exists():
  v=json.loads(report.read_bytes());assert {x['Name'] for x in v['Tests']}==set(names);rows.append({'Block':i,'Passed':v['Passed'],'Failed':v['Failed']});print(json.dumps(rows[-1]),flush=True)
  if v['Failed']:errors.append({'Block':i,'Failures':[x for x in v['Tests'] if x['Status']!='Passed']})
assert len(seen)==378 and identity=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in host.parent.glob('*.dll')};(out/'completion.json').write_text(json.dumps({'Passed':not errors,'SelectedDistinct':378,'Rows':rows,'Errors':errors},indent=2));raise SystemExit(0 if not errors else 1)
