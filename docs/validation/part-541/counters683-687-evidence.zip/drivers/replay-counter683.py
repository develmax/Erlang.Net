from pathlib import Path
import importlib.util,hashlib,json,os
r=Path.cwd();out=r/'artifacts/ci93-four/experimental683/counters610';out.mkdir(exist_ok=False);s=importlib.util.spec_from_file_location('owned',r/'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);rows=[]
for name in ['ordinary','private-owned']:
 d=out/name;d.mkdir();request=json.loads((r/'artifacts/ci93-four/counters610-authentic-red'/name/'request.json').read_bytes());cmd=request['Command'];cmd[-1]=str(d/'actual');before=hashlib.sha256(Path(cmd[4]).read_bytes()).hexdigest().upper();error=None
 try:m.owned(cmd,d,'managed',120,dict(os.environ,DOTNET_PROCESSOR_COUNT='1',DOTNET_GCConserveMemory='9',PYTHONDONTWRITEBYTECODE='1'),str(r))
 except Exception as e:error=repr(e)
 row={'Profile':name,'Error':error,'ManagedHostSha256':before,'FreshOriginalAcquisitionReusedFromAuthenticRed':True};p=d/'actual/comparison.json';c=d/'actual/cleanup610.json'
 if p.exists():v=json.loads(p.read_bytes());row.update(Passed=v.get('Passed'),OwnReferenceProtocolPassed=v.get('OwnReferenceProtocolPassed'),WholeRawValuesAndStacksCompared=v.get('WholeRawValuesAndStacksCompared'))
 if c.exists():row['Cleanup']=json.loads(c.read_bytes())
 assert before==hashlib.sha256(Path(cmd[4]).read_bytes()).hexdigest().upper();rows.append(row);print(json.dumps(row)[:2400],flush=True)
(out/'completion.json').write_text(json.dumps({'Passed':all(x.get('Passed') and x.get('Cleanup',{}).get('PhysicalClosed') and x['Error'] is None for x in rows),'Rows':rows},indent=2))
