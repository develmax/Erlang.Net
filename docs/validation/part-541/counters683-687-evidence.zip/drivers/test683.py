from pathlib import Path
import json,hashlib,importlib.util,os
r=Path.cwd();out=r/'artifacts/ci93-four/experimental683';f=json.loads((out/'source-freeze.json').read_bytes());s=importlib.util.spec_from_file_location('owned',r/'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
for row in f['Rows']:assert hashlib.sha256((r/row['Path']).read_bytes()).hexdigest().upper()==row['Sha256']
names=[]
for file in ['OrdinaryCounterMfa680Names.cs','OrdinaryOpaque682Names.cs']:
 for line in (r/'tests/Erlang.Tests/Runtime/Storage/Counters'/file).read_text().splitlines():
  if 'const string Case' in line or 'Case =' in line:names.append(line.split('"')[1])
assert len(names)==5 and len(set(names))==5
cmd=['dotnet','exec','--fx-version','10.0.11',str(r/'tests/Erlang.Tests/bin/Release/net10.0/Erlang.Tests.dll')]
for name in names:cmd+=['--case',name]
cmd+=['--report',str(out/'five-report.json')]
try:m.owned(cmd,out,'five-tests',120,dict(os.environ,DOTNET_PROCESSOR_COUNT='2',DOTNET_GCConserveMemory='9',PYTHONDONTWRITEBYTECODE='1'),str(r))
except RuntimeError:pass
v=json.loads((out/'five-report.json').read_bytes());print(json.dumps({'Passed':v['Passed'],'Failed':v['Failed'],'Tests':v['Tests']})[:10000]);raise SystemExit(0 if v['Passed']==5 and v['Failed']==0 else 1)
