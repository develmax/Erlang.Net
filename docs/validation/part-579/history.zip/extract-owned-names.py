from pathlib import Path
import re, json
root=Path('src/Otp/Managed/Erlang.Otp.Stdlib/Processes/GenStatem')
files=list(root.glob('*.cs'))
api=(root/'GenStatemModule.cs').read_text(encoding='utf-8')
funcs=set(re.findall(r'\("([a-z_]+)", \d+\)',api))|{'init','callback_mode','handle_event','terminate','code_change','get_parent','get_proc_name','debug_options','hibernate_after','unregister_name','init_ack','init_fail','garbage_collect','hibernate','apply','make_ref','start_timer','cancel_timer','handle_system_msg','handle_debug','get_log','format_status_header','get','get_label','log','macro_log','allow','node','process_info','format','function_exported','is_loaded','get_format_depth','limit_term','send','error_info','callback_mode_result','replies'}
mods={'erlang','gen','sys','proc_lib','logger','io_lib','io','code','error_logger','global'}
fields={'state','data','postponed','log','timeouts','queue','reason','label','name','modules','callback_mode','state_enter','client_info','process_label','domain','report_cb','error_logger','tag','mfa','line','file','chars_limit','depth','single_line','encoding','$status','EXIT'}
groups={}
names={}
def ident(value):
    words=re.findall(r'[A-Za-z0-9]+',value)
    out=''.join(w[0].upper()+w[1:] for w in words)
    if not out or out[0].isdigit(): out='Value'+out
    return out[:100]
def symbol(group,value):
    table=groups.setdefault(group,{})
    if value in table: return group+'.'+table[value]
    name=ident(value)
    used=set(table.values())
    base=name; i=2
    while name in used: name=base+str(i); i+=1
    table[value]=name
    return group+'.'+name
for path in files:
    source=path.read_text(encoding='utf-8')
    def replace(m):
        literal=m.group(0); value=json.loads(literal)
        before=source[max(0,m.start()-180):m.start()]
        after=source[m.end():m.end()+45]
        line=source[source.rfind('\n',0,m.start())+1:m.start()]
        if 'public const string Name =' in line: return literal
        if value=='': return literal
        if value=='gen_statem.erl': group='GenStatemSourceNames'
        elif value in mods and not re.search(r'(?:Term\.A\(|\bIs\([^\n]*,\s*)$',before): group='GenStatemDependencyNames'
        elif value in fields and (re.search(r'(?:Get\(|TryGet\(|Option\(|Get\(Term\.A\(|TryGet\(Term\.A\(|\[Term\.A\()$',before) or re.match(r'\s*,',after) and not re.search(r'(?:Is\([^\n]*,\s*|Term\.A\()$',before)): group='GenStatemStatusNames'
        elif re.search(r'(?:Term\.A\(|\bIs\([^\n]*,\s*)$',before) or ('Name:' in line and path.name!='GenStatemSource.cs') or (path.name.startswith('GenStatemMachine') and 'case ' in line): group='GenStatemProtocolAtoms'
        elif value in funcs or value.startswith('loop_') or value.startswith('-inlined-'): group='GenStatemFunctionNames'
        elif '~' in value or value in {'.','~','0','t','P','p'} or 'text.Append(' in line or 'p =' in line or 'string format' in line: group='GenStatemLogFormats'
        elif value in fields: group='GenStatemStatusNames'
        else: group='GenStatemTextNames'
        return symbol(group,value)
    result=re.sub(r'"(?:[^"\\]|\\.)*"',replace,source)
    path.write_text(result,encoding='utf-8',newline='\n')
for group,table in groups.items():
    lines=['namespace Erlang;','','internal static class '+group,'{']
    for value,name in table.items():
        lines.append('    internal const string '+name+' = '+json.dumps(value,ensure_ascii=False)+';')
    lines+=['}','']
    (root/(group+'.cs')).write_text('\n'.join(lines),encoding='utf-8',newline='\n')
print({g:len(t) for g,t in groups.items()})