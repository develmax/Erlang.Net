from pathlib import Path
import json
p=Path('docs/module-readiness-scope.json')
d=json.loads(p.read_text(encoding='utf-8-sig'))
rows=[r for r in d['Components'] if r['Project']=='src/Otp/Managed/Erlang.Otp.Stdlib']
assert len(rows)==1
r=rows[0]
r['Implemented'].append('Part579: gen_statem has40 explicit managed exports and unchanged original Erlang selection; both pass74 full API observations and311 focused engine scenarios, including256 mode/event combinations and sys exactly-one termination. Source/assembly/corpus receipts: validation/part-579/README.md. Default gen_statem registration remains0; global readiness is not refreshed from partial reports.')
r['Remaining'].append('gen_statem: full upstream gen_statem_SUITE, owned-heap/resource/platform/distribution/global/via, actual Logger handler and module-metadata acceptance remain open. Finite focused evidence does not certify100% OTP compatibility.')
p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')