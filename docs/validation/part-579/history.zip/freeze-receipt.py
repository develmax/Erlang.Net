from pathlib import Path
import json,hashlib,zipfile
root=Path('artifacts/gen-statem')
out=Path('docs/validation/part-579')
with zipfile.ZipFile(out/'history.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(root.iterdir()):
        if p.is_file() and p.suffix in {'.log','.json','.py'}:
            z.write(p,p.name)
        elif p.is_dir() and p.name.startswith('oracle'):
            for f in p.iterdir():
                if f.is_file() and (f.suffix=='.json' or f.name=='oracle.log'):
                    z.write(f,str(f.relative_to(root)))
files={str(p.relative_to(out)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest().upper()
       for p in sorted(out.rglob('*')) if p.is_file() and p.name not in {'README.md','files.json'}}
(out/'files.json').write_text(json.dumps(files,indent=2)+'\n',encoding='utf-8')
print(f'Frozen {len(files)} receipt files; history {int((out/"history.zip").stat().st_size)} bytes')