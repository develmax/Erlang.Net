from pathlib import Path
import re,json
root=Path('src/Otp/Managed/Erlang.Otp.Stdlib/Processes/GenStatem')
allfiles=list(root.glob('*.cs'))
pattern=r'internal const string (\w+)\s*=\s*("(?:[^"\\]|\\.)*")\s*;'
tables={p.stem:{n:json.loads(v) for n,v in re.findall(pattern,p.read_text())} for p in allfiles if re.findall(pattern,p.read_text())}
move={
'Maps':('GenStatemDependencyNames','Maps'),'Merge':('GenStatemFunctionNames','Merge'),'FormatLogMulti':('GenStatemFunctionNames','FormatLogMulti'),
'Reqids':('GenStatemFunctionNames','RequestCollectionPrefix'),'StateName':('GenStatemFunctionNames','StateName'),
'StatusForStateMachine':('GenStatemStatusLabels','Header'),'State2':('GenStatemStatusLabels','State'),
'Status':('GenStatemStatusLabels','Status'),'Parent':('GenStatemStatusLabels','Parent'),'Modules':('GenStatemStatusLabels','Modules'),
'TimeOuts2':('GenStatemStatusLabels','Timeouts'),'LoggedEvents':('GenStatemStatusLabels','LoggedEvents'),'Postponed2':('GenStatemStatusLabels','Postponed')}
formats={'StateMachine':'SingleMachinePrefix','Terminating':'TerminatingSuffix','Label':'SingleLabelPrefix','Reason':'SingleReasonPrefix','Stack':'SingleStackPrefix','LastEvent':'SingleLastEventPrefix','State':'SingleStatePrefix','Log':'SingleLogPrefix','StateMachine2':'MultiMachinePrefix','ProcessLabel':'MultiLabelPrefix','LastEvent2':'MultiLastEventPrefix','WhenServerState':'MultiStatePrefix','ReasonForTermination':'MultiReasonPrefix','Value':'ReasonSeparator','CallbackModules':'MultiModulesPrefix','CallbackMode':'MultiModePrefix','Queued':'MultiQueuePrefix','Postponed':'MultiPostponedPrefix','TimeOuts':'MultiTimeoutsPrefix','Client':'SingleClientPrefix','Stacktrace':'SingleClientStackPrefix','Client2':'MultiClientPrefix'}
move.update({n:('GenStatemLogFormats',new) for n,new in formats.items()})
replacements={}
for old,value in tables['GenStatemTextNames'].items():
    group,name=move.get(old,('GenStatemProtocolAtoms',old))
    table=tables.setdefault(group,{})
    existing=next((n for n,v in table.items() if v==value),None)
    if existing: name=existing
    elif name in table: raise RuntimeError((group,name))
    else: table[name]=value
    replacements['GenStatemTextNames.'+old]=group+'.'+name
for p in allfiles:
    if p.stem=='GenStatemTextNames': continue
    s=p.read_text()
    s=re.sub(r'GenStatemTextNames\.\w+',lambda m:replacements[m[0]],s)
    p.write_text(s,encoding='utf-8',newline='\n')
del tables['GenStatemTextNames']
for group,table in tables.items():
    if not group.endswith(('Names','Atoms','Formats','Labels')): continue
    lines=['namespace Erlang;','','internal static class '+group,'{']
    lines+=['    internal const string '+n+' = '+json.dumps(v,ensure_ascii=False)+';' for n,v in table.items()]
    lines+=['}','']
    (root/(group+'.cs')).write_text('\n'.join(lines),encoding='utf-8',newline='\n')
(root/'GenStatemTextNames.cs').unlink()