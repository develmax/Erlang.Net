using System.Reflection;
using System.Runtime.InteropServices;
using Erlang;

const BindingFlags flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
Type type = typeof(ProcessRuntime).Assembly.GetType("Erlang.NifNativeWindowsCallbacks", true)!;
using var table = (IDisposable)Activator.CreateInstance(type, flags, null, new object[] { false }, null)!;
nint pointer = (nint)type.GetProperty("Pointer", flags)!.GetValue(table)!;
if (Marshal.ReadIntPtr(pointer, 24 * IntPtr.Size) == 0 || Marshal.ReadIntPtr(pointer, 25 * IntPtr.Size) == 0)
    throw new InvalidOperationException("Runtime varargs entry points are missing.");
Console.WriteLine("PASS ordinary .NET runtime asset and actual C entry points");
