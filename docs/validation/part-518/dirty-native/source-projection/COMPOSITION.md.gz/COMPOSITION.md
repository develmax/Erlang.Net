# Dirty/native publication projection 528

Source-only reviewed projection onto parent-reported PR70 head `12893d5eeda975abb7e6fe86f9b55ea38b7f4be8` (the successor to e2e308d05). Exact existing-file preimages were read from w517fix, not inferred from the primary branch. No worktree was modified; no build/native/guest VM, git or CI command was executed by this packet author.

## Scope and payload

`projection-files.json` is the complete allowlist: 27 guarded existing files, 47 new source/tool/test/resource files and one actual source-bound Windows native adapter DLL (75 payloads). `existing-files.patch` contains only the textual existing-file differences; new files and binary fixtures/DLL are supplied under staged-tree. Use one promotion method, never reapply both equivalents. All 27 existing preimages must match before copying anything. Absent targets must remain absent; if the destination advanced, recompose only named conflicts.

Included clusters: actual dirty NIF flags and physical call/image custody521; configurable real dirty IO workers522; ordinary binary scratch before protected receive525; genuine Windows C varargs24/25 bridge526 plus its actual native build asset; genuine dirty original acquisition and variadic-family tools, admitted BEAM/compile fixtures, native child runner, focused tests. Linux bridge remains version5/table368; ordinary Linux callback-table construction does not load the Windows DLL. Windows binder retains assembly-aware native resolution fallback. High-bit illegal flags use the actual pinned printf-compatible format already verified by the parent's seven-variant/four-route run.

## Shared-file conflict resolutions

- ProcessRuntime.cs: start from destination PR70 bytes; add only IO bounds validation/count initialization. Preserve NativeMetadataImage527 assignment.
- ProcessRuntimeOptions.cs: preserve public NativeMetadataImage; add only DirtyIoSchedulerCount.
- Tests Harness Program.cs: start from destination PR70, preserve all existing metadata527 and dynamic source-hash registrations. Add exactly seven dirty/IO/receive/varargs groups. Do not copy primary Program.cs wholesale. The tiny new NifPhysicalCustody521Names supplies the three existing native-flags test IDs without importing ManagedContractBatch513Names or capture WIP.
- Native backend Program.cs: add only the existing real dirty-child entry with explicit owned and IO-worker factory. Keep every other destination dispatcher intact.
- DirtyNative419Access.cs: preserve the seventh optional settlement argument as explicit null, matching the changed reflection signature.
- Core csproj: the native asset uses explicit `PackagePath="runtimes/win-x64/native/Erlang.Nif.WindowsVariadic.dll"`, not a directory inferred as a filename; flat output/publish TargetPath remains intact.

## Explicit exclusions

No build-profile521 implementation/test/tool; no kernel/boot experiments; no managed capture/trace520 or ManagedContractBatch513 child/batch implementation; no selected-library authority experiment; no map523/shared-HAMT/header526 changes or their tests; no metadata527 replacement from the older primary branch. All destination metadata527 source, witness checks, helper, collector/sealer and registrations remain authoritative. No library/module/API ledger or changelog is silently copied. Parent publication documentation must describe the finite native scope and keep all24 known contracts open.

## Source-plan and native-asset handling

The two primary dirty/variadic source-plan.json files are deliberately NOT payloads; see reseal-only-plans.json. Their seals refer to the primary source composition and must not be copied into the projected branch. After all source/style changes, run each existing sealer in the destination: dirty tool `seal.py --repository <destination>` and variadic tool `seal-source-plan.py`. Existing admitted provider/header/golden artifacts must be retained, not regenerated as expected managed output.

The DLL payload SHA C854474AB72CD521AA065DAEE6766F7ED532D9254F7E020154244F049B150821 is bound to actual source9F862DA2... and build receipt under evidence. It is a build product, not a claim of ABI completeness. Parent may publish the reviewed runtime asset or regenerate it from the exact C source before packaging. A Windows CI build/test/pack path MUST install the produced DLL at the declared source asset path before managed native tests/pack. Reuse `build-windows-varargs526.py --repository <destination> --source-sha256 <allowlisted C SHA> --output <fresh artifacts path>`, then copy its DLL into the declared runtimes/win-x64/native folder. Keep fresh build/export/dependency receipt. NuGet must be tested with an ordinary independent consumer, including RID-folder resolution, on the projected commit. Linux managed tests must not attempt to build/load this Windows asset; packaging still requires the actual Windows asset to be present as declared.

## Evidence and validation boundary

`evidence` retains parent's actual seven-flag/four-route28 comparison completion, variadic four-route completion and adapter build receipt. These receipts belong to the earlier actual primary composition and are diagnostic/provenance inputs; they do not prove the newly projected branch. Old AV/original lifecycle failures remain in their original artifact directories. This packet's static checks verify hashes, preserved metadata/source-hash registrations, IO reflection argument and explicit NuGet filename; Python AST checks do not execute collectors.

Parent next: verify allowlist/preimages and scope; promote atomically; style changed source; build serially; run the seven new groups plus dirty/native/image-lifetime/loader/receive398 affected regressions; reseal final sources; perform genuine admitted original/managed whole native comparisons as applicable and ordinary NuGet asset consumer; update English changelog/current module documents; publish exact projected commit and require green mandatory CI. Do not infer complete native ABI/crypto/resource-policy compatibility from flags or finite vararg coverage.
