import subprocess,json,hashlib,sys
from pathlib import Path
root=Path.cwd(); provider=root.parent/'Erlang.Net/artifacts/library376-official-compiler/official-admission.json'
jobs=[('Erlang.NifMapFamily504Observations','artifacts/native-map504/repair518-final'),('Erlang.NifMapMaterialized505Observations','artifacts/native-map505/materialized-repair518-final'),('Erlang.NifMapReentry505Observations','artifacts/native-map505/reentry-repair518-final')]
results=[]
for name,out in jobs:
 plan=root/'tools/Native'/name/'source-plan.json';args=[sys.executable,'-B',str(plan.parent/'collect.py'),'--repository',str(root),'--provider-admission',str(provider),'--plan-sha256',hashlib.sha256(plan.read_bytes()).hexdigest().upper(),'--output',out,'--check-golden','--both-runtime-profiles516']
 with (root/'artifacts/repair518'/f'{name}.log').open('wb') as log:r=subprocess.run(args,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=240)
 results.append({'Tool':name,'ExitCode':r.returncode});print(results[-1],flush=True)
(root/'artifacts/repair518/native-comparisons.json').write_bytes((json.dumps(results,indent=2)+'\n').encode());sys.exit(0 if all(x['ExitCode']==0 for x in results) else 1)
