/*
 * %CopyrightBegin%
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Copyright Ericsson AB 1996-2026. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * %CopyrightEnd%
 */

// Modified: isolated source replay; addresses are observations, not runtime inputs.
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <assert.h>
typedef unsigned char byte;
typedef uint64_t Uint64;
typedef uint32_t Uint32;
typedef uintptr_t UWord;
typedef unsigned int Uint;
typedef int (*erts_void_ptr_cmp_t)(const void*,const void*);
typedef struct { byte *pivot_part_start,*pivot_part_end; } erts_qsort_partion_array_result;
typedef struct { uint64_t hx,skip,i,val; } hxnode_t;
#define ASSERT assert
#define sys_memcpy memcpy
#define YCF_CONSUME_REDS(x)
#define list_val(x) (x)
#define CAR(x) (keys[(x)])
#define EQ(a,b) ((a)==(b))
#define THE_NON_VALUE (-1)
static Uint64 observed_base,observed_comparer;
static byte* initial_base;
static unsigned keys[33];
static Uint64 addresses[4];
static int phase;
static void erts_qsort_swap(size_t,void*,void*);
static void erts_qsort_insertion_sort(byte*,size_t,size_t,erts_void_ptr_cmp_t);
Uint32 erts_sched_local_random_hash_64_to_32_shift(Uint64 key)
{
    key = (~key) + (key << 18); /* key = (key << 18) - key - 1; */
    key = key ^ (key >> 31);
    key = (key + (key << 2)) + (key << 4);
    key = key ^ (key >> 11);
    key = key + (key << 6);
    key = key ^ (key >> 22);
    return (Uint32) key;
}
static void erts_qsort_helper(byte *base,
                              size_t nr_of_items,
                              size_t item_size,
                              erts_void_ptr_cmp_t compare,
                              Uint32 extra_seed);
static erts_qsort_partion_array_result
erts_qsort_partion_array(byte *base,
                         size_t nr_of_items,
                         size_t item_size,
                         erts_void_ptr_cmp_t compare,
                         Uint32 extra_seed);

static void erts_qsort_swap(size_t item_size,
                            void* iptr,
                            void* jptr)
{
    ASSERT(item_size % sizeof(UWord) == 0);

    if (iptr != jptr) {
        /* Do it word by word */
        UWord* iwp = (UWord*) iptr;
        UWord* jwp = (UWord*) jptr;
	size_t cnt;
        for (cnt = item_size / sizeof(UWord); cnt; cnt--) {
            UWord tmp;
	    sys_memcpy(&tmp, jwp, sizeof(UWord));
	    sys_memcpy(jwp, iwp, sizeof(UWord));
	    sys_memcpy(iwp, &tmp, sizeof(UWord));
	    jwp++;
            iwp++;
        }
    }
}

/* **Important Note**
 *
 * A yielding version of this function is generated with YCF. This
 * means that the code has to follow some restrictions. See note about
 * YCF near the top of the file for more information.
 */
static erts_qsort_partion_array_result
erts_qsort_partion_array(byte *base,
                         size_t nr_of_items,
                         size_t item_size,
                         erts_void_ptr_cmp_t compare,
                         Uint32 extra_seed)
{
    /*
      The array is portioned using a fast-path-slow-path approach. We
      first assume that the there is no duplicates of the selected
      pivot item in the array. If this assumption holds, we only need
      to keep track of two regions (items greater than the pivot, and
      items smaller than the pivot) which leads to fewer swaps than if
      we need to keep track of three regions (items greater than the
      pivot, items smaller than the pivot, and items equal to the
      pivot). If we find an item that is equal to the pivot, we fall
      back to the slow path that keeps track of three regions.

      Start of fast path:
     */
    byte* second_part_start = base + (nr_of_items * item_size);
    byte* curr = base + item_size;
    int more_than_one_pivot_item = 0;
    size_t pivot_index =
        ((size_t)erts_sched_local_random_hash_64_to_32_shift((Uint64)extra_seed +
                                                             observed_comparer +
                                                             (observed_base + (Uint64)(base - initial_base)) -
                                                             (Uint64)nr_of_items)) % nr_of_items;
    /* Move pivot first */
    erts_qsort_swap(item_size, base, base + pivot_index * item_size);
    while (curr != second_part_start) {
        int compare_res = compare(curr, base);
        if (compare_res < 0) {
            /* Include in first part */
            curr += item_size;
        } else if (compare_res == 0) {
            more_than_one_pivot_item = 1;
            break;
        } else {
            /* Move to last part */
            second_part_start -= item_size;
            erts_qsort_swap(item_size, curr, second_part_start);
        }
    }
    if (!more_than_one_pivot_item) {
        /* Fast path successful (we don't need to use the slow path) */
        /* Move the pivot before the second part (if any) */
        erts_qsort_partion_array_result res;
        res.pivot_part_start = second_part_start - item_size;
        res.pivot_part_end = second_part_start;
        erts_qsort_swap(item_size, base, res.pivot_part_start);
        return res;
    } else {
        /*
           We have more than one item equal to the pivot item and need
           to keep track of three regions.

           Start of slow path:
        */
        byte * pivot_part_start = curr - item_size;
        byte * pivot_part_end = curr + item_size;
        byte * last_part_start = second_part_start;

	erts_qsort_swap(item_size, base, pivot_part_start);

        while (pivot_part_end != last_part_start) {
            int compare_res =
                compare(pivot_part_end, pivot_part_end - item_size);
            if (compare_res == 0) {
                /* Include in pivot part */
                pivot_part_end += item_size;
            } else if (compare_res < 0) {
                /* Move pivot part one step to the right */
                erts_qsort_swap(item_size, pivot_part_start, pivot_part_end);
                pivot_part_start += item_size;
                pivot_part_end += item_size;
            } else {
                /* Move to last part */
                last_part_start -= item_size;
                erts_qsort_swap(item_size, pivot_part_end, last_part_start);
            }
        }
        {
            erts_qsort_partion_array_result res;
            res.pivot_part_start = pivot_part_start;
            res.pivot_part_end = pivot_part_end;
            return res;
        }
    }
}

static void erts_qsort_insertion_sort(byte *base,
                                      size_t nr_of_items,
                                      size_t item_size,
                                      erts_void_ptr_cmp_t compare)
{
    byte *unsorted_start = base;
    byte *end;

    if (nr_of_items < 2) {
        return;
    }

    end = base + ((nr_of_items-1) * item_size);

    while (unsorted_start < end) {
        byte *smallest_so_far = unsorted_start;
        byte *curr = smallest_so_far + item_size;
        while (curr <= end) {
            if (compare(curr, smallest_so_far) < 0) {
                smallest_so_far = curr;
            }
            curr += item_size;
        }
        if (smallest_so_far != unsorted_start) {
            erts_qsort_swap(item_size, unsorted_start, smallest_so_far);
        }
        unsorted_start += item_size;
    }
}

/* **Important Note**
 *
 * A yielding version of this function is generated with YCF. This
 * means that the code has to follow some restrictions. See note about
 * YCF near the top of the file for more information.
 */
static void erts_qsort_helper(byte *base,
                              size_t nr_of_items,
                              size_t item_size,
                              erts_void_ptr_cmp_t compare,
                              Uint32 extra_seed)
{
    erts_qsort_partion_array_result partion_info;
    size_t nr_of_items_in_first_partion;
    size_t nr_of_items_second_partion;
    const size_t qsort_cut_off = 16;
    if (nr_of_items <= qsort_cut_off) {
        erts_qsort_insertion_sort(base, nr_of_items, item_size, compare);
        YCF_CONSUME_REDS(nr_of_items * erts_fit_in_bits_int64(nr_of_items) * 2);
        return;
    }
    partion_info = erts_qsort_partion_array(base,
                                            nr_of_items,
                                            item_size,
                                            compare,
                                            extra_seed);
    nr_of_items_in_first_partion =
        ((partion_info.pivot_part_start - base) / sizeof(byte)) / item_size;
    nr_of_items_second_partion =
        nr_of_items - (((partion_info.pivot_part_end - base) / sizeof(byte)) / item_size);
    erts_qsort_helper(base,
                      nr_of_items_in_first_partion,
                      item_size, compare,
                      extra_seed + 1);
    erts_qsort_helper(partion_info.pivot_part_end,
                      nr_of_items_second_partion,
                      item_size,
                      compare,
                      extra_seed + 1);
}


static int hxnodecmp(const void*a,const void*b) { return 0; }
static int hxnodecmpkey(const void*a,const void*b) { return 0; }
static void erts_qsort(void *base,size_t n,size_t size,erts_void_ptr_cmp_t compare) {
 observed_base=addresses[phase*2]; observed_comparer=addresses[phase*2+1];
 initial_base=(byte*)base; phase++;
 erts_qsort_helper(base,n,size,compare,1);
}
int main(int argc,char**argv) {
 hxnode_t hxns[33]; Uint n=33,ix,jx,lx,cx; int reject_dupkeys=0;
 if(argc!=5 || sizeof(hxnode_t)!=32) return 2;
 for(int k=0;k<4;k++) addresses[k]=_strtoui64(argv[k+1],NULL,10);
 for(int k=0;k<33;k++){ keys[k]=k%2; hxns[k]=(hxnode_t){0,1,k,k}; }
 erts_qsort(hxns,n,sizeof(hxnode_t),hxnodecmp);
    ix = 0, cx = 0;
    while(ix < n - 1) {
	if (hxns[ix].hx == hxns[ix+1].hx) {

	    /* find region of equal hash values */
	    jx = ix + 2;
	    while(jx < n && hxns[ix].hx == hxns[jx].hx) { jx++; }
	    /* find all correct keys from region
	     * (last in list but now hash sorted so we check highest id instead) */

	    /* resort with keys instead of hash value within region */

	    erts_qsort(&hxns[ix], jx - ix, sizeof(hxnode_t), hxnodecmpkey);

	    while(ix < jx) {
		lx = ix;
		while(++ix < jx && EQ(CAR(list_val(hxns[ix].val)),
				      CAR(list_val(hxns[lx].val)))) {
                    if (reject_dupkeys)
                        return THE_NON_VALUE;

                    if (hxns[ix].i > hxns[lx].i) {
			lx = ix;
		    }
		}
		hxns[cx].hx  = hxns[lx].hx;
		hxns[cx].val = hxns[lx].val;
		cx++;
	    }
	    ix = jx;
	    continue;
	}
	if (ix > cx) {
	    hxns[cx].hx  = hxns[ix].hx;
	    hxns[cx].val = hxns[ix].val;
	}
	cx++;
	ix++;
    }

    if (ix < n) {
	hxns[cx].hx  = hxns[ix].hx;
	hxns[cx].val = hxns[ix].val;
	cx++;
    }


 printf("{\"Count\":%u,\"Ordinals\":[",cx);
 for(unsigned k=0;k<cx;k++) printf("%s%llu",k?",":"",(unsigned long long)hxns[k].val);
 printf("]}\n"); return 0;
}
