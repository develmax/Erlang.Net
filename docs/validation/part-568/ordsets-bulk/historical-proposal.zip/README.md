# Bulk physical occurrence preservation: isolated review proposal

2026-11-03. This package is a draft, not an integrated or verified compatibility checkpoint. No common source, index, readiness ledger, branch or PR was changed by this work.

## Problem and change

The previous source proposal used an ordinary `MapTerm` constructor for inputs longer than 32 pairs. Its dictionary globally removed exact duplicate keys. OTP-29.1.1 instead sorts hash nodes, sorts each equal-hash region by `CMP_TERM`, and compacts only adjacent `EQ` keys, retaining the greatest input ordinal inside each adjacent run. Exact-distinct local funs with equal comparison keys can separate exact repeats. Physical occurrences therefore survive.

The proposal preserves the existing one-argument `MapOperations.FromList` ABI and adds an internal runtime-aware overload for the registered `maps:from_list/1` binding. Its bulk path reuses the runtime hash provider, hash owner admission/close protocol and native map materialization. Hash nodes contain four 64-bit words, matching the pinned profile. The source quicksort observes its actual pinned buffer address and actual comparer function pointer. It retains the two independent sort phases, adjacent-only exact compaction and original ordinal rule. HAMT construction preserves the resulting collision sequence instead of sorting it again. A result of at most 32 occurrences traverses its temporary HAMT and uses the source flat validation behavior, including the ignored early failure on comparison equality.

The package includes the preceding comparison, guard, flat-order, hash and detached-copy proposals: 23 distinct production files in total. `receipt.json` identifies every source byte and the exact ad791 source-only base. `SourceBulk.targets` is a portable flattened overlay; the measured build used the original chained targets with the same selected source bytes. The flattened overlay has not itself been rebuilt.

## Evidence actually obtained

The isolated four-project build completed with zero warnings and zero errors. Terms MVID: `aa63e1d0-c8b4-41fb-bfe1-c40c864af75b`. All six runner assembly hashes are retained.

Both the initial and instrumented twelve-row fixture executions completed. Eleven rows are byte-identical to the pinned original ETF on both backends, including complete error stacks for invalid tuple and improper input. `bulk_repeat_33` remains RED against the recorded original result of 33 occurrences. The first run produced 31/30 occurrences; the instrumented run produced 32/29. Both returned `find(A) = {ok,a}` and `find(B) = {ok,b}`, where the previous candidate had size 2 and `find(A) = {ok,c}`. Initial evidence is preserved separately in `evidence/replay1`.

The instrumented run captured actual buffer/comparer addresses, seeds and pivots. The final pair of events belongs to the final bulk repeat input. An independent MSVC-compiled replay of the pinned C quicksort and adjacent compaction produced exactly 32/29 with those observed addresses and seed 1. No seed or address was selected to match 33. Address arithmetic is explicitly rebound only inside the offline C replay; production takes its own actual addresses. C comparators are specialized to the established equal-hash/equal-comparison pair used by this input. The observed count agrees with C; this is not a proof of all output occurrence sequences or all terms.

`source-replay.c` retains the original C routines and notices; the only changes inside quicksort are two explicit substitutions mapping its local buffer/comparer addresses to the recorded runtime addresses. Its raw stdout contains escaped JSON, retained unchanged. `evidence/probe/C-source-replay.json` contains the decoded report. The raw ETF files and RED receipts are retained unchanged. The shell invocation that ran the instrumented probe followed by the diff script returned the diff script's zero exit code; the probe receipts themselves explicitly record `WholeEtfMatches=false` and are the semantic verdict.

## Open acceptance gates

1. Independent review of source correspondence and the platform/context contract. A single recorded 33 result is not a context-independent golden value for this non-total comparison input. No oracle result was normalized or replaced.
2. Exact physical sequence and ordinal checks, duplicate-preserving HAMT and flat boundary cases, source-aware detached copy, cross-runtime transfer, exception/cancellation/close and retained hash lease controls.
3. Inputs above 128 entries: the proposal uses its own runtime entropy, but correspondence to scheduler-local seed semantics is not established. No universal platform claim is made.
4. Full targeted regression matrix on the final integrated source, permanent tests, style/license review and canonical English checkpoint documentation.
5. Actual merge SHA, required current-head CI/reviews, and genuine complete postmerge checks. The existing PR102 is not merged at this checkpoint; its full/CI outcomes do not validate this proposal.
6. Remaining deterministic ETF/physical map and other source-contract gates described in the earlier audit. This package does not close those by assertion.

Readiness remains 6 Verified / 15 KnownDifferences / 0 PendingVerification, with 21 registered ordsets APIs. Neither 21/21 compatibility nor completion of the bulk audit is claimed.

## Reference and reuse

Pinned OTP-29.1.1 commit: `ad05823719d77c8faee87348ea39513d4e2f99c5`. Reviewed pinned `erts/emulator/beam/erl_map.c`, `utils.c`, `erl_process.h` and existing local ownership/materialization code. The C source replay and CLR sorter/compactor are modified adaptations of Ericsson Apache-2.0 code; full upstream notices remain in the included source files and the repository's existing license texts apply. No new package dependency, external implementation or production Erlang VM dependency was added. Pure ordsets/list module implementations remain unchanged.
