"""Prepare reviewed548 seal updates from Git INDEX bytes only; never applies/stages them."""
import argparse,hashlib,json,pathlib,subprocess
ap=argparse.ArgumentParser();ap.add_argument('--repository',type=pathlib.Path,required=True);ap.add_argument('--output',type=pathlib.Path,required=True);a=ap.parse_args();r=a.repository.resolve();out=a.output.resolve()
if out.exists():raise RuntimeError('Fresh output required')
def git(*args):return subprocess.check_output(['git','-C',str(r),*args])
def index(p):return git('show',':'+p)
def sha(b):return hashlib.sha256(b).hexdigest().upper()
def enc(d):return (json.dumps(d,indent=2)+'\n').encode()
overlay={}; pre={}
def read(p):return overlay.get(p,index(p))
def put(p,b):pre.setdefault(p,sha(index(p)));overlay[p]=b
beam='src/Runtime/Erlang.Runtime.Core/Execution/Beam/'
prod=[beam+n for n in ['BeamLocalFrame.Owned507.cs','BeamOwnedRoots507.cs','BeamRegisterState.Owned507.cs','BeamConstructedCommit548Names.cs']]
tests=['tests/Erlang.Tests/Runtime/Memory/'+n for n in ['BeamConstructedCommit548Checks.cs','BeamConstructedCommit548TestNames.cs']]
harness='tests/Erlang.Tests/Harness/Program.cs'
for p in prod+tests+[harness]:index(p) # New files MUST already be explicitly staged.
owned='tools/Runtime/Erlang.OwnedGuest506Observations/'
sealer=owned+'seal.py';b=index(sealer);needle=b'DEPENDENCIES = [\n';newline=b'\n'
if needle not in b:needle=b'DEPENDENCIES = [\r\n';newline=b'\r\n'
if b.count(needle)!=1:raise RuntimeError('Unexpected sealer preimage')
add=[p for p in prod+tests if ("'"+p+"'").encode() not in b]
put(sealer,b.replace(needle,needle+b''.join(('    '+repr(p)+',').encode()+newline for p in add),1))
changed=set(prod+tests+[harness,sealer])
# Both ledger bindings are raw SHA; preserve every MFA status, scope, witness and count.
for p in ['docs/mfa-compatibility.json','docs/module-readiness.json']:
 d=json.loads(index(p));rows=d['VerifiedSourceFiles']
 for row in rows:
  if row['Path'] in prod:row['Sha256']=sha(index(row['Path']))
 for name in prod:
  if not any(x['Path']==name for x in rows):rows.append({'Path':name,'Sha256':sha(index(name))})
 put(p,enc(d))
plans=[owned+'source-plan.json','tools/Native/Erlang.NifPendingVarargsObservations/reviewed-source-plan.json','tools/Native/Erlang.NifReallocationObservations/SOURCE-PLAN.json','tools/Native/Erlang.NifVariadic526Observations/source-plan.json']
oldplans={p:sha(index(p)) for p in plans}
def refresh(row,base):
 name=row.get('Path');name=base+name if row.get('Scope')=='Tool' else name
 if name not in changed:return
 mode=row.get('HashMode')
 if mode not in ['Raw','BinaryExact','TextLF']:raise RuntimeError('Unknown hash mode: '+str(mode))
 data=read(name)
 if mode=='TextLF':data=data.replace(b'\r\n',b'\n')
 row['Sha256']=sha(data)
 for key in ['Bytes','SealedBytes']:
  if key in row:row[key]=len(data)
for p in plans:
 d=json.loads(index(p));rows=d.get('Inputs',d.get('Files'));base=p.rsplit('/',1)[0]+'/'
 for row in rows:refresh(row,base)
 # Preserve existing scopes; add real new compilation dependencies, never phantom fixtures.
 new=prod+tests if p==plans[0] else ([prod[-1]]+tests if p in plans[1:3] else [prod[-1]])
 for name in new:
  if any(x.get('Path')==name for x in rows):continue
  data=index(name)
  if p==plans[0]:row={'Scope':'Repository','Path':name,'HashMode':'Raw','Sha256':sha(data),'SealedBytes':len(data)}
  elif p==plans[-1]:row={'Scope':'Repository','Path':name,'HashMode':'Raw','Sha256':sha(data)}
  else:
   mode='BinaryExact' if name.startswith('src/') else 'TextLF';data=data if mode=='BinaryExact' else data.replace(b'\r\n',b'\n');row={'Path':name,'HashMode':mode,'Bytes':len(data),'Sha256':sha(data)}
  rows.append(row)
 put(p,enc(d));changed.add(p)
# Existing manual workflow literal plan pins, if any, must follow the new reviewed seals.
workflows=[]
for raw in git('ls-files','-z','--','.github/workflows').split(b'\0'):
 if not raw:continue
 p=raw.decode();b=index(p);new=b
 for plan,old in oldplans.items():
  for token in [old,old.lower()]:new=new.replace(token.encode(),sha(overlay[plan]).encode())
 if new!=b:put(p,new);workflows.append(p)
# Do not silently create workflow/source-plan cycles in the two explicitly bound506 workflows.
if set(workflows)&{'.github/workflows/validate.yml','.github/workflows/owned-guest506-original.yml'}:raise RuntimeError('Unexpected506 workflow mutation: review/reseal dependency order explicitly')
out.mkdir(parents=True)
rows=[]
for p,b in overlay.items():
 dest=out/'staged-tree'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);rows.append({'Path':p,'IndexPreimageSha256':pre[p],'ProposedSha256':sha(b),'Bytes':len(b)})
receipt={'SourceOnly':True,'Applied':False,'InputAuthority':'Git index, never unstaged worktree','Head':git('rev-parse','HEAD').decode().strip(),'Files':rows,'PlanHashes':{p:sha(overlay[p]) for p in plans},'WorkflowLiteralPinsChanged':workflows,'CompatibilityStatusesChanged':False,'HistoricalReceiptsChanged':False,'PhantomNativeFixturesIncluded':False}
(out/'proposal.json').write_bytes(enc(receipt));print(json.dumps(receipt,indent=2))
