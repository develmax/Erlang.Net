"""Prepare reviewed548 seal updates from Git INDEX bytes only; never applies/stages them."""
import argparse,hashlib,json,pathlib,subprocess
ap=argparse.ArgumentParser();ap.add_argument('--repository',type=pathlib.Path,required=True);ap.add_argument('--output',type=pathlib.Path,required=True);a=ap.parse_args();r=a.repository.resolve();out=a.output.resolve()
if out.exists():raise RuntimeError('Fresh output required')
def git(*args):return subprocess.check_output(['git','-C',str(r),*args])
# One persistent read-only Git object reader, not thousands of shell launches.
index_objects={}
for entry in git('ls-files','--stage','-z').split(b'\0'):
 if not entry:continue
 meta,path=entry.split(b'\t',1);mode,oid,stage=meta.split()
 if stage!=b'0':raise RuntimeError('Unmerged index entries are not admissible')
 index_objects[path.decode('utf-8')]=oid
reader=subprocess.Popen(['git','-C',str(r),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
def index(p):
 if p not in index_objects:raise RuntimeError('Required source is not staged/indexed: '+p)
 reader.stdin.write(index_objects[p]+b'\n');reader.stdin.flush();header=reader.stdout.readline().split()
 if len(header)!=3 or header[1]!=b'blob':raise RuntimeError('Expected indexed blob: '+p)
 count=int(header[2]);data=reader.stdout.read(count)
 if len(data)!=count or reader.stdout.read(1)!=b'\n':raise RuntimeError('Truncated indexed blob: '+p)
 return data
def sha(b):return hashlib.sha256(b).hexdigest().upper()
def enc(d):return (json.dumps(d,indent=2)+'\n').encode()
overlay={}; pre={}
def read(p):return overlay.get(p,index(p))
def put(p,b):pre.setdefault(p,sha(index(p)));overlay[p]=b
beam='src/Runtime/Erlang.Runtime.Core/Execution/Beam/'
prod=[beam+n for n in ['BeamLocalFrame.Owned507.cs','BeamOwnedRoots507.cs','BeamRegisterState.Owned507.cs','BeamConstructedCommit548Names.cs']]
tests=['tests/Erlang.Tests/Runtime/Memory/'+n for n in ['BeamConstructedCommit548Checks.cs','BeamConstructedCommit548TestNames.cs']]
harness='tests/Erlang.Tests/Harness/Program.cs'
for p in prod+tests+[harness]:index(p) # New files MUST already be explicitly staged.
owned='tools/Runtime/Erlang.OwnedGuest506Observations/'
sealer=owned+'seal.py';b=index(sealer);needle=b'DEPENDENCIES = [\n';newline=b'\n'
if needle not in b:needle=b'DEPENDENCIES = [\r\n';newline=b'\r\n'
if b.count(needle)!=1:raise RuntimeError('Unexpected sealer preimage')
add=[p for p in prod+tests if ("'"+p+"'").encode() not in b]
put(sealer,b.replace(needle,needle+b''.join(('    '+repr(p)+',').encode()+newline for p in add),1))
changed=set(prod+tests+[harness,sealer])
# Preserve ledger lexical bytes: replace only three hash spans and append one member.
import re
for p in ['docs/mfa-compatibility.json','docs/module-readiness.json']:
 original=index(p);text=original.decode('utf-8');parsed=json.loads(original)
 marker='"VerifiedSourceFiles": ['
 if text.count(marker)!=1:raise RuntimeError('Ambiguous ledger source array: '+p)
 begin=text.index(marker)+len(marker);decoder=json.JSONDecoder();array_start=begin-1
 decoded,consumed=decoder.raw_decode(text[array_start:]);end=array_start+consumed
 if decoded!=parsed['VerifiedSourceFiles']:raise RuntimeError('Ledger source-array parse mismatch')
 segment=text[begin:end-1];before=segment
 for name in prod[:-1]:
  pattern=r'("Path"\s*:\s*"'+re.escape(name)+r'"\s*,\s*"Sha256"\s*:\s*")([A-Fa-f0-9]{64})(")'
  segment,count=re.subn(pattern,lambda m:m.group(1)+sha(index(name))+m.group(3),segment)
  if count!=1:raise RuntimeError('Expected one existing ledger binding: '+name)
 name=prod[-1]
 if any(row['Path']==name for row in decoded):raise RuntimeError('New Names548 ledger row already present; use fresh reviewed preimage')
 nl='\r\n' if '\r\n' in segment else '\n'
 # Preserve existing trailing array whitespace and clone the serializer indentation.
 tail=re.search(r'\s*$',segment).group(0);body=segment[:-len(tail)] if tail else segment
 member=nl+'    {'+nl+'      "Path": "'+name+'",'+nl+'      "Sha256": "'+sha(index(name))+'"'+nl+'    }'
 segment=body+','+member+tail
 result=(text[:begin]+segment+text[end-1:]).encode('utf-8')
 actual=json.loads(result);expected=json.loads(original)
 for row in expected['VerifiedSourceFiles']:
  if row['Path'] in prod[:-1]:row['Sha256']=sha(index(row['Path']))
 expected['VerifiedSourceFiles'].append({'Path':name,'Sha256':sha(index(name))})
 if actual!=expected:raise RuntimeError('Ledger semantics changed outside allowed binding delta')
 put(p,result)
plans=[owned+'source-plan.json','tools/Native/Erlang.NifPendingVarargsObservations/reviewed-source-plan.json','tools/Native/Erlang.NifReallocationObservations/SOURCE-PLAN.json','tools/Native/Erlang.NifVariadic526Observations/source-plan.json']
oldplans={p:sha(index(p)) for p in plans}
# Fail on unrelated stale source rows; never bless them by opportunistic resealing.
def resolved_name(row,base):
 name=row.get('Path');return base+name if row.get('Scope')=='Tool' else name
unrelated=[]
for plan in plans:
 d=json.loads(index(plan));base=plan.rsplit('/',1)[0]+'/'
 for row in d.get('Inputs',d.get('Files')):
  name=resolved_name(row,base)
  if name in changed or name in plans:continue
  mode=row.get('HashMode')
  if mode not in ['Raw','BinaryExact','TextLF']:raise RuntimeError('Unknown source row mode: '+repr(row))
  data=index(name)
  if mode=='TextLF':data=data.replace(b'\r\n',b'\n')
  sizebad=any(row[k]!=len(data) for k in ['Bytes','SealedBytes'] if k in row)
  if row['Sha256'].upper()!=sha(data) or sizebad:unrelated.append({'Plan':plan,'Path':name,'ExpectedSha256':row['Sha256'],'ActualIndexSha256':sha(data),'SizeMismatch':sizebad})
if unrelated:raise RuntimeError('Unrelated source-plan mismatches require separate review; no output written: '+json.dumps(unrelated))
def refresh(row,base):
 name=row.get('Path');name=base+name if row.get('Scope')=='Tool' else name
 if name not in changed:return
 mode=row.get('HashMode')
 if mode not in ['Raw','BinaryExact','TextLF']:raise RuntimeError('Unknown hash mode: '+str(mode))
 data=read(name)
 if mode=='TextLF':data=data.replace(b'\r\n',b'\n')
 row['Sha256']=sha(data)
 for key in ['Bytes','SealedBytes']:
  if key in row:row[key]=len(data)
for p in plans:
 d=json.loads(index(p));rows=d.get('Inputs',d.get('Files'));base=p.rsplit('/',1)[0]+'/'
 for row in rows:refresh(row,base)
 # Preserve existing scopes; add real new compilation dependencies, never phantom fixtures.
 new=prod+tests if p==plans[0] else ([prod[-1]]+tests if p in plans[1:3] else [prod[-1]])
 for name in new:
  if any(x.get('Path')==name for x in rows):continue
  data=index(name)
  if p==plans[0]:row={'Scope':'Repository','Path':name,'HashMode':'Raw','Sha256':sha(data),'SealedBytes':len(data)}
  elif p==plans[-1]:row={'Scope':'Repository','Path':name,'HashMode':'Raw','Sha256':sha(data)}
  else:
   mode='BinaryExact' if name.startswith('src/') else 'TextLF';data=data if mode=='BinaryExact' else data.replace(b'\r\n',b'\n');row={'Path':name,'HashMode':mode,'Bytes':len(data),'Sha256':sha(data)}
  rows.append(row)
 put(p,enc(d));changed.add(p)
# Existing manual workflow literal plan pins, if any, must follow the new reviewed seals.
workflows=[]
for raw in git('ls-files','-z','--','.github/workflows').split(b'\0'):
 if not raw:continue
 p=raw.decode();b=index(p);new=b
 for plan,old in oldplans.items():
  for token in [old,old.lower()]:new=new.replace(token.encode(),sha(overlay[plan]).encode())
 if new!=b:put(p,new);workflows.append(p)
# Do not silently create workflow/source-plan cycles in the two explicitly bound506 workflows.
if set(workflows)&{'.github/workflows/validate.yml','.github/workflows/owned-guest506-original.yml'}:raise RuntimeError('Unexpected506 workflow mutation: review/reseal dependency order explicitly')
out.mkdir(parents=True)
rows=[]
for p,b in overlay.items():
 dest=out/'staged-tree'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);rows.append({'Path':p,'IndexPreimageSha256':pre[p],'ProposedSha256':sha(b),'Bytes':len(b)})
receipt={'SourceOnly':True,'Applied':False,'InputAuthority':'Git index, never unstaged worktree','Head':git('rev-parse','HEAD').decode().strip(),'Files':rows,'PlanHashes':{p:sha(overlay[p]) for p in plans},'WorkflowLiteralPinsChanged':workflows,'CompatibilityStatusesChanged':False,'HistoricalReceiptsChanged':False,'PhantomNativeFixturesIncluded':False}
(out/'proposal.json').write_bytes(enc(receipt));reader.stdin.close();reader.stdout.close();reader.wait();print(json.dumps(receipt,indent=2))
