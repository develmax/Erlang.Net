# Constructed BEAM candidate commit: exact source proof and controls

This packet is SOURCE ONLY. No production/test files were actively changed, compiled, run in a VM, executed natively, sent to CI or committed. No elapsed-time gain is claimed. Parent alone integrates after exact preimage/absence checks and executes red/green/affected validation.

## Existing repeated operation

WriteTuple507/WriteCons507 protects input children with the unchanged temporary builder. roots507.Tuple/Cons calls Frame.CreateTupleInto507/CreateConsInto507: validates each child under the actual heap gate, allocates real owned storage and publishes Candidate through PublishRoot512 (actual binary/native admission). The returned Term is already owned by that registered Candidate.

The old X path immediately calls WriteXSlot507(false); the old Y path calls WriteRaw504(false). Both invoke roots507.Prepare and SetLocalGraph507 on the SAME Candidate with the SAME Term, repeating complete graph validation and binary/native publication. This is independent of the collector/allocator complexity and requires no graph cache to remove.

## New authority and commit boundary

RequireConstructedCandidate548 performs frame.Read(Candidate(index)) under its existing heap gate and checks ReferenceEquals with the exact producer result. It does not infer authority from term type, structural equality, CLR reachability, a module name or cached graph. Disposed/missing/mismatched roots fail closed. Only the two lexical tuple/cons producers call each private commit helper; ordinary/generic/register movement/handler/saved-trace paths still use their original Prepare/adopt validation. No generic already-trusted flag or public API is introduced.

The input builder lifetime stays exactly unchanged and remains alive until the producer exits. The new candidate root is verified before the X array or actual504 cell is written. Only after that write succeeds does the existing roots507.Commit clear old Current and alternate the slots. The existing try/catch Rollback(Candidate) remains around both phases, including actual504 write failure; outer producer rollback stays idempotent as before. Old-root release policy is not otherwise altered.

No await, guest callback or receive checkpoint is inserted between publication and commit. Existing protected receive/try/trim/cancel paths, image/capability admission and code leases are untouched. The heap-gated Read returns before taking a504 word-store gate; the504 write releases its gate before Commit enters the heap gate. No heap/504 lock overlap is added.

The ordinary runtime path retains its old early branch. The new Y helper's roots-null branch calls the unchanged WriteRaw504. Generic unknown/foreign inputs still cannot reach a skip flag: their existing write/validation path is unchanged, while a constructed commit requires exact current Candidate identity.

## Source-derived versus actual counters

For each tested construction, the builder makes one real binary-root retention and the constructed destination makes one. The redundant Prepare made a third. Thus source-derived expected RetainOperations delta is3 before versus2 after in all X/Y x tuple/cons x CLR/504 cases. This is NOT an actual red/green measurement yet. Traversal visits are printed from existing private ProcessBinaryTraversalSnapshot514; no counters are overwritten and no ERTS public metric is invented. Remaining builder and destination walks are retained, so this is not a linear-complexity or boot-deadline completion claim.

## Finite regression design (new source tests, unexecuted)

1. PublicationMatrix runs8 independent owned-runtime combinations. It measures real retained operations/visited terms, requires exactly2 retained operations, checks repeated child aliases and actual binary backing references across real collection, then clears destinations and verifies zero owned backing references. Each of all8 diagnostics is retained before the combined failure, so the old expected3 does not suppress later combinations. This is the meaningful baseline-red target.
2. ClosedPhysicalStoreRollsBack stages an actual Cons through the existing roots producer while old Y mirror storage is live, then closes the real504 execution store through its existing DisposeAsync. Invoking the new private commit step must fail at the real disposed lease write; its own rollback must clear Candidate, return backing references to the old count, preserve old Current identity, and retain only old payload after actual collection. This isolates the exact post-publication failure boundary without a production test hook, fake store or invented exception. State/frame disposal then releases the remaining old mirror root.
3. StaleCandidateRejected refuses reuse of Current as a new Candidate and refuses a structurally equivalent portable impostor while a genuine Candidate exists. It checks that the old register/alias remains valid through collection and cleanup.

The new private-method guard/failure tests require the production helper and are green-only after integration; do not mistake a missing-method error on old source for a meaningful red. Root should first register/run PublicationMatrix against the old source to capture actual3, then apply the production payload and run all3 groups. Existing original-try per-instruction collection, AliasAndTrim, CancelAtTuple, protected receive/cancellation and native/resource controls remain required affected regression. All golden/original fixtures stay unchanged.

## Integration

patches.json binds3 existing production files. One new production Names file and two new test files must be absent. harness-hunk.json binds the current Program and a single insertion anchor. Apply atomically only after every hash/absence guard matches; do not overwrite unrelated root work. Parent may compose the narrow harness hunk on drift. No other runtime or allocator files are included.
