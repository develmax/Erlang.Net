from pathlib import Path
import hashlib
import json
import re
import subprocess

r = Path.cwd()
out = r / 'artifacts/resource542-forward-metadata/plans-forward2'
out.mkdir(exist_ok=False)
sha = lambda b: hashlib.sha256(b).hexdigest().upper()
owned = r / 'tools/Runtime/Erlang.OwnedGuest506Observations/source-plan.json'
subprocess.run(['py', '-3', '-B', 'tools/Runtime/Erlang.OwnedGuest506Observations/seal.py', '--repository', '.', '--replace-plan-sha256', sha(owned.read_bytes())], check=True)
plans = [
    'tools/Native/Erlang.NifPendingVarargsObservations/reviewed-source-plan.json',
    'tools/Native/Erlang.NifReallocationObservations/SOURCE-PLAN.json',
    'tools/Native/Erlang.NifVariadic526Observations/source-plan.json',
    'tools/Native/Erlang.NifPrivateData557Observations/source-plan.json',
]
changes = []

def refresh(name):
    p = r / name
    before = p.read_bytes()
    d = json.loads(before)
    rows = d.get('Inputs', d.get('Files'))
    assert rows is not None
    for row in rows:
        base = p.parent if row.get('Scope') == 'Tool' else r
        target = (base / row['Path']).resolve()
        assert target.is_relative_to(r)
        data = target.read_bytes()
        mode = row['HashMode']
        assert mode in ['Raw', 'TextLF', 'BinaryExact']
        if mode == 'TextLF':
            data = data.replace(b'\r\n', b'\n')
        actual = sha(data)
        if actual != row['Sha256']:
            changes.append(dict(Plan=name, Path=target.relative_to(r).as_posix(), Before=row['Sha256'], After=actual))
            row['Sha256'] = actual
        for key in ['Bytes', 'SealedBytes']:
            if key in row:
                row[key] = len(data)
    (out / p.name.replace('.json', '-before.json')).write_bytes(before)
    p.write_bytes((json.dumps(d, indent=2) + '\n').encode())
    return sha(p.read_bytes())

def pin(workflow, key, digest):
    p = r / workflow
    s = p.read_text()
    pattern = r'(' + re.escape(key) + r': )([0-9A-F]{64})'
    assert len(list(re.finditer(pattern, s))) == 1
    p.write_bytes(re.sub(pattern, lambda m: m.group(1) + digest, s).encode())

pin('.github/workflows/nif-pending-native.yml', 'REVIEWED_SOURCE_PLAN_SHA256', refresh(plans[0]))
pin('.github/workflows/nif-reallocation-native.yml', 'REVIEWED_REALLOCATION_PLAN_SHA256', refresh(plans[1]))
refresh(plans[2])
refresh(plans[3])
(out / 'proof.json').write_text(json.dumps(dict(Changes=changes, WholeContractsClosed=0, OriginalGoldensChanged=False), indent=2) + '\n')
print('Final downstream source-plan cascade refreshed')
