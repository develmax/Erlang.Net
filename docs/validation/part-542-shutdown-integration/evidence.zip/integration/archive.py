from pathlib import Path
import json,hashlib,zipfile
r=Path.cwd();base=r/'artifacts/resource542/shutdown-integration';out=r/'docs/validation/part-542-shutdown-integration';out.mkdir(exist_ok=False)
profiles=[]
for cfg in ['Debug','Release']:
 label=cfg.lower();unit=json.loads((r/f'artifacts/resource542/shutdown-integration-{label}134/result.json').read_bytes());oracle=json.loads((base/f'original-{label}/completion.json').read_bytes());assert unit['Report']['Passed']==134 and unit['Report']['Failed']==0;assert oracle['Passed'] and len(oracle['Equal'])==10 and all(oracle['Equal'].values()) and len(oracle['CleanupCompletedModes'])==6
 profiles.append({'Configuration':cfg,'Cases':134,'WholeStacks':6,'WholeNonopaqueOutcomes':4,'CleanupModes':oracle['CleanupCompletedModes'],'OpaqueFunctionIdsCompared':False,'InputPlanSha256':oracle['InputPlanSha256'],'Assemblies':unit['Assemblies']})
rows=json.loads((base/'source88.json').read_bytes())['Rows']
for row in rows:assert hashlib.sha256((r/row['Path']).read_bytes()).hexdigest().upper()==row['Sha256']
meta=r/'artifacts/resource542-forward-metadata';membership=json.loads((meta/'final-membership.json').read_bytes());assert membership['ExactMembers']==4017
summary={'Passed':True,'Profiles':profiles,'LocalFull504Claimed':False,'Parent371Source':'009658617513ed4e0def79e9f739df4b705d2ad6','Parent371Repeated':False,'Current88Sha256':'B61C526A0FB8465CA396E01C75F75711013998E69BBCE4621EA3AB751BD37114','SourceRows':rows,'Metadata':membership,'ExpectedCatalog':9435,'FullCiPending':True,'ApiDelta':0,'WholeContractDelta':0,'GeneralNestedFactoryPropagationClosed':False,'ResourceBearingShutdownDerivedPublicationClosed':False}
(out/'summary.json').write_text(json.dumps(summary,indent=2))
files=[]
for prefix,folder in [('integration',base),('metadata',meta),('debug134',r/'artifacts/resource542/shutdown-integration-debug134'),('release134',r/'artifacts/resource542/shutdown-integration-release134')]:
 for p in sorted(folder.rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:files.append((prefix+'/'+p.relative_to(folder).as_posix(),p))
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in files:z.writestr(name,p.read_bytes())
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(files)==len(set(z.namelist()))
 for name,p in files:assert z.read(name)==p.read_bytes()
receipt={'Sha256':hashlib.sha256(archive.read_bytes()).hexdigest().upper(),'Bytes':archive.stat().st_size,'Members':len(files),'EveryMemberVerified':True};(out/'archive.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
