from pathlib import Path
import json,hashlib,importlib.util,os
r=Path.cwd();o=r/'artifacts/resource542/shutdown-integration/builds';o.mkdir(exist_ok=False);freeze=json.loads((o.parent/'source88.json').read_bytes());spec=importlib.util.spec_from_file_location('owned',r/'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def check():
 for row in freeze['Rows']:assert hashlib.sha256((r/row['Path']).read_bytes()).hexdigest().upper()==row['Sha256']
rows=[]
for cfg in ['Debug','Release']:
 check();receipt=m.owned(['dotnet','build','tests/Erlang.Tests/Erlang.Tests.csproj','-c',cfg,'--no-restore','-m:1','-p:UseSharedCompilation=false','-p:BuildInParallel=false','-v:q'],o,'build-'+cfg,240,dict(os.environ,DOTNET_PROCESSOR_COUNT='1',DOTNET_GCConserveMemory='9'),str(r));check();rows.append(receipt);print(json.dumps({'Configuration':cfg,'Passed':True,'Seconds':receipt['ElapsedSeconds']}),flush=True)
(o/'completion.json').write_text(json.dumps({'Passed':True,'Builds':rows},indent=2))
