from pathlib import Path
import importlib.util,json,os,sys,hashlib
r=Path.cwd();cfg=sys.argv[1];o=r/'artifacts/ci93-four'/('final-'+cfg.lower());o.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('owned',r/'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
freeze=json.loads((r/'artifacts/ci93-four/final16-source-freeze.json').read_bytes());env=dict(os.environ,DOTNET_PROCESSOR_COUNT='2',DOTNET_GCConserveMemory='9')
def check():
 for row in freeze['Rows']:assert hashlib.sha256((r/row['Path']).read_bytes()).hexdigest().upper()==row['Sha256']
host=r/f'tests/Erlang.Tests/bin/{cfg}/net10.0/Erlang.Tests.dll';host2=r/f'tests/Erlang.Otp.TestAnalysis.Library.Tests/bin/{cfg}/net10.0/Erlang.Otp.TestAnalysis.Library.Tests.dll'
assemblies={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest().upper() for h in [host,host2] for p in h.parent.glob('*.dll')};(o/'assemblies.json').write_text(json.dumps(assemblies,indent=2))
seen=set();results=[]
for index,filename in enumerate(['resource-a140.names.json','resource-b140.names.json','reader19.names.json','lifecycle-selected.json','new33.json','../ci93-four/extra.json']):
 check();names=json.loads((r/'artifacts/resource541'/filename).read_bytes());assert not seen.intersection(names);seen.update(names);cmd=['dotnet','exec','--fx-version','10.0.11',str(host)]
 for name in names:cmd+=['--case',name]
 report=o/f'report-{index}.json';cmd+=['--report',str(report)];receipt=m.owned(cmd,o,f'block-{index}',180,env,str(r));data=json.loads(report.read_bytes());assert data['Passed']==len(names) and data['Failed']==0 and {x['Name'] for x in data['Tests']}==set(names);results.append({'Cases':len(names),'Receipt':receipt});print(json.dumps({'Profile':cfg,'Block':index,'Passed':len(names),'Cumulative':len(seen)}),flush=True)
assert len(seen)==377
receipt=m.owned(['dotnet','exec','--fx-version','10.0.11',str(host2),str(o/'managed')],o,'testanalysis',90,env,str(r));print(json.dumps({'Profile':cfg,'TestAnalysis':'Passed','Seconds':receipt['ElapsedSeconds']}),flush=True)
original=m.owned(['pwsh','-NoProfile','-File',str(r/'tools/validate-otp-testanalysis-original.ps1'),'-ManagedDirectory',str(o/'managed'),'-Admission',str(r.parent/'Erlang.Net/artifacts/library376-official-compiler/official-admission.json'),'-Output',str(o/'original')],o,'original',120,env,str(r));check()
freeze_path=r/'docs/validation/part-541/current-source-freeze-batch4.json'
monitor=m.owned(['py','-3',str(r/'tools/Runtime/Erlang.MonitorOriginal645Observations/run.py'),'--repository',str(r),'--official-admission',str(r.parent/'Erlang.Net/artifacts/library376-official-compiler/official-admission.json'),'--admission-sha256','41CCC2FDE5493D85BEAA21996E12D0885D2919B0D4BF44137D0673DCDC9D5EA6','--configuration',cfg,'--source-freeze',str(freeze_path),'--source-freeze-sha256',hashlib.sha256(freeze_path.read_bytes()).hexdigest().upper(),'--output',str(o/'monitor645')],o,'monitor645',240,env,str(r))
monitor_result=json.loads((o/'monitor645/completion.json').read_bytes());assert monitor_result['Passed'] and monitor_result['EqualRows']==10
for p,sha in assemblies.items():assert hashlib.sha256((r/p).read_bytes()).hexdigest().upper()==sha
(o/'completion.json').write_text(json.dumps({'Passed':True,'Configuration':cfg,'Cases':377,'ExplicitDisjointComposite':True,'Blocks':results,'TestAnalysis':receipt,'Original':original,'Monitor645':monitor,'NoDiagnosticInstrumentation':True,'SourceRows':freeze['Rows']},indent=2));print(json.dumps({'Profile':cfg,'Passed':True,'Affected':377,'OriginalWholeOutcomes':2463}),flush=True)
