from pathlib import Path
import hashlib,importlib.util,json,os,sys
r=Path.cwd();cfg=sys.argv[1];out=r/'artifacts/ci93-four'/('complete-'+cfg.lower());out.mkdir(exist_ok=False);old=r/'artifacts/ci93-four/final-debug'
spec=importlib.util.spec_from_file_location('owned',r/'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
freeze=json.loads((r/'artifacts/ci93-four/final16-source-freeze.json').read_bytes());env=dict(os.environ,DOTNET_PROCESSOR_COUNT='2',DOTNET_GCConserveMemory='9');errors=[];blocks=[];seen=set()
def check():
 for row in freeze['Rows']:assert hashlib.sha256((r/row['Path']).read_bytes()).hexdigest().upper()==row['Sha256']
def run(command,label,timeout):
 check()
 try:receipt=m.owned(command,out,label,timeout,env,str(r))
 except Exception as e:errors.append({'Stage':label,'Error':repr(e)});receipt=None
 check();return receipt
host=r/f'tests/Erlang.Tests/bin/{cfg}/net10.0/Erlang.Tests.dll';analysis=r/f'tests/Erlang.Otp.TestAnalysis.Library.Tests/bin/{cfg}/net10.0/Erlang.Otp.TestAnalysis.Library.Tests.dll'
def inventory():return {str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest().upper() for h in [host,analysis] for p in h.parent.glob('*.dll')}
identity=inventory();(out/'assemblies.json').write_text(json.dumps(identity,indent=2))
if cfg=='Debug':assert identity==json.loads((old/'assemblies.json').read_bytes())
for i,name in enumerate(['resource-a140.names.json','resource-b140.names.json','reader19.names.json','lifecycle-selected.json','new33.json','../ci93-four/extra.json']):
 names=json.loads((r/'artifacts/resource541'/name).read_bytes());assert not seen.intersection(names);seen.update(names)
 if cfg=='Debug' and i==0:
  first=json.loads((old/'report-0.json').read_bytes());retry=json.loads((r/'artifacts/resource541/ci93-regex-isolated/result.json').read_bytes());passed={x['Name'] for x in first['Tests'] if x['Status']=='Passed'};again={x['Name'] for x in retry['Report']['Tests'] if x['Status']=='Passed'};assert first['Passed']==139 and first['Failed']==1 and retry['Report']['Passed']==1 and not passed.intersection(again) and passed|again==set(names)
  assert retry['Assemblies']['Host']==hashlib.sha256(host.read_bytes()).hexdigest().upper();assert retry['Assemblies']['Runtime']==hashlib.sha256((host.parent/'Erlang.Runtime.dll').read_bytes()).hexdigest().upper();blocks.append({'Cases':140,'AcceptedPasses':[139,1],'ExplicitUnchangedDllComposite':True,'OriginalTimeoutRetained':True});print('Debug block0 accepted explicit139+1; original timeout retained',flush=True);continue
 command=['dotnet','exec','--fx-version','10.0.11',str(host)]
 for case in names:command+=['--case',case]
 report=out/f'report-{i}.json';command+=['--report',str(report)];receipt=run(command,f'block-{i}',180)
 if report.exists():
  data=json.loads(report.read_bytes());assert {x['Name'] for x in data['Tests']}==set(names);blocks.append({'Cases':len(names),'Passed':data['Passed'],'Failed':data['Failed'],'Receipt':receipt});print(json.dumps({'Profile':cfg,'Block':i,'Passed':data['Passed'],'Failed':data['Failed'],'CumulativeSelected':len(seen)}),flush=True)
  if data['Passed']!=len(names) or data['Failed']!=0:errors.append({'Stage':f'block-{i}','FailedCases':[x for x in data['Tests'] if x['Status']!='Passed']})
 else:errors.append({'Stage':f'block-{i}','NoReport':True})
assert len(seen)==377
managed=run(['dotnet','exec','--fx-version','10.0.11',str(analysis),str(out/'managed')],'testanalysis',90)
original=None
if managed is not None:original=run(['pwsh','-NoProfile','-File',str(r/'tools/validate-otp-testanalysis-original.ps1'),'-ManagedDirectory',str(out/'managed'),'-Admission',str(r.parent/'Erlang.Net/artifacts/library376-official-compiler/official-admission.json'),'-Output',str(out/'original')],'original',120)
fp=r/'docs/validation/part-541/current-source-freeze-batch4.json'
monitor=run(['py','-3',str(r/'tools/Runtime/Erlang.MonitorOriginal645Observations/run.py'),'--repository',str(r),'--official-admission',str(r.parent/'Erlang.Net/artifacts/library376-official-compiler/official-admission.json'),'--admission-sha256','41CCC2FDE5493D85BEAA21996E12D0885D2919B0D4BF44137D0673DCDC9D5EA6','--configuration',cfg,'--source-freeze',str(fp),'--source-freeze-sha256',hashlib.sha256(fp.read_bytes()).hexdigest().upper(),'--output',str(out/'monitor645')],'monitor645',240)
assert identity==inventory();check();summary={'Passed':not errors,'Configuration':cfg,'AcceptedDistinctCases':377,'Blocks':blocks,'Errors':errors,'TestAnalysis':managed,'Original':original,'Monitor645':monitor,'SameProfileDllsUnchanged':True,'SourceRows':freeze['Rows']};(out/'completion.json').write_text(json.dumps(summary,indent=2));print(json.dumps({'Profile':cfg,'Passed':not errors,'Errors':len(errors),'Distinct':377}),flush=True);raise SystemExit(0 if not errors else 1)
