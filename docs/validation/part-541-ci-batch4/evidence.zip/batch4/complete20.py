from pathlib import Path
import hashlib,importlib.util,json,os,sys
r=Path.cwd();cfg=sys.argv[1];out=r/'artifacts/ci93-four'/('complete20-'+cfg.lower());out.mkdir(exist_ok=False);old=r/'artifacts/ci93-four/final-debug'
spec=importlib.util.spec_from_file_location('owned',r/'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
freeze=json.loads((r/'artifacts/ci93-four/final20-source-freeze.json').read_bytes());env=dict(os.environ,DOTNET_PROCESSOR_COUNT='2',DOTNET_GCConserveMemory='9');errors=[];blocks=[];seen=set()
def check():
 for row in freeze['Rows']:assert hashlib.sha256((r/row['Path']).read_bytes()).hexdigest().upper()==row['Sha256']
def run(command,label,timeout):
 check()
 try:receipt=m.owned(command,out,label,timeout,env,str(r))
 except Exception as e:errors.append({'Stage':label,'Error':repr(e)});receipt=None
 check();return receipt
host=r/f'tests/Erlang.Tests/bin/{cfg}/net10.0/Erlang.Tests.dll';analysis=r/f'tests/Erlang.Otp.TestAnalysis.Library.Tests/bin/{cfg}/net10.0/Erlang.Otp.TestAnalysis.Library.Tests.dll'
def inventory():return {str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest().upper() for h in [host,analysis] for p in h.parent.glob('*.dll')}
identity=inventory();(out/'assemblies.json').write_text(json.dumps(identity,indent=2))
for i,name in enumerate(['resource-a140.names.json','resource-b140.names.json','reader19.names.json','lifecycle-selected.json','new33.json','../ci93-four/extra20.json']):
 names=json.loads((r/'artifacts/resource541'/name).read_bytes());assert not seen.intersection(names);seen.update(names)
 command=['dotnet','exec','--fx-version','10.0.11',str(host)]
 for case in names:command+=['--case',case]
 report=out/f'report-{i}.json';command+=['--report',str(report)];receipt=run(command,f'block-{i}',180)
 if report.exists():
  data=json.loads(report.read_bytes());assert {x['Name'] for x in data['Tests']}==set(names);blocks.append({'Cases':len(names),'Passed':data['Passed'],'Failed':data['Failed'],'Receipt':receipt});print(json.dumps({'Profile':cfg,'Block':i,'Passed':data['Passed'],'Failed':data['Failed'],'CumulativeSelected':len(seen)}),flush=True)
  if data['Passed']!=len(names) or data['Failed']!=0:errors.append({'Stage':f'block-{i}','FailedCases':[x for x in data['Tests'] if x['Status']!='Passed']})
 else:errors.append({'Stage':f'block-{i}','NoReport':True})
assert len(seen)==378
managed=run(['dotnet','exec','--fx-version','10.0.11',str(analysis),str(out/'managed')],'testanalysis',90)
original=None
if managed is not None:original=run(['pwsh','-NoProfile','-File',str(r/'tools/validate-otp-testanalysis-original.ps1'),'-ManagedDirectory',str(out/'managed'),'-Admission',str(r.parent/'Erlang.Net/artifacts/library376-official-compiler/official-admission.json'),'-Output',str(out/'original')],'original',120)
monitor_plan=json.loads((r/'tools/Runtime/Erlang.MonitorOriginal645Observations/inputs.json').read_bytes())
fp=r/monitor_plan['SourceFreezePath']
assert len(json.loads(fp.read_bytes())['Rows'])==89
monitor=run(['py','-3',str(r/'tools/Runtime/Erlang.MonitorOriginal645Observations/run.py'),'--repository',str(r),'--official-admission',str(r.parent/'Erlang.Net/artifacts/library376-official-compiler/official-admission.json'),'--admission-sha256','41CCC2FDE5493D85BEAA21996E12D0885D2919B0D4BF44137D0673DCDC9D5EA6','--configuration',cfg,'--source-freeze',str(fp),'--source-freeze-sha256',hashlib.sha256(fp.read_bytes()).hexdigest().upper(),'--output',str(out/'monitor645')],'monitor645',240)
assert identity==inventory();check();summary={'Passed':not errors,'Configuration':cfg,'AcceptedDistinctCases':378,'Blocks':blocks,'Errors':errors,'TestAnalysis':managed,'Original':original,'Monitor645':monitor,'SameProfileDllsUnchanged':True,'SourceRows':freeze['Rows']};(out/'completion.json').write_text(json.dumps(summary,indent=2));print(json.dumps({'Profile':cfg,'Passed':not errors,'Errors':len(errors),'Distinct':378}),flush=True);raise SystemExit(0 if not errors else 1)
