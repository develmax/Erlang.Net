using System.Collections;
using System.Reflection;
using System.Text.Json;

namespace Erlang.Tests;

internal static class RegexExitDiagnostic
{
    private const BindingFlags Flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
    private static object? Field(object? value, string name) => value?.GetType().GetField(name, Flags)?.GetValue(value);
    private static object? Property(object? value, string name) => value?.GetType().GetProperty(name, Flags)?.GetValue(value);
    private static string? Status(object? value) => value is Task task ? task.Status.ToString() : Property(value, "Task") is Task pending ? pending.Status.ToString() : null;
    private static object[] Snapshot(object value, string name)
    {
        object? gate = Field(value, "gate");
        if (gate is null || !Monitor.TryEnter(gate, 100)) return [];
        try { return (Field(value, name) as IEnumerable)?.Cast<object>().ToArray() ?? []; }
        finally { Monitor.Exit(gate); }
    }
    private static WeakReference<ProcessContext>? closing;
    private static readonly Thread sampler = BeginSampler();
    internal static void Closing(Task<ProcessContext> ready)
    {
        if (ready.IsCompletedSuccessfully)
            Volatile.Write(ref closing, new WeakReference<ProcessContext>(ready.Result));
    }
    private static Thread BeginSampler()
    {
        var thread = new Thread(() =>
        {
            ProcessContext? previous = null;
            int sample = 0;
            while (true)
            {
                Thread.Sleep(1000);
                WeakReference<ProcessContext>? selected = Volatile.Read(ref closing);
                if (selected is null || !selected.TryGetTarget(out ProcessContext? context)) continue;
                if (!ReferenceEquals(previous, context)) { previous = context; sample = 0; }
                if (Status(Property(context, "Done")) is "RanToCompletion" or "Faulted" or "Canceled") continue;
                if (++sample > 5) continue;
                ProcessRuntime runtime = context.Runtime;
            object? owner = Field(runtime, "processPayloads641");
            object[] live = owner is null ? [] : Snapshot(owner, "live");
            object[] exits = Snapshot(runtime, "exitContinuations");
            Console.Error.WriteLine(JsonSerializer.Serialize(new
            {
                Diagnostic = "RegexActorExit",
                Sample = sample,
                Runtime = System.Runtime.CompilerServices.RuntimeHelpers.GetHashCode(runtime),
                Pid = context.Self.ToString(),
                Terminated = Field(context, "Terminated"),
                Canceled = context.Cancellation.IsCancellationRequested,
                ContextTasks = context.GetType().GetFields(Flags).Select(f => new { f.Name, Status = Status(f.GetValue(context)) }).Where(x => x.Status is not null).ToArray(),
                Exits = exits.Select(item => Property(item, "Value")).Select(item => new { Context = (Property(item, "Process") as ProcessContext)?.Self.ToString(), Storage = Status(Property(item, "StorageRetirement")), Physical = Status(Property(item, "PhysicalRetirement")), Cleanup = Status(Property(item, "LocalCleanup")), Quiescence = Status(Property(item, "Quiescence")) }).ToArray(),
                Live641 = live.Select(item => new { Context = (Property(item, "Context641") as ProcessContext)?.Self.ToString(), Ended = Field(item, "ended"), Ready = Status(Field(item, "ready")), Done = Status(Field(item, "done")), Dependency = Status(Field(item, "dependency")), DependencyId = (Field(item, "dependency") as Task)?.Id, DoneId = (Field(item, "done") is TaskCompletionSource d ? d.Task.Id : -1) }).ToArray(),
                RegexActive = Field(Field(runtime, "regex411"), "active"),
                RegexInvocations = Field(runtime, "regex411") is { } regexOwner ? Snapshot(regexOwner, "invocations").Select(item => new { Pid = (Property(item, "Key") as ProcessContext)?.Self.ToString(), Count = Field(Property(item, "Value"), "Count") }).ToArray() : [],
                Regex = Field(runtime, "regex411")?.GetType().GetFields(Flags).Select(f => new { f.Name, Type = f.GetValue(Field(runtime, "regex411"))?.GetType().Name, Status = Status(f.GetValue(Field(runtime, "regex411"))) }).ToArray()
            }));

            }
        }) { IsBackground = true };
        thread.Start();
        return thread;
    }
}
