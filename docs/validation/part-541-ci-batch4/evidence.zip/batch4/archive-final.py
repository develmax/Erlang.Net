from pathlib import Path
import json,hashlib,zipfile
r=Path.cwd();base=r/'artifacts/ci93-four';out=r/'docs/validation/part-541-ci-batch4';out.mkdir(exist_ok=False);profiles=[]
for cfg in ['Debug','Release']:
 p=base/('complete-'+cfg.lower());j=json.loads((p/'completion.json').read_bytes());assert j['Passed'] and j['AcceptedDistinctCases']==377 and not j['Errors'];a=json.loads((p/'original/completion.json').read_bytes());m=json.loads((p/'monitor645/completion.json').read_bytes());assert a['Passed'] and a['Outcomes']==2463 and m['Passed'] and m['EqualRows']==10;profiles.append({'Configuration':cfg,'DistinctAccepted':377,'Debug139PlusIsolated1Composite':cfg=='Debug','OriginalWholeTestAnalysisRows':2463,'FreshMonitorRows':10,'TestAnalysisSeconds':j['TestAnalysis']['ElapsedSeconds'],'ManagedMonitorFamilies':json.loads((p/'monitor645/managed/receipt.json').read_bytes())['FamilyCleanupCompleted'] if (p/'monitor645/managed/receipt.json').exists() else None})
rows=json.loads((base/'final16-source-freeze.json').read_bytes())['Rows']
for row in rows:assert hashlib.sha256((r/row['Path']).read_bytes()).hexdigest().upper()==row['Sha256']
meta=r/'artifacts/resource541-batch4-metadata';membership=json.loads((meta/'final-membership.json').read_bytes());assert membership['ExactMembers']==3996
summary={'Passed':True,'Profiles':profiles,'Current86Sha256':'296DB691FC1D7CA13EEDB4BB355BA73EAE08D1A8125FC952D5D4AF6990611B7B','SourceRows':rows,'Metadata':membership,'ExpectedCatalog':9431,'OriginalFourCiFailuresReproduced':True,'IntermediateRestoredDownOld593ResourceRed':True,'OlderRuntimeCancellationRed':True,'OriginalRegexTimeoutRetained':True,'RegexTimeoutRootCauseClaimed':False,'ApiDelta':0,'WholeContractDelta':0,'KnownDifferences':24,'FullCiPending':True,'NativeNifOriginalPhysicalProofClaimed':False,'InitializationEndedExceptionalLoopResilienceExtended':False};(out/'summary.json').write_text(json.dumps(summary,indent=2));files=[]
for prefix,folder in [('batch4',base),('metadata',meta)]:
 for p in sorted(folder.rglob('*')):
  if not p.is_file() or any(x in p.parts for x in ['bin','obj','token-proof']):continue
  if 'host' in p.parts and p.name!='Erlang.Runtime.dll':continue
  files.append((prefix+'/'+p.relative_to(folder).as_posix(),p))
for name in ['ci93-four-red','ci93-resource-down-intermediate-red','ci93-batch-five-first-green','ci93-final-six','ci93-regex-isolated']:
 folder=r/'artifacts/resource541'/name
 for p in sorted(folder.rglob('*')):
  if p.is_file():files.append(('controls/'+name+'/'+p.relative_to(folder).as_posix(),p))
ci=r.parent/'artifacts/delivery541-0096-failed-ci'
for name in ['tests.json','failure-audit.json','artifact-provenance.json','independent-comparison-audit.json']:files.append(('failed-ci/'+name,ci/name))
for row in rows:files.append(('final-source/'+row['Path'],r/row['Path']))
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in files:z.writestr(name,p.read_bytes())
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(files)==len(set(z.namelist()))
 for name,p in files:assert z.read(name)==p.read_bytes()
receipt={'Sha256':hashlib.sha256(archive.read_bytes()).hexdigest().upper(),'Bytes':archive.stat().st_size,'Members':len(files),'EveryMemberVerified':True};(out/'archive.json').write_text(json.dumps(receipt,indent=2));print(json.dumps({'Profiles':profiles,'Archive':receipt}))
