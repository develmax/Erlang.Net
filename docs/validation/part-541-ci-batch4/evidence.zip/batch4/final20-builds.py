from pathlib import Path
import json,hashlib,importlib.util,os
r=Path.cwd();o=r/'artifacts/ci93-four/final20-builds';o.mkdir(exist_ok=False);freeze=json.loads((r/'artifacts/ci93-four/final20-source-freeze.json').read_bytes());spec=importlib.util.spec_from_file_location('owned',r/'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def check():
 for row in freeze['Rows']:assert hashlib.sha256((r/row['Path']).read_bytes()).hexdigest().upper()==row['Sha256']
rows=[]
for cfg in ['Debug','Release']:
 for project in ['Erlang.Tests','Erlang.Otp.TestAnalysis.Library.Tests']:
  check();label=cfg+'-'+project;j=m.owned(['dotnet','build',f'tests/{project}/{project}.csproj','-c',cfg,'--no-restore','-m:1','-p:UseSharedCompilation=false','-p:BuildInParallel=false','-v:q'],o,label,240,dict(os.environ,DOTNET_PROCESSOR_COUNT='1',DOTNET_GCConserveMemory='9'),str(r));check();rows.append(j);print(json.dumps({'Built':label,'Seconds':j['ElapsedSeconds']}),flush=True)
(o/'completion.json').write_text(json.dumps({'Passed':True,'Builds':rows},indent=2))
