from pathlib import Path
import ast,hashlib,json,subprocess,sys
sys.dont_write_bytecode=True
r=Path.cwd(); t=r/'tools/Runtime/Erlang.OwnedGuest506Observations'; p=t/'seal.py'; s=p.read_text(); tree=ast.parse(s)
node=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(v,ast.Name) and v.id=='DEPENDENCIES' for v in n.targets))
deps=ast.literal_eval(node.value)
changed=subprocess.check_output(['git','diff','--name-only','009658617513ed4e0def79e9f739df4b705d2ad6'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
extra=sorted(x for x in changed if x.endswith('.cs') and x.startswith(('src/','tests/')) and x not in deps)
marker='DEPENDENCIES = [\n';assert s.count(marker)==1
p.write_text(s.replace(marker,marker+''.join('    '+repr(x)+',\n' for x in extra)),newline='\n')
before=hashlib.sha256((t/'source-plan.json').read_bytes()).hexdigest().upper()
subprocess.run([sys.executable,str(p),'--repository',str(r),'--replace-plan-sha256',before],check=True)
subprocess.run([sys.executable,str(r/'tools/Runtime/Erlang.DynamicApply520Observations/seal-source-plan.py')],check=True)
print('Additional exact source bindings',len(extra))
