namespace Erlang;

internal sealed class EtsFileOptions
{
    internal bool ObjectCount { get; set; }
    internal bool Md5 { get; set; }
    internal bool Sync { get; set; }

    internal Term Extended => Term.List((ObjectCount ? new Term[] { Term.A("object_count") } : [])
        .Concat(Md5 ? new Term[] { Term.A("md5sum") } : []).ToArray());
}
