// Derived from lib/stdlib/src/ets.erl, OTP-29.1.1, Apache-2.0.
// Copyright Ericsson AB 1996-2026.
namespace Erlang;

public static partial class EtsModule
{
    private static ValueTask<Term> Print(ProcessContext context, string format, params Term[] arguments)
        => Call(
            context,
            "io",
            "format",
            Term.String(format),
            Term.List(arguments)
        );

    private static async ValueTask<Term> Render(ProcessContext context, Term value)
        => await Call(
            context,
            "lists",
            "flatten",
            await Call(
                context,
                "io_lib",
                "format",
                Term.String("~p"),
                Term.List(value)
            )
        );

    private static async ValueTask<Term> DisplayTables(ProcessContext context)
    {
        await DisplayRow(context, [A("id"), A("name"), A("type"), A("size"), A("mem"), A("owner")]);
        await Call(
            context,
            "io",
            "format",
            Term.String(" ----------------------------------------------------------------------------\n")
        );
        Term tables = await Call(
            context,
            "lists",
            "sort",
            await Invoke(context, "all", [])
        );
        foreach (Term table in Cons.Items(tables))
        {
            try
            {
                var values = new List<Term> { table };
                foreach (string key in new[] { "name", "type", "size", "memory", "owner" })
                {
                    values.Add(await Call(
                        context,
                        Name,
                        "info",
                        table,
                        A(key)
                    ));
                }
                Term owner = await Call(
                    context,
                    "erlang",
                    "process_info",
                    values[5],
                    A("registered_name")
                );
                if (owner is TupleTerm { Items.Count: 2 } registered && Is(registered.Items[0], "registered_name"))
                {
                    values[5] = registered.Items[1];
                }
                await DisplayRow(context, values.ToArray());
            }
            catch (ErlangException error) when (error.ExceptionClass != "throw")
            {
                await Print(context, "~-10s ... unreadable \n", await Render(context, table));
            }
        }

        return A("ok");
    }

    private static async ValueTask<Term> DisplayRow(ProcessContext context, Term[] values)
    {
        int[] widths = [15, 17, 5, 6, 8, 0];
        for (int index = 0; index < values.Length; index++)
        {
            Term text = await Render(context, values[index]);
            int length = Cons.Items(text).Count();
            values[index] = length >= widths[index] ? text
                : Cons.From(Cons.Items(text).Concat(Enumerable.Repeat<Term>(Term.I(32), widths[index] - length)));
        }

        return await Print(context, " ~s ~s ~s ~s ~s ~s\n", values);
    }

    private static async ValueTask<Term> DisplayItem(
        ProcessContext context,
        Term width,
        Term item,
        long position
    )
    {
        using var source = EtsSource.Frame(
            context,
            "do_display_item",
            4,
            4039
        );
        Term text = await Render(context, item);
        Term available = await Call(
            context,
            "erlang",
            "-",
            width,
            Term.I(8)
        );
        if (TermOrder.Compare(Term.I(Cons.Items(text).Count()), available) > 0)
        {
            using var slice = context.EnterSourceLocation(EtsSource.Location(4042));
            Term cut = await Call(
                context,
                "erlang",
                "-",
                width,
                Term.I(13)
            );
            text = Cons.From(Cons.Items(await Call(
                context,
                "string",
                "slice",
                text,
                Term.I(0),
                cut
            )), Term.String("  ..."));
        }

        return await Print(
            context,
            "<~-4w> ~s~n",
            Term.I(position),
            text
        );
    }

    private static async ValueTask<bool> RegexMatches(ProcessContext context, Term item, Term regex)
        => Is(await Call(
            context,
            "re",
            "run",
            await Render(context, item),
            regex,
            Term.List(Term.Tuple(A("capture"), A("none")))
        ), "match");

    private static async ValueTask PrintNumber(
        ProcessContext context,
        Term table,
        Term number,
        Term? regex
    )
    {
        Term key = await Call(
            context,
            Name,
            "first",
            table
        );
        while (regex is null || !Is(key, "$end_of_table"))
        {
            var rows = new List<Term>();
            foreach (Term row in Cons.Items(await Call(
                context,
                Name,
                "lookup",
                table,
                key
            )))
            {
                if (regex is null || await RegexMatches(context, row, regex))
                {
                    rows.Add(row);
                }
            }
            Term rest = await Call(
                context,
                "erlang",
                "-",
                number,
                Term.I(rows.Count)
            );
            if (TermOrder.Compare(rest, Term.I(1)) < 0)
            {
                Term row = await Call(
                    context,
                    "lists",
                    "nth",
                    number,
                    Cons.From(rows)
                );
                await Print(context, "~p~n", row);

                return;
            }
            number = rest;
            key = await Call(
                context,
                Name,
                "next",
                table,
                key
            );
        }
    }

    private static async ValueTask<Term> Browse(
        ProcessContext context,
        Term tableArg,
        Term height,
        Term width
    )
    {
        Term table = await SoftWhereis(context, tableArg);
        Term key = await Call(
            context,
            Name,
            "first",
            table
        );
        Term? regex = null;
        long turn = 1;
        long position = 1;
        bool forceDisplay = false;
        while (true)
        {
            context.Cancellation.ThrowIfCancellationRequested();
            bool end = Is(key, "$end_of_table");
            if (!end && (forceDisplay || TermOrder.Compare(Term.I(turn), height) < 0))
            {
                using var display = EtsSource.Frame(
                    context,
                    "do_display",
                    6,
                    4028,
                    tail: true
                );
                forceDisplay = false;
                foreach (Term row in Cons.Items(await Call(
                    context,
                    Name,
                    "lookup",
                    table,
                    key
                )))
                {
                    if (regex is null || await RegexMatches(context, row, regex))
                    {
                        using var items = EtsSource.Frame(
                            context,
                            "do_display_items",
                            4,
                            4033
                        );
                        await DisplayItem(
                            context,
                            width,
                            row,
                            position++
                        );
                        turn++;
                    }
                }
                key = await Call(
                    context,
                    Name,
                    "next",
                    table,
                    key
                );
                continue;
            }
            Term prompt = A(end ? "EOT  (q)uit (p)Digits (k)ill /Regexp -->" : "(c)ontinue (q)uit (p)Digits (k)ill /Regexp -->");
            Term line = await Call(
                context,
                "io",
                "get_line",
                prompt
            );
            if (line is BitString)
            {
                line = await Call(
                    context,
                    "unicode",
                    "characters_to_list",
                    line
                );
            }
            if (line.Equals(Term.String("\n")))
            {
                line = Term.String("c\n");
            }
            if (Is(line, "eof") || line.Equals(Term.String("q\n")) || end && regex is null && line.Equals(Term.String("c\n")))
            {
                return A("ok");
            }
            if (line.Equals(Term.String("c\n")))
            {
                turn = 1;
                forceDisplay = regex is null;
                continue;
            }
            if (line.Equals(Term.String("k\n")))
            {
                await Call(
                    context,
                    Name,
                    "delete",
                    table
                );

                return A("ok");
            }
            if (line is Cons { Head: Integer first } command && (first.Value == 112 || first.Value == 47))
            {
                Term suffix = await Call(
                    context,
                    "string",
                    "trim",
                    command.Tail,
                    A("trailing"),
                    Term.String("$\n")
                );
                if (first.Value == 112)
                {
                    try
                    {
                        Term number;
                        try
                        {
                            number = await Call(
                                context,
                                "erlang",
                                "list_to_integer",
                                suffix
                            );
                        }
                        catch (ErlangException error) when (error.ExceptionClass != "throw")
                        {
                            await Call(
                                context,
                                "io",
                                "put_chars",
                                Term.String("Bad digits\n")
                            );
                            continue;
                        }
                        await PrintNumber(
                            context,
                            table,
                            number,
                            regex
                        );
                    }
                    catch (ErlangException)
                    {
                    }
                }
                else
                {
                    Term compiled = await Call(
                        context,
                        "re",
                        "compile",
                        suffix,
                        Term.List(A("unicode"))
                    );
                    if (compiled is TupleTerm { Items.Count: 2 } pair && Is(pair.Items[0], "ok"))
                    {
                        regex = pair.Items[1];
                        key = await Call(
                            context,
                            Name,
                            "first",
                            table
                        );
                        turn = 1;
                        position = 1;
                    }
                    else if (compiled is TupleTerm { Items.Count: 2 } error && error.Items[1] is TupleTerm { Items.Count: 2 } detail)
                    {
                        await Print(context, "~ts~n", detail.Items[0]);
                    }
                }
            }
        }
    }
}
