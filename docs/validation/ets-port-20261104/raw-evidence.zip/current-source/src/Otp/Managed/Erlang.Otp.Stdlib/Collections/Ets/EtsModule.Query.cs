// Derived from lib/stdlib/src/ets.erl, OTP-29.1.1, Apache-2.0.
// Copyright Ericsson AB 1996-2026.
using System.Buffers.Binary;

namespace Erlang;

public static partial class EtsModule
{
    private static FunctionTerm Closure(
        ProcessContext context,
        string name,
        int index,
        int arity,
        Term[] environment,
        Func<ProcessContext, IReadOnlyList<Term>, IReadOnlyList<Term>, ValueTask<Term>> body
    )
    {
        var fingerprint = (BitString)context.Runtime.Modules.ModuleInformation(Name, ModuleInformationKeys.Md5);
        var identity = new LocalFunctionIdentity(
            A(Name),
            A(name),
            index,
            (int)(BinaryPrimitives.ReadUInt32BigEndian(fingerprint.ToArray()) >> 5),
            fingerprint
        );

        FunctionTerm Materialize(IReadOnlyList<Term> captured) => new(
            identity,
            arity,
            captured,
            (execution, arguments) => body((ProcessContext)execution, arguments, captured)
        );
        identity = context.Runtime.Functions.Register(
            identity,
            arity,
            environment.Length,
            Materialize
        );

        return Materialize(environment);
    }

    private static async ValueTask<Term> QueryTable(ProcessContext context, Term tableArg, Term options)
    {
        Term table = await SoftWhereis(context, tableArg);
        Term remaining = IsList(options) ? options : Term.List(options);
        Term traverse = A("select");
        Term limit = Term.I(100);
        var parsedValues = new List<Term>();
        string[] keys = ["traverse", "n_objects"];
        bool invalid = false;
        using (context.EnterSourceLocation(EtsSource.Location(3743)))
        {
            for (int index = 0; index < keys.Length; index++)
            {
                string key = keys[index];
                using var helper = EtsSource.Frame(
                    context,
                    "options",
                    3,
                    3831
                );
                if (!IsList(remaining))
                {
                    throw EtsSource.Error(
                        context,
                        "options",
                        [remaining, Cons.From(keys.Skip(index).Select(value => (Term)A(value))), Cons.From(parsedValues.AsEnumerable().Reverse())],
                        A("function_clause"),
                        3830
                    );
                }
                Term selected = await Call(
                    context,
                    "lists",
                    "keyfind",
                    A(key),
                    Term.I(1),
                    remaining
                );
                if (Is(selected, "false"))
                {
                    parsedValues.Add(key == "traverse" ? traverse : limit);
                    continue;
                }
                if (selected is TupleTerm { Items.Count: 2 } pair)
                {
                    Term value = pair.Items[1];
                    if (key == "n_objects" && (Is(value, "default") || value is Integer n && n.Value >= 1))
                    {
                        limit = Is(value, "default") ? Term.I(100) : value;
                    }
                    else if (key == "traverse" && (Is(value, "select") || Is(value, "first_next") || Is(value, "last_prev")
                        || value is TupleTerm { Items.Count: 2 } spec && Is(spec.Items[0], "select")))
                    {
                        traverse = value;
                    }
                    else
                    {
                        invalid = true;
                        break;
                    }
                }
                else
                {
                    throw context.CaptureSourceFailure(new ErlangException(Term.Tuple(A("case_clause"), selected)));
                }
                remaining = await Call(
                    context,
                    "lists",
                    "keydelete",
                    A(key),
                    Term.I(1),
                    remaining
                );
                parsedValues.Add(key == "traverse" ? traverse : limit);
            }
        }
        if (invalid)
        {
            throw EtsSource.Error(
                context,
                "table",
                [table, options],
                A("badarg"),
                3745
            );
        }
        FunctionTerm traversal;
        if (Is(traverse, "first_next") || Is(traverse, "last_prev"))
        {
            traversal = Closure(
                context,
                "-table/2-traverse-0-",
                0,
                0,
                [table, traverse],
                async (c, a, e) =>
            {
                bool reverse = Is(e[1], "last_prev");

                return await QueryKeys(
                    c,
                    e[0],
                    await Call(
                        c,
                        Name,
                        reverse ? "last" : "first",
                        e[0]
                    ),
                    reverse
                );
            }
            );
        }
        else if (traverse is TupleTerm spec)
        {
            traversal = Closure(
                context,
                "-table/2-select-0-",
                1,
                0,
                [table, spec.Items[1], limit],
                async (c, a, e) => await QuerySelect(c, await Call(
                    c,
                    Name,
                    "select",
                    e[0],
                    e[1],
                    e[2]
                ))
            );
        }
        else
        {
            traversal = Closure(
                context,
                "-table/2-select-1-",
                2,
                1,
                [table, limit],
                async (c, a, e) => await QuerySelect(c, await Call(
                    c,
                    Name,
                    "select",
                    e[0],
                    a[0],
                    e[1]
                ))
            );
        }
        FunctionTerm before = Closure(
            context,
            "-table/2-pre-1-",
            3,
            1,
            [table],
            (c, a, e) => Call(
                c,
                Name,
                "safe_fixtable",
                e[0],
                A("true")
            )
        );
        FunctionTerm after = Closure(
            context,
            "-table/2-post-0-",
            4,
            0,
            [table],
            (c, a, e) => Call(
                c,
                Name,
                "safe_fixtable",
                e[0],
                A("false")
            )
        );
        FunctionTerm info = Closure(
            context,
            "-table/2-info-1-",
            5,
            1,
            [table],
            async (c, a, e) =>
        {
            if (Is(a[0], "num_of_objects") || Is(a[0], "keypos"))
            {
                return await Call(
                    c,
                    Name,
                    "info",
                    e[0],
                    Is(a[0], "keypos") ? A("keypos") : A("size")
                );
            }
            if (Is(a[0], "is_unique_objects") || Is(a[0], "is_sorted_key"))
            {
                Term type = await Call(
                    c,
                    Name,
                    "info",
                    e[0],
                    A("type")
                );

                return A((Is(a[0], "is_unique_objects") ? !Is(type, "duplicate_bag") : Is(type, "ordered_set")) ? "true" : "false");
            }

            return A("undefined");
        }
        );
        Term type;
        using (context.EnterSourceLocation(EtsSource.Location(3760)))
        {
            type = await Call(
                context,
                Name,
                "info",
                table,
                A("type")
            );
        }
        Term equality = A(Is(type, "ordered_set") ? "==" : "=:=");
        Term lookup = traverse is TupleTerm ? A("undefined") : Closure(
            context,
            "-table/2-lookup-2-",
            6,
            2,
            [table],
            async (c, a, e) =>
        {
            var rows = new List<Term>();
            foreach (Term key in Cons.Items(a[1]))
            {
                rows.AddRange(Cons.Items(await Call(
                    c,
                    Name,
                    "lookup",
                    e[0],
                    key
                )));
            }

            return Cons.From(rows);
        }
        );
        FunctionTerm format = Closure(
            context,
            "-table/2-format-1-",
            7,
            1,
            [table, options],
            QueryFormat
        );
        Term qlcOptions = Cons.From(
            new Term[]
        {
            Term.Tuple(A("pre_fun"), before), Term.Tuple(A("post_fun"), after),
            Term.Tuple(A("info_fun"), info), Term.Tuple(A("format_fun"), format),
            Term.Tuple(A("key_equality"), equality), Term.Tuple(A("lookup_fun"), lookup)
        },
            remaining
        );

        return await Call(
            context,
            "qlc",
            "table",
            traversal,
            qlcOptions
        );
    }

    private static async ValueTask<Term> QueryKeys(
        ProcessContext context,
        Term table,
        Term key,
        bool reverse
    )
    {
        if (Is(key, "$end_of_table"))
        {
            return Nil.Value;
        }
        Term objects = await Call(
            context,
            Name,
            "lookup",
            table,
            key
        );
        FunctionTerm next = Closure(
            context,
            "-qlc_next/2-0-",
            8,
            0,
            [table, key, A(reverse ? "true" : "false")],
            async (c, a, e) => await QueryKeys(
                c,
                e[0],
                await Call(
                    c,
                    Name,
                    Is(e[2], "true") ? "prev" : "next",
                    e[0],
                    e[1]
                ),
                Is(e[2], "true")
            )
        );

        return Cons.From(Cons.Items(objects), next);
    }

    private static ValueTask<Term> QuerySelect(ProcessContext context, Term result)
    {
        if (Is(result, "$end_of_table"))
        {
            return ValueTask.FromResult<Term>(Nil.Value);
        }
        var pair = (TupleTerm)result;
        FunctionTerm next = Closure(
            context,
            "-qlc_select/1-0-",
            9,
            0,
            [pair.Items[1]],
            async (c, a, e) => await QuerySelect(c, await Call(
                c,
                Name,
                "select",
                e[0]
            ))
        );

        return ValueTask.FromResult(Cons.From(Cons.Items(pair.Items[0]), next));
    }

    private static async ValueTask<Term> QueryFormat(ProcessContext context, IReadOnlyList<Term> arguments, IReadOnlyList<Term> environment)
    {
        Term table = environment[0];
        Term options = environment[1];
        if (arguments[0] is TupleTerm tuple)
        {
            if (tuple.Items.Count == 3 && Is(tuple.Items[0], "all"))
            {
                return Term.Tuple(A(Name), A("table"), options is Nil ? Term.List(table) : Term.List(table, options));
            }
            if (tuple.Items.Count == 2 && Is(tuple.Items[0], "match_spec"))
            {
                Term opts = IsList(options) ? options : Term.List(options);

                return Term.Tuple(A(Name), A("table"), Term.List(table, new Cons(Term.Tuple(A("traverse"), Term.Tuple(A("select"), tuple.Items[1])), opts)));
            }
            if (tuple.Items.Count == 5 && Is(tuple.Items[0], "lookup"))
            {
                Term[] values = Cons.Items(tuple.Items[2]).ToArray();
                if (values.Length == 1)
                {
                    return await Call(
                        context,
                        "io_lib",
                        "format",
                        Term.String("~w:lookup(~w, ~w)"),
                        Term.List(A(Name), table, await Apply(context, tuple.Items[4], values[0]))
                    );
                }
                var formatted = new List<Term>();
                foreach (Term value in values)
                {
                    formatted.Add(await Apply(context, tuple.Items[4], value));
                }

                return await Call(
                    context,
                    "io_lib",
                    "format",
                    Term.String("lists:flatmap(fun(V) -> ~w:lookup(~w, V) end, ~w)"),
                    Term.List(A(Name), table, Cons.From(formatted))
                );
            }
        }

        throw new ErlangException(ErlangErrorReasons.FunctionClause);
    }
}
