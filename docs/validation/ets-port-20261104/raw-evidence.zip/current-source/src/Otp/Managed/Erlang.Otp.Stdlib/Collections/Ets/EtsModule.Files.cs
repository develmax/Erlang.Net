// Derived from lib/stdlib/src/ets.erl, OTP-29.1.1, Apache-2.0.
// Copyright Ericsson AB 1996-2026.
namespace Erlang;

public static partial class EtsModule
{
    private static void Throw(Term reason) => throw new ErlangException(reason, "throw");

    private static Term ErrorResult(Term reason) => Term.Tuple(A("error"), reason);

    private static bool ErrorPair(Term value, out Term reason)
    {
        if (value is TupleTerm { Items.Count: 2 } pair && Is(pair.Items[0], "error"))
        {
            reason = pair.Items[1];

            return true;
        }
        reason = Nil.Value;

        return false;
    }

    private static Term Field(IReadOnlyList<Term> fields, string name, Term? fallback = null)
    {
        foreach (Term field in fields)
        {
            if (field is TupleTerm { Items.Count: >= 1 } pair && Is(pair.Items[0], name))
            {
                return pair;
            }
        }

        return fallback ?? A("false");
    }

    private static Term FieldValue(IReadOnlyList<Term> fields, string name, Term? fallback = null)
        => Field(fields, name) is TupleTerm { Items.Count: 2 } pair ? pair.Items[1] : fallback ?? A("false");

    private static EtsFileOptions ParseSaveOptions(ProcessContext context, Term options)
    {
        if (!IsList(options))
        {
            throw EtsSource.Error(
                context,
                "parse_ft_options",
                [options],
                A("function_clause"),
                3023
            );
        }
        var result = new EtsFileOptions();
        bool extended = false;
        Term cursor = options;
        while (cursor is Cons cell)
        {
            if (cell.Head is TupleTerm { Items.Count: 2 } pair && Is(pair.Items[0], "sync")
                && (Is(pair.Items[1], "true") || Is(pair.Items[1], "false")))
            {
                result.Sync |= Is(pair.Items[1], "true");
            }
            else if (cell.Head is TupleTerm { Items.Count: 2 } info && Is(info.Items[0], "extended_info") && !extended)
            {
                Term entries = info.Items[1];
                while (entries is Cons entry)
                {
                    if (Is(entry.Head, "object_count"))
                    {
                        result.ObjectCount = true;
                    }
                    else if (Is(entry.Head, "md5sum"))
                    {
                        result.Md5 = true;
                    }
                    else
                    {
                        Throw(Term.Tuple(A("unknown_option"), Term.List(Term.Tuple(A("extended_info"), Term.List(entry.Head)))));
                    }
                    entries = entry.Tail;
                }
                if (entries is not Nil)
                {
                    Throw(Term.Tuple(A("malformed_option"), entries));
                }
                extended = true;
            }
            else
            {
                Throw(Term.Tuple(A("unknown_option"), cell.Head));
            }
            cursor = cell.Tail;
        }
        if (cursor is not Nil)
        {
            Throw(Term.Tuple(A("malformed_option"), cursor));
        }

        return result;
    }

    private static async ValueTask<Term> Log(
        ProcessContext context,
        Term name,
        Term state,
        Term terms,
        bool digest
    )
    {
        Term values = terms;
        if (digest)
        {
            var binaries = new List<Term>();
            foreach (Term item in Cons.Items(terms))
            {
                Term binary = await Call(
                    context,
                    "erlang",
                    "term_to_binary",
                    item
                );
                state = await Call(
                    context,
                    "erlang",
                    "md5_update",
                    state,
                    binary
                );
                binaries.Add(binary);
            }
            values = Cons.From(binaries);
        }
        Term logged = await Call(
            context,
            "disk_log",
            digest ? "blog_terms" : "log_terms",
            name,
            values
        );
        if (ErrorPair(logged, out Term reason))
        {
            Throw(reason);
        }
        if (!Is(logged, "ok"))
        {
            throw new ErlangException(Term.Tuple(A("case_clause"), logged));
        }

        return digest ? state : A("true");
    }

    private static async ValueTask<Term> Save(
        ProcessContext context,
        Term tableArg,
        Term file,
        Term options
    )
    {
        try
        {
            Term info = await Call(
                context,
                Name,
                "info",
                tableArg
            );
            if (Is(info, "undefined"))
            {
                Throw(A("badtab"));
            }
            Term[] fields = Cons.Items(info).ToArray();
            Term table = FieldValue(fields, "id");
            EtsFileOptions parsed;
            using (context.EnterSourceLocation(EtsSource.Location(2887)))
            {
                parsed = ParseSaveOptions(context, options);
            }
            await Call(
                context,
                "file",
                "delete",
                file
            );
            Term stat = await Call(
                context,
                "file",
                "read_file_info",
                file
            );
            if (!stat.Equals(ErrorResult(A("enoent"))))
            {
                Throw(A("eaccess"));
            }
            Term name = await Call(context, "erlang", "make_ref");
            Term opened = await Call(
                context,
                "disk_log",
                "open",
                Term.List(
                Term.Tuple(A("name"), name), Term.Tuple(A("file"), file), Term.Tuple(A("repair"), A("truncate")))
            );
            if (ErrorPair(opened, out Term openReason))
            {
                Throw(openReason);
            }
            if (!opened.Equals(Term.Tuple(A("ok"), name)))
            {
                throw new ErlangException(Term.Tuple(A("case_clause"), opened));
            }
            try
            {
                Term header = Term.Tuple(fields.Concat(new Term[]
                {
                    Term.Tuple(A("major_version"), Term.I(1)),
                    Term.Tuple(A("minor_version"), Term.I(0)),
                    Term.Tuple(A("extended_info"), parsed.Extended)
                }).ToArray());
                Term state = parsed.Md5 ? await Call(context, "erlang", "md5_init") : A("true");
                try
                {
                    await Call(
                        context,
                        Name,
                        "safe_fixtable",
                        table,
                        A("true")
                    );
                }
                catch (ErlangException error) when (error.ExceptionClass == "error" && Is(error.Reason, "badarg"))
                {
                    Throw(A("badtab"));
                }
                long count = 0;
                try
                {
                    state = await Log(
                        context,
                        name,
                        state,
                        Term.List(header),
                        parsed.Md5
                    );
                    Term cursor = await Call(
                        context,
                        Name,
                        "select",
                        table,
                        Term.List(Term.Tuple(A("_"), Nil.Value, Term.List(A("$_")))),
                        Term.I(100)
                    );
                    while (!Is(cursor, "$end_of_table"))
                    {
                        var chunk = (TupleTerm)cursor;
                        count += Cons.Items(chunk.Items[0]).LongCount();
                        state = await Log(
                            context,
                            name,
                            state,
                            chunk.Items[0],
                            parsed.Md5
                        );
                        cursor = await Call(
                            context,
                            Name,
                            "select",
                            chunk.Items[1]
                        );
                    }
                }
                finally
                {
                    await Ignore(() => Call(
                        context,
                        Name,
                        "safe_fixtable",
                        table,
                        A("false")
                    ));
                }
                var end = new List<Term>();
                if (parsed.ObjectCount)
                {
                    end.Add(Term.Tuple(A("count"), Term.I(count)));
                }
                if (parsed.Md5)
                {
                    end.Add(Term.Tuple(A("md5"), await Call(
                        context,
                        "erlang",
                        "md5_final",
                        state
                    )));
                }
                if (end.Count > 0)
                {
                    await Log(
                        context,
                        name,
                        state,
                        Term.List(Term.List(A("$end_of_table"), Cons.From(end))),
                        parsed.Md5
                    );
                }
                if (parsed.Sync)
                {
                    Term sync = await Call(
                        context,
                        "disk_log",
                        "sync",
                        name
                    );
                    if (ErrorPair(sync, out Term syncReason))
                    {
                        Throw(syncReason);
                    }
                }

                return await Call(
                    context,
                    "disk_log",
                    "close",
                    name
                );
            }
            catch (ErlangException)
            {
                await Call(
                    context,
                    "disk_log",
                    "close",
                    name
                );
                await Call(
                    context,
                    "file",
                    "delete",
                    file
                );
                throw;
            }
        }
        catch (ErlangException error) when (error.ExceptionClass is "throw" or "exit")
        {
            return ErrorResult(error.Reason);
        }
    }

    private static async ValueTask<Term> Chunk(
        ProcessContext context,
        Term name,
        Term cursor,
        int size,
        bool binary,
        bool verify
    )
    {
        Term result = await Call(
            context,
            "disk_log",
            binary ? "bchunk" : "chunk",
            name,
            cursor,
            Term.I(size)
        );
        if (result is TupleTerm { Items.Count: 3 } triple)
        {
            if (verify && triple.Items[2] is Integer skipped && skipped.Value > 0)
            {
                Throw(A("badfile"));
            }

            return Term.Tuple(triple.Items[0], triple.Items[1]);
        }

        return result;
    }

    private static async ValueTask<Term> OpenRead(ProcessContext context, Term file, bool verify)
    {
        Term name = await Call(context, "erlang", "make_ref");
        Term opened = await Call(
            context,
            "disk_log",
            "open",
            Term.List(
            Term.Tuple(A("name"), name), Term.Tuple(A("file"), file), Term.Tuple(A("mode"), A("read_only")))
        );
        if (opened.Equals(Term.Tuple(A("ok"), name)))
        {
            return name;
        }
        if (opened is TupleTerm { Items.Count: 4 } repaired && Is(repaired.Items[0], "repaired") && repaired.Items[1].Equals(name))
        {
            if (verify)
            {
                await Call(
                    context,
                    "disk_log",
                    "close",
                    name
                );
                Throw(A("badfile"));
            }

            return name;
        }
        if (ErrorPair(opened, out Term reason))
        {
            Throw(Term.Tuple(A("read_error"), reason));
        }
        Throw(opened);

        return name;
    }

    private static async ValueTask<EtsFileHeader> Header(ProcessContext context, Term name, bool verify)
    {
        Term result = await Chunk(
            context,
            name,
            A("start"),
            1,
            verify,
            verify
        );
        if (result is not TupleTerm { Items.Count: 2 } pair || pair.Items[1] is not Cons { Tail: Nil } item)
        {
            Throw(A("badfile"));
            throw new InvalidOperationException();
        }
        Term header = verify && item.Head is BitString ? await Call(
            context,
            "erlang",
            "binary_to_term",
            item.Head
        ) : item.Head;
        if (header is not TupleTerm tuple)
        {
            Throw(A("badfile"));
            throw new InvalidOperationException();
        }
        string[] mandatory = ["name", "type", "protection", "named_table", "keypos", "size"];
        if (tuple.Items.Count(field => field is TupleTerm { Items.Count: 2 } fieldPair
            && fieldPair.Items[0] is Atom tag && mandatory.Contains(tag.Name)) != 6)
        {
            Throw(A("badfile"));
        }
        Term extra = FieldValue(tuple.Items, "extended_info", Nil.Value);
        var parsed = new EtsFileOptions();
        if (IsList(extra))
        {
            parsed.ObjectCount = Cons.Items(extra).Any(value => Is(value, "object_count"));
            parsed.Md5 = Cons.Items(extra).Any(value => Is(value, "md5sum"));
        }
        Term digest = verify && parsed.Md5
            ? await Call(
                context,
                "erlang",
                "md5_update",
                await Call(context, "erlang", "md5_init"),
                item.Head
            ) : A("false");

        // OTP deliberately reads major/minor in the verifying branch, major_version/minor_version otherwise.
        return new EtsFileHeader(
            FieldValue(tuple.Items, verify ? "major" : "major_version", Term.I(0)),
            FieldValue(tuple.Items, verify ? "minor" : "minor_version", Term.I(0)),
            parsed,
            digest,
            tuple.Items,
            pair.Items[0]
        );
    }

    private static (bool Verify, Term Table) ParseLoadOptions(Term options)
    {
        bool verify = false;
        Term table = Nil.Value;
        Term cursor = options;
        while (cursor is Cons cell)
        {
            if (cell.Head is TupleTerm { Items.Count: 2 } pair && Is(pair.Items[0], "verify")
                && (Is(pair.Items[1], "true") || Is(pair.Items[1], "false")))
            {
                verify |= Is(pair.Items[1], "true");
            }
            else if (cell.Head is TupleTerm { Items.Count: 2 } given && Is(given.Items[0], "table") && table is Nil)
            {
                table = given.Items[1];
            }
            else
            {
                Throw(Term.Tuple(A("unknown_option"), cell.Head));
            }
            cursor = cell.Tail;
        }
        if (cursor is not Nil)
        {
            Throw(Term.Tuple(A("malformed_option"), cursor));
        }

        return (verify, table);
    }

    private static TupleTerm RequireFileField(
        ProcessContext context,
        IReadOnlyList<Term> fields,
        string key,
        int line
    )
    {
        using var location = context.EnterSourceLocation(EtsSource.Location(line));
        Term found = Field(fields, key);
        if (found is TupleTerm { Items.Count: 2 } pair)
        {
            return pair;
        }

        throw context.CaptureSourceFailure(new ErlangException(Term.Tuple(A("badmatch"), found)));
    }

    private static ErlangException FileCaseFailure(ProcessContext context, Term value, int line)
    {
        using var location = context.EnterSourceLocation(EtsSource.Location(line));

        return context.CaptureSourceFailure(new ErlangException(Term.Tuple(A("case_clause"), value)));
    }

    private static async ValueTask<Term> CreateFileTable(ProcessContext context, IReadOnlyList<Term> fields, Term existing)
    {
        using var source = EtsSource.Frame(
            context,
            "create_tab",
            2,
            3491
        );
        Term name = RequireFileField(
            context,
            fields,
            "name",
            3491
        ).Items[1];
        Term type = RequireFileField(
            context,
            fields,
            "type",
            3492
        ).Items[1];
        Term protection = RequireFileField(
            context,
            fields,
            "protection",
            3493
        ).Items[1];
        Term keypos = RequireFileField(
            context,
            fields,
            "keypos",
            3494
        );
        _ = RequireFileField(
            context,
            fields,
            "size",
            3495
        );
        var options = new List<Term> { type, protection, keypos };
        Term named = Field(fields, "named_table");
        if (named is TupleTerm { Items.Count: 2 } namedPair && Is(namedPair.Items[1], "true"))
        {
            options.Insert(0, A("named_table"));
        }
        else if (named is not TupleTerm { Items.Count: 2 } namedFalse || !Is(namedFalse.Items[1], "false"))
        {
            throw FileCaseFailure(context, named, 3497);
        }
        Term compressed = Field(fields, "compressed");
        if (compressed is TupleTerm { Items.Count: 2 } compressedPair && Is(compressedPair.Items[1], "true"))
        {
            options.Insert(0, A("compressed"));
        }
        else if (!Is(compressed, "false") && (compressed is not TupleTerm { Items.Count: 2 } compressedFalse || !Is(compressedFalse.Items[1], "false")))
        {
            throw FileCaseFailure(context, compressed, 3501);
        }
        foreach (string option in new[] { "write_concurrency", "read_concurrency" })
        {
            Term value = Field(fields, option);
            if (value is TupleTerm { Items.Count: 2 })
            {
                options.Insert(0, value);
            }
            else if (option == "read_concurrency" && !Is(value, "false"))
            {
                throw FileCaseFailure(context, value, 3510);
            }
        }
        if (existing is not Nil)
        {
            return existing;
        }
        try
        {
            return await Call(
                context,
                Name,
                "new",
                name,
                Cons.From(options)
            );
        }
        catch (ErlangException)
        {
            Throw(A("cannot_create_table"));

            return Nil.Value;
        }
    }

    private static async ValueTask<Term> Load(ProcessContext context, Term file, Term options)
    {
        try
        {
            var parsed = ParseLoadOptions(options);
            Term name = await OpenRead(context, file, parsed.Verify);
            EtsFileHeader header;
            try
            {
                header = await Header(context, name, parsed.Verify);
            }
            catch (ErlangException error) when (error.ExceptionClass == "throw" && Is(error.Reason, "badfile"))
            {
                await Call(
                    context,
                    "disk_log",
                    "close",
                    name
                );
                throw;
            }
            try
            {
                if (TermOrder.Compare(header.Major, Term.I(1)) > 0)
                {
                    Throw(Term.Tuple(A("unsupported_file_version"), Term.Tuple(header.Major, header.Minor)));
                }
                Term table;
                using (context.EnterSourceLocation(EtsSource.Location(3168)))
                {
                    table = await CreateFileTable(context, header.Fields, parsed.Table);
                }
                try
                {
                    EtsFileOptions validation = parsed.Verify ? header.Options : new EtsFileOptions();
                    Term cursor = header.Cursor;
                    Term digest = header.Digest;
                    Term last = Nil.Value;
                    long count = 0;
                    while (true)
                    {
                        Term chunk = await Chunk(
                            context,
                            name,
                            cursor,
                            100,
                            validation.Md5,
                            parsed.Verify
                        );
                        if (Is(chunk, "eof"))
                        {
                            break;
                        }
                        if (chunk is not TupleTerm { Items.Count: 2 } pair)
                        {
                            throw new ErlangException(Term.Tuple(A("case_clause"), chunk));
                        }
                        cursor = pair.Items[0];
                        var data = new List<Term>();
                        last = Nil.Value;
                        Term remaining = pair.Items[1];
                        while (remaining is Cons cell)
                        {
                            Term term = cell.Head;
                            if (validation.Md5)
                            {
                                try
                                {
                                    term = await Call(
                                        context,
                                        "erlang",
                                        "binary_to_term",
                                        term
                                    );
                                }
                                catch (ErlangException)
                                {
                                    remaining = cell.Tail;
                                    continue;
                                }
                            }
                            if (term is Cons { Tail: Cons { Tail: Nil } } end && Is(end.Head, "$end_of_table")
                                && (validation.Md5 || cell.Tail is Nil))
                            {
                                last = term;
                                break;
                            }
                            if (validation.Md5)
                            {
                                digest = await Call(
                                    context,
                                    "erlang",
                                    "md5_update",
                                    digest,
                                    cell.Head
                                );
                            }
                            data.Add(term);
                            count++;
                            remaining = cell.Tail;
                        }
                        if (data.Count == 0)
                        {
                            break;
                        }
                        await Call(
                            context,
                            Name,
                            "insert",
                            table,
                            Cons.From(data)
                        );
                    }
                    if (last is Nil)
                    {
                        if (validation.Md5 || validation.ObjectCount)
                        {
                            Throw(A("badfile"));
                        }
                        if (parsed.Verify && !Term.I(count).Equals(FieldValue(header.Fields, "size")))
                        {
                            Throw(A("invalid_object_count"));
                        }
                    }
                    else
                    {
                        Term[] endInfo = Cons.Items(((Cons)((Cons)last).Tail).Head).ToArray();
                        if (validation.Md5 && !(await Call(
                            context,
                            "erlang",
                            "md5_final",
                            digest
                        )).Equals(FieldValue(endInfo, "md5")))
                        {
                            Throw(A("checksum_error"));
                        }
                        Term expected = validation.ObjectCount ? FieldValue(endInfo, "count") : FieldValue(header.Fields, "size");
                        if ((validation.ObjectCount || parsed.Verify && !validation.Md5) && !Term.I(count).Equals(expected))
                        {
                            Throw(A("invalid_object_count"));
                        }
                    }

                    return Term.Tuple(A("ok"), table);
                }
                catch (ErlangException)
                {
                    await Call(
                        context,
                        Name,
                        "delete",
                        table
                    );
                    throw;
                }
            }
            finally
            {
                await Call(
                    context,
                    "disk_log",
                    "close",
                    name
                );
            }
        }
        catch (ErlangException error) when (error.ExceptionClass is "throw" or "exit")
        {
            return ErrorResult(error.Reason);
        }
    }

    private static async ValueTask<Term> FileInfo(ProcessContext context, Term file)
    {
        if (file is not Atom && !IsList(file))
        {
            throw EtsSource.Error(
                context,
                "tabfile_info",
                [file],
                A("function_clause"),
                3611
            );
        }
        try
        {
            Term name = await OpenRead(context, file, false);
            EtsFileHeader header;
            try
            {
                header = await Header(context, name, false);
            }
            catch (ErlangException error) when (error.ExceptionClass == "throw" && Is(error.Reason, "badfile"))
            {
                await Call(
                    context,
                    "disk_log",
                    "close",
                    name
                );
                throw;
            }
            Term closed = await Call(
                context,
                "disk_log",
                "close",
                name
            );
            if (ErrorPair(closed, out Term reason))
            {
                Throw(reason);
            }
            var fields = new List<Term>();
            foreach (string tag in new[] { "name", "type", "protection", "named_table", "keypos", "size" })
            {
                fields.Add(Field(header.Fields, tag));
            }
            fields.Add(Field(header.Fields, "extended_info", Term.Tuple(A("extended_info"), Nil.Value)));
            fields.Add(Term.Tuple(A("version"), Term.Tuple(header.Major, header.Minor)));

            return Term.Tuple(A("ok"), Cons.From(fields));
        }
        catch (ErlangException error) when (error.ExceptionClass is "throw" or "exit")
        {
            return ErrorResult(error.Reason);
        }
    }
}
