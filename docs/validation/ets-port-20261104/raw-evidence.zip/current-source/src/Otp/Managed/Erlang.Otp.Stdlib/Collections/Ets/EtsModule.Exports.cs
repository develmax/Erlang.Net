namespace Erlang;

public static partial class EtsModule
{
    public static IReadOnlyList<(string Name, int Arity)> NativeExports { get; } = Array.AsReadOnly(new (string, int)[]
    {
        ("new", 2), ("whereis", 1), ("insert", 2), ("lookup", 2), ("member", 2),
        ("delete", 1), ("delete", 2), ("select", 2), ("lookup_element", 3), ("lookup_element", 4),
        ("match", 2), ("internal_select_delete", 2), ("internal_delete_all", 2), ("match_object", 2),
        ("select_count", 2), ("select_reverse", 2), ("insert_new", 2), ("take", 2), ("delete_object", 2),
        ("update_element", 3), ("update_element", 4), ("first", 1), ("last", 1), ("next", 2), ("prev", 2),
        ("first_lookup", 1), ("last_lookup", 1), ("next_lookup", 2), ("prev_lookup", 2),
        ("update_counter", 3), ("update_counter", 4), ("rename", 2), ("setopts", 2), ("give_away", 3),
        ("is_compiled_ms", 1), ("match_spec_compile", 1), ("match_spec_run_r", 3), ("internal_request_all", 0),
        ("safe_fixtable", 2), ("slot", 2), ("match", 1), ("match", 3), ("match_object", 1), ("match_object", 3),
        ("select", 1), ("select", 3), ("select_reverse", 1), ("select_reverse", 3), ("select_replace", 2),
        ("info", 1), ("info", 2)
    });

    public static IReadOnlyList<(string Name, int Arity)> Exports => Array.AsReadOnly(
        NativeExports.Concat(LibraryExports).OrderBy(export => export.Name, StringComparer.Ordinal).ThenBy(export => export.Arity).ToArray()
    );
}
