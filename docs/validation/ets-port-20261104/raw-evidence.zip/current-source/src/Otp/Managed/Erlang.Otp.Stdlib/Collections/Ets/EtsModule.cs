// Derived from lib/stdlib/src/ets.erl, OTP-29.1.1, Apache-2.0.
// Copyright Ericsson AB 1996-2026. Original source and notices remain unchanged.
namespace Erlang;

/// <summary>The explicitly selected C# ETS library over the shared runtime ETS primitives.</summary>
public static partial class EtsModule
{
    public const string Name = "ets";

    public static IReadOnlyList<(string Name, int Arity)> LibraryExports { get; } = Array.AsReadOnly(new (string, int)[]
    {
        ("all", 0), ("delete_all_objects", 1), ("select_delete", 2),
        ("file2tab", 1), ("file2tab", 2), ("foldl", 3), ("foldr", 3),
        ("match_delete", 2), ("tab2file", 2), ("tab2file", 3), ("tabfile_info", 1),
        ("from_dets", 2), ("to_dets", 2), ("init_table", 2), ("test_ms", 2),
        ("tab2list", 1), ("table", 1), ("table", 2), ("fun2ms", 1),
        ("match_spec_run", 2), ("repair_continuation", 2),
        ("i", 0), ("i", 1), ("i", 2), ("i", 3)
    });

    public static void Register(ModuleRegistry registry)
        => registry.InstallSourceWrappers(target =>
        {
            foreach (var export in LibraryExports)
            {
                string function = export.Name;
                target.RegisterReviewedManagedLibrary789(
                    Name,
                    function,
                    export.Arity,
                    (context, arguments) => Invoke(context, function, arguments)
                );
            }
        });

    public static async ValueTask<Term> Invoke(ProcessContext context, string function, IReadOnlyList<Term> arguments)
    {
        if (NativeExports.Contains((function, arguments.Count)))
        {
            return await context.Runtime.Modules.Call(
                context,
                Name,
                function,
                arguments.ToArray()
            );
        }
        if (!LibraryExports.Contains((function, arguments.Count)))
        {
            throw new ErlangException(ErlangErrorReasons.UndefinedFunction);
        }
        using var tail = context.EnterSourceTailCall(Name, function);
        int line = function switch
        {
            "all" => 319,
            "delete_all_objects" => 387,
            "select_delete" => arguments[1].Equals(Term.List(Term.Tuple(A("_"), Nil.Value, Term.List(A("true"))))) ? 1850 : 1852,
            "tab2list" => 2773,
            "match_delete" => 2762,
            "match_spec_run" => 2296,
            "repair_continuation" => 2352,
            "foldl" => 2495,
            "foldr" => 2537,
            "init_table" => 2718,
            "test_ms" => 2675,
            "table" => 3742,
            "fun2ms" => 2448,
            "tab2file" => 2879,
            "file2tab" => 3092,
            "tabfile_info" => 3611,
            "i" => arguments.Count == 0 ? 3883 : 3947,
            _ => 1
        };
        using var source = EtsSource.Frame(
            context,
            function,
            function is "table" or "file2tab" ? 2 : function == "tab2file" || function == "i" && arguments.Count > 0 ? 3 : arguments.Count,
            line
        );
        switch (function)
        {
            case "all":
                Term reference = await Call(context, Name, "internal_request_all");
                var schedulers = (Integer)await Call(
                    context,
                    "erlang",
                    "system_info",
                    A("schedulers")
                );
                Term tables = Nil.Value;
                for (var lane = schedulers.Value; lane > 0; lane--)
                {
                    TupleTerm reply = (await context.ReceiveAsync(value => value is TupleTerm { Items.Count: 2 } pair
                        && pair.Items[0].Equals(reference) ? pair : null))!;
                    tables = Cons.From(Cons.Items(reply.Items[1]), tables);
                }

                return tables;
            case "delete_all_objects":
                await Call(
                    context,
                    Name,
                    "internal_delete_all",
                    arguments[0],
                    A("undefined")
                );

                return A("true");
            case "select_delete":
                if (arguments[1].Equals(Term.List(Term.Tuple(A("_"), Nil.Value, Term.List(A("true"))))))
                {
                    return await Call(
                        context,
                        Name,
                        "internal_delete_all",
                        arguments[0],
                        A("undefined")
                    );
                }

                return await Call(
                    context,
                    Name,
                    "internal_select_delete",
                    arguments[0],
                    arguments[1]
                );
            case "tab2list":
                return await Call(
                    context,
                    Name,
                    "match_object",
                    arguments[0],
                    A("_")
                );
            case "match_delete":
                await Invoke(context, "select_delete", [arguments[0], Term.List(Term.Tuple(arguments[1], Nil.Value, Term.List(A("true"))))]);

                return A("true");
            case "match_spec_run":
                return await Call(
                    context,
                    "lists",
                    "reverse",
                    await Call(
                        context,
                        Name,
                        "match_spec_run_r",
                        arguments[0],
                        arguments[1],
                        Nil.Value
                    )
                );
            case "repair_continuation":
                return await Repair(context, arguments[0], arguments[1]);
            case "foldl":
            case "foldr":
                return await Fold(
                    context,
                    function == "foldr",
                    arguments[0],
                    arguments[1],
                    arguments[2]
                );
            case "init_table":
                return await Initialize(context, arguments[0], arguments[1]);
            case "test_ms":
                Term tested = await Call(
                    context,
                    "erlang",
                    "match_spec_test",
                    arguments[0],
                    arguments[1],
                    A("table")
                );

                return tested is TupleTerm { Items.Count: 4 } result && Is(result.Items[0], "ok")
                    ? Term.Tuple(A("ok"), result.Items[1]) : tested;
            case "from_dets":
            case "to_dets":
                return await Dets(
                    context,
                    function,
                    arguments[0],
                    arguments[1]
                );
            case "fun2ms":
                return await FunToMatchSpec(context, arguments[0]);
            case "tab2file":
                return await Save(
                    context,
                    arguments[0],
                    arguments[1],
                    arguments.Count == 3 ? arguments[2] : Nil.Value
                );
            case "file2tab":
                return await Load(context, arguments[0], arguments.Count == 2 ? arguments[1] : Nil.Value);
            case "tabfile_info":
                return await FileInfo(context, arguments[0]);
            case "table":
                return await QueryTable(context, arguments[0], arguments.Count == 2 ? arguments[1] : Nil.Value);
            case "i":
                return arguments.Count == 0 ? await DisplayTables(context)
                    : await Browse(
                        context,
                        arguments[0],
                        arguments.Count >= 2 ? arguments[1] : Term.I(40),
                        arguments.Count == 3 ? arguments[2] : Term.I(80)
                    );
            default:
                throw new ErlangException(ErlangErrorReasons.UndefinedFunction);
        }
    }

    private static Atom A(string value) => Term.A(value);

    private static bool Is(Term value, string atom) => value is Atom a && a.Name == atom;

    private static bool IsList(Term value) => value is Nil or Cons;

    private static ValueTask<Term> Call(
        ProcessContext context,
        string module,
        string function,
        params Term[] arguments
    )
        => context.Runtime.Modules.Call(
            context,
            module,
            function,
            arguments
        );

    private static async ValueTask<Term> SoftWhereis(ProcessContext context, Term table)
    {
        if (table is not Atom)
        {
            return table;
        }
        Term reference = await Call(
            context,
            Name,
            "whereis",
            table
        );
        if (Is(reference, "undefined"))
        {
            throw EtsSource.Error(
                context,
                "soft_whereis",
                [table],
                A("badarg"),
                2553,
                Term.Tuple(
                    A("error_info"),
                    new MapTerm([
                    new KeyValuePair<Term, Term>(A("cause"), A("id")),
                    new KeyValuePair<Term, Term>(A("module"), A("erl_stdlib_errors"))
                ])
                )
            );
        }

        return reference;
    }

    private static async ValueTask<Term> Apply(ProcessContext context, Term function, params Term[] arguments)
    {
        if (function is not FunctionTerm callback)
        {
            throw ErlangFunctionCallErrors.Capture(context, Term.Tuple(A("badfun"), function));
        }
        if (callback.Arity != arguments.Length)
        {
            throw ErlangFunctionCallErrors.Capture(context,
                Term.Tuple(A("badarity"), Term.Tuple(function, Term.List(arguments))));
        }

        try
        {
            return await callback.Invoke(context, arguments);
        }
        catch (ErlangException error)
        {
            throw context.CaptureSourceFailure(error);
        }
    }

    private static async ValueTask<Term> Repair(ProcessContext context, Term continuation, Term spec)
    {
        if (Is(continuation, "$end_of_table"))
        {
            return continuation;
        }
        if (continuation is TupleTerm tuple && (tuple.Items.Count == 8
            && tuple.Items[3] is Integer && IsList(tuple.Items[5]) && tuple.Items[6] is Integer && tuple.Items[7] is Integer
            || tuple.Items.Count == 6 && tuple.Items[1] is Integer && tuple.Items[2] is Integer
            && IsList(tuple.Items[4]) && tuple.Items[5] is Integer))
        {
            int position = tuple.Items.Count == 8 ? 4 : 3;
            if (Is(await Call(
                context,
                Name,
                "is_compiled_ms",
                tuple.Items[position]
            ), "true"))
            {
                return continuation;
            }
            Term[] values = tuple.Items.ToArray();
            using var location = context.EnterSourceLocation(EtsSource.Location(tuple.Items.Count == 8 ? 2366 : 2380));
            values[position] = await Call(
                context,
                Name,
                "match_spec_compile",
                spec
            );

            return Term.Tuple(values);
        }

        throw EtsSource.Error(
            context,
            "repair_continuation",
            [continuation, spec],
            A("function_clause"),
            2352
        );
    }

    private static async ValueTask<Term> Fold(
        ProcessContext context,
        bool reverse,
        Term function,
        Term accumulator,
        Term tableArg
    )
    {
        Term table = await SoftWhereis(context, tableArg);
        Term cursor;
        using (context.EnterSourceLocation(EtsSource.Location(reverse ? 2538 : 2496)))
        {
            await Call(
                context,
                Name,
                "safe_fixtable",
                table,
                A("true")
            );
        }
        using (context.EnterSourceLocation(EtsSource.Location(reverse ? 2539 : 2497)))
        {
            cursor = await Call(
                context,
                Name,
                reverse ? "last_lookup" : "first_lookup",
                table
            );
        }
        using var body = context.EnterSourceLocation(EtsSource.Location(reverse ? 2541 : 2499));
        try
        {
            while (!Is(cursor, "$end_of_table"))
            {
                var pair = (TupleTerm)cursor;
                using var helper = EtsSource.Frame(
                    context,
                    reverse ? "do_foldr" : "do_foldl",
                    4,
                    reverse ? 2548 : 2506
                );
                accumulator = await Call(
                    context,
                    "lists",
                    reverse ? "foldr" : "foldl",
                    function,
                    accumulator,
                    pair.Items[1]
                );
                using var next = context.EnterSourceLocation(EtsSource.Location(reverse ? 2549 : 2507));
                cursor = await Call(
                    context,
                    Name,
                    reverse ? "prev_lookup" : "next_lookup",
                    table,
                    pair.Items[0]
                );
            }

            return accumulator;
        }
        finally
        {
            using var release = context.EnterSourceLocation(EtsSource.Location(reverse ? 2543 : 2501));
            await Call(
                context,
                Name,
                "safe_fixtable",
                table,
                A("false")
            );
        }
    }

    private static async ValueTask<Term> Initialize(ProcessContext context, Term tableArg, Term function)
    {
        Term table = await SoftWhereis(context, tableArg);
        using (context.EnterSourceLocation(EtsSource.Location(2719)))
        {
            await Invoke(context, "delete_all_objects", [table]);
        }
        Term chunk;
        using (context.EnterSourceLocation(EtsSource.Location(2720)))
        {
            chunk = await Apply(context, function, A("read"));
        }
        using var continuation = EtsSource.Frame(
            context,
            "init_table_continue",
            2,
            2725,
            tail: true
        );
        while (!Is(chunk, "end_of_input"))
        {
            if (chunk is not TupleTerm { Items.Count: 2 } pair || !IsList(pair.Items[0]) || pair.Items[1] is not FunctionTerm)
            {
                using var failed = context.EnterSourceLocation(EtsSource.Location(2733));
                throw context.CaptureSourceFailure(new ErlangException(chunk, "exit"));
            }
            function = pair.Items[1];
            try
            {
                using var insert = EtsSource.Frame(
                    context,
                    "init_table_sub",
                    2,
                    2738
                );
                Term input = pair.Items[0];
                while (input is Cons cell)
                {
                    await Call(
                        context,
                        Name,
                        "insert",
                        table,
                        cell.Head
                    );
                    input = cell.Tail;
                }
                if (input is not Nil)
                {
                    throw EtsSource.Error(
                        context,
                        "init_table_sub",
                        [table, input],
                        A("function_clause"),
                        2735
                    );
                }
            }
            catch (ErlangException error)
            {
                await Ignore(() => Apply(context, function, A("close")));
                Term reason = error.ExceptionClass == "error" ? Term.Tuple(error.Reason, error.StackTraceTerm) : error.Reason;
                using var failed = context.EnterSourceLocation(EtsSource.Location(2728));
                throw context.CaptureSourceFailure(new ErlangException(reason, "exit"));
            }
            using var read = context.EnterSourceLocation(EtsSource.Location(2730));
            chunk = await Apply(context, function, A("read"));
        }

        return A("true");
    }

    private static async ValueTask<Term> Dets(
        ProcessContext context,
        string function,
        Term table,
        Term disk
    )
    {
        Term result;
        try
        {
            result = await Call(
                context,
                "dets",
                function == "from_dets" ? "to_ets" : "from_ets",
                disk,
                table
            );
        }
        catch (ErlangException error)
        {
            result = error.ExceptionClass == "throw" ? error.Reason
                : Term.Tuple(A("EXIT"), error.ExceptionClass == "error" ? Term.Tuple(error.Reason, error.StackTraceTerm) : error.Reason);
        }
        if (result is TupleTerm { Items.Count: 2 } pair && (Is(pair.Items[0], "error") || Is(pair.Items[0], "EXIT")))
        {
            Term reason = Is(pair.Items[0], "EXIT") && pair.Items[1] is TupleTerm { Items.Count: 2 } exit ? exit.Items[0] : pair.Items[1];
            int line = function == "from_dets" ? Is(pair.Items[0], "error") ? 2590 : pair.Items[1] is TupleTerm { Items.Count: 2 } ? 2592 : 2594
                : Is(pair.Items[0], "error") ? 2631 : pair.Items[1] is TupleTerm { Items.Count: 2 } ? 2633 : 2635;
            throw EtsSource.Error(
                context,
                function,
                [table, disk],
                reason,
                line
            );
        }
        if (result.Equals(function == "from_dets" ? table : A("ok")))
        {
            return function == "from_dets" ? A("true") : disk;
        }

        throw EtsSource.Error(
            context,
            function,
            [table, disk],
            result,
            function == "from_dets" ? 2598 : 2639
        );
    }

    private static async ValueTask<Term> FunToMatchSpec(ProcessContext context, Term function)
    {
        if (function is not FunctionTerm)
        {
            throw EtsSource.Error(
                context,
                "fun2ms",
                [function],
                A("function_clause"),
                2447
            );
        }
        Term data = await Call(
            context,
            "erl_eval",
            "fun_data",
            function
        );
        if (data is TupleTerm { Items.Count: 3 } tuple && Is(tuple.Items[0], "fun_data"))
        {
            Term transformed = await Call(
                context,
                "ms_transform",
                "transform_from_shell",
                A(Name),
                tuple.Items[2],
                tuple.Items[1]
            );

            return transformed is TupleTerm { Items.Count: 3 } error && Is(error.Items[0], "error") && error.Items[1] is Cons
                ? Term.Tuple(A("error"), A("transform_error")) : transformed;
        }

        using var failed = context.EnterSourceLocation(EtsSource.Location(2459));
        throw context.CaptureSourceFailure(new ErlangException(
            Term.Tuple(
                A("badarg"),
                Term.Tuple(
                    A(Name),
                    A("fun2ms"),
                    Term.List("function called with real fun should be transformed with parse_transform or called with a fun generated in the shell".Split(' ').Select(value => (Term)A(value)).ToArray())
                )
            ),
            "exit"
        ));
    }

    private static async ValueTask Ignore(Func<ValueTask<Term>> action)
    {
        try
        {
            await action();
        }
        catch (ErlangException)
        {
        }
    }
}
