// Native buffer primitives for unchanged OTP-29.1.1 prim_buffer.erl.
// Derived from OTP prim_buffer_nif.c, Apache-2.0, Ericsson AB 2017-2026.
namespace Erlang;

internal sealed class PrimBufferBuiltinOwner(ProcessRuntime runtime) : IAsyncDisposable
{
    private int disposed;

    internal IReadOnlyList<KeyValuePair<(string Name, int Arity), ErlangFunction>> Bindings()
        => PrimBufferBuiltinNames.Signatures.Select(signature =>
        {
            string function = signature.Name;
            return new KeyValuePair<(string, int), ErlangFunction>(signature,
                (context, arguments) => ValueTask.FromResult(Invoke(context, function, arguments)));
        }).ToArray();

    private Term Invoke(ProcessContext context, string function, IReadOnlyList<Term> arguments)
    {
        ObjectDisposedException.ThrowIf(Volatile.Read(ref disposed) != 0, this);
        if (!ReferenceEquals(context.Runtime, runtime)) { throw new ErlangException(ErlangErrorReasons.BadArgument); }
        context.Cancellation.ThrowIfCancellationRequested();
        runtime.ThrowIfHalted();
        if (function == PrimBufferBuiltinNames.New) { return runtime.ReferenceResources.CreateBuffer(new PrimBufferDataResource()); }
        if (arguments[0] is not ReferenceTerm reference) { throw new ErlangException(ErlangErrorReasons.BadArgument); }
        using var lease = runtime.ReferenceResources.AcquireBuffer(reference);
        if (lease is null) { throw new ErlangException(ErlangErrorReasons.BadArgument); }
        var buffer = lease.Value;
        if (function == PrimBufferBuiltinNames.Lock)
        {
            return Term.A(Interlocked.CompareExchange(ref buffer.Locked, 1, 0) == 0 ? "acquired" : "busy");
        }
        if (function == PrimBufferBuiltinNames.Unlock)
        {
            Volatile.Write(ref buffer.Locked, 0);
            return Term.A(CommonAtomNames.Ok);
        }
        lock (buffer.Gate)
        {
            switch (function)
            {
                case PrimBufferBuiltinNames.Size: return Term.I(buffer.Size);
                case PrimBufferBuiltinNames.Write:
                    BitString[] segments = ErlangIoData.Segments(arguments[1], false, false).ToArray();
                    foreach (BitString segment in segments)
                    {
                        if (segment.BitLength == 0) { continue; }
                        buffer.Segments.Enqueue(segment);
                        buffer.Size += segment.BitLength / 8;
                    }
                    return Term.A(CommonAtomNames.Ok);
                case PrimBufferBuiltinNames.Peek:
                    if (buffer.Segments.Count == 0) { return new BitString(Array.Empty<byte>()); }
                    BitString head = buffer.Segments.Peek();
                    return head.SliceBits(buffer.HeadOffset * 8, head.BitLength - buffer.HeadOffset * 8);
                case PrimBufferBuiltinNames.Read: case PrimBufferBuiltinNames.Skip:
                    if (arguments[1] is not Integer count || count.Value < 0 || count.Value > buffer.Size || count.Value > int.MaxValue)
                    {
                        throw new ErlangException(ErlangErrorReasons.BadArgument);
                    }
                    int remaining = (int)count.Value;
                    byte[]? bytes = function == PrimBufferBuiltinNames.Read ? new byte[remaining] : null;
                    int destination = 0;
                    while (remaining != 0)
                    {
                        BitString segment = buffer.Segments.Peek();
                        int size = Math.Min(remaining, segment.BitLength / 8 - buffer.HeadOffset);
                        if (bytes is not null) { segment.ByteSpan.Slice(buffer.HeadOffset, size).CopyTo(bytes.AsSpan(destination)); }
                        remaining -= size;
                        destination += size;
                        buffer.HeadOffset += size;
                        buffer.Size -= size;
                        if (buffer.HeadOffset == segment.BitLength / 8) { buffer.Segments.Dequeue(); buffer.HeadOffset = 0; }
                    }
                    return bytes is null ? Term.A(CommonAtomNames.Ok) : new BitString(bytes);
                case PrimBufferBuiltinNames.Find:
                    if (arguments[1] is not Integer needle || needle.Value < 0 || needle.Value > byte.MaxValue)
                    {
                        throw new ErlangException(ErlangErrorReasons.BadArgument);
                    }
                    long offset = 0;
                    int skip = buffer.HeadOffset;
                    foreach (BitString segment in buffer.Segments)
                    {
                        int index = segment.ByteSpan[skip..].IndexOf((byte)needle.Value);
                        if (index >= 0) { return Term.Tuple(Term.A(CommonAtomNames.Ok), Term.I(offset + index)); }
                        offset += segment.BitLength / 8 - skip;
                        skip = 0;
                    }
                    return Term.A("not_found");
                default: throw new ErlangException(ErlangErrorReasons.BadArgument);
            }
        }
    }

    public ValueTask DisposeAsync()
    {
        Interlocked.Exchange(ref disposed, 1);
        return ValueTask.CompletedTask;
    }
}
