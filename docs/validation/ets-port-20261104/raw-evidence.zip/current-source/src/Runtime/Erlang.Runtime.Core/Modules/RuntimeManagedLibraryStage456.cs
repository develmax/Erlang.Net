namespace Erlang;

public enum RuntimeManagedLibraryStage456
{
    Collections,
    Modules,
    BinaryWrappers,
    String,
    Unicode,
    Ets,
    GenEvent,
    Timer,
    GenStatem,
    File,
    Code,
    Dets
}
