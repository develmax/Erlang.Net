using System.Security.Cryptography;
using System.Text.Json;
using Erlang;

if (args.Length is not (3 or 4) || args[2] is not ("Managed" or "Beam")
    || args.Length == 4 && args[3] is not ("files" or "browse"))
{
    Console.Error.WriteLine("Usage: Erlang.EtsCompatibility <repository> <oracle-directory> Managed|Beam");

    return 2;
}
string repository = Path.GetFullPath(args[0]);
string directory = Path.GetFullPath(args[1]);
bool managed = args[2] == "Managed";
bool files = args.Length == 4 && args[3] == "files";
bool browse = args.Length == 4 && args[3] == "browse";
await using var runtime = await ProcessRuntime.CreateAsync(
    new RuntimeLibrarySelection(managed ? [RuntimeModuleSelection.Managed(EtsModule.Name)] : []),
    RuntimeNativePrimitives.InternalScalars413 | RuntimeNativePrimitives.PersistentTermCore,
    CancellationToken.None
);
string stdlib = Path.Combine(repository, "src/Otp/Original/Foundation/Erlang.Otp.Stdlib.Beam/Otp");
string kernel = Path.Combine(repository, "src/Otp/Original/Foundation/Erlang.Otp.Kernel.Beam/Otp/ebin");
string erts = Path.Combine(repository, "src/Otp/Original/Foundation/Erlang.Otp.Erts.Beam/Otp/ebin");
string[] dependencies = Directory.GetFiles(Path.Combine(repository, "src/Otp/Original"), "*.beam", SearchOption.AllDirectories)
    .Select(Path.GetFileNameWithoutExtension).Cast<string>().Append("erlang").Append("ets_port_cases").Append("ets_port_device").Append("ets_port_support").Distinct().ToArray();
var images = new List<PreparedBeamImage>();
RuntimeRegexEngine411? regexEngine = null;
await runtime.InitializeModulesAsync(registry =>
{
    if (!managed)
    {
        RuntimeBootstrapEtsLibrary.Register(runtime, registry);
    }
    if (files)
    {
        RuntimeBootstrapFileSystem.Register(runtime, registry);
    }
});
if (browse)
{
    regexEngine = await RuntimeNativePrimitiveProviders.RegisterRegexAsync411(runtime, runtime.Modules,
        Path.Combine(repository, "artifacts/library376-official-compiler/official-admission.json"));
}
string[] fileHelpers = ["file", "raw_file_io", "file_server", "file_io_server", "os", "ram_file", "raw_file_io_list",
    "raw_file_io_delayed", "raw_file_io_compressed", "raw_file_io_deflate", "raw_file_io_inflate", "prim_file", "prim_buffer", "ets_port_support",
    "gen_server", "gen", "proc_lib", "sys", "supervisor", "disk_log", "disk_log_server", "disk_log_sup", "disk_log_1",
    "logger", "logger_config", "logger_backend", "logger_filters", "logger_server", "logger_proxy", "io_lib", "io_lib_format",
    "io", "filename", "unicode", "unicode_util", "binary", "proplists", "erl_posix_msg",
    "dets_server", "dets_sup", "dets_utils", "dets_v9", "init", "timer", "file_sorter"];
foreach (string module in new[] { "lists", "qlc", "gb_trees", "gb_sets", "sets", "maps", "orddict", "ordsets", "sofs", "erl_eval", "ms_transform", "dets",
    "erl_anno", "erl_parse", "erl_lint", "erl_internal", "erl_scan", "eval_bits", "erl_features", "os" }
    .Concat(files ? fileHelpers : []).Distinct()
    .Concat(browse ? new[] { "io", "io_lib", "io_lib_format", "io_lib_pretty", "unicode", "unicode_util", "string", "binary", "re", "net_kernel", "epp", "ets_port_device" } : [])
    .Concat(managed ? [] : new[] { "ets" }).Append("ets_port_cases"))
{
    string file = module is "ets_port_cases" or "ets_port_device" or "ets_port_support" ? Path.Combine(directory, module + ".beam")
        : new[] { stdlib, kernel, erts }.Select(path => Path.Combine(path, module + ".beam")).First(File.Exists);
    Console.WriteLine("Prepare: " + module);
    images.Add(runtime.Modules.PrepareBeam(File.ReadAllBytes(file), new BeamDependencySelection(dependencies)));
}
await runtime.InitializeModulesAsync(registry =>
{
    if (registry.PublishPreparedBeam(images.Where(value => !value.HasOnLoad).ToArray()).Status != BeamPublicationStatus.Published)
    {
        throw new InvalidOperationException("ETS dependency publication failed");
    }
});
foreach (PreparedBeamImage image in images.Where(value => value.HasOnLoad))
{
    BeamOnLoadResult loaded = await runtime.Modules.LoadPreparedOnLoadAsync(runtime, image);
    if (!loaded.Published)
    {
        throw new InvalidOperationException("ETS dependency on_load failed: " + loaded);
    }
}
await Run(async context =>
{
    foreach (TupleTerm field in Cons.Items(ExternalTermFormat.Decode(File.ReadAllBytes(Path.Combine(directory, "features.etf")))))
    {
        await runtime.Modules.Call(
            context,
            "persistent_term",
            "put",
            Term.Tuple(Term.A("erl_features"), field.Items[0]),
            field.Items[1]
        );
    }
    await runtime.Modules.Call(
        context,
        "persistent_term",
        "put",
        Term.Tuple(Term.A("erl_features"), Term.A("init_done")),
        Term.A("true")
    );

    return Term.A("ok");
});
if (files)
{
    Console.WriteLine("File server: " + await Run(async context =>
    {
        await runtime.Modules.Call(
            context,
            "persistent_term",
            "put",
            Term.Tuple(Term.A("logger_config"), Term.A("$primary_config$")),
            Term.I(-1)
        );
        await runtime.Modules.Call(context, "prim_file", "on_load");
        await runtime.Modules.Call(context, "prim_buffer", "on_load");

        return await runtime.Modules.Call(
            context,
            "gen_server",
            "start",
            Term.Tuple(Term.A("local"), Term.A("file_server_2")),
            Term.A("file_server"),
            Nil.Value,
            Nil.Value
        );
    }));
    var supervisorReady = new TaskCompletionSource<Term>(TaskCreationOptions.RunContinuationsAsynchronously);
    _ = runtime.Spawn(async context =>
    {
        try
        {
            supervisorReady.TrySetResult(await runtime.Modules.Call(
                context,
                "supervisor",
                "start_link",
                Term.Tuple(Term.A("local"), Term.A("kernel_safe_sup")),
                Term.A("ets_port_support"),
                Nil.Value
            ));
            await context.ReceiveAsync(value => value is Atom { Name: "stop" } ? value : null);
        }
        catch (Exception error)
        {
            supervisorReady.TrySetException(error);
        }

        return Nil.Value;
    });
    Console.WriteLine("Kernel test supervisor: " + await supervisorReady.Task.WaitAsync(TimeSpan.FromSeconds(15)));
}
var declared = Cons.Items(ExternalTermFormat.Decode(File.ReadAllBytes(Path.Combine(directory, "exports.etf"))))
    .Cast<TupleTerm>().Select(row => (((Atom)row.Items[0]).Name, (int)((Integer)row.Items[1]).Value)).ToHashSet();
var actual = runtime.Modules.Exports.Where(export => export.Module == EtsModule.Name).Select(export => (export.Function, export.Arity)).ToHashSet();
if (!declared.SetEquals(actual))
{
    throw new InvalidOperationException("ETS export surface differs: missing=" + string.Join(',', declared.Except(actual))
        + "; extra=" + string.Join(',', actual.Except(declared)));
}
if (!EtsModule.Exports.ToHashSet().SetEquals(declared.Where(export => export.Name != "module_info")))
{
    throw new InvalidOperationException("ETS public inventory differs from pinned exports");
}
PreparedBeamImage? etsImage = managed ? null : images.Single(image => image.Name == EtsModule.Name);
var native = managed ? runtime.LibrarySelection.Modules.Single(module => module.Module == EtsModule.Name).NativePrimitives
    : etsImage!.NativePrimitiveExports;
if (!EtsModule.NativeExports.ToHashSet().SetEquals(native.Select(export => (export.Name, export.Arity))))
{
    throw new InvalidOperationException("ETS native capability surface differs from the pinned stubs");
}
foreach (var export in actual)
{
    object? owner = runtime.Modules.SourceOwner(EtsModule.Name, export.Function, export.Arity);
    if (managed ? owner is not null : !ReferenceEquals(owner, etsImage))
    {
        throw new InvalidOperationException("ETS selected backend owner mismatch");
    }
}
var failures = new List<object>();
int passed = 0;
Term[] rows = files || browse ? [] : Cons.Items(runtime.ImportExternalTerm(File.ReadAllBytes(Path.Combine(directory, "original.etf"))).Term).ToArray();
foreach (TupleTerm row in rows)
{
    var sent = (TupleTerm)await Run(context => runtime.Modules.Call(
        context,
        "ets_port_cases",
        "worker",
        row.Items[0],
        row.Items[1],
        context.Self
    ));
    Term result = sent.Items[1];
    if (result.Equals(row.Items[2]))
    {
        passed++;
    }
    else
    {
        failures.Add(new { Function = row.Items[0].ToString(), Arguments = row.Items[1].ToString(), Expected = row.Items[2].ToString(), Actual = result.ToString() });
    }
}
int effects = 0;
string effectFile = files ? "filesystem.etf" : browse ? "browse.etf" : "effects.etf";
Term[] effectRows = Cons.Items(ExternalTermFormat.Decode(File.ReadAllBytes(Path.Combine(directory, effectFile)))).ToArray();
foreach (TupleTerm row in effectRows)
{
    Console.WriteLine("Scenario: " + row.Items[0]);
    var sent = (TupleTerm)await Run(context => runtime.Modules.Call(
        context,
        "ets_port_cases",
        "scenario_worker",
        row.Items[0],
        context.Self
    ));
    Term result = sent.Items[1];
    if (result.Equals(row.Items[1]))
    {
        effects++;
    }
    else
    {
        failures.Add(new { Scenario = row.Items[0].ToString(), Expected = row.Items[1].ToString(), Actual = result.ToString() });
    }
}
bool regexDataBalanced = regexEngine is null || regexEngine.Report.MatchDataCreated == regexEngine.Report.MatchDataFreed;
if (!regexDataBalanced)
{
    failures.Add(new { RegexMatchDataLeak = regexEngine!.Report });
}
string? exportedDump = null;
bool? exportedDataMatched = null;
if (files)
{
    exportedDump = Path.Combine(directory, args[2] + ".dump");
    Term exported = await Run(context => runtime.Modules.Call(
        context,
        "ets_port_cases",
        "make_dump",
        Term.String(exportedDump)
    ));
    exportedDataMatched = exported.Equals(ExternalTermFormat.Decode(File.ReadAllBytes(Path.Combine(directory, "dump-data.etf"))));
    if (exportedDataMatched != true)
    {
        failures.Add(new { ExportedDump = exportedDump, Actual = exported.ToString() });
    }
}
File.WriteAllText(
    Path.Combine(directory, args[2] + (files ? "-files" : browse ? "-browse" : "") + "-report.json"),
    JsonSerializer.Serialize(
        new
        {
            Backend = args[2],
            Baseline = "OTP-29.1.1",
            Exports = actual.Count,
            PublicExports = EtsModule.Exports.Count,
            LibraryExports = EtsModule.LibraryExports.Count,
            NativeExports = native.Count,
            Cases = rows.Length,
            Passed = passed,
            Effects = effects,
            EffectCases = effectRows.Length,
            EffectFile = effectFile,
            CompleteCorpus = true,
            RegexDataBalanced = regexDataBalanced,
            ExportedDataMatched = exportedDataMatched,
            ExportedDumpSha256 = exportedDump is not null && File.Exists(exportedDump) ? Digest(exportedDump) : null,
            Failures = failures,
            ManagedAssemblySha256 = Digest(typeof(EtsModule).Assembly.Location),
            RuntimeAssemblySha256 = Digest(typeof(ProcessRuntime).Assembly.Location),
            EtsBeamSha256 = Digest(Path.Combine(stdlib, "ets.beam")),
            CorpusSha256 = Digest(Path.Combine(directory, "original.etf")),
            EffectsSha256 = Digest(Path.Combine(directory, effectFile)),
            FeatureStateSha256 = Digest(Path.Combine(directory, "features.etf")),
            ObserverBeamSha256 = Digest(Path.Combine(directory, "ets_port_cases.beam")),
            DeviceBeamSha256 = Digest(Path.Combine(directory, "ets_port_device.beam"))
        },
        new JsonSerializerOptions { WriteIndented = true }
    )
);
Console.WriteLine($"{args[2]}: {passed}/{rows.Length} contracts, {effects} effects, {failures.Count} differences");

return failures.Count == 0 ? 0 : 1;

static string Digest(string path) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path)));

async Task<Term> Run(Func<ProcessContext, ValueTask<Term>> body)
{
    var result = new TaskCompletionSource<Term>(TaskCreationOptions.RunContinuationsAsynchronously);
    ProcessHandle worker = runtime.Spawn(async context =>
    {
        try
        {
            result.TrySetResult(await body(context));
        }
        catch (ErlangException error)
        {
            result.TrySetResult(Term.Tuple(
                Term.A("uncaught"),
                Term.A(error.ExceptionClass),
                error.Reason,
                error.StackTraceTerm
            ));
        }
        catch (Exception error)
        {
            result.TrySetException(error);
        }

        return Nil.Value;
    });
    Term value = await result.Task.WaitAsync(TimeSpan.FromSeconds(30));
    await worker.Completion.WaitAsync(TimeSpan.FromSeconds(10));

    return value;
}
