# Independent metadata527 source review

Scope: current w517fix source snapshot recorded in snapshot.json. No active edits, build, VM/native execution, Git or CI operations. Collector refresh is independently in progress; its currently missing wiring is not presented as a new production defect.

## Actionable evidence-admission gap

**P2 — Bind the actual executing preloaded module witness before selecting its metadata.** `DynamicApplyNativeMetadata527Admission.Verify` checks the identity sidecar, selected BEAM SHA, source-copy SHA and the occurrence of selected bytes at an offset in the named runtime binary. It never reads the declared `RunningModuleMd5Witness` (`metadata-image527.py`), nor validates that witness against the selected image's actual BEAM NativeMd5 and the admitted launched runtime core. Thus an embedded image found in a file is admitted without the promised check that the observed VM executed that image. Capture the real running erlang module MD5 (plus actual provider/executable identity), include its raw bytes in the completion-bound inventory, and check it against the selected image before constructing the managed metadata profile. Wrong witness/provider must reject admission while legitimate missing Line remains accepted. A matching MD5 alone does not prove Line/debug metadata: retain the exact actual-core binary/offset/SHA binding because BEAM module MD5 excludes metadata chunks.

## Production paths checked, no concrete new blocker found

- Missing Line is legitimate: `BeamInstructionLocations` starts at Nil and ignores absent source locations; `RuntimeNativeMetadataImage` distinguishes `found` from nonempty selected metadata and accepts a found error/3 call whose location is Nil. It does not fall back to a fabricated file/line merely because Nil was selected.
- A wrong module is rejected by the erlang module identity check; the linked function/error import are checked by module, name and arity. The public constructor's absent-export case currently throws Single's InvalidOperationException instead of its named InvalidDataException, but it still rejects the image. This is diagnostic consistency, not a demonstrated compatibility/authority defect.
- New import access is downstream of existing instruction scalar checks (0..int.MaxValue) and linked import/arity checks. Atom references, exported function boundaries and location indexes are validated by the existing readers. No new unchecked negative/truncated index was identified.
- The metadata profile snapshots input bytes and stores immutable selected metadata/hash. Mutation of the caller's input does not alter the profile.
- Default options retain the preexisting ErrorWithInfo location. Explicit selected lineless metadata remains Nil because null-coalescing selects only absence of a profile, not absence of source locations. prepare_loading and unrelated native error paths are unchanged.

## Suggested finite admission controls

1. A genuine executing witness matching the selected embedded image is accepted.
2. A different executing erlang MD5 is rejected before managed VM entry.
3. An execution/provider core mismatch is rejected even if a supplied file contains a self-consistent erlang BEAM.
4. The admitted actual embedded lineless image stays lineless; no stack normalization or outcome-derived replacement is allowed.

No full contract or CI status is inferred from this source review.
