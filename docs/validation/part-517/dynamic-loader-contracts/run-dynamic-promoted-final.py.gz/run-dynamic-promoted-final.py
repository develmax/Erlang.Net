from pathlib import Path
import hashlib,json,importlib.util,shutil,os
repo=Path.cwd();out=repo/'artifacts/batch520/dynamic-promoted-managed';assert not out.exists();out.mkdir()
helper=repo/'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py';s=importlib.util.spec_from_file_location('owned520final',helper);owned=importlib.util.module_from_spec(s);s.loader.exec_module(owned)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
runner=repo/'tests/Erlang.Tests/bin/Debug/net10.0/Erlang.Tests.dll';host=Path(shutil.which('dotnet'));completion=repo/'artifacts/batch520/dynamic-promoted-original/completion.json';rt=host.parent/'shared/Microsoft.NETCore.App/10.0.11';assert rt.exists()
files=[p for p in runner.parent.rglob('*') if p.is_file() and p.suffix in ['.dll','.exe','.pdb','.json']]+[p for p in rt.rglob('*') if p.is_file()]+[host,completion,helper,Path(__file__)]
closure=[dict(Path=str(p.resolve()),Sha256=sha(p)) for p in files];(out/'execution-admission.json').write_text(json.dumps(closure,indent=2)+'\n');rows=[]
for profile,flag in [('ordinary','false'),('private-owned','true')]:
 folder=out/profile;folder.mkdir();error=None
 try:phase=owned.owned([str(host),'exec','--fx-version','10.0.11',str(runner),'--dynamic-apply-boundary520-child',str(repo),str(completion),sha(completion),flag,str(folder/'actual')],folder,'managed',30,dict(os.environ,DOTNET_PROCESSOR_COUNT='2'),repo)
 except Exception as ex:error=repr(ex);phase=json.loads((folder/'managed.exit.json').read_bytes())
 matches=[]
 for name in ['observed.etf','observed-deterministic.etf']:
  actual=folder/'actual'/name;expected=completion.parent/name
  matches.append(dict(File=name,OriginalSha256=sha(expected),ManagedSha256=sha(actual) if actual.exists() else None,Equal=actual.exists() and actual.read_bytes()==expected.read_bytes()))
 rows.append(dict(Profile=profile,WholeCases=26,Phase=phase,Error=error,Files=matches,Passed=phase.get('ExitCode')==0 and all(m['Equal'] for m in matches)))
 print(profile,rows[-1]['Passed'],flush=True)
equal=all(sha(r['Path'])==r['Sha256'] for r in closure)
(out/'completion.json').write_text(json.dumps(dict(WholeCasesPerProfile=26,Profiles=rows,AllPassed=all(r['Passed'] for r in rows),ExecutionClosureEqual=equal,RawRewritten=False,WholePublicContractsPromoted=0),indent=2)+'\n')
raise SystemExit(0 if equal and all(r['Passed'] for r in rows) else 1)
