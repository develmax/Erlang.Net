from pathlib import Path
import importlib.util,json,os,subprocess,sys,hashlib
r=Path.cwd();o=r/'artifacts/ci93-narrow/final-builds';o.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('owned',r/'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
freeze=json.loads((r/'artifacts/ci93-narrow/final4-source-freeze.json').read_bytes())
def check():
 for row in freeze['Rows']:assert hashlib.sha256((r/row['Path']).read_bytes()).hexdigest().upper()==row['Sha256']
rows=[]
for cfg,project in [('Debug','Erlang.Otp.TestAnalysis.Library.Tests'),('Release','Erlang.Tests'),('Release','Erlang.Otp.TestAnalysis.Library.Tests')]:
 check();label=cfg+'-'+project;receipt=m.owned(['dotnet','build',f'tests/{project}/{project}.csproj','-c',cfg,'--no-restore','-m:1','-p:UseSharedCompilation=false','-p:BuildInParallel=false','-v:q'],o,label,240,dict(os.environ,DOTNET_PROCESSOR_COUNT='1',DOTNET_GCConserveMemory='9'),str(r));check();rows.append({'Configuration':cfg,'Project':project,'Receipt':receipt});print(json.dumps({'Built':label,'Seconds':receipt['ElapsedSeconds']}),flush=True)
(o/'completion.json').write_text(json.dumps({'Passed':True,'Builds':rows},indent=2))
