from pathlib import Path
import hashlib
import importlib.util
import json
import os
import subprocess

r = Path.cwd()
out = r / 'artifacts/ci93-narrow/testanalysis-empty-graph-fix'
out.mkdir(exist_ok=False)
assert True
host = r / 'tests/Erlang.Otp.TestAnalysis.Library.Tests/bin/Debug/net10.0/Erlang.Otp.TestAnalysis.Library.Tests.dll'
before = {p.name: hashlib.sha256(p.read_bytes()).hexdigest().upper() for p in host.parent.iterdir() if p.is_file() and (p.suffix == '.dll' or p.name.endswith(('.deps.json', '.runtimeconfig.json')))}
(out / 'assemblies-before.json').write_text(json.dumps(before, indent=2))
spec = importlib.util.spec_from_file_location('owned', r / 'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py')
owned = importlib.util.module_from_spec(spec)
spec.loader.exec_module(owned)
error = None
try:
    owned.owned(['dotnet', 'exec', '--fx-version', '10.0.11', str(host), str(out / 'managed')], out, 'testanalysis', 60, dict(os.environ, DOTNET_PROCESSOR_COUNT='2', DOTNET_GCConserveMemory='9'), str(r))
except Exception as failure:
    error = repr(failure)
receipt = json.loads((out / 'testanalysis.exit.json').read_bytes())
after = {p.name: hashlib.sha256(p.read_bytes()).hexdigest().upper() for p in host.parent.iterdir() if p.is_file() and (p.suffix == '.dll' or p.name.endswith(('.deps.json', '.runtimeconfig.json')))}
assert before == after
result = {'Passed': error is None and receipt['ExitCode'] == 0 and receipt['Settled'] and not receipt['TimedOut'], 'Receipt': receipt, 'Error': error, 'ProductionHead': '7f565b5699df157541817b97172a81f760006cc2', 'ProductionRuntimeUnmodified': False, 'ReadOnlyTestInstrumentation': True}
(out / 'completion.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result))
raise SystemExit(0 if result['Passed'] else 1)
