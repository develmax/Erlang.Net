from pathlib import Path
import json,hashlib,zipfile
r=Path.cwd();root=r/'artifacts/ci93-narrow';out=r/'docs/validation/part-541-shutdown';out.mkdir(exist_ok=False)
profiles=[]
for label in ['final-debug','final-release']:
 value=json.loads((root/label/'completion.json').read_bytes());assert value['Passed'] and value['Cases']==371 and value['NoDiagnosticInstrumentation'];original=json.loads((root/label/'original/completion.json').read_bytes());assert original['Passed'] and original['Outcomes']==2463;profiles.append({'Configuration':value['Configuration'],'Cases':371,'TestAnalysisSeconds':value['TestAnalysis']['ElapsedSeconds'],'RawEtfSha256':original['RawEtfSha256'],'OriginalOutcomes':2463,'ProcessSettled':value['TestAnalysis']['Settled'],'SourceCommit':original['SourceCommit']})
rows=json.loads((root/'final4-source-freeze.json').read_bytes())['Rows']
for row in rows:assert hashlib.sha256((r/row['Path']).read_bytes()).hexdigest().upper()==row['Sha256']
summary={'Passed':True,'Profiles':profiles,'AffectedCompositePerProfile':[140,140,19,38,33,1],'RootlessRegressionRed':True,'OriginalDiagnosticTimeoutsAccepted':False,'IncompleteSandbox371Accepted':False,'SourceRows':rows,'CurrentSourceFreezeSha256':hashlib.sha256((r/'docs/validation/part-541/current-source-freeze.json').read_bytes()).hexdigest().upper(),'ApiDelta':0,'WholeContractDelta':0,'KnownDifferences':24,'ResourceBearingShutdownDerivedPublicationProven':False,'FullCiPending':True}
(out/'summary.json').write_text(json.dumps(summary,indent=2))
files=[]
for prefix,base in [('narrow',root),('metadata',r/'artifacts/resource541-shutdown-metadata')]:
 for p in sorted(base.rglob('*')):
  if p.is_file() and not any(n in p.parts for n in ['style-scratch','final-style4','__pycache__']):files.append((prefix+'/'+p.relative_to(base).as_posix(),p))
for label in ['correction-empty-red','correction-empty-green','correction-final-debug371']:
 base=r/'artifacts/resource541'/label
 for p in sorted(base.rglob('*')):
  if p.is_file():files.append(('regressions/'+label+'/'+p.relative_to(base).as_posix(),p))
for row in rows:files.append(('final-source/'+row['Path'],r/row['Path']))
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in files:z.writestr(name,p.read_bytes())
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(files)==len(set(z.namelist()))
 for name,p in files:assert z.read(name)==p.read_bytes()
receipt={'Sha256':hashlib.sha256(archive.read_bytes()).hexdigest().upper(),'Bytes':archive.stat().st_size,'Members':len(files),'EveryMemberVerified':True};(out/'archive.json').write_text(json.dumps(receipt,indent=2));print(json.dumps({'Profiles':profiles,'Archive':receipt}))
