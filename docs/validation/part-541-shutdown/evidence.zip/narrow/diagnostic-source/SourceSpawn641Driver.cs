using System.Diagnostics;
using System.Reflection;
using System.Text.Json;
using Erlang.Compiler;
using Erlang.Differential;

namespace Erlang.NifNativeBackend;

internal static class SourceSpawn641Driver
{
    internal static async Task Run()
    {
        FieldInfo inputField = typeof(ProcessContext).GetField(
            SourceSpawn641Names.InputField,
            BindingFlags.Instance | BindingFlags.NonPublic
        ) ?? throw new InvalidOperationException(SourceSpawn641Names.MissingInput);
        using var compiled = GeneratedModuleCompiler.Compile(SourceSpawn641Names.Source);
        var samples = new List<object>();
        foreach (int size in SourceSpawn641Names.Sizes)
        {
            for (int repetition = 0; repetition < SourceSpawn641Names.Repetitions; repetition++)
            {
                Console.WriteLine(JsonSerializer.Serialize(new { Phase = SourceSpawn641Names.Arm, Size = size, Repetition = repetition }));
                var runtime = new ProcessRuntime();
                int entered = 0;
                compiled.Definition.Register(runtime.Modules);
                NifNativeHarness.Require(ReferenceEquals(
                    runtime.Modules.SourceOwner(SourceSpawn641Names.Module, SourceSpawn641Names.Arm, 1),
                    compiled.Definition
                ));
                runtime.Modules.RegisterIntrinsic(
                    SourceSpawn641Names.Bridge,
                    SourceSpawn641Names.Entered,
                    0,
                    (context, _) =>
                    {
                        NifNativeHarness.Require(inputField.GetValue(context) is not null);
                        Interlocked.Increment(ref entered);

                        return ValueTask.FromResult<Term>(Term.A(ErlangBooleanAtoms.True));
                    }
                );
                double armMilliseconds = 0;
                double retireMilliseconds = 0;
                double disposeMilliseconds;
                try
                {
                    await NifNativeHarness.Context(runtime, async context =>
                    {
                        var watch = Stopwatch.StartNew();
                        Term pids = await Execution.InvokeAsync(
                            compiled.Definition,
                            SourceSpawn641Names.Arm,
                            context,
                            [Term.I(size)]
                        );
                        armMilliseconds = watch.Elapsed.TotalMilliseconds;
                        Pid[] ids = Cons.Items(pids).Cast<Pid>().ToArray();
                        NifNativeHarness.Require(ids.Length == size && Volatile.Read(ref entered) == size);
                        ProcessHandle[] children = ids.Select(runtime.GetProcessHandle).ToArray();
                        NifNativeHarness.Require(children.All(child => !child.Completion.IsCompleted));
                        watch.Restart();
                        await Execution.InvokeAsync(
                            compiled.Definition,
                            SourceSpawn641Names.Release,
                            context,
                            [pids]
                        );
                        Term[] reasons = await Task.WhenAll(children.Select(child => child.Completion))
                            .WaitAsync(SourceSpawn641Names.Deadline);
                        retireMilliseconds = watch.Elapsed.TotalMilliseconds;
                        NifNativeHarness.Require(reasons.All(reason => reason.Equals(Term.A(SourceSpawn641Names.Normal))));
                    });
                }
                finally
                {
                    var disposeWatch = Stopwatch.StartNew();
                    await runtime.DisposeAsync();
                    disposeMilliseconds = disposeWatch.Elapsed.TotalMilliseconds;
                }

                samples.Add(new
                {
                    Size = size,
                    Repetition = repetition,
                    ActualSourceMfaChildrenWithClaimedInput = entered,
                    ArmMilliseconds = armMilliseconds,
                    ReleaseAndPhysicalDoneMilliseconds = retireMilliseconds,
                    DisposeMilliseconds = disposeMilliseconds
                });
                Console.WriteLine(JsonSerializer.Serialize(samples[^1]));
            }
        }

        Console.WriteLine(JsonSerializer.Serialize(new
        {
            Samples = samples,
            SourceMfa = true,
            EveryChildActualInputChecked = true,
            OriginalOtpComparison = false,
            WholeCiSpeedClaim = false
        }));
    }
}
