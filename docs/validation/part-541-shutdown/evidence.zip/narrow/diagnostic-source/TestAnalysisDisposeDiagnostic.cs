using System.Collections;
using System.Reflection;
using System.Text.Json;
using Erlang;

namespace Erlang.Otp.TestAnalysis.Library.Tests;

internal static class TestAnalysisDisposeDiagnostic
{
    private const BindingFlags Fields = BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public;
    private static object? Read(object? value, string field) => value?.GetType().GetField(field, Fields)?.GetValue(value);
    private static object? Property(object? value, string name) => value?.GetType().GetProperty(name, Fields)?.GetValue(value);
    private static string? Status(object? value) => value is Task task ? task.Status.ToString() : Property(value, "Task") is Task completion ? completion.Status.ToString() : null;
    private static object[] Snapshot(object owner, string collection)
    {
        object? gate = Read(owner, "gate");
        if (gate is null || !Monitor.TryEnter(gate, 100)) return [];
        try { return (Read(owner, collection) as IEnumerable)?.Cast<object>().ToArray() ?? []; }
        finally { Monitor.Exit(gate); }
    }
    internal static void Dump(ProcessRuntime runtime)
    {
        object? owner = Read(runtime, "processPayloads641");
        object[] work = owner is null ? [] : Snapshot(owner, "live");
        object[] executing = Snapshot(runtime, "executingProcesses");
        Console.Error.WriteLine(JsonSerializer.Serialize(new
        {
            Diagnostic = "DisposePending",
            Disposed = Read(runtime, "disposed"),
            HaltResult = Read(runtime, "haltResult")?.ToString(),
            Processes = (Read(runtime, "processes") as ICollection)?.Count,
            PayloadOwnerStopped = Read(owner, "stopped"),
            PayloadOwnerDrained = Read(owner, "drained"),
            Work = work.Select(item => new
            {
                Context = (Property(item, "Context641") as ProcessContext)?.Self.ToString(),
                Ended = Read(item, "ended"), Scheduled = Read(item, "scheduled"),
                QueueSettled = Read(item, "queueSettled"), Executing = Read(item, "executing"),
                Ready = Status(Read(item, "ready")), Done = Status(Read(item, "done")),
                Dependency = Status(Read(item, "dependency")), PayloadType = Read(item, "payload")?.GetType().FullName
            }).ToArray(),
            Executing = executing.Select(item => new
            {
                Pid = (item as ProcessContext)?.Self.ToString(),
                CancellationRequested = (item as ProcessContext)?.Cancellation.IsCancellationRequested,
                InitialCall = Property(item, "InitialCall")?.ToString(),
                Terminated = Read(item, "Terminated"),
                ExecutionStarted = Read(item, "ExecutionStarted"),
                WaitingForMessage = Read(item, "WaitingForMessage"),
                SchedulerRole = Property(Property(item, "ActorTaskScheduler"), "Role")?.ToString(),
                SchedulerRunning = Property(Property(item, "ActorTaskScheduler"), "Running"),
                SchedulerQueued = Property(Property(item, "ActorTaskScheduler"), "WorkCount428"),
                SchedulerReady = Property(Property(item, "ActorTaskScheduler"), "ReadyNode") is not null,
                Tasks = item.GetType().GetFields(Fields).Select(field => new { field.Name, Value = Status(field.GetValue(item)) }).Where(value => value.Value is not null).ToArray()
            }).ToArray(),
            RuntimeTasks = runtime.GetType().GetFields(Fields).Select(field => new { field.Name, Value = Status(field.GetValue(runtime)) }).Where(value => value.Value is not null).ToArray()
        }));
    }
}
