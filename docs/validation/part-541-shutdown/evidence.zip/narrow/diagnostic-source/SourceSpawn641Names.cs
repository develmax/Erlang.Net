namespace Erlang.NifNativeBackend;

internal static class SourceSpawn641Names
{
    internal const string Mode = "--source-spawn641-benchmark";
    internal const string Module = "source_spawn641_probe";
    internal const string Bridge = "source_spawn641_bridge";
    internal const string Entered = "entered";
    internal const string Arm = "arm";
    internal const string Release = "release";
    internal const string InputField = "VmSpawnInput641";
    internal const string MissingInput = "Missing actual spawn-input custody field";
    internal const string Normal = "normal";
    internal const int Repetitions = 3;
    internal static readonly int[] Sizes = [16, 128, 512];
    internal static readonly TimeSpan Deadline = TimeSpan.FromSeconds(30);
    internal const string Source = """
        -module(source_spawn641_probe).
        -export([arm/1, child/1, release/1]).
        arm(N) -> Pids = start(N, self(), []), ready(N), Pids.
        start(0, _, Acc) -> Acc;
        start(N, Parent, Acc) ->
            Pid = spawn(source_spawn641_probe, child, [Parent]),
            start(N - 1, Parent, [Pid | Acc]).
        ready(0) -> ok;
        ready(N) -> receive ready -> ready(N - 1) end.
        child(Parent) ->
            source_spawn641_bridge:entered(),
            Parent ! ready,
            receive go -> ok end.
        release([]) -> ok;
        release([Pid | Rest]) -> Pid ! go, release(Rest).
        """;
}
