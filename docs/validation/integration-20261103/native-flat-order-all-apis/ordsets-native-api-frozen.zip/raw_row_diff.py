"""Read-only ETF framing: compare unchanged row byte slices, never normalize maps."""
import pathlib,json,hashlib
root=pathlib.Path(__file__).parent
def tree(data):
    def read(pos):
        start=pos;tag=data[pos];pos+=1;children=[];atom=None
        if tag==97:pos+=1
        elif tag==98:pos+=4
        elif tag==70:pos+=8
        elif tag in (100,118):
            n=int.from_bytes(data[pos:pos+2],'big');pos+=2;atom=data[pos:pos+n].decode('utf-8' if tag==118 else 'latin1');pos+=n
        elif tag in (115,119):
            n=data[pos];pos+=1;atom=data[pos:pos+n].decode('utf-8' if tag==119 else 'latin1');pos+=n
        elif tag==106:pass
        elif tag==107:
            n=int.from_bytes(data[pos:pos+2],'big');pos+=2+n
        elif tag in (109,77):
            n=int.from_bytes(data[pos:pos+4],'big');pos+=4+n+(1 if tag==77 else 0)
        elif tag in (110,111):
            width=1 if tag==110 else 4;n=int.from_bytes(data[pos:pos+width],'big');pos+=width+1+n
        elif tag in (104,105,108,116,113):
            if tag==113:n=3
            else:
                width=1 if tag==104 else 4;n=int.from_bytes(data[pos:pos+width],'big');pos+=width
                if tag==116:n*=2
            for _ in range(n):
                child,pos=read(pos);children.append(child)
            if tag==108:
                tail,pos=read(pos);assert tail['tag']==106
        else:raise ValueError(f'Unsupported ETF tag {tag} at {start}')
        return {'start':start,'end':pos,'tag':tag,'children':children,'atom':atom},pos
    assert data[0]==131
    result,end=read(1);assert end==len(data);return result
gold=(root/'original.etf').read_bytes();expected=tree(gold)
reports={}
for backend in ['Managed','Beam']:
    actual=(root/'before'/(backend+'.actual.etf')).read_bytes();observed=tree(actual)
    diffs=[]
    assert len(expected['children'])==len(observed['children'])==8
    for layout,(x,y) in enumerate(zip(expected['children'],observed['children'])):
        xr=x['children'][3]['children'];yr=y['children'][3]['children'];assert len(xr)==len(yr)==21
        for slot,(e,a) in enumerate(zip(xr,yr)):
            name=e['children'][0]['atom'];assert name==a['children'][0]['atom']
            arity=len(e['children'][1]['children'])
            assert arity==len(a['children'][1]['children'])
            ei=e['children'][1];ai=a['children'][1]
            assert gold[ei['start']:ei['end']]==actual[ai['start']:ai['end']],(layout,name,'Input arguments differ')
            if gold[e['start']:e['end']]!=actual[a['start']:a['end']]:
                diffs.append({'LayoutIndex':layout,'RowWithinLayout':slot,'GlobalRowIndex':layout*21+slot,
                    'Mfa':f'ordsets:{name}/{arity}','InputArgumentsByteIdentical':True,
                    'OriginalByteSpan':[e['start'],e['end']],'ActualByteSpan':[a['start'],a['end']]})
    reports[backend]={'Rows':168,'DifferentRawRows':len(diffs),'AffectedMFAs':sorted(set(x['Mfa'] for x in diffs)),'Differences':diffs}
assert reports['Managed']==reports['Beam']
out={'Comparison':'Original unchanged ETF row byte spans, no decoding/reencoding/normalization','OriginalSha256':hashlib.sha256(gold).hexdigest().upper(),'Before':reports}
(root/'raw-row-differences.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:{'DifferentRawRows':v['DifferentRawRows'],'AffectedMFAs':v['AffectedMFAs']}for k,v in reports.items()},indent=2))
