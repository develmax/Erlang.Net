namespace Erlang.Tests;

internal static class NifNativeFlatOrderTestNames
{
    internal const string Managed = "runtime/ordsets/native-flat-physical-order/managed";
    internal const string Beam = "runtime/ordsets/native-flat-physical-order/beam";
    internal const string OrdsetsImage = "ordsets.beam";
    internal const string ListsImage = "lists.beam";
}
