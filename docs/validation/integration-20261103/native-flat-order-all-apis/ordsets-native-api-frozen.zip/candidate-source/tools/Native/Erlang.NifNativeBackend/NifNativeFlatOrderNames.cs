namespace Erlang.NifNativeBackend;

internal static class NifNativeFlatOrderNames
{
    internal const string Module = "ordsets";
    internal const string Lists = "lists";
    internal const string Equal = "is_equal";
    internal const string Member = "is_element";
    internal const string Sorted = "is_set";
    internal const string FirstAtom = "a";
    internal const string LastAtom = "z";
    internal const string Failure = "Native physical flat-map comparison diverged from pinned OTP.";
    internal const string OrdsetsSha = "417595CFD47FF9DC43673CEE03083776CBACD3ABB61166BF58C61DC6A13CCE1D";
    internal const string ListsSha = "8941092DC34F0470CD404979E1890DF514D83F2EEB3B0AA8A276553E76471262";
    internal const int ChangedByte = 128;
    internal const int ValueBase = 100;
    internal static readonly int[] Counts = [2, 32];
    internal static readonly int[] BinarySizes = [64, 65];
    internal static readonly byte[] Targets = [0, ChangedByte];
    internal static readonly TimeSpan Deadline = TimeSpan.FromSeconds(30);
}
