using System.Security.Cryptography;
using static Erlang.NifNativeBackend.NifNativeFlatOrderNames;

namespace Erlang.NifNativeBackend;

public static class NifNativeFlatOrderHostChecks
{
    public static async Task Run(bool original, byte[] ordsets, byte[] lists)
    {
        if (original)
        {
            Require(Convert.ToHexString(SHA256.HashData(ordsets)) == OrdsetsSha);
            Require(Convert.ToHexString(SHA256.HashData(lists)) == ListsSha);
        }
        await using var runtime = await ProcessRuntime.CreateAsync(new RuntimeLibrarySelection(original
            ? [RuntimeModuleSelection.Beam(Module, ordsets, [Lists]), RuntimeModuleSelection.Beam(Lists, lists)]
            : [RuntimeModuleSelection.Managed(Module), RuntimeModuleSelection.Managed(Lists)]));
        var selected = runtime.LibrarySelection.Modules.Single(module => module.Module == Module);
        Require(selected.Backend == (original ? RuntimeModuleBackend.Beam : RuntimeModuleBackend.Managed));
        if (original)
            Require(runtime.Modules.Exports.Where(export => export.Module == Module)
                .All(export => runtime.Modules.SourceOwner(export.Module, export.Function, export.Arity) is PreparedBeamImage));

        var completed = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        ProcessHandle actor = runtime.Spawn(async context =>
        {
            try
            {
                foreach (int count in Counts)
                    foreach (int size in BinarySizes)
                        foreach (byte target in Targets)
                        {
                            MapTerm native = Materialize(
                                context.Runtime,
                                count,
                                size,
                                target
                            );
                            var fresh = new MapTerm(native.Entries);
                            bool same = target == 0;
                            int expected = same ? 0 : 1;
                            Require(Math.Sign(TermOrder.Compare(native, fresh)) == expected);
                            Require(Math.Sign(TermOrder.Compare(fresh, native)) == -expected);
                            Require(native.NumericEquals(fresh) == same);
                            Require(native.Equals(fresh) == same);
                            Require(Term.Tuple(native).NumericEquals(Term.Tuple(fresh)) == same);
                            Require(Term.List(native).NumericEquals(Term.List(fresh)) == same);
                            Require(Math.Sign(TermOrder.Compare(Term.Tuple(native), Term.Tuple(fresh))) == expected);
                            Term equal = await runtime.Modules.Call(
                                context,
                                Module,
                                Equal,
                                Term.List(native),
                                Term.List(fresh)
                            );
                            Term member = await runtime.Modules.Call(
                                context,
                                Module,
                                Member,
                                native,
                                Term.List(fresh)
                            );
                            Term sorted = await runtime.Modules.Call(
                                context,
                                Module,
                                Sorted,
                                Term.List(native, fresh)
                            );
                            Term reverseSorted = await runtime.Modules.Call(
                                context,
                                Module,
                                Sorted,
                                Term.List(fresh, native)
                            );
                            Require(equal.Equals(CoreModules.Boolean(same)));
                            Require(member.Equals(CoreModules.Boolean(same)));
                            Require(sorted.Equals(CoreModules.Boolean(false)));
                            Require(reverseSorted.Equals(CoreModules.Boolean(!same)));
                        }
                MapTerm atomLeft = Materialize(
                    context.Runtime,
                    Counts[0],
                    BinarySizes[1],
                    ChangedByte,
                    true
                );
                var atomFresh = new MapTerm(atomLeft.Entries);
                MapTerm atomRight = Materialize(
                    context.Runtime,
                    Counts[0],
                    BinarySizes[1],
                    ChangedByte,
                    true,
                    true
                );
                Require(TermOrder.Compare(atomLeft, atomFresh) > 0 && !atomLeft.NumericEquals(atomFresh));
                Require(TermOrder.Compare(atomLeft, atomRight) > 0 && !atomLeft.NumericEquals(atomRight));
                completed.TrySetResult();
            }
            catch (Exception error)
            {
                completed.TrySetException(error);
            }

            return Nil.Value;
        });
        await completed.Task.WaitAsync(Deadline);
        Term reason = await actor.Completion.WaitAsync(Deadline);
        Require(reason.Equals(Term.A(ProcessExitReasons.Normal)));
    }

    private static unsafe MapTerm Materialize(
        ProcessRuntime runtime,
        int count,
        int bytes,
        byte target,
        bool atoms = false,
        bool swapValues = false
    )
    {
        var storage = NifNativeBinaryStorage.TryAllocate((nuint)bytes, false) ?? throw new OutOfMemoryException();
        storage.RetainEnvironment();
        try
        {
            new Span<byte>(storage.Pointer, bytes).Clear();
            var entries = Enumerable.Range(0, count).Select(index => new KeyValuePair<NifNativeTermValue, NifNativeTermValue>(
                new(new BitString(Enumerable.Repeat((byte)index, bytes).ToArray())),
                new(Term.I(ValueBase + index))
            )).ToList();
            entries[0] = new(new(new NifNativeBinaryNode(storage, 0, (nuint)bytes)), new(Term.I(ValueBase)));
            if (atoms)
            {
                entries.Add(new(new(Term.A(FirstAtom)), new(Term.I(swapValues ? 0 : 1))));
                entries.Add(new(new(Term.A(LastAtom)), new(Term.I(swapValues ? 1 : 0))));
            }
            NifNativeTermValue pending = NifNativeMapGraph504.Create(entries, runtime);
            new Span<byte>(storage.Pointer, bytes).Fill(target);

            return (MapTerm)NifNativeTermGraph.Resolve(pending);
        }
        finally
        {
            storage.ReleaseEnvironment();
        }
    }

    private static void Require(bool condition)
    {
        if (!condition)
            throw new InvalidOperationException(Failure);
    }
}
