using Erlang;
using Erlang.NifNativeBackend;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;

string root = Path.GetFullPath("artifacts/ordsets-native-selection-audit/native-api-corpus");
bool failed = false;
foreach (bool original in new[] { false, true })
{
    string backend = original ? "Beam" : "Managed";
    try
    {
        byte[] lists = File.ReadAllBytes("tests/Erlang.Tests/Resources/BeamOrdsets381/lists.beam");
        byte[] ordsets = File.ReadAllBytes("tests/Erlang.Tests/Resources/BeamOrdsets381/ordsets.beam");
        if (Convert.ToHexString(SHA256.HashData(lists)) != NifNativeFlatOrderNames.ListsSha
            || Convert.ToHexString(SHA256.HashData(ordsets)) != NifNativeFlatOrderNames.OrdsetsSha)
            throw new InvalidDataException("Original image identity differs");
        await using var runtime = await ProcessRuntime.CreateAsync(new RuntimeLibrarySelection(original
            ? [RuntimeModuleSelection.Beam("ordsets", ordsets, ["lists"]), RuntimeModuleSelection.Beam("lists", lists)]
            : [RuntimeModuleSelection.Managed("ordsets"), RuntimeModuleSelection.Managed("lists")]));
        var selected = runtime.LibrarySelection.Modules.Single(module => module.Module == "ordsets");
        if (selected.Backend != (original ? RuntimeModuleBackend.Beam : RuntimeModuleBackend.Managed)
            || original && runtime.Modules.Exports.Where(export => export.Module == "ordsets")
                .Any(export => runtime.Modules.SourceOwner(export.Module, export.Function, export.Arity) is not PreparedBeamImage))
            throw new InvalidDataException("Selected backend/source owner differs");
        PreparedBeamImage image = runtime.Modules.PrepareBeam(File.ReadAllBytes(Path.Combine(root, "ordsets_native_flat_observer.beam")),
            new BeamDependencySelection(["ordsets_native_flat_observer", "ordsets", "lists", "maps", "erlang"]));
        if (runtime.Modules.PublishPreparedBeam([image]).Status != BeamPublicationStatus.Published)
            throw new InvalidDataException("Observer publication failed");
        var completed = new TaskCompletionSource<byte[]>(TaskCreationOptions.RunContinuationsAsynchronously);
        var materialize = typeof(NifNativeFlatOrderHostChecks).GetMethod("Materialize", BindingFlags.NonPublic | BindingFlags.Static)!;
        int rows = 0;
        var coverage = new HashSet<(string Function, int Arity)>();
        ProcessHandle actor = runtime.Spawn(async context =>
        {
            try
            {
                var observations = new List<Term>();
                foreach (int count in NifNativeFlatOrderNames.Counts)
                foreach (int bytes in NifNativeFlatOrderNames.BinarySizes)
                foreach (byte target in NifNativeFlatOrderNames.Targets)
                {
                    var native = (MapTerm)materialize.Invoke(null, [runtime, count, bytes, target, false, false])!;
                    Term result = await runtime.Modules.Call(context, "ordsets_native_flat_observer", "run", native);
                    foreach (TupleTerm row in Cons.Items(result))
                    {
                        coverage.Add((((Atom)row.Items[0]).Name, Cons.Items(row.Items[1]).Count()));
                        rows++;
                    }
                    observations.Add(Term.Tuple(Term.I(count), Term.I(bytes), Term.I(target), result));
                }
                completed.TrySetResult(ExternalTermFormat.Encode(Cons.From(observations)));
            }
            catch (Exception error)
            {
                completed.TrySetException(error);
            }
            return Nil.Value;
        });
        byte[] actual = await completed.Task.WaitAsync(TimeSpan.FromSeconds(30));
        await actor.Completion.WaitAsync(TimeSpan.FromSeconds(30));
        byte[] expected = File.ReadAllBytes(Path.Combine(root, "original.etf"));
        File.WriteAllBytes(Path.Combine(root, backend + ".actual.etf"), actual);
        var exports = runtime.Modules.Exports.Where(export => export.Module == "ordsets" && export.Function != "module_info")
            .Select(export => (export.Function, export.Arity)).ToHashSet();
        bool equal = actual.AsSpan().SequenceEqual(expected);
        var receipt = new { Backend = backend, Rows = rows, APIs = coverage.Count, CoverageMatchesAllExports = exports.SetEquals(coverage),
            WholeEtfMatches = equal, ActualSha256 = Convert.ToHexString(SHA256.HashData(actual)),
            ExpectedSha256 = Convert.ToHexString(SHA256.HashData(expected)), Terms = typeof(MapTerm).Assembly.ManifestModule.ModuleVersionId };
        File.WriteAllText(Path.Combine(root, backend + ".json"), JsonSerializer.Serialize(receipt, new JsonSerializerOptions { WriteIndented = true }));
        Console.WriteLine(JsonSerializer.Serialize(receipt));
        if (!equal || rows != 168 || coverage.Count != 21 || !exports.SetEquals(coverage))
            failed = true;
    }
    catch (Exception error)
    {
        failed = true;
        Console.WriteLine(backend + " FAIL " + error);
    }
}
return failed ? 1 : 0;
