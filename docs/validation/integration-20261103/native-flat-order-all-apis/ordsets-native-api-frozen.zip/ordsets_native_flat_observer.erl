-module(ordsets_native_flat_observer).
-export([run/1,identity/1,keep/1,pair/2]).

run(Map) ->
    Fresh=maps:from_list(maps:to_list(Map)),
    Cases=[{new,[]},{is_empty,[[]]},{size,[[Map,Fresh]]},
        {to_list,[[Map,Fresh]]},{is_set,[[Fresh,Map]]},
        {is_equal,[[Map],[Fresh]]},{is_element,[Map,[Fresh]]},
        {add_element,[Map,[Fresh]]},{del_element,[Map,[Fresh]]},
        {union,[[Map],[Fresh]]},{intersection,[[Map],[Fresh]]},
        {intersection,[[[Map],[Fresh]]]},{is_disjoint,[[Map],[Fresh]]},
        {subtract,[[Map],[Fresh]]},{is_subset,[[Map],[Fresh]]},
        {from_list,[[Map,Fresh]]},{union,[[[Map],[Fresh]]]},
        {map,[fun ?MODULE:identity/1,[Map,Fresh]]},
        {filtermap,[fun ?MODULE:keep/1,[Map,Fresh]]},
        {fold,[fun ?MODULE:pair/2,[],[Map,Fresh]]},
        {filter,[fun ?MODULE:keep/1,[Map,Fresh]]}],
    [{F,Args,probe(F,Args)} || {F,Args} <- Cases].

probe(F,Args) ->
    put(events,[]),
    Result=try apply(ordsets,F,Args) of V -> {ok,V}
        catch C:R:S -> {exception,C,R,S} end,
    {Result,erase(events)}.

record(Tag,X) -> put(events,[{Tag,X}|get(events)]).
identity(X) -> record(identity,X),X.
keep(X) -> record(keep,X),true.
pair(X,Acc) -> record(pair,X),[X|Acc].
