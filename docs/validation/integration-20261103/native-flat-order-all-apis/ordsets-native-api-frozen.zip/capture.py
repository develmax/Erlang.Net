import pathlib,hashlib,json,subprocess
root=pathlib.Path.cwd(); lab=root/'artifacts/ordsets-native-selection-audit/native-api-corpus'
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest().upper()
a=json.loads((root/'artifacts/library376-official-compiler/official-admission.json').read_text(encoding='utf-8-sig'))
assert a['SourceCommit']=='ad05823719d77c8faee87348ea39513d4e2f99c5'
manifest=pathlib.Path(a['ExecutionManifestPath']);assert sha(manifest)==a['ExecutionManifestSha256']
files=json.loads(manifest.read_text(encoding='utf-8-sig'));provider=pathlib.Path(a['InstalledOtpRoot'])
def verify():
    for r in files:assert sha(provider/r['Path'])==r['Sha256'],r['Path']
n=json.loads((root/'artifacts/native-map505/original1/execution-admission.json').read_text())
assert sha(n['LibraryPath'])==n['LibrarySha256'] and sha(n['BuildReceiptPath'])==n['BuildReceiptSha256']
build=pathlib.Path(n['BuildReceiptPath']).parent
assert sha(build/'fixture.c')==n['NativeSourceSha256'] and sha(build/'map_postreturn505.erl')==n['ErlangSourceSha256']
verify()
q=lambda p:json.dumps(pathlib.Path(p).as_posix())
expression=('{ok,map_postreturn505}=compile:file('+q(build/'map_postreturn505.erl')+',[debug_info,{outdir,'+q(lab)+'}]),'
    '{ok,ordsets_native_flat_observer}=compile:file('+q(lab/'ordsets_native_flat_observer.erl')+',[debug_info,{outdir,'+q(lab)+'}]),'
    'ok=map_postreturn505:load('+q(pathlib.Path(n['LibraryPath']).with_suffix(''))+'),'
    'Rows=[begin {M,_,_}=map_postreturn505:make(N,B,T),{N,B,T,ordsets_native_flat_observer:run(M)} end || N<-[2,32],B<-[64,65],T<-[0,128]],'
    '168=lists:sum([length(R)||{_,_,_,R}<-Rows]),'
    'ok=file:write_file("original.etf",term_to_binary(Rows,[deterministic])),io:format("168 complete outcomes,21 APIs,8 native layouts~n"),halt().')
r=subprocess.run([str(provider/'bin/erl.exe'),'+S','2:2','-pa',str(lab),'-noshell','-eval',expression],cwd=lab,capture_output=True,timeout=60)
(lab/'original.stdout').write_bytes(r.stdout);(lab/'original.stderr').write_bytes(r.stderr)
assert r.returncode==0,r.stderr
verify()
receipt={'PinnedCommit':a['SourceCommit'],'ProviderFilesVerifiedBeforeAndAfter':len(files),'NativeLibrarySha256':n['LibrarySha256'],'NativeSourceSha256':n['NativeSourceSha256'],'NativeErlangSourceSha256':n['ErlangSourceSha256'],'ObserverSourceSha256':sha(lab/'ordsets_native_flat_observer.erl'),'ObserverBeamSha256':sha(lab/'ordsets_native_flat_observer.beam'),'OriginalSha256':sha(lab/'original.etf'),'Expression':expression,'ExitCode':r.returncode,'Outcomes':168,'APIs':21,'NativeLayouts':8,'Comparison':'Whole deterministic ETF of input arguments,values,exception classes/reasons/full stacks and callback effects; no filtering or normalization'}
(lab/'provenance.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(r.stdout.decode().strip())
