using System.Reflection;
using System.Diagnostics;
using System.Text.Json;
var assembly=typeof(Erlang.Tests.TermOrderHostChecks).Assembly;
var type=assembly.GetType("Erlang.Tests.LibraryDependencyOriginalHostChecks",true)!;
var method=type.GetMethod("CatchWhole",BindingFlags.Static|BindingFlags.NonPublic)!;
var watch=Stopwatch.StartNew();
await (Task)method.Invoke(null,null)!;
Console.WriteLine(JsonSerializer.Serialize(new{OriginalCatchWholePassed=true,Milliseconds=watch.ElapsedMilliseconds,HarnessOuterApplied=false,ExistingInternalDeadlineChanged=false}));
