using System.Text;

namespace Erlang;

internal sealed class StringBinarySearchBuffer(IReadOnlyList<Term> needle)
{
    private BinaryBacking? backing;
    private byte[]? bytes;
    private long bitOffset;
    private byte[]? completePattern;
    private byte[]? initialPattern;

    internal IReadOnlyList<Term> Needle => needle;

    internal ReadOnlyMemory<byte> Read(BitString binary)
    {
        BinaryBacking current = binary.ResourceBacking577;
        // Mutable/native producers retain the original per-search read protocol.
        if (!current.CanCaptureImmutableOrdinary || binary.OwnedHeapBits is not null)
            return binary.ToArray();

        ResourceBitsRead577 range = binary.CaptureResourceBits577();
        if (range.BitLength < 0 || range.BitLength % BitStringLayout.BitsPerByte != 0)
            return binary.ToArray();

        int length = range.BitLength / BitStringLayout.BitsPerByte;
        long relative = range.BitOffset - bitOffset;
        if (ReferenceEquals(current, backing) && bytes is not null && relative >= 0
            && relative % BitStringLayout.BitsPerByte == 0
            && relative / BitStringLayout.BitsPerByte <= bytes.LongLength - length)
        {
            return new ReadOnlyMemory<byte>(
                bytes,
                checked((int)(relative / BitStringLayout.BitsPerByte)),
                length
            );
        }

        // Copy through the existing BitString reader; no borrowed span survives await.
        byte[] captured = binary.ToArray();
        backing = current;
        bitOffset = range.BitOffset;
        bytes = captured;

        return captured;
    }

    internal byte[] Pattern(bool continuation)
    {
        byte[]? cached = continuation ? initialPattern : completePattern;
        if (cached is not null)
            return cached;

        // Preserve lazy full-versus-initial validation and its exception order.
        string text = string.Concat((continuation ? needle.Take(1) : needle)
            .Cast<Integer>().Select(cp => char.ConvertFromUtf32((int)cp.Value)));
        byte[] encoded = Encoding.UTF8.GetBytes(text);
        if (continuation)
            initialPattern = encoded;
        else
            completePattern = encoded;

        return encoded;
    }
}
