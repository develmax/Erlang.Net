-module(proc_stop_scheduling_probe).
-export([run/0,caller/1,tracer/2]).

run() ->
    {module,proc_lib}=code:ensure_loaded(proc_lib),
    StopFuns=[{proc_lib,N,A} || {N,A}<-proc_lib:module_info(functions),
        lists:prefix("-stop/3",atom_to_list(N))],
    [_|_]=StopFuns,
    DumpTuple={list_to_tuple(lists:duplicate(128,{process_dump}))},
    lists:foreach(fun(MFA)->1=erlang:trace_pattern(MFA,
        [{'_',[],[{message,DumpTuple},{return_trace}]}],[local]) end,StopFuns),
    Parent=self(),
    {Caller,Monitor}=spawn_monitor(?MODULE,caller,[Parent]),
    Tracer=spawn_opt(?MODULE,tracer,[Caller,Parent],[{priority,high}]),
    Caller!{go,Tracer},
    collect(Caller,Monitor,Tracer,undefined,[]).

caller(Parent) ->
    receive {go,Tracer} ->
        1=erlang:trace(self(),true,[call,send,set_on_spawn,{tracer,Tracer}]),
        put(probe_payload,lists:duplicate(200000,trace_payload)),
        Started=erlang:monotonic_time(microsecond),
        Result=try oracle_proc_stop:run() of Value->{ok,Value}
            catch Class:Reason:Stack->{exception,Class,Reason,Stack} end,
        Elapsed=erlang:monotonic_time(microsecond)-Started,
        Parent!{result,self(),Elapsed,Result,
            process_info(self(),monitors),process_info(self(),messages)},
        receive {cleanup,Child} ->
            Down=case is_pid(Child) andalso is_process_alive(Child) of
                true ->
                    Child!release,
                    receive {'DOWN',_,process,Child,_}=ObservedDown->ObservedDown
                        after 1000->no_down end;
                false -> none
            end,
            Parent!{cleanup_result,self(),Down,
                process_info(self(),monitors),process_info(self(),messages)}
        end
    end.

tracer(Caller,Parent) -> trace_loop(Caller,Parent,false,[]).
trace_loop(Caller,Parent,Paused,Events) ->
    receive
        {trace,Caller,call,{proc_lib,Function,_Arguments},Dump} when is_tuple(Dump) ->
            ok=file:write_file("trace-process-dumps.etf",term_to_binary(Dump,[deterministic])),
            Event={dump_trace,Function,lists:sum([byte_size(B)||B<-tuple_to_list(Dump)]),erlang:monotonic_time(microsecond)},
            Parent!Event,
            trace_loop(Caller,Parent,true,[Event|Events]);
        {trace,Child,send,{_Tag,ok},_Destination}=Event when Child=/=Caller ->
            Parent!{paused,Child,Event,false,erlang:monotonic_time(microsecond)},
            trace_loop(Caller,Parent,Paused,[Event|Events]);
        finish -> Parent!{trace_events,lists:reverse(Events)};
        Event -> trace_loop(Caller,Parent,Paused,[Event|Events])
    end.

collect(Caller,Monitor,Tracer,Child,Events) ->
    receive
        {paused,Target,_,_,_}=Event ->
            collect(Caller,Monitor,Tracer,Target,[Event|Events]);
        {result,Caller,_,_,_,_}=Result ->
            Caller!{cleanup,Child},
            Cleanup=receive {cleanup_result,Caller,_,_,_}=C->C
                after 2000->cleanup_timeout end,
            Tracer!finish,
            Trace=receive {trace_events,_}=T->T after 1000->trace_timeout end,
            receive {'DOWN',Monitor,process,Caller,normal}->ok after 1000->error(caller_not_closed) end,
            {Result,Cleanup,lists:reverse(Events),Trace};
        {'DOWN',Monitor,process,Caller,Reason} -> error({caller_failed,Reason});
        Event -> collect(Caller,Monitor,Tracer,Child,[Event|Events])
    after 5000 ->
        exit(Caller,kill),exit(Tracer,kill),
        error(probe_timeout)
    end.

