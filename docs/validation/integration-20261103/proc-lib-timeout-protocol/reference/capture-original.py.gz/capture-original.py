import json,hashlib,subprocess
from pathlib import Path
R=Path.cwd();O=R/'artifacts/proc-lib-timeout/original';O.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
a=json.loads((R/'artifacts/library376-official-compiler/official-admission.json').read_text(encoding='utf-8-sig'));assert a['SourceCommit']=='ad05823719d77c8faee87348ea39513d4e2f99c5'
m=Path(a['ExecutionManifestPath']);assert sha(m)==a['ExecutionManifestSha256'];files=json.loads(m.read_text(encoding='utf-8-sig'));provider=Path(a['InstalledOtpRoot'])
def verify():
 for row in files:assert sha(provider/row['Path'])==row['Sha256'],row['Path']
verify()
line=next(x for x in (R/'tools/Validation/Erlang.Differential/ProcLibStopCaseSources.cs').read_text().splitlines() if 'public const string AfterAckTimeoutWaitsForRealDown =' in x)
source=json.loads(line.split(' = ',1)[1].rstrip(';'));out=[]
for name,code in [('candidate',source),('diagnostic',source.replace('waitdead(C),case Kind','waitdead(C),case Kind').replace('end,clean(). start(M)', 'end,{clean(),Kind,Elapsed,Outcome}. start(M)'))]:
 d=O/name;d.mkdir(exist_ok=True);(d/'oracle_proc_stop.erl').write_bytes(code.encode());expr='{ok,oracle_proc_stop}=compile:file("oracle_proc_stop.erl",[debug_info,report_errors,report_warnings]),Rows=[oracle_proc_stop:run()||_<-lists:seq(1,50)],ok=file:write_file("outcomes.etf",term_to_binary(Rows,[deterministic])),io:format("~p~n",[Rows]),halt().'
 p=subprocess.run([str(provider/'bin/erl.exe'),'+S','2:2','-noshell','-pa','.', '-eval',expr],cwd=d,capture_output=True,timeout=60,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));(d/'stdout').write_bytes(p.stdout);(d/'stderr').write_bytes(p.stderr);assert p.returncode==0,(name,p.stdout,p.stderr);out.append({'Name':name,'SourceSha256':sha(d/'oracle_proc_stop.erl'),'BeamSha256':sha(d/'oracle_proc_stop.beam'),'Rows':50,'EtfSha256':sha(d/'outcomes.etf'),'ExitCode':p.returncode})
verify();(O/'receipt.json').write_bytes((json.dumps({'PinnedCommit':a['SourceCommit'],'ProviderFilesVerifiedBeforeAndAfter':len(files),'ExecutionManifestSha256':a['ExecutionManifestSha256'],'Results':out},indent=2)+'\n').encode());print(json.dumps(out))
