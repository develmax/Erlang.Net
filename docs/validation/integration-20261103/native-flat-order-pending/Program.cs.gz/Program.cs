using System.Reflection;
using System.Text.Json;
using Erlang;

Term Binary(byte value) => new BitString(Enumerable.Repeat(value, 64).ToArray());
var physical = new KeyValuePair<Term, Term>[] {new(Binary(128), Term.I(100)),new(Binary(1), Term.I(101))};
await using var runtime = new ProcessRuntime();
var assembly = Assembly.LoadFrom(Path.GetFullPath("artifacts/ordsets-native-selection-audit/candidate-runner/Erlang.NifNativeBackend.dll"));
var helper = assembly.GetType("Erlang.NifNativeBackend.NifNativeMapMaterialized505HostChecks")!;
var pair = helper.GetMethod("Pair", BindingFlags.Static | BindingFlags.NonPublic)!;
var entries = Array.CreateInstance(pair.ReturnType, 2);
entries.SetValue(pair.Invoke(null, [128,100]),0);
entries.SetValue(pair.Invoke(null, [1,101]),1);
var factory = helper.GetMethod("MaterializeFlat", BindingFlags.Static | BindingFlags.NonPublic)!;
var native = (MapTerm)factory.Invoke(null, [runtime, entries])!;
var fresh = new MapTerm(native.Entries);
Console.WriteLine(JsonSerializer.Serialize(new {
    Order = Math.Sign(TermOrder.Compare(native, fresh)),
    Numeric = native.NumericEquals(fresh),
    Exact = native.Equals(fresh),
    Terms = typeof(MapTerm).Assembly.ManifestModule.ModuleVersionId
}));
var completion = new TaskCompletionSource<Term[]>(TaskCreationOptions.RunContinuationsAsynchronously);
var actor = runtime.Spawn(async context =>
{
    try
    {
        Term equal = await runtime.Modules.Call(context,"ordsets","is_equal",Term.List(native),Term.List(fresh));
        Term member = await runtime.Modules.Call(context,"ordsets","is_element",native,Term.List(fresh));
        Term sorted = await runtime.Modules.Call(context,"ordsets","is_set",Term.List(native,fresh));
        completion.TrySetResult([equal,member,sorted]);
    }
    catch(Exception e) {completion.TrySetException(e);}
    return Nil.Value;
});
var results = await completion.Task.WaitAsync(TimeSpan.FromSeconds(30));
await actor.Completion.WaitAsync(TimeSpan.FromSeconds(30));
Console.WriteLine(string.Join(",",results.Select(x=>x.ToString())));
