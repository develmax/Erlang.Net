import hashlib,json,pathlib,subprocess
root=pathlib.Path.cwd()
lab=root/'artifacts/ordsets-native-selection-audit/flat-order-probe'
admission=json.loads((root/'artifacts/library376-official-compiler/official-admission.json').read_text(encoding='utf-8-sig'))
assert admission['SourceCommit']=='ad05823719d77c8faee87348ea39513d4e2f99c5'
provider=pathlib.Path(admission['InstalledOtpRoot'])
manifest=pathlib.Path(admission['ExecutionManifestPath'])
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest().upper()
assert sha(manifest)==admission['ExecutionManifestSha256']
files=json.loads(manifest.read_text(encoding='utf-8-sig'))
def verify():
    for r in files: assert sha(provider/r['Path'])==r['Sha256'],r['Path']
native=json.loads((root/'artifacts/native-map505/original1/execution-admission.json').read_text())
assert sha(native['LibraryPath'])==native['LibrarySha256']
beamroot=root/'artifacts/native-map505/original1/original-batch'
verify()
lib=pathlib.Path(native['LibraryPath']).with_suffix('').as_posix()
expression='ok=map_postreturn505:load('+json.dumps(lib)+'),{M,_,_}=map_postreturn505:make(2,65,128),F=maps:from_list(maps:to_list(M)),io:format("~p~n",[{M<F,M>F,M==F,M=:=F,ordsets:is_equal([M],[F]),ordsets:is_element(M,[F]),ordsets:is_set([M,F])}]),halt().'
r=subprocess.run([str(provider/'bin/erl.exe'),'+S','2:2','-pa',str(beamroot),'-noshell','-eval',expression],cwd=lab,capture_output=True,timeout=30)
(lab/'original.stdout').write_bytes(r.stdout);(lab/'original.stderr').write_bytes(r.stderr)
assert r.returncode==0,r.stderr
verify()
(lab/'original-receipt.json').write_text(json.dumps({'PinnedCommit':admission['SourceCommit'],'ProviderFilesVerifiedBeforeAndAfter':len(files),'LibrarySha256':native['LibrarySha256'],'Expression':expression,'ExitCode':r.returncode,'Stdout':r.stdout.decode()},indent=2)+'\n')
print(r.stdout.decode().strip())
