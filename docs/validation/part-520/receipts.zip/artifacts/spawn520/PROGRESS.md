# Spawn resource validation candidate (Part520 work in progress)

Parent publication: Part519 / PR72 / 74e8f740e3e51b613a21e7d53d79c9ae7f498ff2, exact-head CI551 green on all three jobs, Windows9166/9166. This candidate has not been published or represented as green CI.

## Implementation

- Six production targets validate native-small scalar/map resource options, sticky malformed duplicates, explicit min/max contradictions and unrelated invalid options before preserving host refusal for valid unsupported allocation policies.
- Public spawn option errors retain badopt metadata and original arguments; internal requests retain asynchronous reference/reply-tag/error processing for malformed options.
- Heap-class arithmetic is instantiated only after a resource option is encountered. Runtime resource accounting/default policy has not been invented or enabled.
- The immutable original330 fixture remains separate from the315 malformed-scope reference and15 default-dependent companion. No existing acquired golden was edited or filtered.
- A separate genuine original proc_lib lane has now been integrated from the actual provider image; it has not yet been compiled/executed. The existing managed backend lane remains available.

## Actual checks

- Clean compiled host after correcting two source-proposal compile defects. Four focused validation/asynchronous-error/metadata/comparator groups pass.
- Fresh original OTP metadata image and module-md5 witness acquired against the same6427-file provider admission.
- All three original acquisitions passed: full330=201118 bytes, malformed315=177459 bytes, defaults15=9864 bytes (first retained acquisition). Each retry has its own raw/source/process receipts.
- First managed preparation failed before semantic comparison because the new wrapper assumed metadata Files contained only leaf names and misordered owned-process log/cwd arguments. Both defects were corrected with confined relative-path validation and independent per-profile logs; the failed logs are retained.
- Next wrapper defects: ordinary passive decode did not admit external function terms; private replay inherited an unintended10-second generic host-actor deadline despite its declared2-minute batch deadline. It now uses the existing non-executing function decoder and a dedicated finite controller with the original declared deadline.
- Both current profiles captured their complete315 outcomes and stacks (ordinary about4 seconds, private about26 seconds), then correctly FAILED whole comparison at missing native spawn_opt wrapper file/line metadata. This is actual remaining semantic evidence, not a successful compatibility claim.
- No acceptance comparator, original ETF, error stack or source line was normalized to make this pass. Missing metadata must come from the actual admitted BEAM site; native spawn_opt/4 correctly lacks an Erlang file location.

## Remaining gates

1. Derive wrapped spawn error locations from the actual admitted/inlined original erlang image, with explicit source guards and branch categories.
2. Compile/run the new original proc_lib lane and preserve all independent managed/original profile results.
3. Re-run whole315 comparisons, affected regression, final source/style/hash seals, then publish and inspect exact-head GitHub CI. Keep15 default-dependent rows and valid resource enforcement pending.
4. Canonical deltas remain0/0:708 registered,180 full,504 pending,24 known differences. Scoped malformed validation is not15 full API closures.

## Actual source metadata and original-library acceptance

- The actual admitted embedded erlang image now supplies branch-proven wrapper error locations via keyfind/error_info tuple provenance; no observed line-number constants are embedded in production. Four source-proven improper spawn_request branches select inherited/error-info/badarg-cause metadata without changing reason/cause values.
- Corrected a parent source-analysis mistake before publication: Erlang is_list is the Cons-or-Nil type guard, including improper lists. The temporary proper-list override was removed; its failed actual row remains evidence. The constructor guard now follows the exact lexical source branch.
- Actual four-route probe request547: ORIGINAL proc_lib ordinary/private both pass the entire315 named-target protocol, all full values/stacks, authenticated worker Caller/Worker PID roles and confined spawn_reply reference bijection. Native code identity/source-owner/provider/witness checks remain active. Two successful complete outputs/comparison receipts are retained separately.
- Legacy C# proc_lib ordinary/private both remain RED at proc_lib frame source metadata. Those complete raw outputs/failures are preserved; they are not accepted as equivalent and do not disappear from the24 known-difference ledger.
- The architecture explicitly selected by the user keeps OTP libraries in Erlang and native BIF/runtime in C#. The NEW required CI gate therefore explicitly selects original-proc-lib in both runtime profiles. The existing managed backend remains independently selectable, and --both-proc-lib-backends542 remains strict: any requested failing route returns overall failure. No legacy failure is converted to a passing comparison.
- This proves only315 named-target malformed-option cases; the full330 reference contains90 NEW_FUN terms and remains outside positive scope, and15 default-dependent cases remain pending. No local-function creator PID or full valid heap enforcement is claimed.
- Five finite validation/witness/strict-code negative groups pass; exact final-style/affected regression/seal/publication CI remain next.
