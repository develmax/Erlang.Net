# Allocator cursor boundary audit

Read-only baseline source audit, not review of the as-yet unintegrated optimization. No build/VM/native/git execution.

Direct mutable sites: Heap506.Allocate reserves in existing slab and newly appended slab, then rolls back selected.Release on identity/block/copy failures. Generation508 collection releases every dead block on minor or major passes. Retirement clears Cells and removes the complete slab list. No other production slab Reserve/Release/list mutation caller was found.

Exact first-fit preservation requires invalidating every requested-length heap cursor on all physical releases, including rollback and both GC modes; freed words merge with earlier holes, so invalidating only the released length is wrong. Allocation only consumes ranges and cannot create an earlier fit, so a proven no-fit slab can be skipped for that exact request length until release. Appending a new slab must make cached old end discover that new slab. Retirement must discard every cursor and avoid holding stale slab identities.

Per-slab firstFree must stay the earliest free bit, not advance beyond smaller holes just because another length allocated later. FreeWords rejects impossibility but does not prove a contiguous run exists. Reserve must not alter bitmap/counters on failure. Zero tuples bypass Allocate; preserve the corrected empty-tuple fastpath.

Exception boundary: existing Allocate try begins after Reserve. New cursor dictionary operations that allocate memory must not occur between successful Reserve and this protected region. Stage metadata capacity/key first or extend rollback protection. Any cursor write failure after reserving must release the range and invalidate cursors; otherwise the new optimization leaks reserved payload. Compute checked arithmetic before bitmap mutation and keep final per-slab bookkeeping allocation-free.

Complexity limit: firstFree alone can retain a tiny unusable prefix hole. Repeated length2 allocations in a slab with free1-word prefix and free suffix re-scan a growing occupied prefix every success; a heap-level exact-length slab cursor does not prevent this because the same slab remains successful. For a full fragmented-work bound, add per-slab/per-length scan hints or free intervals, invalidated on release; otherwise state the narrower unfragmented guarantee. Use actual bitmap-visit diagnostics, not elapsed time only.

Finite acceptance suggestions: exact slab/offset first-fit parity for mixed1/2/large lengths; prefix-hole repeated length2; bridged adjacent holes becoming larger fits after minor/major GC; allocation rollback followed by reuse; cached old end plus append; empty tuples; retirement cleanup with no stale cursor references. No public VM memory/statistics parity follows from private allocator diagnostics.
