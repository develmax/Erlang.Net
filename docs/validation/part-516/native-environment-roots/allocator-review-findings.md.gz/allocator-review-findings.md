# Independent frozen allocator first-fit review519

Reviewed frozen green-manifest5D38284D063FD2AC79E6201651E3E3AAF3FCF75A1297C2B7C48E865EA254675A, all four declared payloads and all three exact preimages verified. No active edit, build, VM/native execution, git mutation or CI was performed. No concrete blocker was found in the bounded three-production-file source comparison.

## Exact original placement

Each slab-length cursor skips only positions already proven not to fit that exact length, including the range consumed by its last successful allocation. Other reservations only consume free cells and cannot create an earlier fit. Start is max(saved cursor, actual earliest free cell), so different-length hints cannot hide a small earlier hole. The requested-length heap cursor similarly skips only slabs proven no fit until a release. FirstFree advances over occupied cells only after allocation at its current position; freeWords is merely an early impossible-fit rejection. The bitmap remains authoritative for successful contiguous ranges.

Any physical release clears every per-length slab hint and rewinds FirstFree to the earliest released offset, so adjacent old holes merged by a different-sized release become discoverable. The unified ReleaseAllocation519 also clears every heap length hint. Both actual release sites now use it: allocation failure rollback and all minor/major GC dead-block releases. Retirement clears heap cursors with the slab list, so no cached slab index survives disposal. New slab appends are reachable from old cached-end indices.

## Exception custody

Slab candidate dictionary insertion occurs before Array.Fill commits bitmap occupancy. Its OOM leaves no reserved range. Heap failed-slab cursor updates occur only when Reserve returned failure. Successful heap cursor insertion happens inside the existing reservation rollback try, as do identity arithmetic, block construction, child copy and blocks.Add; failure releases actual range and invalidates hints. The post-bitmap slab counter/firstFree work does not allocate. New slab creation/add still precedes Reserve; failure before reservation can leave only a conservative empty slab, not an untracked occupied range. This review found no missing live-reservation rollback path.

## Work bound and controls

Per-(slab,length) success cursors address the free1-word-prefix/repeated length2 issue raised in the earlier boundary audit: they skip already consumed suffixes even while global FirstFree correctly remains at the one-word hole. Within a release-free interval each requested length scans forward; releases invalidate that proof as required. This is not a global linear bound under arbitrarily interleaved releases or unbounded distinct request lengths, nor a public ERTS memory/timing claim.

MixedFirstFit compares4000 deterministic mixed reserve/releases with the original first-fit bitmap algorithm. FragmentedLinearScan exercises the one-word prefix and then confirms length1 still reuses it. HeapLinearScan measures real slab visits. CollectionAndRollbackReuse checks reclaimed holes after minor/major collection and identity-overflow reservation rollback. Root adds printing before unchanged assertions for actual red/green evidence; this source review does not claim those executions or their results. Existing zero-tuple bypass remains unchanged.

Final-source build/tests and normative native dual collectors remain required. No whole API contract is promoted by this private allocator optimization.
