# Independent bounded final review: Part516 plus private self-GC519

No concrete additional correctness defect was found in the reviewed current source. File hashes are bound in snapshot.json. This is source-only review; no build, managed/original VM, native fixture, git mutation or CI was executed. Earlier native profile timeouts remain actual unresolved execution evidence until the parent's final-source dual collectors complete.

## Synchronous self collection

ProcessRuntime.GarbageCollection.cs:9-17 admits owned collection only for !Async, exact requester.Self, private OwnedTermsPilot506 and RuntimeActorExecutionTurn.IsOwnedBy(requester). The actor authority is ThreadStatic and checked again by CollectOwnedGeneration508, so an inherited async context on another thread does not supply execution authority. No await occurs between this guard and owned collection. Ordinary, off-actor, async and other-process routes retain existing behavior; no global CLR counter is substituted for guest collection.

CollectGeneration508 acquires the process heap gate and starts from all registered frame roots plus actual old-generation child cells on a minor pass. It validates/traverses the complete graph including hidden physical native map children and computes checked counters before releasing dead blocks. It performs no runtime/module/native callback. The heap gate is released before CollectManagedGarbage invokes CLR collection. Thus this new call does not hold the heap gate across CLR collection or introduce a runtime-gate acquisition inside the collector. Foreign/unknown root domain behavior is not promoted to full public GC compatibility.

The new tests explicitly clear a real owned root, invoke the real BIF and check the actual slab-backed term becomes inaccessible; another keeps an owned descendant and binary live solely through a hidden physical map row; ordinary mode checks no heap is created. These are stronger assertions than checking garbage_collect returns true, but require actual final-source execution.

## Append-only native inventory

NifNativeCallEnvironment.OwnedRoots516.cs:24 onward treats inventory as evidence of already published actual environment custody, never as a substitute for new graph publication. A newly seen static composite gets a complete physical-aware graph capture and RetainLocalGraph507 even if some children are already inventoried. It does not infer composite custody merely from their presence. Inventory UnionWith occurs only after every required root publication succeeds. Allocation failure may retain extra actual roots or partial metadata, but no cached identity can lack its previously committed root.

Known immutable pending tuple/cons/binary/map nodes are cached only after their leaves succeed; unknown graphs remain uncached. Actual production tuple creation snapshots into a new array and map construction derives fresh arrays/persistent nodes; no callback mutates those graph edges after publication. Native late writes change binary bytes, not the graph's descendant/backing identity, so node memoization does not freeze result bytes. Static traversal includes NativeMapOwnedRoots510.Children and does not call identity/hash providers. RetainLocalGraph holds the same graph; it does not create duplicate owned tuple/list payload.

NifNativeCallEnvironment.cs:ClearTerms clears the inventories together with terms, iterators, tuple arrays and backing references, then disposes the environment guest frame. No independent clear/free admits a process-bound environment; retired environments cannot reuse old inventory in a new root domain. Successful opaque result export still happens before environment disposal. Existing deferred-reason ordering was reviewed separately; the self-GC call adds no asynchronous collection between native env disposal and outer error transfer.

## Acceptance boundary

The existing native profile timeouts are not resolved by this report. Root must execute the normative original/ordinary/private collectors on these exact bytes and retain full default/deterministic outputs, complete stacks, independent failures and actual process/native cleanup. Private self collection does not validate remote/async GC, every original public resource counter, or unsupported native send/schedule contracts. No API compatibility classification should change from this bounded review.
