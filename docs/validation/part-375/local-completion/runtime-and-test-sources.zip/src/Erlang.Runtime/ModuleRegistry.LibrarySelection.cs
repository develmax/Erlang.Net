using System.Security.Cryptography;

namespace Erlang;

public sealed partial class ModuleRegistry
{
    internal RuntimeLibraryPreparedSelection PrepareStartupLibraries(RuntimeLibrarySelection request)
    {
        var images = new Dictionary<string, PreparedBeamImage>(StringComparer.Ordinal);
        var bootstrap = new Dictionary<string, ModuleCodeImage>(StringComparer.Ordinal);
        foreach (RuntimeModuleSelection choice in request.Modules)
        {
            if (!preloadedModules.ContainsKey(choice.Module) || !codeImages.TryGetValue(choice.Module, out ModuleCodeImage? image)
                || oldCode.ContainsKey(choice.Module) || sourceOwners.Keys.Any(key => key.Module == choice.Module))
                throw new InvalidOperationException(LibrarySelectionNames.Owner + LibrarySelectionNames.ContextSeparator + choice.Module);
            bootstrap.Add(choice.Module, image);
            if (choice.Backend != RuntimeModuleBackend.Beam)
                continue;
            try
            {
                PreparedBeamImage prepared = PrepareBeam(choice.OwnedImage, new BeamDependencySelection(choice.Dependencies.Append(choice.Module)));
                if (prepared.Name != choice.Module || prepared.HasOnLoad)
                    throw new InvalidDataException(LibrarySelectionNames.Request);
                foreach (var signature in functions.Keys.Where(key => key.Module == choice.Module))
                    if (!prepared.Code.Exports.Any(export => export.Name == signature.Function && export.Arity == signature.Arity))
                        throw new InvalidDataException(LibrarySelectionNames.MissingExport + LibrarySelectionNames.ContextSeparator
                            + choice.Module + LibrarySelectionNames.FunctionSeparator + signature.Function
                            + LibrarySelectionNames.AritySeparator + signature.Arity);
                images.Add(choice.Module, prepared);
            }
            catch (Exception error)
            {
                throw new InvalidOperationException(LibrarySelectionNames.Phase + LibrarySelectionNames.ContextSeparator + choice.Module, error);
            }
        }
        var result = new RuntimeLibraryPreparedSelection(request, images, bootstrap);
        foreach (RuntimeModuleSelection choice in request.Modules.Where(value => value.Backend == RuntimeModuleBackend.Beam))
            foreach (BeamImport import in images[choice.Module].Code.Structure.Imports)
                ValidateStartupImport(
                    result,
                    choice,
                    images[choice.Module].Code,
                    import
                );

        return result;
    }

    private void ValidateStartupImport(
        RuntimeLibraryPreparedSelection plan,
        RuntimeModuleSelection caller,
        BeamLinkedCode code,
        BeamImport import
    )
    {
        string module = code.Structure.Atoms[import.ModuleAtomIndex]!;
        string function = code.Structure.Atoms[import.FunctionAtomIndex]!;
        if (module == ErlangModuleNames.Module && function == BeamPreparationNames.GetModuleInfo && import.Arity is 1 or 2)
            return;
        bool selectedBeam = plan.Images.TryGetValue(module, out PreparedBeamImage? target);
        bool native = selectedBeam
            ? target!.ExecutionIdentity.NativePrimitives.ContainsKey((function, import.Arity))
            : IsNativeEntry(module, function, import.Arity);
        if (native)
            return;
        bool self = caller.Module == module;
        bool declared = self || caller.Dependencies.Contains(module, StringComparer.Ordinal);
        bool chosen = plan.Request.Modules.Any(choice => choice.Module == module);
        bool exists = selectedBeam
            ? target!.Code.Exports.Any(export => export.Name == function && export.Arity == import.Arity)
            : functions.ContainsKey((module, function, import.Arity));
        if (!declared || !chosen || !exists)
            throw new InvalidOperationException(LibrarySelectionNames.Dependency + LibrarySelectionNames.ContextSeparator + caller.Module
                + LibrarySelectionNames.DependencyArrow + module + LibrarySelectionNames.FunctionSeparator + function
                + LibrarySelectionNames.AritySeparator + import.Arity);
    }

    internal void PublishStartupLibraries(RuntimeLibraryPreparedSelection plan)
    {
        if (plan.Images.Count == 0)
            return;
        BeamPublicationResult result = PublishPreparedBeam(plan.Images.OrderBy(pair => pair.Key, StringComparer.Ordinal).Select(pair => pair.Value).ToArray());
        if (result.Status != BeamPublicationStatus.Published)
            throw new InvalidOperationException(LibrarySelectionNames.Publish + LibrarySelectionNames.ContextSeparator + result.Status);
    }

    internal RuntimeLibrarySelectionSnapshot CaptureStartupLibraries(RuntimeLibraryPreparedSelection plan)
    {
        lock (gate)
        {
            var modules = new List<RuntimeLibraryModuleSnapshot>();
            foreach (RuntimeModuleSelection choice in plan.Request.Modules)
            {
                bool beam = plan.Images.TryGetValue(choice.Module, out PreparedBeamImage? prepared);
                ModuleCodeImage expected = beam ? prepared!.ExecutionIdentity.Image : plan.BootstrapImages[choice.Module];
                var exports = functions.Where(pair => pair.Key.Module == choice.Module).ToArray();
                if (oldCode.ContainsKey(choice.Module) || !ReferenceEquals(codeImages.GetValueOrDefault(choice.Module), expected)
                    || exports.Length == 0 || exports.Any(pair => beam
                        ? !ReferenceEquals(sourceOwners.GetValueOrDefault(pair.Key), prepared)
                        : sourceOwners.ContainsKey(pair.Key)))
                    throw new InvalidOperationException(LibrarySelectionNames.Owner + LibrarySelectionNames.ContextSeparator + choice.Module);
                var primitiveBodies = beam ? prepared!.ExecutionIdentity.NativePrimitives.Values : Array.Empty<ErlangFunction>();
                var assemblies = (beam ? primitiveBodies : exports.Select(pair => pair.Value))
                    .Select(body => new RuntimeLibraryAssemblyIdentity(
                        body.Method.Module.Assembly.GetName().FullName ?? body.Method.Module.Assembly.GetName().Name!,
                        body.Method.Module.ModuleVersionId
                    ));
                modules.Add(new(
                    choice.Module,
                    choice.Backend,
                    expected,
                    beam ? Convert.ToHexString(SHA256.HashData(choice.OwnedImage.Span)) : null,
                    (BitString)ModuleInformation(choice.Module, ModuleInformationKeys.Md5),
                    exports.Select(pair => new BeamFunctionSignature(pair.Key.Function, pair.Key.Arity)),
                    exports.Where(pair => IsNativeEntry(pair.Key.Module, pair.Key.Function, pair.Key.Arity)).Select(pair => new BeamFunctionSignature(pair.Key.Function, pair.Key.Arity)),
                    assemblies,
                    choice.Dependencies.Select(module => new RuntimeLibraryDependencySnapshot(module, plan.Request.Modules.Single(value => value.Module == module).Backend))
                ));
            }

            return new(modules);
        }
    }
}
