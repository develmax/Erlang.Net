-module(atom_contract492_binary_to_existing_atom1_p0).
-export([run/0,run_stacks/0,probe/1]).
run() -> ordsets_core_support:run(?MODULE,cases()).
run_stacks() -> ordsets_core_support:profiles(?MODULE,cases()).
cases() -> [c0,c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13,c14,c15,c16,c17,c18,c19,c20,c21,c22,c23,c24,c25,c26,c27,c28,c29,c30,c31,c32,c33,c34,c35,c36,c37,c38,c39,c40].
probe(c0) -> _=erlang:apply(erlang,opaque(binary_to_atom),[<<>>]), erlang:apply(erlang,opaque(binary_to_existing_atom),[<<>>]);
probe(c1) -> _=erlang:apply(erlang,opaque(binary_to_atom),[<<0>>]), erlang:apply(erlang,opaque(binary_to_existing_atom),[<<0>>]);
probe(c2) -> _=erlang:apply(erlang,opaque(binary_to_atom),[<<97,0,98>>]), erlang:apply(erlang,opaque(binary_to_existing_atom),[<<97,0,98>>]);
probe(c3) -> erlang:apply(erlang,opaque(binary_to_existing_atom),[<<127,128,255>>]);
probe(c4) -> _=erlang:apply(erlang,opaque(binary_to_atom),[<<195,191>>]), erlang:apply(erlang,opaque(binary_to_existing_atom),[<<195,191>>]);
probe(c5) -> _=erlang:apply(erlang,opaque(binary_to_atom),[<<196,128>>]), erlang:apply(erlang,opaque(binary_to_existing_atom),[<<196,128>>]);
probe(c6) -> _=erlang:apply(erlang,opaque(binary_to_atom),[<<226,130,172>>]), erlang:apply(erlang,opaque(binary_to_existing_atom),[<<226,130,172>>]);
probe(c7) -> _=erlang:apply(erlang,opaque(binary_to_atom),[<<240,159,152,128>>]), erlang:apply(erlang,opaque(binary_to_existing_atom),[<<240,159,152,128>>]);
probe(c8) -> _=erlang:apply(erlang,opaque(binary_to_atom),[<<244,143,191,191>>]), erlang:apply(erlang,opaque(binary_to_existing_atom),[<<244,143,191,191>>]);
probe(c9) -> _=erlang:apply(erlang,opaque(binary_to_atom),[<<239,183,144>>]), erlang:apply(erlang,opaque(binary_to_existing_atom),[<<239,183,144>>]);
probe(c10) -> erlang:apply(erlang,opaque(binary_to_existing_atom),[<<128>>]);
probe(c11) -> erlang:apply(erlang,opaque(binary_to_existing_atom),[<<192,128>>]);
probe(c12) -> erlang:apply(erlang,opaque(binary_to_existing_atom),[<<193,191>>]);
probe(c13) -> erlang:apply(erlang,opaque(binary_to_existing_atom),[<<194>>]);
probe(c14) -> erlang:apply(erlang,opaque(binary_to_existing_atom),[<<224,128,128>>]);
probe(c15) -> erlang:apply(erlang,opaque(binary_to_existing_atom),[<<237,160,128>>]);
probe(c16) -> erlang:apply(erlang,opaque(binary_to_existing_atom),[<<244,144,128,128>>]);
probe(c17) -> erlang:apply(erlang,opaque(binary_to_existing_atom),[<<248,128,128,128,128>>]);
probe(c18) -> erlang:apply(erlang,opaque(binary_to_existing_atom),[<<255>>]);
probe(c19) -> erlang:apply(erlang,opaque(binary_to_existing_atom),[<<1:1>>]);
probe(c20) -> _=erlang:apply(erlang,opaque(binary_to_atom),[binary:copy(<<97>>,255)]), erlang:apply(erlang,opaque(binary_to_existing_atom),[binary:copy(<<97>>,255)]);
probe(c21) -> erlang:apply(erlang,opaque(binary_to_existing_atom),[binary:copy(<<97>>,256)]);
probe(c22) -> erlang:apply(erlang,opaque(binary_to_existing_atom),[binary:copy(<<97>>,257)]);
probe(c23) -> _=erlang:apply(erlang,opaque(binary_to_atom),[binary:copy(<<240,159,152,128>>,255)]), erlang:apply(erlang,opaque(binary_to_existing_atom),[binary:copy(<<240,159,152,128>>,255)]);
probe(c24) -> erlang:apply(erlang,opaque(binary_to_existing_atom),[binary:copy(<<240,159,152,128>>,256)]);
probe(c25) -> erlang:apply(erlang,opaque(binary_to_existing_atom),[binary:copy(<<255>>,1020)]);
probe(c26) -> erlang:apply(erlang,opaque(binary_to_existing_atom),[binary:copy(<<255>>,1021)]);
probe(c27) -> erlang:apply(erlang,opaque(binary_to_existing_atom),[<<97,255>>]);
probe(c28) -> erlang:apply(erlang,opaque(binary_to_existing_atom),[<<255,97>>]);
probe(c29) -> erlang:apply(erlang,opaque(binary_to_existing_atom),[a]);
probe(c30) -> erlang:apply(erlang,opaque(binary_to_existing_atom),[0]);
probe(c31) -> erlang:apply(erlang,opaque(binary_to_existing_atom),[1.0]);
probe(c32) -> erlang:apply(erlang,opaque(binary_to_existing_atom),[[]]);
probe(c33) -> erlang:apply(erlang,opaque(binary_to_existing_atom),[[97]]);
probe(c34) -> erlang:apply(erlang,opaque(binary_to_existing_atom),[{}]);
probe(c35) -> erlang:apply(erlang,opaque(binary_to_existing_atom),[#{}]);
probe(c36) -> _=erlang:apply(erlang,opaque(binary_to_atom),[<<>>]), erlang:apply(erlang,opaque(binary_to_existing_atom),[<<>>]);
probe(c37) -> _=erlang:apply(erlang,opaque(binary_to_atom),[<<0>>]), erlang:apply(erlang,opaque(binary_to_existing_atom),[<<0>>]);
probe(c38) -> _=erlang:apply(erlang,opaque(binary_to_atom),[<<195,191>>]), erlang:apply(erlang,opaque(binary_to_existing_atom),[<<195,191>>]);
probe(c39) -> _=erlang:apply(erlang,opaque(binary_to_atom),[<<240,159,152,128>>]), erlang:apply(erlang,opaque(binary_to_existing_atom),[<<240,159,152,128>>]);
probe(c40) -> erlang:apply(erlang,opaque(binary_to_existing_atom),[<<"atom_contract492_never_created_89348">>]).
opaque(Value) -> put(atom_contract492_input,Value),erase(atom_contract492_input).
