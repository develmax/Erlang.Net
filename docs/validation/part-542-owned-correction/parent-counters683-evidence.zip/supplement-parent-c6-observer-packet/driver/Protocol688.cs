using System.Collections;
using System.Reflection;
using Erlang;

internal static class Protocol688
{
    private static readonly string[] Modes = ["pure", "hibernate_argument", "error", "throw", "exit"];
    private static TupleTerm Tuple(Term value, int count) { Program.Require(value is TupleTerm t && t.Items.Count == count); return (TupleTerm)value; }
    private static bool Is(Term value, string atom) => value is Atom a && a.Name == atom;
    private static Term Field(Term fields, string key)
    {
        var matches = Cons.Items(fields).Select(v => Tuple(v, 2)).Where(v => Is(v.Items[0], key)).ToArray();
        Program.Require(matches.Length == 1);
        return matches[0].Items[1];
    }
    private static bool Number(Term value, int number) => value is Integer integer && integer.Value == number;
    private static Dictionary<string, ReferenceTerm> Roles(byte[] bytes)
    {
        var outer = Tuple(ExternalTermFormat.Decode(bytes), 2);
        Program.Require(Is(outer.Items[1], "normal"));
        var returned = Tuple(outer.Items[0], 2);
        Program.Require(Is(returned.Items[0], "returned"));
        var body = Tuple(returned.Items[1], 2);
        Program.Require(Is(body.Items[0], "ordinary_vm686"));
        Term[] rows = Cons.Items(body.Items[1]).ToArray();
        Program.Require(rows.Length == Modes.Length);
        var roles = new Dictionary<string, ReferenceTerm>(StringComparer.Ordinal);
        for (int index = 0; index < rows.Length; index++)
        {
            var row = Tuple(rows[index], 2);
            string mode = Modes[index];
            Program.Require(Is(row.Items[0], mode));
            Term fields = row.Items[1], witness = Field(fields, "ref_witness"), why = Field(fields, "raw_why");
            if (index == 0)
            {
                Program.Require(Is(witness, "no_counter") && Is(Field(fields, "done"), "ok")
                    && Is(Field(fields, "native_read"), "no_counter") && Is(why, "normal"));
                continue;
            }
            Program.Require(witness is ReferenceTerm);
            var reference = (ReferenceTerm)witness;
            Program.Call("OriginalAtomics590Identity", "ValidateDescriptor", reference);
            Program.Require(roles.Values.All(prior => !prior.Equals(reference)));
            roles.Add("counter-" + mode, reference);
            if (index == 1)
            {
                var done = Tuple(Field(fields, "done"), 2);
                Program.Require(Is(done.Items[0], "value") && Number(done.Items[1], 1)
                    && Number(Field(fields, "native_read"), 1) && Is(why, "normal"));
            }
            else
            {
                Program.Require(Is(Field(fields, "same_ref"), "true") && Number(Field(fields, "read_from_reason"), 0));
                Program.Require(index == 2 ? Number(Field(fields, "read_from_stack"), 0)
                    : Is(Field(fields, "read_from_stack"), "not_applicable"));
                if (index != 4)
                {
                    var failure = Tuple(why, 2);
                    Term[] stack = Cons.Items(failure.Items[1]).ToArray();
                    Program.Require(stack.Length > 0 && stack.All(frame => frame is TupleTerm { Items.Count: 4 }));
                }
                else Program.Require(Is(Tuple(why, 2).Items[0], "native686"));
            }
        }
        Program.Require(roles.Count == 4);
        return roles;
    }
    private static (int Offset, string Role)[] Occurrences(byte[] data, Dictionary<string, ReferenceTerm> roles)
    {
        Type wire = Assembly.Load("Erlang.Tests").GetType("Erlang.Tests.OriginalCounters610Wire", true)!;
        const BindingFlags flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
        object instance = Activator.CreateInstance(wire, flags, null, [data, roles], null)!;
        var result = (IEnumerable)wire.GetMethod("Read", flags)!.Invoke(instance, null)!;
        return result.Cast<object>().Select(row => (
            (int)row.GetType().GetProperty("Offset")!.GetValue(row)!,
            (string)row.GetType().GetProperty("Role")!.GetValue(row)!)).ToArray();
    }
    internal static void RequireSameBinding(byte[] plain, byte[] deterministic)
    {
        var a = Roles(plain);
        var b = Roles(deterministic);
        Program.Require(a.Count == b.Count && a.All(pair => b.TryGetValue(pair.Key, out var other)
            && pair.Value.Node == other.Node && pair.Value.Creation == other.Creation
            && pair.Value.Words.SequenceEqual(other.Words)));
    }
    internal static object Compare(byte[] original, byte[] managed)
    {
        var aRoles = Roles(original);
        var bRoles = Roles(managed);
        var a = Occurrences(original, aRoles);
        var b = Occurrences(managed, bRoles);
        Program.Require(a.Length == b.Length && a.Length >= 4);
        Program.Require(a.Select(row => row.Role).SequenceEqual(b.Select(row => row.Role)));
        Program.Require(a.Select(row => row.Role).ToHashSet().SetEquals(aRoles.Keys));
        int ax = 0, bx = 0;
        for (int index = 0; index < a.Length; index++)
        {
            Program.Require(original.AsSpan(ax, a[index].Offset - ax).SequenceEqual(managed.AsSpan(bx, b[index].Offset - bx)));
            ax = a[index].Offset + 12;
            bx = b[index].Offset + 12;
        }
        Program.Require(original.AsSpan(ax).SequenceEqual(managed.AsSpan(bx)));
        object Describe(Dictionary<string, ReferenceTerm> roles) => roles.ToDictionary(pair => pair.Key,
            pair => new { pair.Value.Node, pair.Value.Creation, Words = pair.Value.Words.ToArray() });
        return new { Passed = true, WholeRawBytesEqual = original.AsSpan().SequenceEqual(managed),
            OriginalRoles = Describe(aRoles), ManagedRoles = Describe(bRoles), OccurrenceRoles = a.Select(row => row.Role).ToArray(),
            Policy = "Only authenticated four-role 12-byte reference-number spans differ; no term/stack rewriting" };
    }
}
