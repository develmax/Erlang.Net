using System.Collections;
using System.Reflection;
using System.Text.Json;
using Erlang;

internal static class Program
{
    private const BindingFlags Flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance;
    private static Assembly tests = null!;
    internal static object Call(string type, string method, params object?[] args)
        => tests.GetType("Erlang.Tests." + type, true)!.GetMethod(method, Flags)!.Invoke(null, args)!;
    internal static void Require(bool value) { if (!value) throw new InvalidDataException("Observer688 contract"); }
    private static async Task<int> Main(string[] args)
    {
        string original = Path.GetFullPath(args[0]), output = Path.GetFullPath(args[1]);
        bool owned = bool.Parse(args[2]);
        Directory.CreateDirectory(output);
        tests = Assembly.LoadFrom(Path.Combine(AppContext.BaseDirectory, "Erlang.Tests.dll"));
        var runtime = (ProcessRuntime)Call("OwnedGuest506RuntimeFactory", "Create", owned, null);
        var errors = new List<string>();
        var comparisons = new List<object>();
        bool profile = false;
        try
        {
            profile = (bool)typeof(ProcessRuntime).GetProperty("OwnedTermsPilot506", Flags)!.GetValue(runtime)!;
            Require(profile == owned);
            PreparedBeamImage? facet = null;
            await runtime.InitializeModulesAsync(registry =>
            {
                facet = (PreparedBeamImage)Call("CountersOriginal421Preparation", "Prepare", runtime, registry);
                Require(registry.PublishPreparedBeam(facet).Status == BeamPublicationStatus.Published);
            });
            string[] names = ["ordinary_vm686", "ordinary_vm_probe686", "contract_worker513"];
            var images = names.Select(name => runtime.Modules.PrepareBeam(
                File.ReadAllBytes(Path.Combine(original, name + ".beam")),
                new BeamDependencySelection(["erlang", "erts_internal", .. names]))).ToArray();
            Require(images.All(image => !image.HasOnLoad && image.NativePrimitiveExports.Count == 0));
            Require(runtime.Modules.PublishPreparedBeam(images).Status == BeamPublicationStatus.Published);
            void Owners()
            {
                Require(ReferenceEquals(runtime.Modules.SourceOwner(names[0], "run", 0), images[0]));
                Require(ReferenceEquals(runtime.Modules.SourceOwner(names[1], "entered", 1), images[1]));
                Require(ReferenceEquals(runtime.Modules.SourceOwner(names[2], "run", 1), images[2]));
                Require(ReferenceEquals(runtime.Modules.SourceOwner(names[2], "worker", 3), images[2]));
                Call("CountersOriginal421Preparation", "AssertPublished", runtime.Modules, facet);
            }
            Owners();
            var completed = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
            ProcessHandle controller = runtime.Spawn(async context =>
            {
                IDisposable? carriers = null;
                try
                {
                    Term value = await runtime.Modules.Call(context, names[2], "run", Term.A(names[0]));
                    carriers = (IDisposable)Call("OriginalCounters610ResultOwnership", "CaptureHostCarriers", value);
                    foreach (bool deterministic in new[] { false, true })
                    {
                        string file = deterministic ? "observed-deterministic.etf" : "observed.etf";
                        Term minor = Term.Tuple(Term.A("minor_version"), Term.I(2));
                        var bytes = (BitString)await runtime.Modules.Call(context, "erlang", "term_to_binary", value,
                            deterministic ? Term.List(Term.A("deterministic"), minor) : Term.List(minor));
                        byte[] actual = bytes.ToArray();
                        await File.WriteAllBytesAsync(Path.Combine(output, file), actual);
                        byte[] expected = File.ReadAllBytes(Path.Combine(original, file));
                        try { comparisons.Add(Protocol688.Compare(expected, actual)); }
                        catch (Exception error) { errors.Add(file + ": " + error); }
                    }
                    Protocol688.RequireSameBinding(File.ReadAllBytes(Path.Combine(original, "observed.etf")), File.ReadAllBytes(Path.Combine(original, "observed-deterministic.etf")));
                    Protocol688.RequireSameBinding(File.ReadAllBytes(Path.Combine(output, "observed.etf")), File.ReadAllBytes(Path.Combine(output, "observed-deterministic.etf")));
                    Owners();
                }
                catch (Exception error) { completed.TrySetException(error); }
                finally
                {
                    try { carriers?.Dispose(); }
                    catch (Exception error) { completed.TrySetException(error); }
                }
                completed.TrySetResult();
                return Nil.Value;
            });
            await completed.Task.WaitAsync(TimeSpan.FromSeconds(180));
            await controller.Completion.WaitAsync(TimeSpan.FromSeconds(30));
        }
        catch (Exception error) { errors.Add(error.ToString()); }
        finally
        {
            try { await runtime.DisposeAsync().AsTask().WaitAsync(TimeSpan.FromSeconds(30)); }
            catch (Exception error) { errors.Add("cleanup: " + error); }
        }
        var cleanup = runtime.CountersStorage421;
        // Report after genuine VM disposal; do not count an early Array.Retired latch as owner settlement.
        bool settled = cleanup.Closed && cleanup.Created == cleanup.Freed && cleanup.LiveArrays == 0
            && cleanup.OwnedNativeBytes == 0 && cleanup.ActiveInvocations == 0;
        bool passed = errors.Count == 0 && comparisons.Count == 2 && settled;
        await File.WriteAllTextAsync(Path.Combine(output, "completion.json"), JsonSerializer.Serialize(new
        {
            Passed = passed, RequestedOwnedProfile = owned, ActualOwnedProfile = profile,
            Comparisons = comparisons, Cleanup = cleanup, PhysicalCleanupPassed = settled, Errors = errors,
            Scope = "five outcomes/four authenticated reference roles; whole raw stacks retained"
        }, new JsonSerializerOptions { WriteIndented = true }));
        return passed ? 0 : 1;
    }
}
