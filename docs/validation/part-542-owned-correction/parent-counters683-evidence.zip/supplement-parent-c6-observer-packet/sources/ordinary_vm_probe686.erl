-module(ordinary_vm_probe686).
-export([entered/1]).
entered(_) -> ok.
