-module(ordinary_vm686).
-export([run/0,start/3,start_offline/3,worker/3,resume/2]).
start(Parent,Ref,Mode) -> spawn_monitor(ordinary_vm686,worker,[Parent,Ref,Mode]).
start_offline(Parent,Ref,Mode) -> spawn_opt(ordinary_vm686,worker,[Parent,Ref,Mode],[monitor,{scheduler,2}]).
worker(Parent,Ref,Mode) ->
    ordinary_vm_probe686:entered(self()),
    Parent ! {ready,self()},
    receive go -> ok end,
    case Mode of
        pure -> finish686(Parent,ok);
        hibernate_argument ->
            self() ! wake686,
            erlang:hibernate(ordinary_vm686,resume,[Parent,Ref]);
        error -> erlang:error({native686,Ref},[Ref]);
        throw -> erlang:throw({native686,Ref});
        exit -> erlang:exit({native686,Ref})
    end.
resume(Parent,Ref) ->
    receive wake686 -> ok end,
    ok=erts_internal:counters_add(Ref,1,1),
    finish686(Parent,{value,erts_internal:counters_get(Ref,1)}).
finish686(Parent,Value) ->
    Parent ! {done,self(),Value},
    receive finish -> ok end.

run() ->
    {ordinary_vm686,[observe686(Mode) || Mode <- [pure,hibernate_argument,error,throw,exit]]}.
observe686(Mode) ->
    Ref=case Mode of pure -> no_counter; _ -> erts_internal:counters_new(1) end,
    {Pid,M}=start(self(),Ref,Mode),
    receive {ready,Pid} -> ok after 10000 -> error(no_ready686) end,
    Pid ! go,
    case Mode of
        pure -> observe_normal686(Mode,Ref,Pid,M);
        hibernate_argument -> observe_normal686(Mode,Ref,Pid,M);
        _ ->
            Why=receive {'DOWN',M,process,Pid,Reason} -> Reason after 10000 -> error(no_down686) end,
            {Same,StackRead}=case {Mode,Why} of
                {error,{{native686,Seen},[{_,_,[FrameRef],_}|_]}} ->
                    {Seen =:= Ref andalso FrameRef =:= Ref,erts_internal:counters_get(FrameRef,1)};
                {throw,{{nocatch,{native686,Seen}},[_|_]}} -> {Seen =:= Ref,not_applicable};
                {exit,{native686,Seen}} -> {Seen =:= Ref,not_applicable}
            end,
            UsedRef=reason_ref686(Why),
            {Mode,[{ref_witness,Ref},{same_ref,Same},{read_from_reason,erts_internal:counters_get(UsedRef,1)},
                   {read_from_stack,StackRead},{raw_why,Why}]}
    end.
observe_normal686(Mode,Ref,Pid,M) ->
    Done=receive {done,Pid,Value} -> Value after 10000 -> error(no_done686) end,
    Pid ! finish,
    Why=receive {'DOWN',M,process,Pid,Reason} -> Reason after 10000 -> error(no_down686) end,
    Native=case Mode of pure -> no_counter; _ -> erts_internal:counters_get(Ref,1) end,
    {Mode,[{ref_witness,Ref},{done,Done},{native_read,Native},{raw_why,Why}]}.
reason_ref686({{native686,Ref},_}) -> Ref;
reason_ref686({{nocatch,{native686,Ref}},_}) -> Ref;
reason_ref686({native686,Ref}) -> Ref.
