"""Source-only packet. Root builds external driver and explicitly executes this collector."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
sys.dont_write_bytecode = True

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest().upper()
def save(path, value): Path(path).write_bytes((json.dumps(value, indent=2)+'\n').encode())
def require(value, why):
    if not value: raise RuntimeError(why)
def load(name, path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--repository',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--plan-sha256',required=True)
    parser.add_argument('--host-bin',type=Path,required=True)
    parser.add_argument('--driver-bin',type=Path,required=True)
    parser.add_argument('--dotnet',type=Path,required=True)
    parser.add_argument('--execute',action='store_true')
    sources=parser.add_mutually_exclusive_group(required=True)
    sources.add_argument('--official-admission',type=Path)
    sources.add_argument('--build-receipt',type=Path)
    parser.add_argument('--admission-sha256',required=True)
    parser.add_argument('--otp-source',type=Path)
    parser.add_argument('--expected-head')
    args=parser.parse_args()
    packet=Path(__file__).resolve().parent;repo=args.repository.resolve();out=args.output.resolve()
    require(sha(packet/'inputs.json')==args.plan_sha256.upper(),'Reviewed inputs plan SHA differs')
    plan=json.loads((packet/'inputs.json').read_bytes())
    require(args.official_admission is not None and args.official_admission.resolve()==Path(plan['OfficialAdmissionPath']).resolve() and args.admission_sha256.upper()==plan['OfficialAdmissionSha256'],'Explicit reviewed official admission differs')
    require(args.dotnet.resolve()==Path(plan['DotnetPath']).resolve() and sha(args.dotnet)==plan['DotnetSha256'],'Reviewed dotnet host differs')
    def guard():
        for row in plan['Inputs']:
            root=packet if row['Root']=='Packet' else repo
            path=(root/row['Path']).resolve()
            require(path.is_relative_to(root) and path.is_file() and sha(path)==row['Sha256'],'Input differs: '+str(path))
    guard()
    require(not out.exists() and out.is_relative_to(repo/'artifacts'),'Fresh owned artifact output required')
    host=args.host_bin.resolve();driver=args.driver_bin.resolve()
    require(host.is_dir() and driver.is_dir(),'Prepared host/driver required; collector does not build')
    require(host==Path(plan['HostDirectory']).resolve(),'Reviewed host directory differs')
    frozen={row['Path']:row['Sha256'] for row in plan['HostFiles']}
    def host_guard():
        actual={path.name:sha(path) for path in host.iterdir() if path.is_file() and path.suffix in ['.dll','.json']}
        require(actual==frozen,'Protected host DLL/deps/runtimeconfig snapshot differs')
    host_guard()
    driver_names=['Observer688.dll','Observer688.deps.json','Observer688.runtimeconfig.json']
    require(all((driver/name).is_file() for name in driver_names),'External driver build incomplete')
    driver_before={name:sha(driver/name) for name in driver_names}
    require(args.dotnet.is_file(),'Explicit dotnet executable required')
    if not args.execute:
        print(json.dumps(dict(Prepared=True,Executed=False,HostFiles=len(frozen),FiveOutcomes=True,FourRoles=True)));return
    out.mkdir(parents=True)
    helper=load('observer688_existing',repo/'tools/Runtime/Erlang.OwnedGuest506Observations/collect.py')
    owned=load('observer688_owned',repo/'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py')
    require(os.name=='nt','This bounded adapter uses existing Windows owned helper; Linux requires existing stage adapter')
    errors=[];provider_after=None;before=None;results=[]
    original=out/'original';original.mkdir()
    for path in sorted((packet/'sources').glob('*.erl')):shutil.copyfile(path,original/path.name)
    try:
        installed,executable,before,provider_after=helper.provider(args,repo)
        save(out/'provider-before.json',before)
        expression=r"""W=fun(N,T)->ok=file:write_file(N,term_to_binary(T,[{minor_version,2}])) end,
Expected=filename:absname(os:getenv("CONTRACT506_ORIGINAL_ROOT")),Expected=filename:absname(code:root_dir()),8=erlang:system_info(wordsize),
Compiled=[compile:file(F,[return_errors,return_warnings]) || F<-filelib:wildcard("*.erl")],W("compile.etf",Compiled),
true=lists:all(fun({ok,_,_})->true;({ok,_})->true;(_)->false end,Compiled),
true=lists:all(fun(M)->filename:absname(code:which(M))=:=filename:absname(atom_to_list(M)++".beam") end,[ordinary_vm686,ordinary_vm_probe686,contract_worker513]),
W("image-owners.etf",[{M,code:which(M),M:module_info(md5),M:module_info(compile)} || M<-[ordinary_vm686,ordinary_vm_probe686,contract_worker513]]),
T=contract_worker513:run(ordinary_vm686),W("observed.etf",T),
ok=file:write_file("observed-deterministic.etf",term_to_binary(T,[deterministic,{minor_version,2}])),
W("worker-witnesses.etf",get(contract_worker513_witnesses)),case T of {{returned,_},normal}->halt(0);_->halt(78) end.
"""
        environment={key:value for key,value in os.environ.items() if not key.startswith('ERL_')}
        environment['CONTRACT506_ORIGINAL_ROOT']=str(installed)
        receipt=owned.owned([str(executable),'+S','2:2','+A','1','-noshell','-noinput','-boot','no_dot_erlang','-pa',str(original),'-eval',expression],original,'original',180,environment,str(original))
        require(receipt['Settled'] and receipt['ExitCode']==0 and not receipt['TimedOut'] and not receipt['Failures'],'Original process failure')
        results.append(dict(Route='original',Passed=True,Receipt=receipt))
    except Exception as error:
        errors.append('original: '+repr(error));results.append(dict(Route='original',Passed=False,Error=repr(error)))
    # Both managed profiles are independent after original BEAM and raw preparation; never abort after first route failure.
    prepared=all((original/name).is_file() for name in ['ordinary_vm686.beam','ordinary_vm_probe686.beam','contract_worker513.beam','observed.etf','observed-deterministic.etf'])
    for profile in ['ordinary','private']:
        route=out/profile;route.mkdir()
        if not prepared:
            results.append(dict(Route=profile,Skipped=True,Reason='Original BEAM/raw preparation failed'));continue
        try:
            private=route/'host';shutil.copytree(host,private)
            require(all(sha(private/name)==digest for name,digest in frozen.items()),'Copied host differs')
            for name in driver_names:
                require(not (private/name).exists(),'Driver filename collision');shutil.copyfile(driver/name,private/name)
            capture=route/'capture'
            receipt=owned.owned([str(args.dotnet),str(private/'Observer688.dll'),str(original),str(capture),str(profile=='private').lower()],route,'managed',240,os.environ.copy(),str(private))
            completion=json.loads((capture/'completion.json').read_bytes())
            require(receipt['Settled'] and receipt['ExitCode']==0 and not receipt['TimedOut'] and not receipt['Failures'] and completion['Passed'],'Managed process/comparison failed')
            require(completion['ActualOwnedProfile']==(profile=='private') and completion['RequestedOwnedProfile']==(profile=='private'),'Wrong managed profile')
            results.append(dict(Route=profile,Passed=True,Receipt=receipt,Completion=completion))
        except Exception as error:
            errors.append(profile+': '+repr(error));results.append(dict(Route=profile,Passed=False,Error=repr(error)))
    try:
        if provider_after is not None:
            after=provider_after();save(out/'provider-after.json',after)
            require(after==before['Inventory'],'Provider mutated')
        guard();host_guard();require(driver_before=={name:sha(driver/name) for name in driver_names},'Driver mutated')
    except Exception as error:errors.append('integrity: '+repr(error))
    files=[dict(Path=path.relative_to(out).as_posix(),Sha256=sha(path)) for path in sorted(out.rglob('*')) if path.is_file()]
    completion=dict(Passed=not errors and len(results)==3 and all(row.get('Passed') for row in results),Results=results,Errors=errors,
        InputPlanSha256=sha(packet/'inputs.json'),DriverFiles=driver_before,Files=files,WholeContractCredits=0,
        Scope='5 observer outcomes; 4 authenticated reference roles; 4 whole value/stack comparisons; no original physical-custody claim')
    save(out/'completion.json',completion)
    print(json.dumps(dict(Passed=completion['Passed'],Output=str(out))))
    return 0 if completion['Passed'] else 1
if __name__=='__main__':sys.exit(main())
