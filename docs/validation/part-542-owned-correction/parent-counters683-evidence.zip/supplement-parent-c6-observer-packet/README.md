# Observer688: original/managed ordinary native MFA semantics

Source-only, unexecuted proposal. No runtime/source/Harness changes. Parent reported the separate seven physical controls green; this packet does not reinterpret those as original evidence.

Exactly one fresh original compilation/execution of three source files, then replay the identical three BEAM files through public PreparedBeam publication and public contract_worker513 run/1, independently on ordinary and private profiles. Five outcomes: pure, native hibernate argument, error, throw, exit. Four authenticated native counter-reference roles. Preserve all raw reasons and full error/throw stacks. In-VM reference equality plus actual counters_get on reason/stack witnesses authenticates each role; witness roots legitimately remain alive in the observer.

Compare default and deterministic ETF for both profiles: four whole-stream comparisons. The bounded existing OriginalCounters610Wire traverses the complete stream; only the 12 number bytes of each authenticated four-role NEWER_REFERENCE_EXT differ. All node/creation/tag/arity bytes, frame metadata, line/file context and remaining terms are literal. No projection, re-encoding, frame stripping, identity wildcard or arbitrary reference normalization. Raw byte equality is separately recorded. Same-role default/deterministic bindings must match within each VM. This protocol is distinct from610's six-role corpus and the seven managed physical controls. No original physical Host-retirement, shutdown/offline, sixth storage-family or whole API compatibility claim.

## Root-owned commands (not executed by author)

First build only this external project; no project/source references or runtime rebuild. Sources passed copied SourceLayout and true Roslyn token-kind/text2/2, syntax2/2; Python AST parse passed. The first syntax-parser attempt hit a PowerShell assembly-load conflict; the successful receipt uses an isolated load context.

```powershell
$packet = 'D:/Distr/Work/Codex/Erlang.Net/Erlang.Net/artifacts/batch688/ordinary-original-observer538'
$runtimeBin = 'D:\Distr\Work\Codex\Erlang.Net\w518repair\tests\Erlang.Tests\bin\Release\net10.0'
dotnet build "$packet/final-driver/Observer688.csproj" -c Release -p:RuntimeDirectory="$runtimeBin" -p:ImportDirectoryBuildProps=false -p:ImportDirectoryBuildTargets=false
py -3 "$packet/collect.py" --repository D:/Distr/Work/Codex/Erlang.Net/w518repair --output D:/Distr/Work/Codex/Erlang.Net/w518repair/artifacts/ci93-four/original688-release-01 --plan-sha256 7A032AB2486CDDF7B7AA847E82D526D45F74F0FDB0951DF1E76AC1DA7B4D597B --host-bin "$runtimeBin" --driver-bin "$packet/final-driver/bin/Release/net10.0" --dotnet "C:/Program Files/dotnet/dotnet.exe" --official-admission "D:\Distr\Work\Codex\Erlang.Net\Erlang.Net\artifacts\library376-official-compiler\official-admission.json" --admission-sha256 41CCC2FDE5493D85BEAA21996E12D0885D2919B0D4BF44137D0673DCDC9D5EA6 --execute
```

Collector protects67 exact source/helper/packet inputs including current48 source freeze,38 root host DLL/JSON files, reviewed dotnet executable and official provider admission. It inventories the actual6427-file provider before/after through existing admission helper; original modules assert actual code:which paths before recording MD5/compile metadata. Each owned route has raw stdout/stderr, exit/cleanup receipt. Managed output uses unique private copies of the full host bin with matching DLL hashes; root DLLs stay untouched. Runtime disposal is awaited and actual counters owner report must have Closed, Created=Freed, LiveArrays/OwnedNativeBytes/ActiveInvocations=0. Original failure is retained; prepared independent managed profiles still run, one managed failure does not suppress the other. Failed compilation/missing raw preparation gates dependent replay.

The packet binds Release only. If final binaries change or Debug is desired, create a separate reviewed input-plan amendment; do not silently reaccept current hashes. The external driver has not been compiled, and fresh OTP has not been invoked by this author: semantic/runtime validation remains parent-owned. No API/status credit before actual comparisons and affected regression on final sources.
