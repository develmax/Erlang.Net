from pathlib import Path
import subprocess,json,hashlib
r=Path.cwd();out=r/'artifacts/parent683-integration';out.mkdir(exist_ok=True);assert not list(out.iterdir());parent='c6b7cc809e41ee9f4f5759184d10d52dd8c48531';head='278fc760a1e2b44754b17d7349f7cac27c42de16'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
conflicts=subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],text=True).splitlines();assert len(conflicts)==23 and not any(p.endswith('.cs') for p in conflicts)
for p in conflicts:
 b=(r/p).read_bytes();dst=out/'conflicts'/p;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b)
 ours=subprocess.check_output(['git','show',head+':'+p]);(r/p).write_bytes(ours)
 if p=='AGENTS.md':
  theirs=subprocess.check_output(['git','show',parent+':'+p]);prefix=theirs.split(b'\n\n',1)[0]+b'\n\n';(r/p).write_bytes(prefix+ours)
 if p=='docs/changelog/0094.md':
  theirs=subprocess.check_output(['git','show',parent+':'+p]);marker=b'## Part541 \xe2\x80\x94 2026-10-29 \xe2\x80\x94 Preserve native counter ownership in ordinary MFA processes';assert theirs.count(marker)==1 and marker not in ours;(r/p).write_bytes(ours+b'\n\n'+marker+theirs.split(marker,1)[1])
subprocess.run(['git','add','--',*conflicts],check=True)
a=json.loads((r/'docs/validation/part-541/current-source-freeze-counters683-687.json').read_bytes())['Rows'];b=json.loads((r/'docs/validation/part-542-owned-correction/current-source-freeze-native677.json').read_bytes())['Rows'];paths=sorted({x['Path'] for x in a+b});assert len(paths)==145
rows=[{'Path':p,'Sha256':hashlib.sha256((r/p).read_bytes()).hexdigest().upper()} for p in paths];(out/'source145.json').write_text(json.dumps({'Rows':rows},indent=2));(out/'resolution.json').write_text(json.dumps({'Parent':parent,'PreviousChild':head,'ProductionConflicts':0,'MetadataConflictsResolvedToChildPendingMandatoryReseal':len(conflicts)-2,'EnglishBothEntriesPreserved':True,'NativeAndOwnedBeamAliasesPreserved':True,'FinalSourceCount':145},indent=2));print('145 C# source freeze; production merge clean, metadata deliberately requires resealing')
