from pathlib import Path
import json,hashlib,os,importlib.util
r=Path.cwd();out=r/'artifacts/parent683-integration/regress';out.mkdir(exist_ok=False);freeze=r/'artifacts/parent683-integration/source145.json';raw=freeze.read_bytes();rows=json.loads(raw)['Rows'];s=importlib.util.spec_from_file_location('owned',r/'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
plan=r/'tools/Runtime/Erlang.BeamFunction542Observations/inputs.json';planraw=plan.read_bytes();pp=json.loads(planraw);six=set(pp['Cases']+pp['OwnedCases']);assert len(six)==6
parent=json.loads((r.parent/'w518repair/artifacts/ci93-four/final48-regress/selected.json').read_bytes());blocks=parent['Blocks'];seen={n for b in blocks for n in b};assert len(seen)==510 and not seen.intersection(six)
child=set(json.loads((r/'artifacts/resource542/final-parent-integration/cases.json').read_bytes()));assert len(child)==141 and six<=child
extra=sorted(child-seen-six);blocks.append(extra);seen.update(extra);assert len(extra)==123 and len(seen)==633
(out/'selected.json').write_text(json.dumps({'RegressionDistinct':633,'OriginalCollectorDisjointSix':sorted(six),'CompleteAcceptedTarget':639,'Blocks':blocks},indent=2))
def check():
 assert freeze.read_bytes()==raw and plan.read_bytes()==planraw
 for x in rows:assert hashlib.sha256((r/x['Path']).read_bytes()).hexdigest().upper()==x['Sha256']
errors=[];results=[]
for cfg in ['Release','Debug']:
 d=out/cfg;d.mkdir();host=r/f'tests/Erlang.Tests/bin/{cfg}/net10.0/Erlang.Tests.dll';identity={p.name:hashlib.sha256(p.read_bytes()).hexdigest().upper() for p in host.parent.glob('*.dll')}
 for i,names in enumerate(blocks):
  check();cmd=['dotnet','exec','--fx-version','10.0.11',str(host)]
  for n in names:cmd+=['--case',n]
  report=d/f'block{i}.json';cmd+=['--report',str(report)]
  try:m.owned(cmd,d,f'block{i}',180,dict(os.environ,DOTNET_PROCESSOR_COUNT='2',DOTNET_GCConserveMemory='9',PYTHONDONTWRITEBYTECODE='1'),str(r))
  except Exception as e:errors.append({'Profile':cfg,'Block':i,'Error':repr(e)})
  if report.exists():
   v=json.loads(report.read_bytes());assert {x['Name'] for x in v['Tests']}==set(names);row={'Profile':cfg,'Block':i,'Passed':v['Passed'],'Failed':v['Failed']};results.append(row);print(json.dumps(row),flush=True)
   if v['Failed']:errors.append({'Profile':cfg,'Block':i,'Failures':[x for x in v['Tests'] if x['Status']!='Passed']})
  else:errors.append({'Profile':cfg,'Block':i,'MissingReport':True})
  assert identity=={p.name:hashlib.sha256(p.read_bytes()).hexdigest().upper() for p in host.parent.glob('*.dll')}
 check();(d/'assemblies.json').write_text(json.dumps(identity,indent=2))
 target=out/('original-'+cfg)
 try:
  m.owned(['py','-3','-B',str(r/'tools/Runtime/Erlang.BeamFunction542Observations/run.py'),'--repository',str(r),'--output',str(target),'--official-admission',str(r.parent/'Erlang.Net/artifacts/library376-official-compiler/official-admission.json'),'--admission-sha256','41CCC2FDE5493D85BEAA21996E12D0885D2919B0D4BF44137D0673DCDC9D5EA6','--configuration',cfg],out,'original-'+cfg,360,dict(os.environ,PYTHONDONTWRITEBYTECODE='1',DOTNET_GCConserveMemory='9'),str(r))
  v=json.loads((target/'completion.json').read_bytes());assert v['Passed'];print(json.dumps({'Profile':cfg,'OriginalWholeAndSixManaged':True}),flush=True)
 except Exception as e:errors.append({'Profile':cfg,'OriginalError':repr(e)})
 check();assert identity=={p.name:hashlib.sha256(p.read_bytes()).hexdigest().upper() for p in host.parent.glob('*.dll')}
(out/'completion.json').write_text(json.dumps({'Passed':not errors,'RegressionDistinctPerProfile':633,'DisjointFreshOriginalManagedCases':6,'AcceptedTargetPerProfile':639,'Rows':results,'Errors':errors},indent=2));raise SystemExit(0 if not errors else 1)
