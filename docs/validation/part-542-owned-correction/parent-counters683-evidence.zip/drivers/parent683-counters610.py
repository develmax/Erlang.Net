from pathlib import Path
import json,hashlib,importlib.util,os
r=Path.cwd();out=r/'artifacts/parent683-integration/counters610';out.mkdir(exist_ok=False);s=importlib.util.spec_from_file_location('owned',r/'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);host=r/'tests/Erlang.Tests/bin/Release/net10.0/Erlang.Tests.dll';identity={p.name:hashlib.sha256(p.read_bytes()).hexdigest().upper() for p in host.parent.glob('*.dll')};results=[];errors=[]
for mode in ['ordinary','private-owned']:
 d=out/mode;d.mkdir();request=json.loads((r.parent/'w518repair/artifacts/ci93-four/counters610-authentic-red'/mode/'request.json').read_bytes());cmd=request['Command'];cmd[4]=str(host);cmd[-1]=str(d/'actual')
 try:m.owned(cmd,d,'managed',120,dict(os.environ,DOTNET_PROCESSOR_COUNT='1',DOTNET_GCConserveMemory='9',PYTHONDONTWRITEBYTECODE='1'),str(r))
 except Exception as e:errors.append({'Mode':mode,'Error':repr(e)})
 c=json.loads((d/'actual/comparison.json').read_bytes());cleanup=json.loads((d/'actual/cleanup610.json').read_bytes());passed=c['Passed'] and c['OwnReferenceProtocolPassed'] and c['WholeRawValuesAndStacksCompared'] and cleanup['PhysicalClosed'];results.append({'Mode':mode,'Passed':passed,'Cleanup':cleanup});print(json.dumps(results[-1]),flush=True)
 if not passed:errors.append({'Mode':mode,'ComparisonFailed':True})
assert identity=={p.name:hashlib.sha256(p.read_bytes()).hexdigest().upper() for p in host.parent.glob('*.dll')}
(out/'completion.json').write_text(json.dumps({'Passed':not errors,'Rows':results,'Errors':errors,'ImmutableOriginalCaptureReused':True,'ParentOriginalAdmissionSha256':'28ED28BD9522DB6025B2883945B2C2FCDC7D66C88A25B051A7820C3753DD3F4C'},indent=2));raise SystemExit(0 if not errors else 1)
