from pathlib import Path
import os,subprocess
r=Path.cwd()
for cfg in ['Debug','Release']:
 subprocess.run(['py','-3','tools/Runtime/Erlang.BeamFunction542Observations/run.py','--repository','.', '--configuration',cfg,'--output','artifacts/resource542/monitor652-integration/original-'+cfg.lower(),'--official-admission',str(r.parent/'Erlang.Net/artifacts/library376-official-compiler/official-admission.json'),'--admission-sha256','41CCC2FDE5493D85BEAA21996E12D0885D2919B0D4BF44137D0673DCDC9D5EA6'],check=True,env=dict(os.environ,DOTNET_GCConserveMemory='9'))
