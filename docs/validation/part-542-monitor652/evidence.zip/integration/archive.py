from pathlib import Path
import json,hashlib,zipfile
r=Path.cwd();base=r/'artifacts/resource542/monitor652-integration';out=r/'docs/validation/part-542-monitor652';out.mkdir(exist_ok=False)
profiles=[]
for cfg in ['Debug','Release']:
 label=cfg.lower();unit=json.loads((r/f'artifacts/resource542/monitor652-final-{label}135/result.json').read_bytes());oracle=json.loads((base/f'original-{label}/completion.json').read_bytes());assert unit['Report']['Passed']==135 and unit['Report']['Failed']==0 and oracle['Passed'] and len(oracle['Equal'])==10 and all(oracle['Equal'].values());profiles.append({'Configuration':cfg,'Cases':135,'WholeStacks':6,'WholeNonopaqueOutcomes':4,'CleanupModes':oracle['CleanupCompletedModes'],'OpaqueFunctionIdsCompared':False,'InputPlanSha256':oracle['InputPlanSha256'],'Assemblies':unit['Assemblies']})
rows=json.loads((base/'source90.json').read_bytes())['Rows']
for row in rows:assert hashlib.sha256((r/row['Path']).read_bytes()).hexdigest().upper()==row['Sha256']
meta=r/'artifacts/resource542-permanent652-metadata';membership=json.loads((meta/'final-membership.json').read_bytes());assert membership['ExactMembers']==4019
summary={'Passed':True,'Profiles':profiles,'ExpectedCatalog':9436,'Current90Sha256':'FD3E87BDA68B95DD97FB92AFC5D6B87EDDC0463F478BC5426484CE18ADDC0543','SourceRows':rows,'Metadata':membership,'Review4414173126Reproduced':False,'ResourceTagGraphAndActualProcessOrderAsserted':True,'ActualThreeProcessCancellationCompletionAndResourceRetirementAsserted':True,'FreshDownDuringDisposeGuardedByDisposed':True,'AnchoredRuntimeProposalApplied':False,'ApiDelta':0,'WholeContractDelta':0,'LocalFull505Claimed':False,'FullCiPending':True}
(out/'summary.json').write_text(json.dumps(summary,indent=2));files=[]
for prefix,folder in [('integration',base),('metadata',meta),('debug135',r/'artifacts/resource542/monitor652-final-debug135'),('release135',r/'artifacts/resource542/monitor652-final-release135'),('parent009-proof',r.parent/'w518repair/artifacts/monitor652'),('parent009-strong-case',r.parent/'w518repair/artifacts/resource541/p1-earlier-target-strong'),('parent009-expected-red-actual-pass',r.parent/'w518repair/artifacts/resource541/p1-earlier-target-red')]:
 for p in sorted(folder.rglob('*')):
  if p.is_file() and not any(n in p.parts for n in ['__pycache__','style']):files.append((prefix+'/'+p.relative_to(folder).as_posix(),p))
for name in ['tests/Erlang.Tests/Runtime/Processes/Signals/MonitorShutdown652Names.cs','tests/Erlang.Tests/Runtime/Processes/Signals/MonitorShutdown652Checks.cs']:files.append(('final-source/'+name,r/name))
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in files:z.writestr(name,p.read_bytes())
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(files)==len(set(z.namelist()))
 for name,p in files:assert z.read(name)==p.read_bytes()
receipt={'Sha256':hashlib.sha256(archive.read_bytes()).hexdigest().upper(),'Bytes':archive.stat().st_size,'Members':len(files),'EveryMemberVerified':True};(out/'archive.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
