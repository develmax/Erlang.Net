from pathlib import Path
import subprocess,os
r=Path.cwd()
for cfg in ['Debug','Release']:
 subprocess.run(['py','-3','artifacts/resource542/run542.py','--configuration',cfg,'--label','monitor652-final-'+cfg.lower()+'135','--names','artifacts/resource542/monitor652-integration/new135.json'],check=True,env=dict(os.environ,DOTNET_GCConserveMemory='9'))
