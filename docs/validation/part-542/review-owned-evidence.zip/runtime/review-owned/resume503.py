from pathlib import Path
import json,hashlib,importlib.util,sys,os
r=Path.cwd();base=r/'artifacts/resource542';root=base/'review-owned';out=root/'resumed-final-blocks';out.mkdir(exist_ok=False)
freeze=(root/'source-final.json').read_bytes();f=json.loads(freeze);plan=json.loads((root/'final-block-plan503.json').read_bytes())
def guard():
 assert (root/'source-final.json').read_bytes()==freeze
 for x in f['Rows']:assert hashlib.sha256((r/x['Path']).read_bytes()).hexdigest().upper()==x['Sha256']
s=importlib.util.spec_from_file_location('owner',r/'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
profiles=[]
for config in ['Debug','Release']:
 seen=set();blocks=[];identity=None
 if config=='Debug':
  for label in ['review503-debug-0','review503-debug-1','review503-debug-port2-outside']:
   v=json.loads((base/label/'result.json').read_bytes());identity=identity or v['Assemblies'];assert v['Assemblies']==identity
   if label=='review503-debug-1':
    failed={x['Name']for x in v['Report']['Tests']if x['Status']!='Passed'};assert failed==set(json.loads((root/'eacces2-names.json').read_bytes()))
    selected={x['Name']for x in v['Report']['Tests']if x['Status']=='Passed'}
   else:
    assert v['Report']['Failed']==0;selected=set(v['Names'])
   assert not seen.intersection(selected);seen|=selected;blocks.append({'Label':label,'PassedNames':sorted(selected),'Assemblies':identity,'RetainedSandboxEacces':label=='review503-debug-1'})
 for i,name in enumerate(plan['Blocks']):
  if config=='Debug'and i<2:continue
  guard();names=json.loads((base/name).read_bytes());assert not seen.intersection(names);label='review503-resumed-'+config.lower()+'-'+str(i)
  m.owned([sys.executable,str(base/'run542.py'),'--label',label,'--names',str(base/name),'--configuration',config],out,label,240,dict(os.environ,DOTNET_GCConserveMemory='9',PYTHONDONTWRITEBYTECODE='1'),str(r))
  v=json.loads((base/label/'result.json').read_bytes());identity=identity or v['Assemblies'];assert v['Assemblies']==identity and v['Report']['Failed']==0 and v['Report']['Passed']==len(names)
  guard();seen.update(names);blocks.append({'Label':label,'PassedNames':names,'Assemblies':identity});print(json.dumps({'Configuration':config,'PassedBlock':len(names),'TotalDistinct':len(seen)}),flush=True)
 assert len(seen)==503 and seen==set(plan['Names']);profiles.append({'Configuration':config,'DistinctPassed':503,'Assemblies':identity,'Blocks':blocks})
guard();(out/'completion.json').write_text(json.dumps({'Passed':True,'Profiles':profiles,'ExplicitComposite':True,'DebugSandbox138PlusOutside2':True,'FailedSandboxReportRetained':True,'SourceFreezeSha256':hashlib.sha256(freeze).hexdigest().upper()},indent=2));print('Final affected Debug503 and Release503 complete explicit composites',flush=True)
