from pathlib import Path
import json,hashlib,importlib.util,os,sys
r=Path.cwd();base=r/'artifacts/resource542';root=base/'review-owned';out=root/'final-composite503';out.mkdir(exist_ok=False)
fbytes=(root/'source-final.json').read_bytes();f=json.loads(fbytes);plan=json.loads((root/'final-block-plan503.json').read_bytes())
def guard():
 assert (root/'source-final.json').read_bytes()==fbytes
 for x in f['Rows']:assert hashlib.sha256((r/x['Path']).read_bytes()).hexdigest().upper()==x['Sha256']
s=importlib.util.spec_from_file_location('owner',r/'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
for i,name in enumerate(plan['Blocks'][2:],2):
 guard();label='review503-finish-release-'+str(i);m.owned([sys.executable,str(base/'run542.py'),'--label',label,'--names',str(base/name),'--configuration','Release'],out,label,240,dict(os.environ,DOTNET_GCConserveMemory='9',PYTHONDONTWRITEBYTECODE='1'),str(r));guard();print(json.dumps({'Configuration':'Release','RemainingBlock':i,'Passed':len(json.loads((base/name).read_bytes()))}),flush=True)
profiles=[]
for config in ['Debug','Release']:
 labels=(['review503-debug-0','review503-debug-1','review503-debug-port2-outside']+['review503-resumed-debug-'+str(i)for i in range(2,7)])if config=='Debug'else(['review503-resumed-release-0','review503-resumed-release-1','review503-release-halt1-isolated']+['review503-finish-release-'+str(i)for i in range(2,7)])
 seen=set();identity=None;receipts=[]
 for label in labels:
  v=json.loads((base/label/'result.json').read_bytes());identity=identity or v['Assemblies'];assert v['Assemblies']==identity and v['Receipt']['Settled'] and not v['Receipt']['TimedOut'];passed={x['Name']for x in v['Report']['Tests']if x['Status']=='Passed'};failed=[x for x in v['Report']['Tests']if x['Status']!='Passed'];assert not seen.intersection(passed);seen|=passed;receipts.append({'Label':label,'PassedNames':sorted(passed),'FailedObservationsRetained':failed,'Receipt':v['Receipt']})
 assert len(seen)==503 and seen==set(plan['Names']);profiles.append({'Configuration':config,'Assemblies':identity,'DistinctPassed':503,'Receipts':receipts})
guard();(out/'completion.json').write_text(json.dumps({'Passed':True,'Profiles':profiles,'ExplicitComposite':True,'DebugPortEaccesOutsideRetry':2,'ReleaseChildOomIsolatedRetry':1,'FailedReportsRetained':True,'NoUninterrupted503Claim':True,'SourceFreezeSha256':hashlib.sha256(fbytes).hexdigest().upper()},indent=2));print('Debug503/503 and Release503/503 explicit current-DLL composites complete; all initial failures retained',flush=True)
