from pathlib import Path
import os, sys, json, importlib.util, hashlib
sys.dont_write_bytecode = True
r = Path.cwd()
out = r / 'artifacts/resource542' / sys.argv[1]
assert not out.exists()
out.mkdir()
freeze_path=r/'artifacts/resource542/review-owned/source-final.json'
freeze_bytes=freeze_path.read_bytes()
freeze=json.loads(freeze_bytes)
for row in freeze['Rows']:
    assert hashlib.sha256((r/row['Path']).read_bytes()).hexdigest().upper()==row['Sha256']
(out/'source-before.json').write_bytes(freeze_bytes)
spec = importlib.util.spec_from_file_location('owner535', r / 'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
cmd = ['dotnet', 'build', 'tests/Erlang.Tests/Erlang.Tests.csproj', '-c', 'Release', '--no-restore', '-m:1', '-p:UseSharedCompilation=false', '-p:BuildInParallel=false', '-v:q']
receipt = m.owned(cmd, out, 'build', 240, dict(os.environ, DOTNET_PROCESSOR_COUNT='1', DOTNET_GCConserveMemory='9'), str(r))
print(json.dumps(receipt))
assert receipt['Settled'] and receipt['ExitCode'] == 0

for row in freeze['Rows']:
    assert hashlib.sha256((r/row['Path']).read_bytes()).hexdigest().upper()==row['Sha256']
assert freeze_path.read_bytes()==freeze_bytes
(out/'source-after.json').write_bytes(freeze_bytes)
