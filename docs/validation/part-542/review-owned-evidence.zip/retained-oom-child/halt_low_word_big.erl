-module(halt_low_word_big).
-export([run/0]).
run()->erlang:halt(18446744073709551663),io:put_chars("CONTINUE\n").
