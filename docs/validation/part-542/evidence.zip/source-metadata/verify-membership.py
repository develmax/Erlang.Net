from pathlib import Path
import json,hashlib,importlib.util,collections
r=Path.cwd();p=r/'tools/Native/Erlang.NifPendingVarargsObservations/reviewed-source-plan.json';spec=importlib.util.spec_from_file_location('pendingfinal530',p.parent/'run-reviewed.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);d=json.loads(p.read_bytes())
actual=m.reviewed_inputs(r,p); declared={x['Path'] for x in d['Files']}; print('MISSING',sorted(actual-declared)); print('EXTRA',sorted(declared-actual)); assert actual==declared
for row in d['Files']:
    data=(r/row['Path']).read_bytes()
    assert row['HashMode'] in ['BinaryExact','TextLF']
    if row['HashMode']=='TextLF':data=data.replace(b'\r\n',b'\n')
    assert hashlib.sha256(data).hexdigest().upper()==row['Sha256'] and len(data)==row['Bytes'],row['Path']
ledger=json.loads((r/'docs/mfa-compatibility.json').read_bytes());proof={'ExactMembers':len(d['Files']),'EveryHashAndLengthVerified':True,'SourceGuards':len(ledger['VerifiedSourceFiles']),'MfaStatuses':dict(collections.Counter(x['Status'] for x in ledger['Entries'])),'WholeContractsClosed':0}
(r/'artifacts/resource542-metadata/final-membership.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
