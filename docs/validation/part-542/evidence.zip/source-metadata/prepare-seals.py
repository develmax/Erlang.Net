from pathlib import Path
import ast,json,hashlib,subprocess
r=Path.cwd();a=r/'artifacts/resource542-metadata';sha=lambda b:hashlib.sha256(b).hexdigest().upper();raw=(r/'docs/validation/part-542/source-freeze.json').read_bytes();assert sha(raw)=='A54537B03A523911167A3BE5C4C400FAD6DC578729018FDE8E60EDC490F11421';f=json.loads(raw);assert len(f['Rows'])==11
for row in f['Rows']:assert sha((r/row['Path']).read_bytes())==row['Sha256'],row['Path']
tool=r/'tools/Runtime/Erlang.BeamFunction542Observations';plan=json.loads((tool/'inputs.json').read_bytes());assert len(plan['Inputs'])==35
for row in plan['Inputs']:assert sha((r/row['Path']).read_bytes())==row['Sha256'],row['Path']
snap=a/'pre-seal-snapshot';assert not snap.exists();snap.mkdir();paths=set()
for folder in [r/'tools/Native',r/'tools/Runtime']:
 for p in folder.rglob('*'):
  if p.is_file() and p.name.lower() in ['source-plan.json','source-plan2.json','reviewed-source-plan.json'] and not {'bin','obj'}.intersection(p.parts):paths.add(p.relative_to(r).as_posix())
paths.update(['tools/Runtime/Erlang.OwnedGuest506Observations/seal.py','tools/Native/Erlang.NifPendingVarargsObservations/run-reviewed.py','tools/Native/Erlang.NifPendingVarargsObservations/seal-source-plan.py','.github/workflows/validate.yml','.github/workflows/nif-pending-native.yml','.github/workflows/nif-reallocation-native.yml','docs/mfa-compatibility.json','docs/module-readiness.json','docs/native-infrastructure.json'])
rows=[]
for name in sorted(paths):
 b=(r/name).read_bytes();p=snap/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);rows.append(dict(Path=name,Sha256=sha(b)))
(snap/'manifest.json').write_text(json.dumps(dict(Files=rows,SourceOnly=True),indent=2)+'\n');(snap/'git-status.txt').write_bytes(subprocess.check_output(['git','status','--porcelain=v1']));(snap/'git-index.txt').write_bytes(subprocess.check_output(['git','diff','--cached','--name-status']))
extra=[x['Path'] for x in f['Rows']]+[p.relative_to(r).as_posix() for folder in [tool,r/'tests/Erlang.Tests/Fixtures/BeamPassive647'] for p in folder.rglob('*') if p.is_file()]+['docs/validation/part-542/source-freeze.json']
p=r/'tools/Runtime/Erlang.OwnedGuest506Observations/seal.py';s=p.read_text();n=next(x for x in ast.parse(s).body if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='DEPENDENCIES' for t in x.targets));known=ast.literal_eval(n.value);ordered=known+sorted(set(extra)-set(known));lines=s.splitlines(keepends=True);lines[n.lineno-1:n.end_lineno]=['DEPENDENCIES = [\n'+''.join('    '+repr(x)+',\n' for x in ordered)+']\n'];p.write_bytes(''.join(lines).encode())
source=r.parent/'w518repair/artifacts/resource541-metadata/reseal-after-main.py';s=source.read_text().replace('resource541-metadata','resource542-metadata').replace('refresh541','refresh542').replace('plans541','plans542').replace('614c8e87e9fa321ef194655cbe190dc8c36db103','7f565b5699df157541817b97172a81f760006cc2').replace("'tools/Runtime/Erlang.MonitorOriginal645Observations/'", "'tools/Runtime/Erlang.MonitorOriginal645Observations/','tools/Runtime/Erlang.BeamFunction542Observations/'")
anchor="extra.add('docs/validation/part-541/source-freeze.json')";assert anchor in s;s=s.replace(anchor,anchor+"\nextra.add('docs/validation/part-542/source-freeze.json')\nextra.update(p.relative_to(r).as_posix() for p in (r/'tests/Erlang.Tests/Fixtures/BeamPassive647').rglob('*') if p.is_file())")
(a/'final-seals542.py').write_text(s,encoding='utf-8',newline='\n');s=(r.parent/'w518repair/artifacts/resource541-metadata/verify-current-membership.py').read_text().replace('resource541-metadata','resource542-metadata');(a/'verify-membership.py').write_text(s,encoding='utf-8',newline='\n');print('Snapshot',len(rows),'metadata files;11C# and35 inputs exact; enrolled new source/tool/genuinefixtures/freeze')
