from pathlib import Path
import hashlib
import importlib.util
import json
import os
import shutil
import sys
from types import SimpleNamespace

sys.dont_write_bytecode = True
repo = Path.cwd()
out = repo / 'artifacts/resource542/original-identical-before-purge'
out.mkdir(parents=True, exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest().upper()

def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result

owned = module('owned647', repo / 'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py')
provider = module('provider647', repo / 'tools/Runtime/Erlang.OwnedGuest506Observations/collect.py')
args = SimpleNamespace(official_admission=repo.parent/'Erlang.Net/artifacts/library376-official-compiler/official-admission.json', admission_sha256='41CCC2FDE5493D85BEAA21996E12D0885D2919B0D4BF44137D0673DCDC9D5EA6', build_receipt=None, otp_source=None)
installed, erl, before, after = provider.provider(args, repo)
(out/'provider-before.json').write_text(json.dumps(before, indent=2))
errors = []
try:
    fixture = repo/'tests/Erlang.Tests/Fixtures/CodePurgerOriginal432'
    manifest = json.loads((fixture/'manifest.json').read_bytes())
    for name in ['subject-v1.beam', 'subject-v2.beam']:
        assert sha(fixture/name) == manifest[name]
        shutil.copyfile(fixture/name, out/name)
    source = repo.parent/'Erlang.Net/artifacts/batch647/function-image-analysis/beam_passive_fun647.erl'
    shutil.copyfile(source, out/source.name)
    inputs = {q.name: sha(q) for q in out.iterdir() if q.suffix in ['.erl','.beam']}
    env = dict(os.environ, ERL_FLAGS='+S 1:1 +A 1', ERL_CRASH_DUMP=str(out/'erl_crash.dump'))
    for name in ['ERL_AFLAGS','ERL_ZFLAGS','ERL_LIBS','ERL_COMPILER_OPTIONS','ERLC_EMULATOR','ERLC_USE_SERVER','ERLC_SERVER_ID','ERLC_CONFIGURATION','ERL_ROOTDIR']:
        env.pop(name, None)
    owned.owned([str(installed/'bin/erlc.exe'), '+debug_info', '-o', str(out), source.name], out, 'compile', 120, env, str(out))
    for mode in ['complete']:
        expression = ('{ok,A}=file:read_file("subject-v1.beam"),{ok,B}=file:read_file("subject-v2.beam"),'
            'Outcome=beam_passive_fun647:'+mode+'(A,A),io:format("~tp~n",[Outcome]),'
            'ok=file:write_file("'+mode+'.etf",term_to_binary(Outcome,[{minor_version,2}])),halt(0).')
        owned.owned([str(erl), '+S', '1:1', '+A', '1', '-noshell', '-noinput', '-boot', 'no_dot_erlang', '-pa', str(out), '-eval', expression], out, mode, 60, env, str(out))
    assert all(sha(out/name) == expected for name, expected in inputs.items())
except Exception as error:
    errors.append(repr(error))
finally:
    current = after()
    (out/'provider-after.json').write_text(json.dumps(dict(Inventory=current, Equal=current==before['Inventory']), indent=2))
    if current != before['Inventory']:
        errors.append('Provider changed')
    (out/'completion.json').write_text(json.dumps(dict(Passed=not errors, Errors=errors, FreshObserverCompilation=True, CachedOriginalSubjectImages=True, Pin='ad05823719d77c8faee87348ea39513d4e2f99c5'), indent=2))
print(json.dumps(dict(Passed=not errors, Errors=errors)))
assert not errors
