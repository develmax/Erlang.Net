using System.Security.Cryptography;
using System.Text.Json;
using Erlang.Differential;
using static Erlang.Tests.BeamPassive647Names;

namespace Erlang.Tests;

internal static class BeamPassive647Checks
{
    internal static async Task Run(string mode)
    {
        string output = Path.GetFullPath(Path.Combine(Output, Guid.NewGuid().ToString("N")));
        Directory.CreateDirectory(output);
        await using var fixture = await CodePurger432Fixture.Create();
        string? worker = Environment.GetEnvironmentVariable(WorkerPath);
        using var compiled = worker is null ? GeneratedModuleCompiler.Compile(Source, FileName) : null;
        string? entryPath = Environment.GetEnvironmentVariable(EntryPath);
        Require(entryPath is null || worker is not null);
        object sourceOwner;
        if (worker is null)
        {
            compiled!.Definition.Register(fixture.Runtime.Modules);
            sourceOwner = compiled.Definition;
        }
        else
        {
            byte[] workerBytes = System.IO.File.ReadAllBytes(worker);
            Require(Convert.ToHexString(SHA256.HashData(workerBytes)) == Environment.GetEnvironmentVariable(WorkerSha)?.ToUpperInvariant());
            var dependencies = new BeamDependencySelection(new[] { RuntimeModule, CodePurger432HostNames.Module, CodePurger432HostNames.Subject, BeamPassive647Names.Module });
            PreparedBeamImage image = fixture.Runtime.Modules.PrepareBeam(workerBytes, dependencies);
            Require(fixture.Runtime.Modules.PublishPreparedBeam(image).Status == BeamPublicationStatus.Published);
            sourceOwner = image;
        }
        Require(ReferenceEquals(fixture.Runtime.Modules.SourceOwner(BeamPassive647Names.Module, mode, 2), sourceOwner));
        if (entryPath is not null)
        {
            byte[] entryBytes = System.IO.File.ReadAllBytes(entryPath);
            Require(Convert.ToHexString(SHA256.HashData(entryBytes)) == Environment.GetEnvironmentVariable(EntrySha)?.ToUpperInvariant());
            var dependencies = new BeamDependencySelection(new[] { RuntimeModule, CodePurger432HostNames.Module,
                CodePurger432HostNames.Subject, BeamPassive647Names.Module, EntryModule });
            PreparedBeamImage entry = fixture.Runtime.Modules.PrepareBeam(entryBytes, dependencies);
            Require(fixture.Runtime.Modules.PublishPreparedBeam(entry).Status == BeamPublicationStatus.Published);
            Require(ReferenceEquals(fixture.Runtime.Modules.SourceOwner(EntryModule, EntryRun, 3), entry));
            Require(ReferenceEquals(fixture.Runtime.Modules.SourceOwner(EntryModule, "worker", 5), entry));
        }
        Term[] subjectArguments = [new BitString(CodePurgerOriginal432Access.Resource(CodePurgerOriginal432Names.FirstBeam)),
            new BitString(CodePurgerOriginal432Access.Resource(CodePurgerOriginal432Names.SecondBeam))];
        Term actual = await fixture.Actor.InvokeAsync(async context => entryPath is null
            ? await fixture.Runtime.Modules.Call(
                context,
                BeamPassive647Names.Module,
                mode,
                subjectArguments
            )
            : await fixture.Runtime.Modules.Call(
                context,
                EntryModule,
                EntryRun,
                Term.A(mode),
                subjectArguments[0],
                subjectArguments[1]
            ));
        var wire = (BitString)await fixture.Actor.InvokeAsync(async context => await fixture.Runtime.Modules.Call(
            context,
            RuntimeModule,
            Encode,
            actual
        ));
        byte[] bytes = wire.ToArray();
        System.IO.File.WriteAllBytes(Path.Combine(output, Raw), bytes);
        bool? wholeStackBytesEqual = null;
        string? actualStackSha256 = null, originalStackSha256 = null;
        if (entryPath is not null)
        {
            Require(actual is TupleTerm { Items: [Atom { Name: WholeMarker }, _, Atom { Name: StackMarker }, _] });
            var envelope = (TupleTerm)actual;
            var stackWire = (BitString)await fixture.Actor.InvokeAsync(async context => await fixture.Runtime.Modules.Call(
                context,
                RuntimeModule,
                Encode,
                envelope.Items[3]
            ));
            byte[] stackBytes = stackWire.ToArray();
            System.IO.File.WriteAllBytes(Path.Combine(output, StackFile), stackBytes);
            string originalFolder = Environment.GetEnvironmentVariable(OriginalFolder)
                ?? throw new InvalidOperationException(Failure);
            byte[] originalStack = System.IO.File.ReadAllBytes(Path.Combine(originalFolder, mode, StackFile));
            System.IO.File.WriteAllBytes(Path.Combine(output, "original-" + StackFile), originalStack);
            actualStackSha256 = Convert.ToHexString(SHA256.HashData(stackBytes));
            originalStackSha256 = Convert.ToHexString(SHA256.HashData(originalStack));
            wholeStackBytesEqual = stackBytes.AsSpan().SequenceEqual(originalStack);
            actual = envelope.Items[1];
        }
        System.IO.File.WriteAllText(
            Path.Combine(output, Receipt),
            JsonSerializer.Serialize(
                new
                {
                    Mode = mode,
                    CallerBackend = entryPath is not null ? "matched-original-BEAM649-spawn-worker" : worker is null ? "generated-source" : "genuine-original-BEAM647",
                    FullStackRawBytesEqual = wholeStackBytesEqual,
                    ActualStackSha256 = actualStackSha256,
                    OriginalStackSha256 = originalStackSha256,
                    WholeOutcomeOpaqueIdsCompared = false,
                    WorkerSha256 = worker is null ? null : Convert.ToHexString(SHA256.HashData(System.IO.File.ReadAllBytes(worker))),
                    CleanupPhase = "not-yet-reached",
                    CleanupClaim = false,
                    SubjectBackend = "genuine-original-BEAM432",
                    RawWholeOutcomeSha256 = Convert.ToHexString(SHA256.HashData(bytes)),
                    FullExceptionStackRetained = true,
                    Normalization = false,
                    RuntimeSha256 = Convert.ToHexString(SHA256.HashData(System.IO.File.ReadAllBytes(typeof(ProcessRuntime).Assembly.Location))),
                    HostSha256 = Convert.ToHexString(SHA256.HashData(System.IO.File.ReadAllBytes(typeof(BeamPassive647Checks).Assembly.Location))),
                    ExpectedContractAssertionPending = true
                },
                new JsonSerializerOptions { WriteIndented = true }
            )
        );
        Require(wholeStackBytesEqual is null or true);
        Require(actual is TupleTerm { Items.Count: 5 });
        var row = (TupleTerm)actual;
        Require(row.Items[0].Equals(Term.Tuple(Term.A(Value), Term.I(1))));
        Require(row.Items[1].Equals(Term.A(ErlangBooleanAtoms.False)));
        Require(row.Items[2].Equals(Term.A(mode == Abort ? ErlangBooleanAtoms.False : ErlangBooleanAtoms.True)));
        Require(row.Items[4].Equals(Term.I(mode == Reload ? 1 : 2)));
        if (mode == Complete)
        {
            Require(row.Items[3] is TupleTerm
            {
                Items: [Atom { Name: BeamPassive647Names.Exception }, Atom { Name: BeamPassive647Names.Error },
                    TupleTerm { Items: [Atom { Name: BeamPassive647Names.BadFun }, FunctionTerm] }, _, Atom { Name: ErlangBooleanAtoms.True }]
            });
        }
        else
            Require(row.Items[3].Equals(Term.Tuple(Term.A(Value), Term.I(1))));
    }

    private static void Require(bool value)
    {
        if (!value) throw new InvalidOperationException(Failure);
    }
}
