namespace Erlang.Tests;

internal static class BeamPassive647Names
{
    internal const string Module = "beam_passive_fun647";
    internal const string FileName = "beam_passive_fun647.erl";
    internal const string Complete = "complete";
    internal const string Abort = "abort";
    internal const string Reload = "reload";
    internal const string CompleteCase = "runtime/fun647/passive-beam-fun-complete-purge-badfun";
    internal const string AbortCase = "runtime/fun647/passive-beam-fun-soft-abort-remains-callable";
    internal const string ReloadCase = "runtime/fun647/passive-beam-fun-identical-reload-rebinds";
    internal const string RuntimeModule = "erlang";
    internal const string Encode = "term_to_binary";
    internal const string Value = "value";
    internal const string Exception = "exception";
    internal const string Error = "error";
    internal const string BadFun = "badfun";
    internal const string Output = "artifacts/passive-fun647";
    internal const string Raw = "actual.etf";
    internal const string Receipt = "receipt.json";
    internal const string Failure = "Passive BEAM closure dispatch differs after purge/abort/identical reload; full raw outcome retained.";
    internal static readonly TimeSpan Deadline = TimeSpan.FromSeconds(15);
    internal const string WorkerPath = "ERLANG_FUN647_WORKER";
    internal const string WorkerSha = "ERLANG_FUN647_WORKER_SHA256";
    internal const string EntryPath = "ERLANG_FUN649_ENTRY";
    internal const string EntrySha = "ERLANG_FUN649_ENTRY_SHA256";
    internal const string OriginalFolder = "ERLANG_FUN649_ORIGINAL_OUTPUT";
    internal const string EntryModule = "beam_passive_entry649";
    internal const string EntryRun = "run";
    internal const string WholeMarker = "whole_outcome";
    internal const string StackMarker = "unchanged_full_stack";
    internal const string StackFile = "stack.etf";
    internal const string Source = """
        -module(beam_passive_fun647).
        -export([complete/2,abort/2,reload/2,capture/1]).
        complete(A,B) ->
         load(A),F=beam_purge_subject432:fun_value(),Before=capture(F),load(B),
         Held=erlang:check_process_code(self(),beam_purge_subject432),
         Purged=erts_code_purger:soft_purge(beam_purge_subject432),
         {Before,Held,Purged,capture(F),beam_purge_subject432:version()}.
        reload(A,B) ->
         load(A),F=beam_purge_subject432:fun_value(),Before=capture(F),load(B),
         Held=erlang:check_process_code(self(),beam_purge_subject432),
         Purged=erts_code_purger:soft_purge(beam_purge_subject432),load(A),
         {Before,Held,Purged,capture(F),beam_purge_subject432:version()}.
        abort(A,B) ->
         load(A),F=beam_purge_subject432:fun_value(),Before=capture(F),
         {P,Ref}=spawn_monitor(beam_purge_subject432,hold,[self()]),
         try
          receive {ready432,P} -> ok after 5000 -> erlang:error(no_ready647) end,
          load(B),Held=erlang:check_process_code(self(),beam_purge_subject432),
          Purged=erts_code_purger:soft_purge(beam_purge_subject432),
          {Before,Held,Purged,capture(F),beam_purge_subject432:version()}
         after
          P!stop432,
          receive {stopped432,P,_} -> ok after 5000 -> exit(P,kill) end,
          receive {'DOWN',Ref,process,P,_} -> ok after 5000 -> exit(P,kill) end
         end.
        capture(F) -> try F() of V -> {value,V} catch C:R:S -> {exception,C,R,S,same_reason_fun(R,F)} end.
        same_reason_fun({badfun,G},F) -> G=:=F;
        same_reason_fun(_,_) -> not_applicable.
        load(Bin) -> {module,beam_purge_subject432}=erlang:load_module(beam_purge_subject432,Bin),ok.
        """;
}
