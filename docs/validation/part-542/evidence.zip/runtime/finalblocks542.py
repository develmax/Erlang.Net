from pathlib import Path
import hashlib
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
repo = Path.cwd()
root = repo / 'artifacts/resource542'
output = root / 'final-blocks'
output.mkdir(exist_ok=False)
spec = importlib.util.spec_from_file_location('owned542blocks', repo / 'tools/Native/Erlang.DdllFormatterOriginalObservations/scripts/owned.py')
owned = importlib.util.module_from_spec(spec)
spec.loader.exec_module(owned)
freeze_bytes = (root / 'final-source-freeze.json').read_bytes()
freeze = json.loads(freeze_bytes)
plan = json.loads((root / 'final-block-plan.json').read_bytes())
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest().upper()

def check_source():
    assert (root / 'final-source-freeze.json').read_bytes() == freeze_bytes
    for row in freeze['Rows']:
        assert digest(repo / row['Path']) == row['Sha256'], row['Path']

profiles = []
for configuration in ['Debug', 'Release']:
    seen, blocks, identity = set(), [], None
    for index, name in enumerate(plan['Blocks']):
        check_source()
        names = json.loads((root / name).read_bytes())
        assert names and not seen.intersection(names)
        seen.update(names)
        label = 'final-' + configuration.lower() + '-' + str(index)
        command = [sys.executable, str(root / 'run542.py'), '--label', label, '--names', str(root / name), '--configuration', configuration]
        owned.owned(command, output, label, 240, dict(os.environ, PYTHONDONTWRITEBYTECODE='1'), str(repo))
        result = json.loads((root / label / 'result.json').read_bytes())
        if identity is None:
            identity = result['Assemblies']
        assert result['Assemblies'] == identity
        check_source()
        blocks.append(dict(Label=label, Names=names, ElapsedSeconds=result['Receipt']['ElapsedSeconds']))
        print(json.dumps(dict(Profile=configuration, Passed=len(names), Cumulative=len(seen))), flush=True)
    assert len(seen) == plan['DistinctCases'] == 500 and seen == set(plan['Names'])
    profiles.append(dict(Configuration=configuration, Assemblies=identity, DistinctCases=len(seen), Blocks=blocks))
check_source()
(output / 'completion.json').write_text(json.dumps(dict(Passed=True, Profiles=profiles,
    ExplicitDisjointComposite=True, Single500Run=False, SourceFreezeSha256=hashlib.sha256(freeze_bytes).hexdigest().upper()), indent=2))
print('Final Debug500/500 and Release500/500 explicit composites', flush=True)
