using System.Security.Cryptography;
using System.Text.Json;
using Erlang.Differential;
using static Erlang.Tests.BeamPassive647Names;

namespace Erlang.Tests;

internal static class BeamPassive647Checks
{
    internal static async Task Run(string mode)
    {
        string output = Path.GetFullPath(Path.Combine(Output, Guid.NewGuid().ToString("N")));
        Directory.CreateDirectory(output);
        await using var fixture = await CodePurger432Fixture.Create();
        string? worker = Environment.GetEnvironmentVariable(WorkerPath);
        using var compiled = worker is null ? GeneratedModuleCompiler.Compile(Source, FileName) : null;
        object sourceOwner;
        if (worker is null)
        {
            compiled!.Definition.Register(fixture.Runtime.Modules);
            sourceOwner = compiled.Definition;
        }
        else
        {
            byte[] workerBytes = System.IO.File.ReadAllBytes(worker);
            Require(Convert.ToHexString(SHA256.HashData(workerBytes)) == Environment.GetEnvironmentVariable(WorkerSha)?.ToUpperInvariant());
            var dependencies = new BeamDependencySelection(new[] { RuntimeModule, CodePurger432HostNames.Module, CodePurger432HostNames.Subject, BeamPassive647Names.Module });
            PreparedBeamImage image = fixture.Runtime.Modules.PrepareBeam(workerBytes, dependencies);
            Require(fixture.Runtime.Modules.PublishPreparedBeam(image).Status == BeamPublicationStatus.Published);
            sourceOwner = image;
        }
        Require(ReferenceEquals(fixture.Runtime.Modules.SourceOwner(BeamPassive647Names.Module, mode, 2), sourceOwner));
        Term actual = await fixture.Actor.InvokeAsync(async context => await fixture.Runtime.Modules.Call(
            context,
            BeamPassive647Names.Module,
            mode,
            new BitString(CodePurgerOriginal432Access.Resource(CodePurgerOriginal432Names.FirstBeam)),
            new BitString(CodePurgerOriginal432Access.Resource(CodePurgerOriginal432Names.SecondBeam))
        ));
        var wire = (BitString)await fixture.Actor.InvokeAsync(async context => await fixture.Runtime.Modules.Call(
            context,
            RuntimeModule,
            Encode,
            actual
        ));
        byte[] bytes = wire.ToArray();
        System.IO.File.WriteAllBytes(Path.Combine(output, Raw), bytes);
        System.IO.File.WriteAllText(
            Path.Combine(output, Receipt),
            JsonSerializer.Serialize(
                new
                {
                    Mode = mode,
                    CallerBackend = worker is null ? "generated-source" : "genuine-original-BEAM647",
                    WorkerSha256 = worker is null ? null : Convert.ToHexString(SHA256.HashData(System.IO.File.ReadAllBytes(worker))),
                    CleanupPhase = "not-yet-reached",
                    CleanupClaim = false,
                    SubjectBackend = "genuine-original-BEAM432",
                    RawWholeOutcomeSha256 = Convert.ToHexString(SHA256.HashData(bytes)),
                    FullExceptionStackRetained = true,
                    Normalization = false,
                    RuntimeSha256 = Convert.ToHexString(SHA256.HashData(System.IO.File.ReadAllBytes(typeof(ProcessRuntime).Assembly.Location))),
                    HostSha256 = Convert.ToHexString(SHA256.HashData(System.IO.File.ReadAllBytes(typeof(BeamPassive647Checks).Assembly.Location))),
                    ExpectedContractAssertionPending = true
                },
                new JsonSerializerOptions { WriteIndented = true }
            )
        );
        Require(actual is TupleTerm { Items.Count: 5 });
        var row = (TupleTerm)actual;
        Require(row.Items[0].Equals(Term.Tuple(Term.A(Value), Term.I(1))));
        Require(row.Items[1].Equals(Term.A(ErlangBooleanAtoms.False)));
        Require(row.Items[2].Equals(Term.A(mode == Abort ? ErlangBooleanAtoms.False : ErlangBooleanAtoms.True)));
        Require(row.Items[4].Equals(Term.I(mode == Reload ? 1 : 2)));
        if (mode == Complete)
        {
            Require(row.Items[3] is TupleTerm
            {
                Items: [Atom { Name: BeamPassive647Names.Exception }, Atom { Name: BeamPassive647Names.Error },
                    TupleTerm { Items: [Atom { Name: BeamPassive647Names.BadFun }, FunctionTerm] }, _, Atom { Name: ErlangBooleanAtoms.True }]
            });
        }
        else
            Require(row.Items[3].Equals(Term.Tuple(Term.A(Value), Term.I(1))));
    }

    private static void Require(bool value)
    {
        if (!value) throw new InvalidOperationException(Failure);
    }
}
