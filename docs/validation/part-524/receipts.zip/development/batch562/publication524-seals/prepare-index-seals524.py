"""Part524: Git-index-only seal/ledger proposal; no apply/build/VM/CI."""
import argparse,ast,hashlib,json,pathlib,re,subprocess
ap=argparse.ArgumentParser();ap.add_argument('--repository',type=pathlib.Path,required=True);ap.add_argument('--output',type=pathlib.Path,required=True);a=ap.parse_args();repo=a.repository.resolve();out=a.output.resolve();here=pathlib.Path(__file__).resolve().parent
require=lambda c,m: None if c else (_ for _ in ()).throw(RuntimeError(m))
sha=lambda b:hashlib.sha256(b).hexdigest().upper()
enc=lambda d:(json.dumps(d,indent=2)+'\n').encode()
require(out.is_relative_to(repo/'artifacts') and not out.exists(),'Fresh contained artifacts output required')
spec=(here/'reviewed-source-paths.json').read_bytes();require(sha(spec)=='88CC63FDA2344CD0F7E7DADC751BE5CA7025255C7CC86F4F432B12284FED7D79','Reviewed25 path list changed');reviewed=json.loads(spec);require(len(reviewed)==len(set(reviewed))==25,'Expected exactly25 distinct reviewed paths')
def git(*args):return subprocess.check_output(['git','-C',str(repo),*args])
objects={}
for item in git('ls-files','--stage','-z').split(b'\0'):
 if not item:continue
 meta,path=item.split(b'\t',1);mode,oid,stage=meta.split();require(stage==b'0','Unmerged index not admitted');objects[path.decode()]=oid
staged=set(git('diff','--cached','--name-only','-z').decode().split('\0'))-{''};require(staged==set(reviewed),'Staged scope differs: '+str({'Missing':sorted(set(reviewed)-staged),'Extra':sorted(staged-set(reviewed))}))
reader=subprocess.Popen(['git','-C',str(repo),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
def index(name):
 require(name in objects,'Missing index input: '+name);reader.stdin.write(objects[name]+b'\n');reader.stdin.flush();h=reader.stdout.readline().split();require(len(h)==3 and h[1]==b'blob','Index blob expected: '+name);n=int(h[2]);b=reader.stdout.read(n);require(len(b)==n and reader.stdout.read(1)==b'\n','Truncated index blob');return b
overlay={};pre={}
def read(name):return overlay[name] if name in overlay else index(name)
def put(name,data):pre.setdefault(name,sha(index(name)));overlay[name]=data
prod=[p for p in reviewed if p.startswith('src/')];tests=[p for p in reviewed if p.startswith('tests/') and p!='tests/Erlang.Tests/Harness/Program.cs'];require(len(prod)==11 and len(tests)==7,'Expected11production/7test targets')
# Static values only: parse existing sealer declarations, never execute a sealer.
def const_value(node,env):
 if isinstance(node,ast.Constant):return node.value
 if isinstance(node,ast.Name):return env[node.id]
 if isinstance(node,(ast.Tuple,ast.List,ast.Set)):
  v=[const_value(x,env) for x in node.elts];return set(v) if isinstance(node,ast.Set) else tuple(v) if isinstance(node,ast.Tuple) else v
 if isinstance(node,ast.BinOp) and isinstance(node.op,ast.Add):return const_value(node.left,env)+const_value(node.right,env)
 if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='frozenset' and len(node.args)==1:return frozenset(const_value(node.args[0],env))
 raise RuntimeError('Nonliteral sealer selector needs review: '+ast.dump(node))
def declaration(name,source,env=None):
 matches=[n.value for n in ast.walk(ast.parse(source)) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets)];require(len(matches)==1,'Expected one sealer declaration: '+name);return const_value(matches[0],env or {})
owned='tools/Runtime/Erlang.OwnedGuest506Observations/';var='tools/Native/Erlang.NifVariadic526Observations/';private='tools/Native/Erlang.NifPrivateData557Observations/'
# Keep actual direct changed Core/test dependencies stable for future reseals.
owned_sealer=owned+'seal.py';b=index(owned_sealer);deps=declaration('DEPENDENCIES',b.decode());extra=[p for p in prod+tests if p not in deps]
if extra:
 nl=b'\r\n' if b'\r\n' in b else b'\n';needle=b'DEPENDENCIES = ['+nl;require(b.count(needle)==1,'Owned sealer insertion guard differs');put(owned_sealer,b.replace(needle,needle+b''.join(('    '+repr(p)+',').encode()+nl for p in extra),1))
# Variadic's native groups already include NIF files. Add missing reviewed
# integer memory/Terms units to its existing explicit production selector only.
var_sealer=var+'seal-source-plan.py';b=index(var_sealer);core=declaration('CORE',b.decode());env={'CORE':core};groups=declaration('source_groups',b.decode(),env);explicit=declaration('MAP_PRODUCTION519',b.decode())
extra=[p for p in prod if p not in explicit and not any(p.startswith(g+'/') for g in groups)]
if extra:
 nl=b'\r\n' if b'\r\n' in b else b'\n';needle=b'MAP_PRODUCTION519 = ('+nl;require(b.count(needle)==1,'Variadic sealer insertion guard differs');put(var_sealer,b.replace(needle,needle+b''.join(('    '+json.dumps(p)+',').encode()+nl for p in extra),1))
changed=set(reviewed)|set(overlay)
# Preserve all original ledger lexical bytes outside8 SHA spans+3 appended src objects.
newsrc_expected={p for p in prod if p.endswith(('BoxedInteger559Names.cs','ProcessTermHeap.Integer559.cs','IOwnedIntegerStorage559.cs'))};require(len(newsrc_expected)==3,'Expected exact3 new source targets')
for name in ['docs/mfa-compatibility.json','docs/module-readiness.json']:
 original=index(name);text=original.decode();data=json.loads(original);marker='"VerifiedSourceFiles": [';require(text.count(marker)==1,'Ambiguous ledger source list');start=text.index(marker)+len(marker);rows,end_offset=json.JSONDecoder().raw_decode(text[start-1:]);end=start-1+end_offset
 require(rows==data['VerifiedSourceFiles'] and len(rows)==1945,'Expected1945 source guards before524: '+name)
 existing={r['Path'] for r in rows};newsrc=[p for p in prod if p not in existing];require(set(newsrc)==newsrc_expected,'Unexpected ledger new source membership')
 segment=text[start:end-1]
 for p in prod:
  if p not in existing:continue
  pattern=r'("Path"\s*:\s*"'+re.escape(p)+r'"\s*,\s*"Sha256"\s*:\s*")([A-Fa-f0-9]{64})(")';segment,count=re.subn(pattern,lambda m:m.group(1)+sha(index(p))+m.group(3),segment);require(count==1,'Missing/duplicate source binding: '+p)
 nl='\r\n' if '\r\n' in segment else '\n';tail=re.search(r'\s*$',segment).group(0);body=segment[:-len(tail)] if tail else segment
 for p in newsrc:body+=','+nl+'    {'+nl+'      "Path": "'+p+'",'+nl+'      "Sha256": "'+sha(index(p))+'"'+nl+'    }'
 result=(text[:start]+body+tail+text[end-1:]).encode();expected=json.loads(original)
 for row in expected['VerifiedSourceFiles']:
  if row['Path'] in prod:row['Sha256']=sha(index(row['Path']))
 expected['VerifiedSourceFiles'] += [{'Path':p,'Sha256':sha(index(p))} for p in newsrc]
 require(json.loads(result)==expected and len(expected['VerifiedSourceFiles'])==1948,'Unauthorized ledger semantic/membership delta');put(name,result)
plans=[owned+'source-plan.json','tools/Native/Erlang.NifPendingVarargsObservations/reviewed-source-plan.json','tools/Native/Erlang.NifReallocationObservations/SOURCE-PLAN.json',var+'source-plan.json',private+'source-plan.json'];oldplans={p:sha(index(p)) for p in plans}
def resolve(row,base):return base+row['Path'] if row.get('Scope')=='Tool' else row['Path']
def hashbytes(data,mode):
 require(mode in ('Raw','BinaryExact','TextLF'),'Unreviewed hash mode: '+str(mode));return data.replace(b'\r\n',b'\n') if mode=='TextLF' else data
def record_matches(row,data):
 data=hashbytes(data,row['HashMode']);return row['Sha256'].upper()==sha(data) and all(row[k]==len(data) for k in ('Bytes','SealedBytes') if k in row)
# All unrelated rows, including index plan/workflow references, fail closed.
bad=[]
for plan in plans:
 d=json.loads(index(plan));base=plan.rsplit('/',1)[0]+'/'
 for row in d.get('Inputs',d.get('Files')):
  p=resolve(row,base)
  if p not in changed and not record_matches(row,index(p)):bad.append({'Plan':plan,'Path':p,'BoundSha256':row['Sha256'],'ActualIndexSha256':sha(hashbytes(index(p),row['HashMode']))})
require(not bad,'Unrelated stale rows require separate review; no output emitted: '+json.dumps(bad))
def refresh(row,base):
 p=resolve(row,base)
 if p not in changed:return
 data=hashbytes(read(p),row['HashMode']);row['Sha256']=sha(data)
 for k in ('Bytes','SealedBytes'):
  if k in row:row[k]=len(data)
def tool_rows(prefix,scope='Tool'):
 return [{'Scope':scope,'Path':p[len(prefix):] if scope=='Tool' else p,'HashMode':'Raw','Sha256':sha(read(p))} for p in sorted(objects) if p.startswith(prefix) and p!=prefix+'source-plan.json']
# Owned exact current sealer selectors, including the new job/fixture/helpers and workflow.
d=json.loads(index(plans[0]));src=read(owned_sealer).decode();deps=declaration('DEPENDENCIES',src);flows=declaration('WORKFLOWS',src);allowed=declaration('allowed_root',src);rows=[]
for p in sorted(objects):
 if not p.startswith(owned) or p==plans[0]:continue
 rel=p[len(owned):];require(rel.split('/')[0] in {'fixtures','golden'} or rel in allowed,'Unlisted Owned tool member: '+p);data=read(p);rows.append({'Scope':'Tool','Path':rel,'HashMode':'Raw','Sha256':sha(data),'Bytes':len(data)})
for p in deps+flows:
 mode='Raw' if pathlib.PurePosixPath(p).suffix in {'.etf','.beam','.cs'} else 'TextLF';data=hashbytes(read(p),mode);rows.append({'Scope':'Repository','Path':p,'HashMode':mode,'Sha256':sha(data),'SealedBytes':len(data)})
d['Inputs']=rows;put(plans[0],enc(d));changed.add(plans[0]);workflow_pins=[]
def pin(workflow,plan):
 b=read(workflow);old=oldplans[plan].encode();require(b.count(old)==1,'Expected exactly one old plan literal: '+workflow);put(workflow,b.replace(old,sha(overlay[plan]).encode()));changed.add(workflow);workflow_pins.append(workflow)
# Manual source policies: existing rows retain modes; add the actual new src/test compilation units.
for plan in plans[1:3]:
 d=json.loads(index(plan));rows=d['Files'];base=plan.rsplit('/',1)[0]+'/'
 for row in rows:refresh(row,base)
 existing={r['Path'] for r in rows}
 for p in prod+tests:
  if p in existing:continue
  mode='BinaryExact' if p.startswith('src/') else 'TextLF';data=hashbytes(read(p),mode);rows.append({'Path':p,'HashMode':mode,'Bytes':len(data),'Sha256':sha(data)})
 put(plan,enc(d));changed.add(plan)
 if plan==plans[1]:pin('.github/workflows/nif-pending-native.yml',plan)
 else:pin('.github/workflows/nif-reallocation-native.yml',plan)
# Variadic rebuild from its real static selectors; no generated plans in suffix groups.
d=json.loads(index(plans[3]));src=read(var_sealer).decode();core=declaration('CORE',src);env={'CORE':core};suffixes=declaration('SOURCE_SUFFIXES',src);excluded=declaration('EXCLUDED_DIRECTORIES',src);groups=declaration('source_groups',src,env);inputs=set(declaration('MAP_PRODUCTION519',src));rows=tool_rows(var)
for p in objects:
 if any(p.startswith(g+'/') for g in groups) and pathlib.PurePosixPath(p).suffix in suffixes and not set(pathlib.PurePosixPath(p).parts)&set(excluded):inputs.add(p)
asset=declaration('NATIVE_ASSET',src,env);adapter=declaration('WINDOWS_ADAPTER_SOURCE',src,env);inputs.update([core+'/Erlang.Runtime.Core.csproj',asset])
for p in sorted(inputs):
 mode='Raw' if pathlib.PurePosixPath(p).suffix=='.cs' or p in (asset,adapter) else 'TextLF';rows.append({'Scope':'Repository','Path':p,'HashMode':mode,'Sha256':sha(hashbytes(read(p),mode))})
d['Inputs']=rows;d['BuildScriptSha256']=sha(read(var+'build-native.py'));put(plans[3],enc(d));changed.add(plans[3])
# Private557 LAST: actual broad source selector, final sealer/helper/workflow bytes.
d=json.loads(index(plans[4]));src=read(private+'seal.py').decode();groups=declaration('groups',src);suffixes=declaration('SUFFIX',src);excluded=declaration('EXCLUDE',src);inputs=set();rows=tool_rows(private)
for p in objects:
 if any(p.startswith(g+'/') for g in groups) and pathlib.PurePosixPath(p).suffix in suffixes and not set(pathlib.PurePosixPath(p).parts)&set(excluded):inputs.add(p)
inputs.update('tools/Validation/Erlang.Differential/'+n for n in ['GeneratedModuleCompiler.cs','GeneratedModuleArtifact.cs','GeneratedModuleReferences.cs','GeneratedModuleMetadata.cs','OracleDiagnostics.cs'])
inputs.update(['.github/workflows/validate.yml','.gitattributes','Directory.Build.props','global.json','src/Runtime/Erlang.Runtime.Core/runtimes/win-x64/native/Erlang.Nif.WindowsVariadic.dll',var+'build-native.py',var_sealer])
for p in sorted(inputs):
 mode='Raw' if pathlib.PurePosixPath(p).suffix in {'.cs','.dll'} else 'TextLF';rows.append({'Scope':'Repository','Path':p,'HashMode':mode,'Sha256':sha(hashbytes(read(p),mode))})
require(not any(p in inputs for p in plans),'Generated plan dependency cycle refused')
d['Inputs']=rows;d['NativeSourceSha256']=sha(read(private+'fixtures/load_private557.c'));d['ErlangSourceSha256']=sha(read(private+'fixtures/load_private557.erl'));d['BuildScriptSha256']=sha(read(private+'build-native.py'));put(plans[4],enc(d));changed.add(plans[4])
# Strict final closure validates all proposed row sizes/hashes after workflow changes.
for plan in plans:
 d=json.loads(overlay[plan]);base=plan.rsplit('/',1)[0]+'/'
 for row in d.get('Inputs',d.get('Files')):require(record_matches(row,read(resolve(row,base))),'Final closure mismatch: '+plan+' -> '+resolve(row,base))
# No additional workflow literal or late-cycle updates are silently allowed.
for p in objects:
 if p.startswith('.github/workflows/'):
  for plan,old in oldplans.items():require(old.encode() not in read(p),'Unrefreshed literal old plan hash: '+p+' -> '+plan)
out.mkdir(parents=True);emitted=[]
for p,b in overlay.items():
 q=out/'staged-tree'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);emitted.append({'Path':p,'IndexPreimageSha256':pre[p],'ProposedSha256':sha(b),'Bytes':len(b)})
receipt={'SourceOnly':True,'Applied':False,'InputAuthority':'Frozen Git index object IDs only; no worktree source reads','Head':git('rev-parse','HEAD').decode().strip(),'ReviewedPathsSha256':sha(spec),'ReviewedPaths':reviewed,'ReviewedIndexObjects':{p:objects[p].decode() for p in reviewed},'LedgerDelta':{'Before':1945,'After':1948,'ExistingHashSpans':8,'NewSourceRows':3,'StatusesScopesAndCountsChanged':False},'PlanInputs':{p:len(json.loads(overlay[p]).get('Inputs',json.loads(overlay[p]).get('Files'))) for p in plans},'PlanHashes':{p:sha(overlay[p]) for p in plans},'WorkflowPins':workflow_pins,'Files':emitted,'HistoricalReceiptsChanged':False,'PhantomNativeFixtureChangesIncluded':False}
(out/'proposal.json').write_bytes(enc(receipt));reader.stdin.close();reader.stdout.close();reader.wait();print(json.dumps(receipt,indent=2))
