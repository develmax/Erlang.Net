internal static class GenStatemBeamReflectionNames
{
    internal const string PreparationDecodeOptions = "PreparationDecodeOptions";
    internal const string Read = "Read";
    internal const string Atoms = "Atoms";
    internal const string Imports = "Imports";
    internal const string ModuleAtomIndex = "ModuleAtomIndex";
    internal const string StructureReader = "Erlang.BeamStructureReader";
}
