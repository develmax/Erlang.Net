# Identical BEAM republish / native closure target review

Source-only; no code or fixture edits, builds, VM or CI execution. Exact OTP29.1.1 ad05823719d77c8faee87348ea39513d4e2f99c5 sources exported here with read-only git show.

Finding: NifBeamEntryHostChecks.ClosuresAndGenerations line271 expects old captured closure=>old mock Bound and fresh closure=>new mock Replacement after publishing the EXACT SAME byte[] twice. This expectation contradicts pinned OTP fun dispatch. Keep the regression, but its identical-byte case should require Replacement for BOTH and real context.ExecutingSourceImage equal the selected second image in the replacement callback. It must not be changed into merely any-success or remove old-image assertions generally.

Exact pinned chain:
- erl_fun.c79-85 compares module, lambda index, arity and full uniq bytes. Refcount/original code image/NIF owner are NOT part of the lookup key.
- erl_fun.c287-296 passes identity to fun_staged_upsert; same identity reuses staged entry.
- emu_load.c645-650 supplies module, checksum, lambda index and user arity;666-668 overwrites that entry's STAGING dispatch address with the NEW code label. Identical bytes have identical checksum and identity. JIT asm_load.c1218/1238 performs the same operations.
- beam_common.c1626-1627 call_fun obtains active_code_ix and reads funp->entry.disp->addresses[code_ix]; environment is then copied from the particular fun. The entrypoint is not retained from the capturing generation.
- erl_nif.c4860 selects codeinfo from this_mi->code_hdr;5006 invokes patch_call_nif_early(entry,this_mi), whose body patches that image's entry instructions. Therefore when shared fun entry selects NEW code, a NIF patched at that new entry is the new image's NIF. No reverse lookup back to the capturing image is made.

The fixture directly installs a managed test table by reflection rather than executing real NIF load/upgrade. That is suitable as a runtime entry-routing unit fixture but cannot override the shared OTP fun-entry rule. A real first-loaded/second-upgraded NIF fixture additionally needs a valid upgrade callback and admission; the direct Bind is not such an upgrade proof. Code publication/identity mapping and NIF API upgrade support are separate assertions.

Preserve distinct-code generation coverage: add another scenario using genuinely different BEAM checksums but the same module and function shape. For example compile alternate make(N)->fun(X)->N+X+1 end (not +0 which optimizer can remove), retain the first closure and bind both image tables. Require old=>old Bound and new=>new Replacement, actual context image exact for each. Keep original per-image table retirement and owner Calls assertions. Do not use a new module name, fake fingerprint, or changed debug-only chunk in lieu of proving different code checksum. Verify descriptor fingerprints differ.

Standalone host-only BeamModule route is deliberately unadmitted in BeamClosureFactory and does not exercise runtime shared entries. Preserve its isolation and exact standalone table checks separately. Already-running old function invocations retain their execution/image lease; that fact does not imply a later captured-fun call must choose its capture generation when identities are equal.

Required empirical follow-up: genuine original OTP observer loading identical bytes twice and calling saved/fresh local fun (with real NIF upgrade if testing native tables), complete raw outcomes/stacks; plus distinct-checksum observer. The source conclusion here is exact, but these execution receipts have not been produced by this author. No full API compatibility credit.
