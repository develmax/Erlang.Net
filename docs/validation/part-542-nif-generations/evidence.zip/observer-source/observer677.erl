-module(observer677).
-export([run/5]).
run(Mode,First,Second,A,B) ->
    {ok,OldBytes}=file:read_file(First),
    {ok,NewBytes}=file:read_file(Second),
    {ok,{nif_fun_dispatch677,OldMd5}}=beam_lib:md5(First),
    {ok,{nif_fun_dispatch677,NewMd5}}=beam_lib:md5(Second),
    ExpectedSame=(Mode=:=same),
    ExpectedSame=(OldBytes=:=NewBytes),
    ExpectedSame=(OldMd5=:=NewMd5),
    {module,nif_fun_dispatch677}=code:load_binary(nif_fun_dispatch677,First,OldBytes),
    OldMd5=nif_fun_dispatch677:module_info(md5),
    original_code=nif_fun_dispatch677:marker(),
    ok=nif_fun_dispatch677:load(A),
    Old=nif_fun_dispatch677:make(),
    42=Old(),
    {module,nif_fun_dispatch677}=code:load_binary(nif_fun_dispatch677,Second,NewBytes),
    NewMd5=nif_fun_dispatch677:module_info(md5),
    ok=nif_fun_dispatch677:load(B),
    Fresh=nif_fun_dispatch677:make(),
    {Mode,{old,observe(Old)},{fresh,observe(Fresh)},
     {same_fun,Old=:=Fresh},{same_beam,OldBytes=:=NewBytes},
     {same_checksum,OldMd5=:=NewMd5},{marker,nif_fun_dispatch677:marker()}}.
observe(F) ->
    try {value,F()}
    catch C:R:S -> {raised,C,R,S}
    end.
