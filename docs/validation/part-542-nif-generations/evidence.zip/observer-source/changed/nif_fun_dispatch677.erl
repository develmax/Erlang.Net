-module(nif_fun_dispatch677).
-export([load/1,identity/0,make/0,marker/0]).
-nifs([identity/0]).
load(Path) -> erlang:load_nif(Path, 0).
identity() -> erlang:nif_error(not_loaded).
make() -> fun identity/0.
marker() -> changed_code.
