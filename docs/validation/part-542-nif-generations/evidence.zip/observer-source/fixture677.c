#include "erl_nif.h"
#include <stdint.h>
#ifndef GENERATION677
#error GENERATION677 must be 42 or 43
#endif
static int load677(ErlNifEnv *env, void **priv, ERL_NIF_TERM info)
{ (void)env; (void)info; *priv=(void*)(uintptr_t)GENERATION677; return 0; }
static int upgrade677(ErlNifEnv *env, void **priv, void **old, ERL_NIF_TERM info)
{
    (void)env; (void)info;
    if (!old || *old!=(void*)(uintptr_t)42) return 17;
    *priv=(void*)(uintptr_t)GENERATION677;
    return 0;
}
static void unload677(ErlNifEnv *env, void *priv)
{ (void)env; (void)priv; }
static ERL_NIF_TERM identity677(ErlNifEnv *env,int argc,const ERL_NIF_TERM argv[])
{ (void)argc; (void)argv; return enif_make_int(env,(int)(uintptr_t)enif_priv_data(env)); }
static ErlNifFunc funcs677[] = {{"identity",0,identity677,0}};
ERL_NIF_INIT(nif_fun_dispatch677,funcs677,load677,NULL,upgrade677,unload677)
