"""SOURCE-ONLY PROPOSAL: bounded original OTP Windows observer; no managed bindings."""
import argparse,hashlib,importlib.util,json,os,re,shutil,subprocess,sys
from pathlib import Path

def load(n,p):
    s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m

def main():
    p=argparse.ArgumentParser()
    for n in ['repository','official-admission','output']:p.add_argument('--'+n,type=Path,required=True)
    for n in ['admission-sha256','proposal-manifest-sha256']:p.add_argument('--'+n,required=True)
    a=p.parse_args();repo=a.repository.resolve();proposal=Path(__file__).resolve().parent
    need=lambda x,t: x or (_ for _ in ()).throw(RuntimeError(t))
    sha=lambda q:hashlib.sha256(Path(q).read_bytes()).hexdigest().upper()
    need(os.name=='nt' and sys.maxsize>2**32,'Windows x64 only')
    manifest=proposal/'source-manifest.json';need(sha(manifest)==a.proposal_manifest_sha256.upper(),'Unreviewed proposal')
    plan=json.loads(manifest.read_bytes())
    for row in plan['Files']:need(sha(proposal/row['Path'])==row['Sha256'],'Proposal changed '+row['Path'])
    for row in plan['Helpers']:need(sha(repo/row['Path'])==row['Sha256'],'Helper changed '+row['Path'])
    c=load('dispatch677_common',repo/'tools/Native/Erlang.NifVersion651Observations/common.py')
    provider=c.load('dispatch677_provider',repo/c.PROVIDER);owned=c.load('dispatch677_owned',repo/c.OWNED)
    decoder=c.load('dispatch677_etf',repo/'tools/Distribution/Erlang.GuestConnectedSendObservations/passive_etf.py')
    out=a.output.resolve();need(out.is_relative_to(repo/'artifacts') and not out.exists(),'Fresh confined output required');out.mkdir(parents=True)
    a.build_receipt=a.otp_source=None;errors=[];after=None;sealed=None;before=None;rows=[]
    try:
        installed,erl,before,after=provider.provider(a,repo);c.save(out/'provider-before.json',before)
        need(all(ord(ch)<128 for ch in str(out)+str(installed)),'ASCII path protocol required')
        headers=out/'headers';headers.mkdir();recipe=json.loads((repo/'tools/Native/Erlang.NifFixtureHost/native/source-plan.json').read_bytes())
        for h in recipe['Headers']:
            if not h['OutputName'].endswith('.in'):shutil.copyfile(c.checked(installed/'usr/include'/h['OutputName'],h['Sha256']),headers/h['OutputName'])
        shutil.copyfile(installed/'usr/include/erl_int_sizes_config.h',headers/'erl_int_sizes_config.h')
        sizes=(headers/'erl_int_sizes_config.h').read_text()
        for name,value in recipe['GeneratedSizes'].items():need(re.search(r'^#define\s+'+name+r'\s+'+str(value)+r'\s*$',sizes,re.M),'Wrong LLP64 '+name)
        vs=Path(os.environ.get('ProgramFiles(x86)','C:/Program Files (x86)'))/'Microsoft Visual Studio/Installer/vswhere.exe'
        installation=subprocess.check_output([str(vs),'-latest','-products','*','-requires','Microsoft.VisualStudio.Component.VC.Tools.x86.x64','-property','installationPath'],text=True,timeout=30).strip()
        setup=Path(installation)/'VC/Auxiliary/Build/vcvars64.bat';need(setup.is_file() and not any(v in str(setup) for v in ['"','%','\r','\n']),'Invalid vcvars')
        env=c.environment();configured=subprocess.run('cmd.exe /d /s /c ""'+str(setup)+'" >nul && set"',capture_output=True,timeout=60)
        (out/'vcvars.stdout').write_bytes(configured.stdout);(out/'vcvars.stderr').write_bytes(configured.stderr);need(configured.returncode==0,'vcvars failed')
        for line in configured.stdout.decode('mbcs').splitlines():
            if '=' in line and not line.startswith('='):
                k,v=line.split('=',1);env[k.upper()]=v
        tools={n:shutil.which(n,path=env.get('PATH')) for n in ['cl.exe','link.exe','dumpbin.exe']};need(all(tools.values()),'VC tools missing')
        sealed=c.snapshot([manifest,*[proposal/r['Path'] for r in plan['Files']],*[repo/r['Path'] for r in plan['Helpers']],a.official_admission,setup,*headers.iterdir(),*[Path(v) for v in tools.values()]])
        c.save(out/'sealed-inputs.json',sealed)
        def stage(argv,d,name,t=120):return c.stage(owned,argv,d,name,env,t)
        libs={};beams={}
        for generation in [42,43]:
            d=out/('native'+str(generation));d.mkdir()
            try:
                shutil.copyfile(proposal/'fixture677.c',d/'fixture.c')
                stage([tools['cl.exe'],'/nologo','/std:c11','/W4','/WX','/O2','/MD','/utf-8','/I'+str(headers),'/DGENERATION677='+str(generation),'/c','fixture.c','/Fofixture.obj'],d,'compile')
                lib=d/('native'+str(generation)+'.dll')
                stage([tools['link.exe'],'/NOLOGO','/DLL','/MACHINE:X64','/Brepro','/OUT:'+lib.name,'fixture.obj'],d,'link')
                stage([tools['dumpbin.exe'],'/nologo','/exports',lib],d,'exports')
                exports=re.findall(r'^\s+\d+\s+[0-9A-Fa-f]+\s+[0-9A-Fa-f]+\s+(\S+)\s*$',(d/'exports.stdout.log').read_text(encoding='mbcs'),re.M)
                need(exports==['nif_init'],'Unexpected exports');libs[generation]=lib
            except Exception as e:errors.append(dict(Phase='native',Generation=generation,Error=repr(e)))
        for mode in ['same','changed']:
            d=out/('beam-'+mode);d.mkdir()
            try:
                shutil.copyfile(proposal/mode/'nif_fun_dispatch677.erl',d/'nif_fun_dispatch677.erl')
                shutil.copyfile(proposal/'observer677.erl',d/'observer677.erl')
                stage([installed/'bin/erlc.exe','+debug_info','-o',d,'nif_fun_dispatch677.erl','observer677.erl'],d,'compile')
                beams[mode]=d
            except Exception as e:errors.append(dict(Phase='beam',Mode=mode,Error=repr(e)))
        for mode in ['same','changed']:
            d=out/('capture-'+mode);d.mkdir();failure=None
            try:
                need(set(libs)=={42,43} and 'same' in beams and mode in beams,'Missing actual preparation')
                estr=c.estr;first=beams['same']/'nif_fun_dispatch677.beam';second=beams[mode]/'nif_fun_dispatch677.beam'
                expr=('Root=filename:absname('+estr(installed)+'),Root=filename:absname(code:root_dir()),'
                    'Parent=self(),{P,M}=spawn_monitor(fun()->R=try observer677:run('+mode+','+estr(first)+','+estr(second)+','+estr(libs[42].with_suffix(''))+','+estr(libs[43].with_suffix(''))+') catch C:E:S->{setup_raised,C,E,S} end,Parent!{observation,R} end),'
                    'receive {observation,V}->ok=file:write_file("observed.etf",term_to_binary(V,[{minor_version,2}])) after 30000->erlang:error(observation_timeout) end,'
                    "receive {'DOWN',M,process,P,normal}->ok;{'DOWN',M,process,P,X}->erlang:error({worker_exit,X}) after 30000->erlang:error(down_timeout) end,"
                    'ok=file:write_file("cleanup.etf",term_to_binary({child_normal,not is_process_alive(P)},[{minor_version,2}])),halt(0).')
                (d/'invocation.eval').write_text(expr);env['ERL_CRASH_DUMP']=str(d/'erl_crash.dump')
                stage([erl,'+S','1:1','+A','1','-noshell','-noinput','-boot','no_dot_erlang','-pa',beams['same'],'-eval',expr],d,'observe',120)
                A=lambda x:('atom',x);I=lambda x:('integer',x);T=lambda *x:('tuple',tuple(x))
                expected=T(A(mode),T(A('old'),T(A('value'),I(43 if mode=='same' else 42))),T(A('fresh'),T(A('value'),I(43))),T(A('same_fun'),A('true' if mode=='same' else 'false')),T(A('same_beam'),A('true' if mode=='same' else 'false')),T(A('same_checksum'),A('true' if mode=='same' else 'false')),T(A('marker'),A('original_code' if mode=='same' else 'changed_code')))
                need(decoder.decode_exact((d/'observed.etf').read_bytes())==expected,'Whole original outcome differs')
                need(decoder.decode_exact((d/'cleanup.etf').read_bytes())==T(A('child_normal'),A('true')),'Worker cleanup differs')
            except Exception as e:failure=repr(e);errors.append(dict(Phase='observe',Mode=mode,Error=failure))
            row=dict(Mode=mode,Passed=failure is None,Error=failure);rows.append(row);c.save(d/'completion.json',row)
    except Exception as e:errors.append(dict(Phase='prepare',Error=repr(e)))
    finally:
        try:
            if sealed is not None:c.verify_rows(sealed)
            if after is not None:
                current=after();c.save(out/'provider-after.json',current);need(current==before['Inventory'],'Provider changed')
        except Exception as e:errors.append(dict(Phase='after',Error=repr(e)))
    c.save(out/'completion.json',dict(Passed=len(rows)==2 and all(r['Passed'] for r in rows) and not errors,Pin=c.PIN,OriginalOnly=True,ActualNifCallbacks=True,Rows=rows,Errors=errors,ManagedExecution=False,ApiDelta=0,FullContractDelta=0))
    return 0 if len(rows)==2 and all(r['Passed'] for r in rows) and not errors else 1
if __name__=='__main__':raise SystemExit(main())
