namespace Erlang;

internal static class ErlangClockSourceLocation
{
    internal static readonly Term Convert = Term.List(
        Term.Tuple(Term.A(ErlangSourceLocationNames.File), Term.String("erlang.erl")),
        Term.Tuple(Term.A(ErlangSourceLocationNames.Line), Term.I(13495))
    );
    internal static readonly MapTerm ErrorInfo = new([
        new KeyValuePair<Term, Term>(Term.A("module"), Term.A("erl_erts_errors"))]);
}
