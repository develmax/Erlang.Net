// Derived from lib/stdlib/src/timer.erl, Erlang/OTP 29.1.1, Apache-2.0.
// Copyright Ericsson AB 1996-2025. Original notices remain in the retained source.
using static Erlang.TimerLibraryNames;

namespace Erlang;

/// <summary>The explicitly selected C# implementation of the pinned timer library.</summary>
public static partial class TimerLibrary
{
    public const string Name = Module;

    public static IReadOnlyList<(string Name, int Arity)> Exports { get; } = Array.AsReadOnly(new (string, int)[]
    {
        ("apply_after", 2), ("apply_after", 3), ("apply_after", 4),
        ("send_after", 2), ("send_after", 3), ("exit_after", 2), ("exit_after", 3),
        ("kill_after", 1), ("kill_after", 2),
        (Interval, 2), (Interval, 3), (Interval, 4),
        (Repeatedly, 2), (Repeatedly, 3), (Repeatedly, 4),
        ("send_interval", 2), ("send_interval", 3), ("cancel", 1), ("sleep", 1),
        ("tc", 1), ("tc", 2), ("tc", 3), ("tc", 4), ("now_diff", 2),
        ("seconds", 1), ("minutes", 1), ("hours", 1), ("hms", 3),
        ("start", 0), ("start_link", 0), ("init", 1), ("handle_call", 3),
        ("handle_info", 2), ("handle_cast", 2), ("terminate", 2), ("code_change", 3)
    });

    public static void Register(ModuleRegistry registry)
        => registry.InstallPreloaded(target =>
        {
            foreach (var export in Exports)
            {
                string function = export.Name;
                target.RegisterReviewedManagedLibrary789(
                    Module,
                    function,
                    export.Arity,
                    (context, arguments) => Invoke(context, function, arguments)
                );
            }
        });

    public static async ValueTask<Term> Invoke(ProcessContext context, string function, IReadOnlyList<Term> arguments)
    {
        if (!Exports.Contains((function, arguments.Count)))
        {
            throw new ErlangException(ErlangErrorReasons.UndefinedFunction);
        }
        using var tail = context.EnterSourceTailCall(Module, function);
        Term a = arguments.Count == 0 ? Nil.Value : arguments[0];
        switch (function)
        {
            case "apply_after":
            case Interval:
            case Repeatedly:
                return await Apply(context, function, arguments);
            case "send_after":
            case "send_interval":
                return await Send(
                    context,
                    function,
                    a,
                    arguments.Count == 2 ? context.Self : arguments[1],
                    arguments[^1]
                );
            case "exit_after":
            case "kill_after":
                {
                    bool kill = function == "kill_after";
                    Term target = arguments.Count == (kill ? 1 : 2) ? context.Self : arguments[1];

                    return await Apply(context, "apply_after", [a, Term.A("erlang"), Term.A("exit"),
                    Term.List(target, kill ? Term.A("kill") : arguments[^1])]);
                }
            case "cancel":
                if (a is TupleTerm { Items.Count: 2 } reference && reference.Items[1] is ReferenceTerm)
                {
                    switch (reference.Items[0])
                    {
                        case Atom { Name: "instant" }:
                            return Cancelled;
                        case Atom { Name: "send_local" }:
                            _ = await Bif(context, "cancel_timer", reference.Items[1]);

                            return Cancelled;
                        case Atom { Name: "once" or "interval" }:
                            return await Request(context, "cancel", a);
                    }
                }

                return BadArgument;
            case "sleep":
                while (a is Integer time && time.Value > MaximumReceive)
                {
                    await context.ReceiveErlangAsync<Term>(_ => null, Term.I(MaximumReceive));
                    a = new Integer(time.Value - MaximumReceive);
                }
                await TimerSource.Run(
                    context,
                    "sleep",
                    1,
                    552,
                    async () =>
                {
                    await context.ReceiveErlangAsync<Term>(_ => null, a);

                    return Ok;
                }
                );

                return Ok;
            case "tc":
                return await TimeCall(context, arguments);
            case "seconds":
                return await Multiply(
                    context,
                    "seconds",
                    a,
                    MillisecondsPerSecond,
                    687
                );
            case "minutes":
                return await Multiply(
                    context,
                    "minutes",
                    a,
                    MillisecondsPerSecond * SecondsPerMinute,
                    694
                );
            case "hours":
                return await Multiply(
                    context,
                    "hours",
                    a,
                    MillisecondsPerSecond * SecondsPerMinute * SecondsPerMinute,
                    701
                );
            case "hms":
                return await TimerSource.Run(
                    context,
                    "hms",
                    3,
                    710,
                    async () =>
                {
                    Term hours = await Multiply(
                        context,
                        "hours",
                        a,
                        MillisecondsPerSecond * SecondsPerMinute * SecondsPerMinute,
                        701
                    );
                    Term minutes = await Multiply(
                        context,
                        "minutes",
                        arguments[1],
                        MillisecondsPerSecond * SecondsPerMinute,
                        694
                    );
                    Term sum = await Bif(
                        context,
                        "+",
                        hours,
                        minutes
                    );
                    Term seconds = await Multiply(
                        context,
                        "seconds",
                        arguments[2],
                        MillisecondsPerSecond,
                        687
                    );

                    return await Bif(
                        context,
                        "+",
                        sum,
                        seconds
                    );
                }
                );
            case "now_diff":
                if (a is TupleTerm { Items.Count: 3 } later && arguments[1] is TupleTerm { Items.Count: 3 } earlier)
                {
                    return await TimerSource.Run(
                        context,
                        "now_diff",
                        2,
                        677,
                        async () =>
                    {
                        Term delta = await Bif(
                            context,
                            "-",
                            later.Items[0],
                            earlier.Items[0]
                        );
                        Term major = await Bif(
                            context,
                            "*",
                            delta,
                            Term.I(MicrosecondsPerSecond)
                        );
                        Term middle = await Bif(
                            context,
                            "+",
                            major,
                            later.Items[1]
                        );
                        middle = await Bif(
                            context,
                            "-",
                            middle,
                            earlier.Items[1]
                        );
                        Term micros = await Bif(
                            context,
                            "*",
                            middle,
                            Term.I(MicrosecondsPerSecond)
                        );
                        micros = await Bif(
                            context,
                            "+",
                            micros,
                            later.Items[2]
                        );

                        return await Bif(
                            context,
                            "-",
                            micros,
                            earlier.Items[2]
                        );
                    }
                    );
                }

                throw TimerSource.Clause(
                    context,
                    function,
                    arguments,
                    676
                );
            case "start":
                {
                    Term started = await Start(context);
                    RequireOk(started);

                    return Ok;
                }
            case "start_link":
                return await Call(
                    context,
                    "gen_server",
                    "start_link",
                    Term.Tuple(Term.A("local"), Term.A(Server)),
                    Term.A(Module),
                    Nil.Value,
                    Nil.Value
                );
            default:
                return await Callback(context, function, arguments);
        }
    }

    private static ValueTask<Term> Multiply(
        ProcessContext context,
        string function,
        Term value,
        int factor,
        int line
    )
        => TimerSource.Run(
            context,
            function,
            1,
            line,
            () => Bif(
                context,
                "*",
                value,
                Term.I(factor)
            )
        );

    private static bool IsList(Term value) => value is Cons or Nil;

    private static bool ProperLength(Term value, out int count)
    {
        count = 0;
        while (value is Cons cell)
        {
            count++;
            value = cell.Tail;
        }

        return value is Nil;
    }

    private static bool IsDestination(Term value)
        => value is Pid or Atom || value is TupleTerm { Items.Count: 2 } tuple && tuple.Items.All(item => item is Atom);

    private static bool IsTime(Term value) => value is Integer time && time.Value >= 0;

    private static ValueTask<Term> Call(
        ProcessContext context,
        string module,
        string function,
        params Term[] arguments
    )
        => context.Runtime.Modules.Call(
            context,
            module,
            function,
            arguments
        );

    private static ValueTask<Term> Bif(ProcessContext context, string function, params Term[] arguments)
        => Call(
            context,
            "erlang",
            function,
            arguments
        );

    private static async ValueTask<Term> Apply(ProcessContext context, string operation, IReadOnlyList<Term> arguments)
    {
        Term time = arguments[0];
        Term module;
        Term function;
        Term args;
        if (arguments.Count < 4)
        {
            args = arguments.Count == 2 ? Nil.Value : arguments[2];
            if (!ProperLength(args, out int length) || arguments[1] is not FunctionTerm callback || callback.Arity != length)
            {
                return BadArgument;
            }
            module = Term.A("erlang");
            function = Term.A("apply");
            args = Term.List(callback, args);
        }
        else
        {
            module = arguments[1];
            function = arguments[2];
            args = arguments[3];
            if (module is not Atom || function is not Atom || !IsList(args))
            {
                return BadArgument;
            }
        }
        if (!IsTime(time))
        {
            return BadArgument;
        }
        Term mfa = Term.Tuple(module, function, args);
        if (operation == "apply_after" && time is Integer instant && instant.Value.IsZero)
        {
            _ = await DoApply(context, mfa, false);

            return Term.Tuple(Ok, Term.Tuple(Term.A("instant"), await Bif(context, "make_ref")));
        }
        Term started = await Clock(context);

        return operation == "apply_after"
            ? await Request(context, Once, Term.Tuple(started, time, mfa))
            : await Request(context, operation, Term.Tuple(
                started,
                time,
                context.Self,
                mfa
            ));
    }

    private static async ValueTask<Term> Send(
        ProcessContext context,
        string operation,
        Term time,
        Term target,
        Term message
    )
    {
        if (!IsDestination(target))
        {
            return BadArgument;
        }
        if (operation == "send_after")
        {
            if (time is Integer instant && instant.Value.IsZero)
            {
                _ = await Bif(
                    context,
                    "send",
                    target,
                    message
                );

                return Term.Tuple(Ok, Term.Tuple(Term.A("instant"), await Bif(context, "make_ref")));
            }
            if (IsTime(time) && target is Pid && (await Bif(context, "node", target)).Equals(await Bif(context, "node")))
            {
                return Term.Tuple(Ok, Term.Tuple(Term.A("send_local"), await Bif(
                    context,
                    "send_after",
                    time,
                    target,
                    message
                )));
            }

            return await Apply(context, "apply_after", [time, Term.A(Module), Term.A("send"), Term.List(target, message)]);
        }
        if (!IsTime(time))
        {
            return BadArgument;
        }

        return await Request(
            context,
            Interval,
            Term.Tuple(
                await Clock(context),
                time,
                target,
                Term.Tuple(Term.A(Module), Term.A("send"), Term.List(target, message))
            )
        );
    }

    private static async ValueTask<Term> TimeCall(ProcessContext context, IReadOnlyList<Term> arguments)
    {
        int count = arguments.Count;
        bool listSecond = count == 2 && IsList(arguments[1]);
        bool listThird = count == 3 && IsList(arguments[2]);
        Term unit = count == 1 || listSecond || listThird ? Term.A("microsecond") : arguments[^1];
        Term before = await Bif(context, "monotonic_time");
        Term result;
        int sourceArity = count == 1 || count == 2 && !listSecond ? 2 : count == 2 || count == 3 && !listThird ? 3 : 4;
        int callLine = sourceArity == 2 ? 599 : sourceArity == 3 ? 633 : 658;
        result = await TimerSource.Run(
            context,
            "tc",
            sourceArity,
            callLine,
            async () =>
        {
            if (sourceArity == 2)
            {
                if (arguments[0] is not FunctionTerm function)
                {
                    throw TimerSource.CallFailure(context, Term.Tuple(Term.A("badfun"), arguments[0]));
                }
                if (function.Arity != 0)
                {
                    throw TimerSource.CallFailure(context, Term.Tuple(Term.A("badarity"), Term.Tuple(function, Nil.Value)));
                }

                return await context.InvokeGuestFunction507(function, []);
            }

            if (sourceArity == 3 && arguments[0] is FunctionTerm callback && ProperLength(arguments[1], out int length)
                && callback.Arity != length)
            {
                throw TimerSource.CallFailure(context, Term.Tuple(Term.A("badarity"), Term.Tuple(callback, arguments[1])));
            }

            return sourceArity == 3 ? await Bif(
                context,
                "apply",
                arguments[0],
                arguments[1]
            )
                : await Bif(
                    context,
                    "apply",
                    arguments[0],
                    arguments[1],
                    arguments[2]
                );
        }
        );
        Term after = await Bif(context, "monotonic_time");
        Term elapsed = await TimerSource.Run(
            context,
            "tc",
            sourceArity,
            callLine + 2,
            () =>
            Bif(
                context,
                "convert_time_unit",
                CoreModules.Arithmetic("-", after, before),
                Term.A("native"),
                unit
            )
        );

        return Term.Tuple(elapsed, result);
    }

    private static async ValueTask<Term> Clock(ProcessContext context)
    {
        var micros = (Integer)await Bif(context, "monotonic_time", Term.A("microsecond"));

        return new Integer((micros.Value + MillisecondsPerSecond - 1) / MillisecondsPerSecond);
    }

    private static void RequireOk(Term result)
    {
        if (result is not TupleTerm { Items.Count: 2 } tuple || !tuple.Items[0].Equals(Ok))
        {
            throw new ErlangException(Term.Tuple(Term.A("badmatch"), result));
        }
    }
}
