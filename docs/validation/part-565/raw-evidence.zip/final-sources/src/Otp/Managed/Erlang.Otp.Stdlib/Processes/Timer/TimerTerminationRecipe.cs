namespace Erlang;

internal sealed record TimerTerminationRecipe(RuntimeFunctionEntries Owner) : IRuntimeStoredFunctionRecipe
{
    public FunctionTerm Rebind(IReadOnlyList<Term> environment)
    {
        var identity = new LocalFunctionIdentity(
            Term.A(TimerLibrary.Name),
            Term.A("-terminate/2-fun-0-"),
            1,
            0,
            new BitString(new byte[16])
        );
        var function = new FunctionTerm(
            identity,
            2,
            environment,
            (context, arguments) => TimerLibrary.TerminateEntry((ProcessContext)context, arguments)
        );
        Owner.RegisterStoredSource(function, this);

        return function;
    }
}
