// Derived from Erlang/OTP 29.1.1 timer.erl, Apache-2.0; Ericsson AB 1996-2025.
using static Erlang.TimerLibraryNames;

namespace Erlang;

public static partial class TimerLibrary
{
    private static async ValueTask<Term> Start(ProcessContext context)
    {
        var spec = new MapTerm(new Dictionary<Term, Term>
        {
            [Term.A("id")] = Term.A(Server),
            [Term.A("start")] = Term.Tuple(Term.A(Module), Term.A("start_link"), Nil.Value),
            [Term.A("restart")] = Term.A("permanent"),
            [Term.A("shutdown")] = Term.I(ShutdownMilliseconds),
            [Term.A("type")] = Term.A("worker"),
            [Term.A("modules")] = Term.List(Term.A(Module))
        });
        Term result = await Call(
            context,
            "supervisor",
            "start_child",
            Term.A("kernel_sup"),
            spec
        );
        if (result is TupleTerm tuple)
        {
            if (tuple.Items.Count is 2 or 3 && tuple.Items[0].Equals(Ok))
            {
                return Term.Tuple(Ok, tuple.Items[1]);
            }
            if (tuple.Items.Count == 2 && tuple.Items[0].Equals(Error))
            {
                if (tuple.Items[1] is Atom { Name: "already_present" })
                {
                    result = await Call(
                        context,
                        "supervisor",
                        "restart_child",
                        Term.A("kernel_sup"),
                        Term.A(Server)
                    );
                    if (result is TupleTerm { Items.Count: 2 } restarted && restarted.Items[0].Equals(Ok))
                    {
                        return result;
                    }
                    if (result is not TupleTerm { Items.Count: 2 } error || !error.Items[0].Equals(Error)
                        || error.Items[1] is not TupleTerm { Items.Count: 2 } started || started.Items[0] is not Atom { Name: "already_started" })
                    {
                        throw new ErlangException(Term.Tuple(Term.A("case_clause"), result));
                    }

                    return Term.Tuple(Ok, started.Items[1]);
                }
                if (tuple.Items[1] is TupleTerm { Items.Count: 2 } existing && existing.Items[0] is Atom { Name: "already_started" })
                {
                    return Term.Tuple(Ok, existing.Items[1]);
                }
            }
        }

        return result;
    }

    private static async ValueTask<Term> Request(ProcessContext context, string request, Term argument)
    {
        try
        {
            return await MaybeRequest(context, request, argument);
        }
        catch (ErlangException error) when (error.ExceptionClass == "exit"
            && error.Reason is TupleTerm { Items.Count: 2 } reason && reason.Items[0] is Atom { Name: "noproc" })
        {
            RequireOk(await Start(context));

            return await MaybeRequest(context, request, argument);
        }
    }

    private static ValueTask<Term> MaybeRequest(ProcessContext context, string request, Term argument)
        => Call(
            context,
            "gen_server",
            "call",
            Term.A(Server),
            Term.Tuple(Term.A(request), argument),
            Term.A("infinity")
        );

    private static async ValueTask<Term> Callback(ProcessContext context, string function, IReadOnlyList<Term> arguments)
    {
        Term state = arguments[^1];
        switch (function)
        {
            case "init":
                if (arguments[0] is not Nil)
                {
                    throw TimerSource.Clause(
                        context,
                        function,
                        arguments,
                        767
                    );
                }
                _ = await Bif(
                    context,
                    "process_flag",
                    Term.A("trap_exit"),
                    Term.A("true")
                );

                return Term.Tuple(Ok, await Call(
                    context,
                    "ets",
                    "new",
                    Term.A(Module),
                    Term.List(Term.A("private"))
                ));
            case "code_change":
                return Term.Tuple(Ok, arguments[1]);
            case "handle_cast":
                return Term.Tuple(Term.A("noreply"), state);
            case "handle_call":
                return await HandleCall(context, arguments[0], state);
            case "handle_info":
                {
                    if (arguments[0] is TupleTerm message)
                    {
                        if (message.Items.Count == 3 && message.Items[0] is Atom { Name: "timeout" }
                            && message.Items[2] is TupleTerm { Items.Count: 2 } payload && payload.Items[0] is Atom { Name: Once })
                        {
                            Term taken = await Call(
                                context,
                                "ets",
                                "take",
                                state,
                                message.Items[1]
                            );
                            if (taken is Cons { Head: TupleTerm { Items.Count: 1 } entry, Tail: Nil }
                                && entry.Items[0].Equals(message.Items[1]))
                            {
                                _ = await DoApply(context, payload.Items[1], false);
                            }
                            else if (taken is not Nil)
                            {
                                throw TimerSource.Error(
                                    context,
                                    "handle_info",
                                    2,
                                    840,
                                    Term.Tuple(Term.A("case_clause"), taken)
                                );
                            }
                        }
                        else if (message.Items.Count == 5 && message.Items[0] is Atom { Name: "DOWN" }
                            && message.Items[2] is Atom { Name: "process" })
                        {
                            _ = await Remove(context, message.Items[1], state);
                        }
                    }

                    return Term.Tuple(Term.A("noreply"), state);
                }
            case "terminate":
                if (state is not Atom { Name: "undefined" })
                {
                    FunctionTerm fold = new TimerTerminationRecipe(context.Runtime.Functions).Rebind(Array.Empty<Term>());
                    _ = await TimerSource.Run(
                        context,
                        "terminate",
                        2,
                        868,
                        () =>
                        Call(
                            context,
                            "ets",
                            "foldl",
                            fold,
                            Term.A("undefined"),
                            state
                        )
                    );
                    _ = await Call(
                        context,
                        "ets",
                        "delete",
                        state
                    );
                }

                return Ok;
            default:
                throw new ErlangException(ErlangErrorReasons.UndefinedFunction);
        }
    }

    private static async ValueTask<Term> HandleCall(ProcessContext context, Term request, Term state)
    {
        if (request is TupleTerm { Items.Count: 2 } pair)
        {
            if (pair.Items[0] is Atom { Name: Once } && pair.Items[1] is TupleTerm { Items.Count: 3 } once)
            {
                Term timeout = CoreModules.Arithmetic("+", once.Items[0], once.Items[1]);
                Term reply;
                try
                {
                    Term reference = await Bif(
                        context,
                        "start_timer",
                        timeout,
                        context.Self,
                        Term.Tuple(Term.A(Once), once.Items[2]),
                        Absolute
                    );
                    _ = await Call(
                        context,
                        "ets",
                        "insert",
                        state,
                        Term.Tuple(reference)
                    );
                    reply = Term.Tuple(Ok, Term.Tuple(Term.A("once"), reference));
                }
                catch (ErlangException error) when (error.ExceptionClass == "error" && error.Reason is Atom { Name: "badarg" })
                {
                    reply = BadArgument;
                }

                return Term.Tuple(Term.A("reply"), reply, state);
            }
            if (pair.Items[0] is Atom { Name: Interval or Repeatedly } operation
                && pair.Items[1] is TupleTerm { Items.Count: 4 } interval)
            {
                Term entry = await StartInterval(context, interval.Items, operation.Name == Repeatedly);
                _ = await Call(
                    context,
                    "ets",
                    "insert",
                    state,
                    entry
                );

                return Term.Tuple(Term.A("reply"), Term.Tuple(Ok, Term.Tuple(Term.A("interval"), ((TupleTerm)entry).Items[0])), state);
            }
            if (pair.Items[0] is Atom { Name: "cancel" }
                && pair.Items[1] is TupleTerm { Items.Count: 2 } cancel && cancel.Items[0] is Atom { Name: "once" or "interval" } type)
            {
                bool removed = await Remove(context, cancel.Items[1], state);
                if (removed && type.Name == "interval")
                {
                    _ = await Bif(
                        context,
                        "demonitor",
                        cancel.Items[1],
                        Term.List(Term.A("flush"))
                    );
                }

                return Term.Tuple(Term.A("reply"), Cancelled, state);
            }
        }

        return Term.Tuple(Term.A("noreply"), state);
    }

    private static async ValueTask<bool> Remove(ProcessContext context, Term reference, Term state)
    {
        Term taken = await Call(
            context,
            "ets",
            "take",
            state,
            reference
        );
        if (taken is Cons { Tail: Nil, Head: TupleTerm entry } && entry.Items.Count is 1 or 3 && entry.Items[0].Equals(reference))
        {
            if (entry.Items.Count == 1)
            {
                _ = await CancelTimer(context, reference);
            }
            else if (entry.Items.Count == 3)
            {
                _ = await Bif(
                    context,
                    "send",
                    entry.Items[1],
                    Term.Tuple(Term.A("cancel"), entry.Items[2])
                );
            }
            else
            {
                throw new ErlangException(Term.Tuple(Term.A("case_clause"), taken));
            }

            return true;
        }
        if (taken is not Nil)
        {
            throw new ErlangException(Term.Tuple(Term.A("case_clause"), taken));
        }

        return false;
    }

    private static ValueTask<Term> CancelTimer(ProcessContext context, Term reference)
        => Bif(
            context,
            "cancel_timer",
            reference,
            CancelOptions
        );

    internal static async ValueTask<Term> TerminateEntry(ProcessContext context, IReadOnlyList<Term> arguments)
    {
        if (arguments[0] is TupleTerm { Items.Count: 1 } once)
        {
            _ = await CancelTimer(context, once.Items[0]);
        }
        else if (arguments[0] is TupleTerm { Items.Count: 3 } interval)
        {
            _ = await Bif(
                context,
                "send",
                interval.Items[1],
                Term.Tuple(Term.A("cancel"), interval.Items[2])
            );
        }
        else
        {
            throw TimerSource.Clause(
                context,
                "-terminate/2-fun-0-",
                arguments,
                869
            );
        }

        return arguments[1];
    }
}
