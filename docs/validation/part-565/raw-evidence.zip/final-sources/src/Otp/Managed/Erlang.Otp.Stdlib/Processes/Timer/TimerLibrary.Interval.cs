// Derived from Erlang/OTP 29.1.1 timer.erl, Apache-2.0; Ericsson AB 1996-2025.
using static Erlang.TimerLibraryNames;

namespace Erlang;

public static partial class TimerLibrary
{
    private static async ValueTask<Term> StartInterval(ProcessContext context, IReadOnlyList<Term> arguments, bool waitComplete)
    {
        Term tag = await Bif(context, "make_ref");
        Term server = context.Self;
        Term started = arguments[0];
        Term time = arguments[1];
        Term target = arguments[2];
        Term mfa = arguments[3];
        var recipe = new TimerIntervalRecipe(context.Runtime.Functions);
        FunctionTerm worker = recipe.Rebind([server, target, tag, started, time, mfa, CoreModules.Boolean(waitComplete)]);
        var spawned = (TupleTerm)await Bif(context, "spawn_monitor", worker);

        return Term.Tuple(spawned.Items[1], spawned.Items[0], tag);
    }

    internal static async ValueTask<Term> RunInterval(ProcessContext context, IReadOnlyList<Term> environment)
    {
        Term serverMonitor = await Bif(
            context,
            "monitor",
            Term.A("process"),
            environment[0]
        );
        Term targetMonitor = await Bif(
            context,
            "monitor",
            Term.A("process"),
            environment[1]
        );
        Term timer = await Schedule(
            context,
            environment[3],
            environment[4],
            environment[5]
        );

        return await IntervalLoop(
            context,
            serverMonitor,
            targetMonitor,
            environment[2],
            CoreModules.Bool(environment[6]),
            timer
        );
    }

    private static async ValueTask<Term> IntervalLoop(
        ProcessContext context,
        Term serverMonitor,
        Term targetMonitor,
        Term tag,
        bool waitComplete,
        Term timer
    )
    {
        bool Stop(TupleTerm message)
            => message.Items.Count == 2 && message.Items[0] is Atom { Name: "cancel" } && message.Items[1].Equals(tag)
                || message.Items.Count == 5 && message.Items[0] is Atom { Name: "DOWN" }
                && message.Items[2] is Atom { Name: "process" }
                && (message.Items[1].Equals(serverMonitor) || message.Items[1].Equals(targetMonitor));

        while (true)
        {
            TupleTerm message = (await context.ReceiveAsync(value => value is TupleTerm tuple
                && (Stop(tuple) || tuple.Items.Count == 3 && tuple.Items[0] is Atom { Name: "timeout" }
                    && tuple.Items[1].Equals(timer) && tuple.Items[2] is TupleTerm { Items.Count: 4 } payload
                    && payload.Items[0] is Atom { Name: Interval }) ? tuple : null))!;
            if (Stop(message))
            {
                return await CancelTimer(context, timer);
            }
            var action = (TupleTerm)message.Items[2];
            Term outcome = await DoApply(context, action.Items[3], waitComplete);
            if (outcome is TupleTerm { Items.Count: 2 } success && success.Items[0].Equals(Ok)
                && success.Items[1] is TupleTerm { Items.Count: 2 } spawned && spawned.Items[0] is Atom { Name: "spawn" })
            {
                TupleTerm finished = (await context.ReceiveAsync(value => value is TupleTerm tuple
                    && (Stop(tuple) || tuple.Items.Count == 5 && tuple.Items[0] is Atom { Name: "DOWN" }
                        && tuple.Items[2] is Atom { Name: "process" } && tuple.Items[1].Equals(spawned.Items[1])) ? tuple : null))!;
                if (Stop(finished))
                {
                    return Ok;
                }
            }
            timer = await Schedule(
                context,
                action.Items[1],
                action.Items[2],
                action.Items[3]
            );
            await context.BumpReductionsAsync(1);
        }
    }

    private static async ValueTask<Term> Schedule(
        ProcessContext context,
        Term current,
        Term time,
        Term mfa
    )
    {
        Term next = CoreModules.Arithmetic("+", current, time);
        Term payload = Term.Tuple(
            Term.A(Interval),
            next,
            time,
            mfa
        );
        if (TermOrder.Compare(next, await Clock(context)) <= 0)
        {
            Term reference = await Bif(context, "make_ref");
            _ = await Bif(
                context,
                "send",
                context.Self,
                Term.Tuple(Term.A("timeout"), reference, payload)
            );

            return reference;
        }

        return await Bif(
            context,
            "start_timer",
            next,
            context.Self,
            payload,
            Absolute
        );
    }

    private static async ValueTask<Term> DoApply(ProcessContext context, Term value, bool waitComplete)
    {
        if (value is not TupleTerm { Items.Count: 3 } mfa)
        {
            throw new ErlangException(ErlangErrorReasons.FunctionClause);
        }
        Term module = mfa.Items[0];
        Term function = mfa.Items[1];
        Term args = mfa.Items[2];
        if (module is Atom { Name: Module } && function is Atom { Name: "send" })
        {
            try
            {
                Term[] pair = Cons.Items(args).ToArray();
                if (pair.Length != 2)
                {
                    throw new ErlangException(ErlangErrorReasons.FunctionClause);
                }
                _ = await Bif(
                    context,
                    "send",
                    pair[0],
                    pair[1]
                );

                return Term.Tuple(Ok, Term.A("send"));
            }
            catch (ErlangException)
            {
                return Error;
            }
        }
        if (module is Atom { Name: "erlang" } && function is Atom { Name: "exit" }
            && args is Cons { Tail: Cons { Tail: Nil } second } first)
        {
            try
            {
                Term pid = first.Head;
                if (pid is Atom { Name: not "undefined" })
                {
                    pid = await Bif(context, "whereis", pid);
                }
                if (pid is not Pid)
                {
                    pid = Term.A("undefined");
                }
                _ = await Bif(
                    context,
                    "exit",
                    pid,
                    second.Head
                );

                return Term.Tuple(Ok, Term.A("exit"));
            }
            catch (ErlangException)
            {
                return Error;
            }
        }
        try
        {
            Term spawned = await Bif(
                context,
                waitComplete ? "spawn_monitor" : "spawn",
                module,
                function,
                args
            );

            return Term.Tuple(Ok, waitComplete
                ? Term.Tuple(Term.A("spawn"), ((TupleTerm)spawned).Items[1]) : Term.A("spawn"));
        }
        catch (ErlangException error) when (error.ExceptionClass == "error" && error.Reason is Atom { Name: "badarg" })
        {
            return Error;
        }
    }
}
