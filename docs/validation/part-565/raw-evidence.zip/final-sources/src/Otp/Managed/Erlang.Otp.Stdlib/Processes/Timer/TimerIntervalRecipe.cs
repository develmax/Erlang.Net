namespace Erlang;

// Rebinding owns the destination environment. Never retain source terms in a
// transferred delegate: interval actions can outlive the creating server turn.
internal sealed record TimerIntervalRecipe(RuntimeFunctionEntries Owner) : IRuntimeStoredFunctionRecipe
{
    public FunctionTerm Rebind(IReadOnlyList<Term> environment)
    {
        var identity = new LocalFunctionIdentity(
            Term.A(TimerLibrary.Name),
            Term.A("-start_interval_loop/5-fun-0-"),
            0,
            0,
            new BitString(new byte[16])
        );
        var function = new FunctionTerm(
            identity,
            0,
            environment,
            (context, _) => TimerLibrary.RunInterval((ProcessContext)context, environment)
        );
        Owner.RegisterStoredSource(function, this);

        return function;
    }
}
