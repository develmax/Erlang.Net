namespace Erlang;

internal static class TimerLibraryNames
{
    internal const string Module = "timer";
    internal const string Server = "timer_server";
    internal const string Once = "apply_once";
    internal const string Interval = "apply_interval";
    internal const string Repeatedly = "apply_repeatedly";
    internal const long MaximumReceive = 0xffffffff;
    internal const int MillisecondsPerSecond = 1000;
    internal const int MicrosecondsPerSecond = 1000000;
    internal const int SecondsPerMinute = 60;
    internal const int ShutdownMilliseconds = 1000;
    internal static readonly Term Ok = Term.A("ok");
    internal static readonly Term Error = Term.A("error");
    internal static readonly Term BadArgument = Term.Tuple(Error, Term.A("badarg"));
    internal static readonly Term Cancelled = Term.Tuple(Ok, Term.A("cancel"));
    internal static readonly Term Absolute = Term.List(Term.Tuple(Term.A("abs"), Term.A("true")));
    internal static readonly Term CancelOptions = Term.List(
        Term.Tuple(Term.A("async"), Term.A("true")),
        Term.Tuple(Term.A("info"), Term.A("false")));
}
