"""Admit complete focused timer receipts; never refresh global readiness from them."""
from pathlib import Path
import hashlib
import json
import sys

repository = Path(__file__).resolve().parents[2]
evidence = Path(sys.argv[1]).resolve()
output = Path(sys.argv[2]).resolve()


def read(relative):
    return json.loads((evidence / relative).read_text(encoding="utf-8-sig"))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


primary = []
profiles = []
upstream = []
for backend in ("Managed", "Beam"):
    row = read(f"acceptance-closure/{backend}-report.json")
    assert row["Backend"] == backend
    assert row["Exports"] == 36 and row["Cases"] == row["Passed"] == 728
    assert row["EffectPassed"] == 11 and not row["Failures"]
    assert row["CorpusSha256"] == digest(evidence / "acceptance-closure/original.etf")
    primary.append(row)
    for depth in (0, 1, 2, 3, 32):
        profile = read(f"closure-depth-{depth}/{backend}-report.json")
        assert profile["Cases"] == profile["Passed"] == 728
        assert profile["EffectPassed"] == 11 and not profile["Failures"]
        for identity in ("ManagedAssemblySha256", "RuntimeAssemblySha256"):
            assert profile[identity] == row[identity]
        profiles.append({"depth": depth, "backend": backend, "passed": profile["Passed"],
                         "corpusSha256": profile["CorpusSha256"]})
    suite = read(f"accepted-suite/{backend}-upstream-report.json")
    assert suite["Cases"] == suite["Passed"] == 47 and not suite["Failures"]
    upstream.append(suite)

for identity in ("ManagedAssemblySha256", "RuntimeAssemblySha256"):
    assert primary[0][identity] == primary[1][identity]
binary = evidence / "build-closure/bin/Erlang.TimerCompatibility/debug"
assert digest(binary / "Erlang.Runtime.dll") == primary[0]["RuntimeAssemblySha256"]
assert digest(binary / "Erlang.Otp.Stdlib.dll") == primary[0]["ManagedAssemblySha256"]
suite_inputs = read("accepted-suite/suite-final-inputs.json")
for file, expected in suite_inputs["Files"].items():
    assert digest(binary / file) == expected.upper()
bindings = read("final-source-bindings.json")
for file, expected in bindings.items():
    assert digest(repository / file) == expected.upper()
inventory = json.loads((repository / "docs/validation/part-565/source-inventory.json").read_text())
assert len(inventory["exports"]) == 36 and len(inventory["imports"]) == 37
assert inventory["sourceUnchanged"]
assert digest(repository / "src/Otp/Original/Foundation/Erlang.Otp.Stdlib.Beam/Otp/timer.beam") == inventory["beamSha256"].upper()

result = {
    "baseline": "OTP-29.1.1", "module": "timer", "exports": 36,
    "primaryCasesPerBackend": 728, "behavioralScenariosPerBackend": 11,
    "upstreamCasesPerBackend": 47, "backtraceDepths": [0, 1, 2, 3, 8, 32],
    "fullRegressionRun": False, "globalReadinessRegenerated": False,
    "universalCompatibilityCertified": False, "defaultTimerExports": 0,
    "primary": primary, "profiles": profiles, "upstream": upstream,
    "suiteInputIdentities": suite_inputs, "sourceBindings": bindings,
    "originalInputSha256": digest(evidence / "upstream-original/upstream.etf"),
    "projectedUpstreamSha256": digest(evidence / "accepted-suite/upstream.etf"),
    "projectionProof": (evidence / "accepted-suite/projection-proof.txt").read_text(),
    "ordinaryBuildBoundary": "Unrelated concurrent DETS draft compilation errors; focused filtered build passed."
}
output.parent.mkdir(parents=True, exist_ok=True)
output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print("timer: both backends admitted; 728 primary + 11 scenarios + 47 upstream; depth 0/1/2/3/8/32")
