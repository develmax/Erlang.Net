using System.Security.Cryptography;
using System.Text.Json;
using Erlang;

if (args.Length is not (3 or 4) || args[2] is not ("Managed" or "Beam"))
{
    Console.Error.WriteLine("Usage: Erlang.TimerCompatibility <repository> <oracle-directory> Managed|Beam");

    return 2;
}
string repository = Path.GetFullPath(args[0]);
string directory = Path.GetFullPath(args[1]);
bool managed = args[2] == "Managed";
bool suite = args.Length == 4 && args[3] == "suite";
int? depth = args.Length == 4 && args[3].StartsWith("depth:", StringComparison.Ordinal) ? int.Parse(args[3][6..]) : null;
await using var runtime = await ProcessRuntime.CreateAsync(
    new RuntimeLibrarySelection(managed ? [RuntimeModuleSelection.Managed(TimerLibrary.Name)] : []),
    RuntimeNativePrimitives.EtsStorageCore | RuntimeNativePrimitives.InternalScalars413 | RuntimeNativePrimitives.PersistentTermCore,
    CancellationToken.None
);
string stdlib = Path.Combine(repository, "src/Otp/Original/Foundation/Erlang.Otp.Stdlib.Beam/Otp");
string kernel = Path.Combine(repository, "src/Otp/Original/Foundation/Erlang.Otp.Kernel.Beam/Otp/ebin");
string[] dependencies = Directory.GetFiles(stdlib, "*.beam").Concat(Directory.GetFiles(kernel, "*.beam"))
    .Select(file => Path.GetFileNameWithoutExtension(file)).Concat(["erlang", "ct", "timer_port_cases", "timer_suite_capture", "timer_simple_SUITE"]).Distinct().ToArray();
string[] helpers = ["gen_server", "gen", "proc_lib", "sys", "supervisor", "lists", "maps", "queue", "ets",
    "logger", "logger_config", "logger_filters", "logger_backend", "logger_server", "logger_proxy", "proplists"];
var images = new List<PreparedBeamImage>();
await runtime.InitializeModulesAsync(registry => RuntimeBootstrapEtsLibrary.Register(runtime, registry));
foreach (string module in helpers.Concat(managed ? [] : new[] { "timer" }).Append("timer_port_cases")
    .Concat(suite ? ["timer_simple_SUITE", "timer_suite_capture"] : Array.Empty<string>()))
{
    Console.WriteLine("Preparing: " + module);
    string file = module is "timer_port_cases" or "timer_simple_SUITE" or "timer_suite_capture" ? Path.Combine(directory, module + ".beam")
        : File.Exists(Path.Combine(stdlib, module + ".beam")) ? Path.Combine(stdlib, module + ".beam")
        : Path.Combine(kernel, module + ".beam");
    images.Add(runtime.Modules.PrepareBeam(File.ReadAllBytes(file), new BeamDependencySelection(dependencies)));
}
await runtime.InitializeModulesAsync(registry =>
{
    if (registry.PublishPreparedBeam(images.ToArray()).Status != BeamPublicationStatus.Published)
    {
        throw new InvalidOperationException("Timer test dependency publication failed");
    }
});
foreach (var export in TimerLibrary.Exports)
{
    if (!runtime.Modules.HasExport("timer", export.Name, export.Arity)
        || (runtime.Modules.SourceOwner("timer", export.Name, export.Arity) is PreparedBeamImage) == managed)
    {
        throw new InvalidOperationException("Timer backend owner/export mismatch");
    }
}
var oracleExports = Cons.Items(ExternalTermFormat.Decode(File.ReadAllBytes(Path.Combine(directory, "exports.etf"))))
    .Cast<TupleTerm>().Select(row => (((Atom)row.Items[0]).Name, (int)((Integer)row.Items[1]).Value)).ToHashSet();
var registeredExports = runtime.Modules.Exports.Where(row => row.Module == "timer" && row.Function != "module_info")
    .Select(row => (row.Function, row.Arity)).ToHashSet();
if (!oracleExports.SetEquals(TimerLibrary.Exports) || !oracleExports.SetEquals(registeredExports))
{
    throw new InvalidOperationException("Timer exports differ from pinned OTP");
}
Term[] rows = Cons.Items(runtime.ImportExternalTerm(File.ReadAllBytes(Path.Combine(directory, "original.etf"))).Term).ToArray();
var failures = new List<object>();
int passed = 0;
Term[] effects = Cons.Items(ExternalTermFormat.Decode(File.ReadAllBytes(Path.Combine(directory, "effects.etf")))).ToArray();
TupleTerm startup = effects.Cast<TupleTerm>().Single(row => row.Items[0] is Atom { Name: "start" });
Term started = await Run(context => runtime.Modules.Call(
    context,
    "timer_port_cases",
    "scenario",
    startup.Items[0]
));
if (!started.Equals(startup.Items[1]))
{
    throw new InvalidOperationException("Timer startup scenario failed: " + started);
}
if (depth is { } requestedDepth)
{
    _ = await Run(context => runtime.Modules.Call(
        context,
        "erlang",
        "system_flag",
        Term.A("backtrace_depth"),
        Term.I(requestedDepth)
    ));
}
if (suite)
{
    Term[] suiteRows = Cons.Items(runtime.ImportExternalTerm(File.ReadAllBytes(Path.Combine(directory, "upstream.etf"))).Term).ToArray();
    foreach (TupleTerm row in suiteRows)
    {
        if (row.Items[1] is not TupleTerm { Items.Count: 2 } expected || expected.Items[0] is not Atom { Name: "ok" })
        {
            throw new InvalidOperationException("Pinned upstream testcase failed: " + row);
        }
        Console.WriteLine("Upstream: " + row.Items[0]);
        Term sent = await Run(context => runtime.Modules.Call(
            context,
            "timer_suite_capture",
            "worker",
            row.Items[0],
            context.Self
        ));
        Term actual = ((TupleTerm)sent).Items[1];
        if (actual.Equals(row.Items[1]))
        {
            passed++;
        }
        else
        {
            failures.Add(new { Test = row.Items[0].ToString(), Expected = row.Items[1].ToString(), Actual = actual.ToString() });
        }
    }
    File.WriteAllText(
        Path.Combine(directory, args[2] + "-upstream-report.json"),
        JsonSerializer.Serialize(
            new
            {
                Backend = args[2],
                Cases = suiteRows.Length,
                Passed = passed,
                Failures = failures
            },
            new JsonSerializerOptions { WriteIndented = true }
        )
    );
    Console.WriteLine($"{args[2]}: upstream {passed}/{suiteRows.Length}");

    return failures.Count == 0 ? 0 : 1;
}
foreach (TupleTerm row in rows)
{
    Term sent = await Run(context => runtime.Modules.Call(
        context,
        "timer_port_cases",
        "worker",
        row.Items[0],
        row.Items[1],
        context.Self
    ));
    Term result = ((TupleTerm)sent).Items[1];
    if (result.Equals(row.Items[2]))
    {
        passed++;
    }
    else
    {
        failures.Add(new { Function = row.Items[0].ToString(), Arguments = row.Items[1].ToString(), Expected = row.Items[2].ToString(), Actual = result.ToString() });
    }
}
int effectPassed = 0;
foreach (TupleTerm row in effects)
{
    Console.WriteLine("Scenario: " + row.Items[0]);
    Term sent = await Run(context => runtime.Modules.Call(
        context,
        "timer_port_cases",
        "scenario_worker",
        row.Items[0],
        context.Self
    ));
    Term result = ((TupleTerm)sent).Items[1];
    if (result.Equals(row.Items[1]))
    {
        effectPassed++;
    }
    else
    {
        failures.Add(new { Scenario = row.Items[0].ToString(), Expected = row.Items[1].ToString(), Actual = result.ToString() });
    }
}
File.WriteAllText(
    Path.Combine(directory, args[2] + "-report.json"),
    JsonSerializer.Serialize(
        new
        {
            Backend = args[2],
            Baseline = "OTP-29.1.1",
            Exports = TimerLibrary.Exports.Count,
            Cases = rows.Length,
            Passed = passed,
            EffectPassed = effectPassed,
            Failures = failures,
            TimerBeamSha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(Path.Combine(stdlib, "timer.beam")))),
            ManagedAssemblySha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(TimerLibrary).Assembly.Location))),
            RuntimeAssemblySha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(ProcessRuntime).Assembly.Location))),
            CorpusSha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(Path.Combine(directory, "original.etf"))))
        },
        new JsonSerializerOptions { WriteIndented = true }
    )
);
Console.WriteLine($"{args[2]}: {passed}/{rows.Length} contracts; {effectPassed} scenarios; {failures.Count} failures");

return failures.Count == 0 ? 0 : 1;

async Task<Term> Run(Func<ProcessContext, ValueTask<Term>> body)
{
    var result = new TaskCompletionSource<Term>(TaskCreationOptions.RunContinuationsAsynchronously);
    ProcessHandle worker = runtime.Spawn(async context =>
    {
        try
        {
            result.TrySetResult(await body(context));
        }
        catch (ErlangException error)
        {
            result.TrySetResult(Term.Tuple(
                Term.A("uncaught"),
                Term.A(error.ExceptionClass),
                error.Reason,
                error.StackTraceTerm
            ));
        }
        catch (Exception error)
        {
            result.TrySetException(error);
        }

        return Nil.Value;
    });
    Term value = await result.Task.WaitAsync(TimeSpan.FromSeconds(30));
    await worker.Completion.WaitAsync(TimeSpan.FromSeconds(10));

    return value;
}
