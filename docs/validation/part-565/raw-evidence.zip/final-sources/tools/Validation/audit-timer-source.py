"""Inventory the unchanged pinned timer source and BEAM imports, without executing tests."""
from pathlib import Path
import hashlib
import json
import re
import struct
import subprocess
import sys

root = Path(__file__).resolve().parents[2]
source = subprocess.check_output([
    "git", "-C", str(root.parent / "otp"), "show",
    "OTP-29.1.1:lib/stdlib/src/timer.erl"])
retained = root / "src/Otp/Original/Foundation/Erlang.Otp.Stdlib.Beam/Otp"
assert source == (retained / "timer.erl").read_bytes()
beam = (retained / "timer.beam").read_bytes()
chunks = {}
offset = 12
while offset < len(beam):
    name = beam[offset:offset + 4].decode("ascii")
    size = struct.unpack_from(">I", beam, offset + 4)[0]
    chunks[name] = beam[offset + 8:offset + 8 + size]
    offset += 8 + (size + 3) // 4 * 4
atoms = [None]
atom_chunk = chunks.get("AtU8", chunks.get("Atom"))
position = 4
count = struct.unpack_from(">i", atom_chunk)[0]
for _ in range(abs(count)):
    first = atom_chunk[position]
    position += 1
    if count >= 0:
        size = first
    elif first & 8 == 0:
        size = first >> 4
    elif first & 16 == 0:
        size = ((first & 224) << 3) | atom_chunk[position]
        position += 1
    else:
        width = (first >> 5) + 2
        assert width < 9
        size = int.from_bytes(atom_chunk[position:position + width], "big")
        position += width
    atoms.append(atom_chunk[position:position + size].decode("utf-8"))
    position += size
imports = chunks["ImpT"]
rows = []
for index in range(struct.unpack_from(">I", imports)[0]):
    module, function, arity = struct.unpack_from(">III", imports, 4 + index * 12)
    rows.append({"module": atoms[module], "function": atoms[function], "arity": arity})
text = source.decode("utf-8")
exports = []
for declaration in re.findall(r"-export\(\[(.*?)\]\)\.", text, re.S):
    exports.extend({"function": name, "arity": int(arity)}
                   for name, arity in re.findall(r"(\w+)/(\d+)", declaration))
result = {
    "baseline": "OTP-29.1.1", "commit": "ad05823719d77c8faee87348ea39513d4e2f99c5",
    "sourceSha256": hashlib.sha256(source).hexdigest(),
    "beamSha256": hashlib.sha256(beam).hexdigest(),
    "sourceUnchanged": True, "exports": exports, "imports": rows,
    "clauses": [{"line": n, "text": line} for n, line in enumerate(text.splitlines(), 1)
                if re.match(r"^[a-z][a-z_]*\(", line)]}
output = Path(sys.argv[1])
output.parent.mkdir(parents=True, exist_ok=True)
output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(f"timer: {len(exports)} exports, {len(rows)} imports; pinned source unchanged")
