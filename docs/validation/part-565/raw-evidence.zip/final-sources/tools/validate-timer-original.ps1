param(
    [string]$Admission = 'artifacts/library376-official-compiler/official-admission.json',
    [string]$Output = 'artifacts/timer-compatibility',
    [string]$RunnerDll,
    [switch]$CaptureOnly,
    [switch]$IncludeUpstreamSuite,
    [ValidateRange(0, 64)][int]$BacktraceDepth = 8
)
$ErrorActionPreference = 'Stop'
$repository = Split-Path $PSScriptRoot -Parent
Push-Location $repository
try {
    $profile = Get-Content -LiteralPath $Admission -Raw | ConvertFrom-Json
    if ($profile.ReleaseVersion -cne '29.1.1' -or
        $profile.SourceCommit -cne 'ad05823719d77c8faee87348ea39513d4e2f99c5' -or
        -not $profile.EveryExtractedFileMatchesArchive -or
        (Get-FileHash -LiteralPath $profile.ExecutionManifestPath).Hash -cne $profile.ExecutionManifestSha256) {
        throw 'Timer requires the admitted official OTP 29.1.1 provider.'
    }
    $inventory = Get-Content -LiteralPath $profile.ExecutionManifestPath -Raw | ConvertFrom-Json
    $closure = @($inventory | Where-Object {
        $_.Path -eq 'bin/erl.exe' -or
        $_.Path -match '^erts-[^/]+/bin/(erl.exe|beam.smp.dll)$' -or
        $_.Path -match '^lib/(stdlib-8.1|kernel-[^/]+|erts-17.1)/(ebin|src)/(timer|gen_server|gen|supervisor|proc_lib|sys|ets|lists|maps|erlang)\.(beam|erl)$'
    })
    if ($closure.Count -lt 15) { throw 'Incomplete timer oracle closure.' }
    function Test-Closure {
        foreach ($entry in $closure) {
            if ((Get-FileHash -LiteralPath (Join-Path $profile.InstalledOtpRoot $entry.Path)).Hash -cne $entry.Sha256) {
                throw 'Timer oracle input changed.'
            }
        }
    }
    Test-Closure
    $directory = [IO.Path]::GetFullPath($Output)
    if (Test-Path -LiteralPath $directory) { throw 'Choose a new output directory.' }
    New-Item -ItemType Directory -Path $directory | Out-Null
    $relative = [IO.Path]::GetRelativePath($repository, $directory).Replace('\', '/')
    if ($relative.Contains('"') -or $relative.Contains("`n")) { throw 'Unsupported output path.' }
    $expression = '{ok,timer_port_cases}=compile:file("tools/Validation/Erlang.TimerCompatibility/timer_port_cases.erl",[{outdir,"' + $relative + '"}]),' +
        'true=code:add_patha("' + $relative + '"),erlang:system_flag(backtrace_depth,' + $BacktraceDepth + '),' +
        'ok=timer_port_cases:write("' + $relative + '"),halt().'
    & (Join-Path $profile.InstalledOtpRoot 'bin/erl.exe') -noshell -eval $expression 2>&1 |
        Tee-Object -FilePath (Join-Path $directory 'oracle.log')
    if ($LASTEXITCODE -ne 0) { throw 'Timer oracle failed.' }
    if ($IncludeUpstreamSuite) {
        $suiteExpression = '{ok,timer_simple_SUITE}=compile:file("tools/Validation/Erlang.TimerCompatibility/Reference/timer_simple_SUITE.erl",[{outdir,"' + $relative + '"}]),' +
            '{ok,timer_suite_capture}=compile:file("tools/Validation/Erlang.TimerCompatibility/timer_suite_capture.erl",[{outdir,"' + $relative + '"}]),' +
            'true=code:add_patha("' + $relative + '"),ok=timer_suite_capture:write("' + $relative + '"),halt().'
        & (Join-Path $profile.InstalledOtpRoot 'bin/erl.exe') -noshell -eval $suiteExpression 2>&1 |
            Tee-Object -FilePath (Join-Path $directory 'upstream.log')
        if ($LASTEXITCODE -ne 0) { throw 'Timer upstream capture failed.' }
    }
    Test-Closure
    [ordered]@{
        Baseline = $profile.ReleaseTag
        SourceCommit = $profile.SourceCommit
        BacktraceDepth = $BacktraceDepth
        ProviderArchiveSha256 = $profile.ArchiveSha256
        ExecutionManifestSha256 = $profile.ExecutionManifestSha256
        Closure = $closure
        Files = @(Get-ChildItem -LiteralPath $directory -File | ForEach-Object {
            [ordered]@{ Name = $_.Name; Sha256 = (Get-FileHash -LiteralPath $_.FullName).Hash }
        })
    } | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $directory 'provenance.json') -Encoding utf8
    if (-not $CaptureOnly) {
        if (-not $RunnerDll) { throw 'Supply a built timer validator DLL or use CaptureOnly.' }
        foreach ($backend in @('Managed', 'Beam')) {
            & dotnet $RunnerDll $repository $directory $backend
            if ($LASTEXITCODE -ne 0) { throw "Timer $backend comparison failed." }
        }
    }
}
finally { Pop-Location }
