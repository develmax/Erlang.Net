@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b %errorlevel%
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.51.36231\bin\Hostx64\x64\cl.exe" "/nologo" "/std:c11" "/W4" "/WX" "/O2" "/MD" "/LD" "/ID:\a\Erlang.Net\Erlang.Net\subject\artifacts\library376-official-compiler\installed\erts-17.1\include" "D:\a\Erlang.Net\Erlang.Net\subject\artifacts\async-microstates\e7fd9173fee54eefb1ea22a5a357b944\fixtures\async_msacc1127_drv.c" "/Fe:D:\a\Erlang.Net\Erlang.Net\subject\artifacts\async-microstates\e7fd9173fee54eefb1ea22a5a357b944\fixtures\async_msacc1127_drv.dll"
exit /b %errorlevel%
