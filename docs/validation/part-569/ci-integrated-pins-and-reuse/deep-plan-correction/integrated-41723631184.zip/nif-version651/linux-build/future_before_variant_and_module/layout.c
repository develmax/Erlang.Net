#include "fixture.c"
#include <stdio.h>
int main(void){printf("%zu %zu %zu\n",sizeof(Entry651),sizeof(Function651),offsetof(Entry651,functions));return 0;}
