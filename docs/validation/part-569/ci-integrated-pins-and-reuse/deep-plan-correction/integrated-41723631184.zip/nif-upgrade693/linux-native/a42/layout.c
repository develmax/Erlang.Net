#include "fixture.c"
#include <stddef.h>
int main(void){printf("%zu %zu %zu %zu %zu\n",sizeof(ErlNifEntry),sizeof(ErlNifFunc),offsetof(ErlNifEntry,funcs),sizeof(void*),sizeof(ERL_NIF_TERM));return 0;}
