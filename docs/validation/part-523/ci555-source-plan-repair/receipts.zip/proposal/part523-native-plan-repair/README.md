# Part523 native source-plan repair

AUTHORITATIVE BASE: immutable clean w518repair at published Part523 commit161e70f7, supplied by root. Current primary/Part525 source bytes were NOT used. Source-only proposal; no build/native/VM/git/CI execution and no active source changes.

Apply exactly four staged targets after their raw preimage guards pass: Family504, Materialized505, Reentry505 source plans, then validate.yml. Each legacy plan had exactly the same three stale declarations: NifNativeCallEnvironment E65BF3...→E1ED789..., NifNativeLibraryOwner45FA5A...→48173F..., ProcessTermHeapF3B167...→C2712D.... repair-audit.json records complete hashes.

The plans additionally bind the actual reviewed Float15+NIF4 production source closure. Nineteen paths total, including the new Float storage interface/names/heap partial and both load-private NIF partials; each plan gains16 previously absent paths. Existing dependency modes remain unchanged. New rows use the existing supported TextLF mode and managed phase. This is necessary because Materialized505 currently accepts ONLY TextLF dependencies. No collector policy is relaxed and its actual raw hashes remain available in normal receipts.

Every non-Dependencies plan field remains byte-value identical as parsed JSON: all goldens, original provenance, source/collector/build hashes, cases, serialization rules and default difference scopes are preserved. No original output is replaced or recaptured by this repair. The workflow changes ONLY the three hardcoded plan SHA strings; it does not disable checks or relax native comparison gates.

New plan SHA values:

- Family504: F3A8035EE41519746D8937DF6493368717247676F3A85AEE4766D345D45BEA58
- Materialized505: A7A4008F499CA62193855DAF1C2BD4ED1F3C5C814CE6E033042080DD3B572BFC
- Reentry505: 5C83AFA122236377CB9FFD53811D0F031920A9801E41B7C28D0BE33E5E928107

IMPORTANT: this packet intentionally does NOT include the downstream cascade. Root owns final refresh after applying these four files: Owned506 → Pending reviewed-source-plan → pending workflow pin → Reallocation SOURCE-PLAN → reallocation workflow pin → Variadic526 → Private557 LAST. Those plans bind workflow/earlier plan bytes; carrying old copies forward would recreate source-admission failure. Recalculate on final source separately for Part524/525, not by copying Part523 runtime hashes across newer production changes.

Existing pure collector checks can run BEFORE the full regression: Family collect.dependencies(root,plan), Materialized collect.sources(root,tool,plan), Reentry collect.dependencies(root,plan,False). Import their modules without calling main, build-native, provider or managed_preflight. The latter checks built artifacts, whereas this early admission must require source only. A separate bounded all8 preflight proposal is being prepared; it is not an extra hidden tracked target in this frozen repair.

No literal SchemaVersion3 source-plan consumer was identified in bounded src/tools/tests source scans; root confirmed no specific extra schema3 target. No unrelated historical/immutable evidence was rebound speculatively. Full regress/native execution still required at the final repaired head; source hash repair alone is not native success.
