# Optional whole-owner source closure amendment

Apply AFTER frozen batch566 part523-native-plan-repair and BEFORE root's downstream five-plan/workflow cascade. This source-only amendment adds two already published owner/environment partials to the three legacy plans, then updates only their workflow SHA pins again. Existing goldens and all non-dependency fields stay unchanged.

The actual published owner files are main, Dirty521 and LoadPrivateData557. Environment files are main, MapIterator504, OwnedRoots516 and LoadPrivateData557. v1 binds all except Dirty521 and MapIterator504; this amendment completes all seven exact owner/env files. The iterator partial directly serves the family APIs; binding its actual source prevents a partial-only change from escaping the older main-file seal. Hash mode remains supported managed TextLF.

No active edits, source changes, compiler/native/VM/git/CI execution occurred. Root must refresh the same Owned→Pending→workflow pin→Realloc→workflow pin→Var→Private-last cascade AFTER these final four bytes. This is not native execution proof or a change to comparison gates. Preimages are frozen v1 payloads, not current Part525 sources.
