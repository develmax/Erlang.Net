from pathlib import Path
import json,hashlib,subprocess,re
root=Path.cwd();out=root/'artifacts/part523-ci555/final-cascade-v2';out.mkdir(exist_ok=False)
plans=['tools/Runtime/Erlang.OwnedGuest506Observations/source-plan.json','tools/Native/Erlang.NifPendingVarargsObservations/reviewed-source-plan.json','tools/Native/Erlang.NifReallocationObservations/SOURCE-PLAN.json','tools/Native/Erlang.NifVariadic526Observations/source-plan.json','tools/Native/Erlang.NifPrivateData557Observations/source-plan.json']
allowed=set(plans+['.gitattributes','.github/workflows/validate.yml','.github/workflows/nif-pending-native.yml','.github/workflows/nif-reallocation-native.yml','tools/Native/Erlang.NifMapFamily504Observations/source-plan.json','tools/Native/Erlang.NifMapMaterialized505Observations/source-plan.json','tools/Native/Erlang.NifMapReentry505Observations/source-plan.json']);changes=[];pins=[]
def sha(d):return hashlib.sha256(d).hexdigest().upper()
def norm(d,mode):
 assert mode in ['Raw','TextLF','BinaryExact'],mode
 return d.replace(b'\r\n',b'\n') if mode=='TextLF' else d
def refresh(name):
 p=root/name;raw=p.read_bytes();old=json.loads(raw);d=json.loads(raw);key='Inputs' if 'Inputs' in d else 'Files'
 for r in d[key]:
  base=p.parent if r.get('Scope')=='Tool' else root;target=(base/r['Path']).resolve();assert target.is_relative_to(root.resolve());rel=target.relative_to(root).as_posix();data=norm(target.read_bytes(),r['HashMode']);actual=sha(data)
  if actual!=r['Sha256']:
   assert rel in allowed,(name,rel,'unapproved stale input')
   assert sha(norm(subprocess.check_output(['git','show','HEAD:'+rel]),r['HashMode']))==r['Sha256'],(name,rel,'preimage differs')
   changes.append(dict(Plan=name,Path=rel,Old=r['Sha256'],New=actual));r['Sha256']=actual
   for k in ['Bytes','SealedBytes']:
    if k in r:r[k]=len(data)
 assert {k:v for k,v in d.items() if k!=key}=={k:v for k,v in old.items() if k!=key}
 backup=out/'preimages'/name;backup.parent.mkdir(parents=True,exist_ok=True);backup.write_bytes(raw);p.write_bytes((json.dumps(d,indent=2)+'\n').encode());return sha(p.read_bytes())
def pin(name,key,value):
 p=root/name;s=p.read_text();pattern=r'('+re.escape(key)+r': )([0-9A-F]{64})';m=list(re.finditer(pattern,s));assert len(m)==1;pins.append(dict(Path=name,Old=m[0].group(2),New=value));p.write_bytes(re.sub(pattern,lambda m:m.group(1)+value,s).encode())
refresh(plans[0]);pin('.github/workflows/nif-pending-native.yml','REVIEWED_SOURCE_PLAN_SHA256',refresh(plans[1]));pin('.github/workflows/nif-reallocation-native.yml','REVIEWED_REALLOCATION_PLAN_SHA256',refresh(plans[2]));refresh(plans[3]);refresh(plans[4]);count=0
for name in plans:
 p=root/name;d=json.loads(p.read_bytes())
 for r in d.get('Inputs',d.get('Files')):
  base=p.parent if r.get('Scope')=='Tool' else root;data=norm((base/r['Path']).read_bytes(),r['HashMode']);assert sha(data)==r['Sha256'],(name,r['Path']);count+=1
proof=dict(Changes=changes,Pins=pins,AllFiveFinalRowsVerified=count,FinalHashes={n:sha((root/n).read_bytes()) for n in plans},CsharpOrGoldenChanged=False,ClassificationsChanged=False);(out/'proof.json').write_text(json.dumps(proof,indent=2)+'\n');subprocess.run(['git','add','--',*plans,'.github/workflows/nif-pending-native.yml','.github/workflows/nif-reallocation-native.yml'],check=True);print('All',count,'finalrows verified;',len(changes),'guarded bindings refreshed',flush=True)
