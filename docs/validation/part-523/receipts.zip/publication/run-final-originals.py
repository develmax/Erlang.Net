import pathlib,subprocess,json,hashlib,sys,os
root=pathlib.Path.cwd()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()
provider=pathlib.Path(r"D:/Distr/Work/Codex/Erlang.Net/Erlang.Net/artifacts/library376-official-compiler/official-admission.json")
assert sha(provider)=="41CCC2FDE5493D85BEAA21996E12D0885D2919B0D4BF44137D0673DCDC9D5EA6"
head=subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()
metadata=root/"artifacts/spawn520/native-metadata-first/completion.json"
assert sha(metadata)=="AA3DB5D80107CFBDEE87C4DA4934812726BC32EBC78F24BA745CB01DBAD46058"
mode=sys.argv[1]
if mode=="float":
 tool=root/"tools/Runtime/Erlang.OwnedGuest506Observations"
 args=[sys.executable,"-B",str(tool/"capture-float556.py"),"--repository",str(root),"--expected-head",head,"--source-plan-sha256",sha(tool/"source-plan.json"),"--official-admission",str(provider),"--admission-sha256",sha(provider),"--output",str(root/"artifacts/part523/float-v2-final"),"--managed-host",str(root/"tests/Erlang.Tests/bin/Debug/net10.0/Erlang.Tests.dll"),"--metadata-completion",str(metadata),"--metadata-completion-sha256",sha(metadata)]
elif mode=="private":
 tool=root/"tools/Native/Erlang.NifPrivateData557Observations"
 args=[sys.executable,"-B",str(tool/"collect.py"),"--expected-head",head,"--plan-sha256",sha(tool/"source-plan.json"),"--official-admission",str(provider),"--admission-sha256",sha(provider),"--output",str(root/"artifacts/nif-private-data557/part523-final"),"--execute-original","--with-managed"]
else:raise ValueError(mode)
(root/"artifacts/part523"/(mode+"-final-command.json")).write_text(json.dumps(args,indent=2)+"\n")
with (root/"artifacts/part523"/(mode+"-final-coordinator.log")).open("wb") as out:
 result=subprocess.run(args,cwd=root,stdout=out,stderr=subprocess.STDOUT,env=dict(os.environ,DOTNET_PROCESSOR_COUNT="2",PYTHONDONTWRITEBYTECODE="1"))
print(mode,"exit",result.returncode)
raise SystemExit(result.returncode)
