"""Final Part523 bounded index-only two-plan refresh. Never applies/stages/runs a VM."""
import argparse,hashlib,json,pathlib,re,subprocess
ap=argparse.ArgumentParser();ap.add_argument('--repository',type=pathlib.Path,required=True);ap.add_argument('--output',type=pathlib.Path,required=True);a=ap.parse_args();repo=a.repository.resolve();out=a.output.resolve();here=pathlib.Path(__file__).resolve().parent

def require(c,m):
 if not c:raise RuntimeError(m)
def sha(b):return hashlib.sha256(b).hexdigest().upper()
def git(*args):return subprocess.check_output(['git','-C',str(repo),*args])
require(out.is_relative_to(repo/'artifacts') and not out.exists(),'Fresh contained artifact output required')
spec=(here/'reviewed-source-paths.json').read_bytes();require(sha(spec)=='20F9447DF913F7E2DEFCC65E3A0EDAE922FCC19409C29520C61DA3F57733E4F3','Reviewed source path inventory changed');reviewed=set(json.loads(spec));require(len(reviewed)==46,'Expected46 reviewed source paths')
owned='tools/Runtime/Erlang.OwnedGuest506Observations/source-plan.json';pending='tools/Native/Erlang.NifPendingVarargsObservations/reviewed-source-plan.json';realloc='tools/Native/Erlang.NifReallocationObservations/SOURCE-PLAN.json';variadic='tools/Native/Erlang.NifVariadic526Observations/source-plan.json';private='tools/Native/Erlang.NifPrivateData557Observations/source-plan.json';plans=[owned,pending,realloc,variadic,private]
bookkeeping=set(plans)|{'docs/mfa-compatibility.json','docs/module-readiness.json','tools/Runtime/Erlang.OwnedGuest506Observations/seal.py','tools/Native/Erlang.NifVariadic526Observations/seal-source-plan.py','.github/workflows/nif-pending-native.yml','.github/workflows/nif-reallocation-native.yml'}
staged=set(git('diff','--cached','--name-only','-z').decode().split('\0'))-{''};require(reviewed<=staged and staged<=reviewed|bookkeeping|{'docs/native-infrastructure.json'},'Unexpected staged scope: '+str({'MissingReviewed':sorted(reviewed-staged),'Extra':sorted(staged-reviewed-bookkeeping-{'docs/native-infrastructure.json'})}))
objects={}
for item in git('ls-files','--stage','-z').split(b'\0'):
 if not item:continue
 meta,path=item.split(b'\t',1);mode,oid,stage=meta.split();require(stage==b'0','Unmerged index');objects[path.decode()]=oid
reader=subprocess.Popen(['git','-C',str(repo),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
def index(p):
 require(p in objects,'Missing index source: '+p);reader.stdin.write(objects[p]+b'\n');reader.stdin.flush();h=reader.stdout.readline().split();require(len(h)==3 and h[1]==b'blob','Index blob required');n=int(h[2]);b=reader.stdout.read(n);require(len(b)==n and reader.stdout.read(1)==b'\n','Truncated index object');return b
fixture='tools/Runtime/Erlang.OwnedGuest506Observations/fixtures/boxed_float556.erl';collector='tools/Native/Erlang.NifPrivateData557Observations/collect.py'
old_fixture='46F445F7C8C297DDB5EA7AD0490A5344DD133CE683B91E4C8F961D5E5D1EF0C9';new_fixture='C80A710C63FF2AD200401A16C40D650A4A809B53673EE0DBDB03BB58396726C2';old_collector='C0FB55EDD3C3F2095BDFF9C978D2DB83AE7AC18B8F6FA1E53707EA1A5EAAE8A5';new_collector='237E4F0E5CD281081D6B78C520E97277090590322EB487CFC7E3FFEE210DEC4C'
require(sha(index(fixture))==new_fixture and len(index(fixture))==1432,'Staged fixture is not exact frozen V2');require(sha(index(collector))==new_collector,'Staged collector is not exact reviewed final closure fix')
expected={(owned,fixture):('Raw',old_fixture,1400),(private,fixture):('TextLF',old_fixture,None),(private,collector):('Raw',old_collector,None)}
overlay={};oldsha={p:sha(index(p)) for p in plans};changes=[];seen=set();bad=[]
def resolved(row,base):return base+row['Path'] if row.get('Scope')=='Tool' else row['Path']
def normalized(data,mode):
 require(mode in ('Raw','BinaryExact','TextLF'),'Unknown source hash mode: '+str(mode));return data.replace(b'\r\n',b'\n') if mode=='TextLF' else data
def matches(row,data):
 b=normalized(data,row['HashMode']);return row['Sha256'].upper()==sha(b) and all(row[k]==len(b) for k in ('Bytes','SealedBytes') if k in row)
for plan in plans:
 data=json.loads(index(plan));base=plan.rsplit('/',1)[0]+'/'
 for row in data.get('Inputs',data.get('Files')):
  p=resolved(row,base);key=(plan,p)
  require(p!='docs/native-infrastructure.json','New native infrastructure dependency requires separate review')
  if key in expected:
   mode,bound,size=expected[key];require(key not in seen,'Duplicate intended binding');seen.add(key);require(row['HashMode']==mode and row['Sha256'].upper()==bound and (size is None or row.get('Bytes')==size),'Reviewed old row differs: '+str(key))
  elif not matches(row,index(p)):bad.append({'Plan':plan,'Path':p,'BoundSha256':row['Sha256'],'ActualIndexSha256':sha(normalized(index(p),row['HashMode']))})
require(seen==set(expected),'Required exact bindings absent');require(not bad,'Unrelated mismatches: '+json.dumps(bad))
# Replace only intended scalar spans, preserving complete plan lexical bytes.
for plan in [owned,private]:
 original=index(plan);text=original.decode();expected_data=json.loads(original);rows=expected_data.get('Inputs',expected_data.get('Files'));base=plan.rsplit('/',1)[0]+'/'
 for row in rows:
  p=resolved(row,base)
  if (plan,p) not in expected:continue
  path_token='"Path": '+json.dumps(row['Path']);require(text.count(path_token)==1,'Ambiguous exact row path');pos=text.index(path_token);start=text.rfind('{',0,pos);oldrow,used=json.JSONDecoder().raw_decode(text[start:]);require(oldrow==row,'Row lexical admission mismatch');span=text[start:start+used];content=normalized(index(p),row['HashMode'])
  span,n=re.subn(r'("Sha256"\s*:\s*")[A-Fa-f0-9]{64}(")',lambda m:m.group(1)+sha(content)+m.group(2),span);require(n==1,'Expected single row SHA')
  row['Sha256']=sha(content)
  for k in ('Bytes','SealedBytes'):
   if k in row:
    span,n=re.subn(r'("'+k+r'"\s*:\s*)\d+',lambda m:m.group(1)+str(len(content)),span);require(n==1,'Expected single row size');row[k]=len(content)
  text=text[:start]+span+text[start+used:];changes.append({'Plan':plan,'Path':p,'NewSha256':sha(content),'HashMode':row['HashMode']})
 proposal=text.encode();require(json.loads(proposal)==expected_data,'Unauthorized plan semantic delta');overlay[plan]=proposal
# All five plans must match final proposed bytes; unchanged plans stay untouched.
for plan in plans:
 data=json.loads(overlay.get(plan,index(plan)));base=plan.rsplit('/',1)[0]+'/'
 for row in data.get('Inputs',data.get('Files')):
  p=resolved(row,base);require(matches(row,overlay[p] if p in overlay else index(p)),'Final closure mismatch: '+plan+' -> '+p)
# Owned/private workflow pins are dynamic; no old literal pin may remain hidden.
for p in objects:
 if p.startswith('.github/workflows/'):
  b=index(p)
  for plan in overlay:require(oldsha[plan].encode() not in b,'Unexpected literal changed-plan workflow pin: '+p)
out.mkdir(parents=True);emitted=[]
for p,b in overlay.items():
 q=out/'staged-tree'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);emitted.append({'Path':p,'IndexPreimageSha256':oldsha[p],'ProposedSha256':sha(b),'Bytes':len(b)})
receipt={'SourceOnly':True,'Applied':False,'InputAuthority':'Git index objects only','Head':git('rev-parse','HEAD').decode().strip(),'StagedPathCount':len(staged),'Changes':changes,'Files':emitted,'AllFivePlansFinalClosureVerified':True,'NativeInfrastructureDocInputBindings':[],'NativeInfrastructureDocStaged':'docs/native-infrastructure.json' in staged,'WorkflowPinsChanged':False,'LedgerBytesChanged':False,'StatusesChanged':False,'HistoricalEvidenceChanged':False,'FixtureV1FailureRewritten':False}
(out/'proposal.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode());reader.stdin.close();reader.stdout.close();reader.wait();print(json.dumps(receipt,indent=2))
