# Next coherent batch for the24 known contracts

Read-only/source-only audit of PRIMARY, with explicit publication-tree cross-check. No source/document mutation, build, VM, native call, Git, CI or compatibility promotion. contracts.json preserves all24 exact MFA limits and separates current missing behavior from missing whole-protocol evidence.

## Current status and evidence boundary

Authoritative PRIMARY ledger:708 registered commands =180 Verified compatible,24 Known differences,504 Needs verification. PUBLICATION w517fix has the SAME status counts. Both full API_COMPATIBILITY.md reports correctly enumerate180/24/504. Both indexes still say16/30/541: that is a stale generated-index defect, not a new change in API readiness. Both trees and exact file hashes are recorded in documentation-drift.json.

The actual inner resource-family receipts guest541-final-ordinary/managed and guest541-final-reviewed/managed have Captured=true, complete raw/default+deterministic equality, PhysicalCleanupPassed=true and AllFiniteChecksPassed=true, private-owned; FullCompatibilityClaimed=false remains explicit. Their outer preparation receipts say PreparedOnly and must not be mistaken for the actual inner execution receipt. The frozen original530 family/fresh/genuine-upgrade captures are reusable source-bound references. Actual fresh539 after the slot26 fix retained raw mismatches with physical cleanup true, reaching the real file-server prerequisite. Boot543 retained false boot/driver completion; its two complete actor snapshots show advancing code_server/erl_prim_loader path processing, not a proved stuck mailbox. Source548 reduces repeated constructor publication and Parent reports final acceptance in its publication branch; this audit does not independently execute or import that as full-resource parity.

## Recommended implementation batch: one shared resource-policy provider (19 MFAs affected)

Exact direct consumers:

- erlang:spawn_opt/2,3,4,5 and erlang:spawn_request/2,3,4,5 (8).
- proc_lib:spawn_opt/2,3,4,5 and proc_lib:start/5,start_link/5,start_monitor/5 (7).
- erlang:process_info/1,2, erlang:system_flag/2, erlang:statistics/1 (4).

Implement this as a shared source-exact resource/heap/GC family, not19 unrelated parser fixes. Current ProcessSpawnOptions has no min_heap_size/min_bin_vheap_size/max_heap_size case and reaches default badarg. Merely accepting/storing these options would hide the behavior gap; allocation thresholds, VM defaults, child inheritance, maximum policy, logging and process termination effects must actually occur.

Bounded safe order within this batch:

1. Complete actual guest physical-word/header custody and source policy accounting prerequisites. Current owned Storage only covers tuple/cons/map/bitmap; default transfer leaves other Terms unchanged. Native524 headers explicitly own real resource leases but have no526 numeric allocation. Big-number/float/function/reference/heap/refc/sub-binary/native-resource term/header domains and live stack/continuation cells must be classified and represented before public heap totals/budgets can claim them. Preserve physical map hidden children/own-VM identity and all binary/native leases. Do not substitute CLR bytes or pretend payload-only words are a complete ERTS heap.
2. Wire real guest collection through all admitted safe paths. Current public GC only calls CollectOwnedGeneration508 for synchronous actor-owned self; async/other/default paths still collect CLR. Establish same-owner admission, mark/root completeness, cancellation and physical retirement before collecting target-owned graphs; do not collect guest storage under a runtime gate callback.
3. Integrate the pinned heap-sizing/default/maximum policy ON that actual domain. Reuse prepared source audits as input but rebase against real519 allocator/526 headers/current548 sources. Validate fullsweep/source rounding and explicit failure ordering, inheritance, message/binary participation, maximum enforcement and isolated process effects. Native/dirty frames and late cleanup must remain physically pinned.
4. Expose actual process_info physical fields and VM-local completed-collection/reclaimed-word counters only after the domain is complete; then route statistics and system defaults to the same provider. Preserve default-list order, duplicated queries, live/dead/other-owner snapshots and invalid-key behavior.
5. Replay the existing whole24 shared workers/source matrix across ordinary/private and original backend selections. A private opt-in implementation alone does not close a public contract on unsupported/default paths.

This is high leverage groundwork for19 MFAs, not a prediction that19 can be promoted in the next commit. Each promotion still requires complete source/term/effect/error and original evidence. The current actual315 native/proc_lib local error/metadata work is a useful finite prerequisite; it does not cover native heap policy, every option, remote scheduler/alias/autoconnect or whole physical accounting.

## Independent next native behavior: image upgrade/load lifecycle (1 MFA)

load_nif/2 has an explicit current UpgradeUnsupported when a prior image is ready. This is a concrete implementation refusal; resource-family finite success cannot close it. The coherent next native batch is true old/current/pending image admission, real ErlNifEntry.upgrade/private-data transfer, RT_TAKEOVER callback-version publication/rollback, normal-scheduler lifecycle barrier and old DSO pin/unlink/destructor ownership. Reuse corrected530 fresh/genuine-upgrade originals and existing527/529 transactions; do not add another loader framework. Fresh-after-purge and genuine upgrade are distinct source protocols. Keep ordinary/private, reviewed/default, Windows/Linux ABI and thread/dirty/env/native binary/resource lifetime gates separate until actually executed. Root remains sole owner of runtime/native/CI mutation.

This can be independently analyzed/prepared while the19-resource family is developed, but shared native-owner/collector integration must be serialized. Full ABI/crypto boot remains broader than this one lifecycle batch.

## Dependent crash/hibernate batch (4 MFAs)

proc_lib:init_p/3,init_p/5,wake_up/3,hibernate/3 retain physical crash-field, logger and remote-neighbour obligations; wake_up/hibernate also require real physical hibernate effects. The managed report builder currently substitutes undefined for unavailable heap/stack fields. Original Erlang execution will use the same missing process_info provider. Consume the completed resource provider, then validate full crash report/logger formatting/configuration/overload/file effects, neighbour graph and full stacks. Hibernation's current ProcessRuntime catch changes continuation and waits for a message; it is not proof of stack/heap compaction. Do not rewrite the reports to accept undefined or remove numeric leaves.

## Evidence-only work to run in parallel

Historical fresh-receiver failure wording in proc_lib entries is already explicitly rechecked, not a confirmed current constructor bug. Missing remote whole-trace proof is not evidence that all connected spawning is absent. Use existing515 remote profile with genuine distribution/target-local observation in all3 orientations: original→original, managed original-net_kernel→original, original→managed. Its packet is still source-only;129 missing-peer cells are mandatory remote obligations, unlike126 inapplicable no-options crossproduct cells. Preserve compiled-worker launch context/full stack, all named identity aliases/opaque leaves and source/image/body ownership; no leaf dropping, PID/string normalization or synthetic counters.

513 passive typed-rule self-audits and source-only fixture manifests are not managed execution. Root's current native315 observations can be indexed as exact bounded evidence after final-source/CI admission, but cannot replace every whole24 job or current raw original provenance. Reuse successful prepared providers/builds and independent-case failure aggregation, avoiding repeated full regression during unchanged acquisition. Run affected blocks after final production composition and the required full gate once; no retry-count or timing improvement is invented here.

## Documentation repair bundled with next production increment

Existing full-report generator: tools/Build/Erlang.Tool/Program.cs readiness -> Readiness.Generate -> MfaCompatibilityMarkdown.Generate. Command (not executed):

    dotnet run --project tools/Build/Erlang.Tool --no-build -- readiness docs <already-admitted-complete-test-report.json> <fresh-output-directory>

It validates full report/registry/evidence inputs and generates API_COMPATIBILITY.md and module readiness. Do NOT pass a91-case affected report as a canonical full test report. It does not currently generate API_COMPATIBILITY_INDEX.md. The old part354 finalizer hardcodes16/30/541 and also mutates unrelated evidence/docs; do not rerun it. Add a small ledger-driven index renderer to the existing generator in the next production increment, preserving the status definitions and full-report anchors. Parent requested a separate source-only implementation proposal for this repair. No standalone full-CI rerun solely for index repair is needed; use that increment's already-required exact-head gate.
