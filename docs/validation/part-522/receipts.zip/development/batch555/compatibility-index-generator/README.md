# Ledger-driven compatibility index generator555

SOURCE-ONLY proposal. No active source/docs edits, build, VM/native execution, Git or CI. Coordinator reports publication base6dab7b39889e8972873db6e9aabf1e91ba3df4f3; this agent binds the actual current w517fix file bytes, without querying Git. Existing touched preimages are identical in PRIMARY and publication trees. Root owns integration/build/actual generator checks and final output adoption.

## Change

Add MfaCompatibilityIndexMarkdown.cs and its Names file. Readiness.Generate now constructs ONE outputLedger after all existing validation and uses it for BOTH API_COMPATIBILITY.md and API_COMPATIBILITY_INDEX.md. Counts/status sections come only from that admitted ledger; every section is emitted even when count0. Rows use existing safe command formatting, deterministic module/function/arity sorting and links to the actual full-report status anchors. The introductory distinction between presence and full compatibility is preserved. No test counts, API status, limits, evidence, percentages or registry entries are fabricated or updated.

The existing baseline/registry/source/evidence/full-test-report admission path is unchanged; no alternate entry point bypasses it. The index is simply another artifact in the existing explicit output directory. Do not overwrite active docs while generating: use a fresh output directory, inspect counts/links/full-report consistency, then adopt the actual verified output with the next production increment. Do not run the historical354 finalizer (it hardcodes old counts and mutates unrelated files).

## Minimal checks

The EXISTING MfaCompatibilityHostChecks.CheckGenerator is extended, without another harness registration or full golden copy. It checks all-pending output including zero-count Verified/Known sections. A separate mixed synthetic ADMISSION fixture uses1 Verified,1 Known and remaining Pending, with its already-established proof/source fixture mechanisms; these are explicitly synthetic tool inputs, never real API compatibility evidence. It validates summary/category counts, all sorted command rows and link anchors against the generated full report, exactly one occurrence of each heading, total row count, LF output and input ledger bytes remaining unchanged. Existing admission rejection tests remain present and run afterward.

Neither source tests nor generator were executed by this agent. Root can run the existing tool/readiness-explicit-command-compatibility-admission group on final built sources; its output is still tool testing, not a full runtime report. Actual index generation must use the increment's already-admitted complete canonical report, not its91-case affected subset.

## Parent command (not executed)

    dotnet run --project tools/Build/Erlang.Tool --no-build -- readiness docs <already-admitted-complete-test-report.json> <fresh-output-directory>

After that increment's required validation succeeds, copy its actual generated index with the usual current-ledger/evidence/source guards. Current PRIMARY and publication JSON/full reports both180/24/504; their indexes remain historical16/30/541 until regenerated. No active index payload is supplied here because that would claim unexecuted renderer output. No extra standalone full-CI cycle solely for this documentation artifact is requested.
