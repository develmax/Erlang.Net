namespace Erlang;

internal sealed class OwnedPayloadCopyFrame506
{
    internal Term Source { get; }
    internal PreparedOwnedMap517? MapPlan { get; }
    internal PreparedOwnedMapNode526? NodePlan526 { get; }
    internal Term[] Children { get; }
    internal Term[] Copied { get; }
    internal int Index { get; set; }

    internal OwnedPayloadCopyFrame506(Term source, PreparedMapGraph517 maps)
    {
        Source = source;
        MapPlan = source is MapTerm map ? maps.Find(map) : null;
        NodePlan526 = maps.FindNode526(source);
        Children = NodePlan526 is { } nodePlan ? nodePlan.Children526()
            : MapPlan is { } plan ? plan.Children.ToArray() : source switch
            {
                Cons cons => [cons.Head, cons.Tail],
                TupleTerm tuple => tuple.Items.ToArray(),
                _ => []
            };
        Copied = new Term[Children.Length];
    }
}
