from pathlib import Path
import argparse,hashlib,json
p=argparse.ArgumentParser();p.add_argument('checkout');p.add_argument('--apply',action='store_true');a=p.parse_args()
packet=Path(__file__).resolve().parent;checkout=Path(a.checkout).resolve();rows=json.loads((packet/'targets.json').read_text());errors=[]
def sha(b):return hashlib.sha256(b).hexdigest().upper()
for row in rows:
 target=checkout/row['Target'];payload=packet/row['PayloadPath']
 if sha(payload.read_bytes())!=row['PayloadSha256']:errors.append('Payload drift: '+row['Target'])
 if row['ExpectedAbsent']:
  if target.exists():errors.append('Unexpected existing target: '+row['Target'])
 elif not target.exists() or sha(target.read_bytes())!=row['PreimageSha256']:errors.append('Preimage drift: '+row['Target'])
if errors:raise SystemExit('\n'.join(errors))
print(json.dumps({'AllPreimagesMatch':True,'Targets':len(rows),'Apply':a.apply}))
if a.apply:
 for row in rows:
  target=checkout/row['Target'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((packet/row['PayloadPath']).read_bytes())
