# Map publication projection over Part518

Target checkout supplied by parent: D:/Distr/Work/Codex/Erlang.Net/w517fix, expected parent HEAD f14e8666bb441e14f3c56707e2ebe74f6d2a279f. No Git operation was performed to independently verify HEAD; every actual target preimage is byte-bound instead.

79 target files: complete523/526 map graph/storage/header routes,528 eight-file real size correction, local source guest-call boundary and BEAM import guest-call correction, finite controls, exact genuine fixture and its job. SourceSnapshotCaptured precedes Resource113 integration; the snapshot receipt and its 79 raw hashes are retained.

Only two target payloads differ from final primary snapshot:
- ModuleRegistry.BeamPrimitives starts from w517fix and adds only exact MapKeys, HamtChildren and DebugSharing Flat/Shared capability hunks. Unbound native-stub diagnostic accumulation, its names and any boot/capture work are excluded.
- Harness Program starts from w517fix and adds only eight map test registrations plus explicit admitted OriginalMap child. Existing Part518 native metadata/Native7 controls, all earlier registrations and child routes are untouched. Managed513 capture, build-profile, cleanup witness substitutions and unrelated harness work from primary are excluded.

All other 77 payloads are exact final-source snapshots. Allocator519 production first-fit hints remain intact; physical words include real encoded NativeMemory prefixes. Tuple/cons/map roots, HAMT shared structural nodes and flat key aliases are actual backed objects, not synthetic word counters. Native resource/raw-word integration is separate and absent.

## Evidence boundary

Parent reports final primary clean build0/0;85/85 affected controls; genuine compiled original worker matches exact whole deterministic ETF in BOTH profiles, with sender/receiver alias/custody checks and physical settlement/closure equality. Completion artifact artifacts/batch528/map-clean-final-whole/completion.json is retained as an evidence reference. This publication projection has NOT been built or executed: parent must run corresponding acceptance against projected final sources and preserve proof. No contracts are promoted by this packet.

Earlier retained red source run isolated private local-call alias loss; ordinary aliases passed. BEAM red whole output had exactly three private semantic leaves: same false and shared size737→759 in both operand orders; the internal import bridge fixes physical duplicate custody without dropping any values/scalars. The fixture/golden bytes remain unchanged.

## Parent integration

Run py -3 <packet>/apply-projection.py D:/Distr/Work/Codex/Erlang.Net/w517fix for a read-only complete preimage/payload audit. Once all targets match, add --apply; every target is checked before the first write. Git/build/CI/changelog/metadata remain parent-owned. Use targets.json as the complete include list; do not copy source-snapshot wholesale. integration.patch is review material only.

Parent should repeat eight map controls, the85 affected set, exact genuine admitted whole child, Native7/metadata controls and build before publication. Expected shared capability and harness differences are narrow enough to inspect directly.
