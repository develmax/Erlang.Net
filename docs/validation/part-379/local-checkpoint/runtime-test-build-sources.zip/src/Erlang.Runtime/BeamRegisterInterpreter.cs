namespace Erlang;

internal static class BeamRegisterInterpreter
{
    public static ValueTask<Term> Execute(
        ProcessContext context,
        BeamLinkedCode code,
        string name,
        IReadOnlyList<Term> arguments,
        long? diagnosticInstructionBudget = null
    )
        => Execute(
            context,
            code,
            name,
            arguments,
            new(new ModuleCodeImage(code.Structure.Atoms[1]!), code),
            diagnosticInstructionBudget
        );

    internal static ValueTask<Term> Execute(
        ProcessContext context,
        BeamLinkedCode code,
        string name,
        IReadOnlyList<Term> arguments,
        BeamExecutionIdentity execution,
        long? diagnosticInstructionBudget = null
    )
    {
        BeamLinkedFunction function = code.Exports.SingleOrDefault(value => value.Name == name && value.Arity == arguments.Count)
            ?? throw new InvalidDataException(BeamModuleDiagnostics.MissingExport);

        return ExecuteLocal(
            context,
            code,
            function,
            arguments,
            Array.Empty<Term>(),
            execution,
            diagnosticInstructionBudget
        );
    }

    internal static ValueTask<Term> ExecuteLocal(
        ProcessContext context,
        BeamLinkedCode code,
        BeamLinkedFunction function,
        IReadOnlyList<Term> arguments,
        IReadOnlyList<Term> environment,
        long? diagnosticInstructionBudget = null
    )
        => ExecuteLocal(
            context,
            code,
            function,
            arguments,
            environment,
            new(new ModuleCodeImage(code.Structure.Atoms[1]!), code),
            diagnosticInstructionBudget
        );

    internal static ValueTask<Term> ExecuteLocal(
        ProcessContext context,
        BeamLinkedCode code,
        BeamLinkedFunction function,
        IReadOnlyList<Term> arguments,
        IReadOnlyList<Term> environment,
        BeamExecutionIdentity execution,
        long? diagnosticInstructionBudget = null
    )
        => ExecuteCore(
            context,
            code,
            function,
            arguments,
            environment,
            execution,
            SourceCodeAdmissionKind.Continuation,
            diagnosticInstructionBudget
        );

    internal static ValueTask<Term> ExecuteFunction(
        ProcessContext context,
        BeamLinkedCode code,
        BeamLinkedFunction function,
        IReadOnlyList<Term> arguments,
        IReadOnlyList<Term> environment,
        BeamExecutionIdentity execution,
        long? diagnosticInstructionBudget = null
    )
        => ExecuteCore(
            context,
            code,
            function,
            arguments,
            environment,
            execution,
            SourceCodeAdmissionKind.Function,
            diagnosticInstructionBudget
        );

    private static async ValueTask<Term> ExecuteCore(
        ProcessContext context,
        BeamLinkedCode code,
        BeamLinkedFunction function,
        IReadOnlyList<Term> arguments,
        IReadOnlyList<Term> environment,
        BeamExecutionIdentity execution,
        SourceCodeAdmissionKind admission,
        long? diagnosticInstructionBudget
    )
    {
        context.Cancellation.ThrowIfCancellationRequested();
        using var lease = await context.Runtime.Modules.AcquireSourceEntry(context, execution.Image, admission);
        using var flow = lease.Attach(execution.Owner);
        BeamRegisterValidation.Validate(code, function);
        var registers = new BeamRegisterState();
        for (int index = 0; index < arguments.Count; index++)
        {
            registers.Write(index, arguments[index]);
        }
        for (int index = 0; index < environment.Count; index++)
        {
            registers.Write(arguments.Count + index, environment[index]);
        }
        var continuations = new Stack<BeamCallContinuation>();
        var callFrames = new Stack<BeamCallFrame>();
        var functionFrames = new Stack<BeamFunctionScope>();
        var handlers = new Stack<BeamHandlerTag>();
        BeamHandlerTag? pendingHandler = null;
        BeamFunctionScope? functionFrame = null;
        bool entering = true;
        int pc = function.FirstInstructionIndex;
        long diagnosticSteps = 0;

        bool ReturnToCaller()
        {
            functionFrame?.Dispose();
            functionFrame = null;
            if (!continuations.TryPop(out BeamCallContinuation? continuation))
                return false;
            function = continuation.Function;
            pc = continuation.InstructionIndex;
            functionFrame = functionFrames.Pop();
            functionFrame.ClearContinuation();

            return true;
        }

        try
        {
            while (true)
            {
                try
                {
                    if (entering)
                    {
                        if (execution.NativePrimitives.TryGetValue((function.Name, function.Arity), out ErlangFunction? primitive))
                        {
                            Term[] primitiveArguments = Enumerable.Range(0, function.Arity).Select(registers.Read).ToArray();
                            using (context.EnterBeamNative(function.Module, function.Name, function.Arity))
                                registers.Write(0, await RuntimeExceptionCapture.InvokeNative(
                                    context,
                                    primitive,
                                    function.Module,
                                    function.Name,
                                    primitiveArguments
                                ));
                            entering = false;
                            if (!ReturnToCaller())
                                return registers.Read(0);
                            continue;
                        }
                        functionFrame = new BeamFunctionScope(context, function, Enumerable.Range(0, function.Arity).Select(registers.Read).ToArray());
                        int entryLine = function.FirstInstructionIndex - 3;
                        if (entryLine >= 0 && code.Instructions[entryLine].Definition.Name == BeamLinkNames.Line && code.SourceLocations.Count != 0)
                        {
                            int location = (int)code.Instructions[entryLine].Operands[0].Value;
                            if (location >= code.SourceLocations.Count)
                                throw new InvalidDataException(BeamLineNames.Invalid);
                            functionFrame.SetLocation(code.SourceLocations[location]);
                        }
                        entering = false;
                        if (NifImageBindingStore.TryGetValue(execution.Image, out var bindings))
                        {
                            using var native = bindings!.Admit(function.Name, function.Arity);
                            if (native is not null)
                            {
                                Term[] nativeArguments = Enumerable.Range(0, function.Arity).Select(registers.Read).ToArray();
                                registers.Write(0, await native.InvokeAsync(context, nativeArguments));
                                if (!ReturnToCaller())
                                    return registers.Read(0);
                                continue;
                            }
                        }
                    }
                    await context.ReduceAsync();
                    if (diagnosticInstructionBudget is { } budget && diagnosticSteps++ >= budget)
                    {
                        throw new InvalidOperationException(BeamRegisterNames.DiagnosticBudgetExceeded);
                    }
                    if (pc < function.FirstInstructionIndex || pc >= function.EndInstructionIndex)
                    {
                        throw new InvalidDataException(BeamRegisterNames.Unsupported);
                    }
                    BeamInstruction instruction = code.Instructions[pc++];
                    var operands = instruction.Operands;
                    switch (instruction.Definition.Name)
                    {
                        case BeamGeneralOpcodeNames.NilTest:
                        case BeamGeneralOpcodeNames.NonemptyListTest:
                        case BeamGeneralOpcodeNames.ListTest:
                        case BeamGeneralOpcodeNames.TupleTest:
                        case BeamGeneralOpcodeNames.FloatTest:
                        case BeamGeneralOpcodeNames.AtomTest:
                        case BeamGeneralOpcodeNames.TupleArity:
                        case BeamGeneralOpcodeNames.FunctionTest:
                        case BeamGeneralOpcodeNames.ArithmeticEqual:
                        case BeamGeneralOpcodeNames.ExactNotEqual:
                        case BeamGeneralOpcodeNames.GreaterOrEqual:
                        case BeamGeneralOpcodeNames.Less:
                            if (!BeamGeneralTests.Match(code, registers, instruction))
                                pc = Branch(
                                    code,
                                    function,
                                    operands[0],
                                    new ErlangException(ErlangErrorReasons.FunctionClause)
                                );
                            break;
                        case BeamGeneralOpcodeNames.GetList:
                        case BeamGeneralOpcodeNames.GetHead:
                        case BeamGeneralOpcodeNames.GetTail:
                            if (Read(code, registers, operands[0]) is not Cons cell)
                                throw new InvalidDataException(BeamRegisterNames.Unsupported);
                            Term cellHead = cell.Head;
                            Term cellTail = cell.Tail;
                            registers.Write(operands[1], instruction.Definition.Name == BeamGeneralOpcodeNames.GetTail ? cellTail : cellHead);
                            if (instruction.Definition.Name == BeamGeneralOpcodeNames.GetList)
                                registers.Write(operands[2], cellTail);
                            break;
                        case BeamGeneralOpcodeNames.Swap:
                            registers.SwapRegisters(operands[0], operands[1]);
                            break;
                        case BeamGeneralOpcodeNames.Trim:
                            if (!callFrames.TryPeek(out BeamCallFrame? trimFrame) || trimFrame.FunctionEntryLabel != function.EntryLabel
                                || trimFrame.ContinuationDepth != continuations.Count || trimFrame.Slots != operands[0].Value + operands[1].Value)
                                throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);
                            registers.Trim((int)operands[0].Value, (int)operands[1].Value);
                            callFrames.Pop();
                            callFrames.Push(trimFrame with { Slots = (int)operands[1].Value });
                            break;
                        case BeamGeneralOpcodeNames.Jump:
                            pc = Branch(
                                code,
                                function,
                                operands[0],
                                new ErlangException(ErlangErrorReasons.FunctionClause)
                            );
                            break;
                        case BeamGeneralOpcodeNames.SelectValue:
                            Term selectedValue = Read(code, registers, operands[0]);
                            BeamOperand selectedTarget = operands[1];
                            for (int choice = 3; choice < operands.Count; choice += 2)
                            {
                                if (!selectedValue.Equals(Read(code, registers, operands[choice])))
                                    continue;
                                selectedTarget = operands[choice + 1];
                                break;
                            }
                            pc = Branch(
                                code,
                                function,
                                selectedTarget,
                                new ErlangException(ErlangErrorReasons.FunctionClause)
                            );
                            break;
                        case BeamGeneralOpcodeNames.MapFields:
                            if (Read(code, registers, operands[1]) is not MapTerm fieldsMap)
                                throw new InvalidDataException(BeamLinkDiagnostics.OperandRole);
                            if (operands.Skip(3).Any(key => !fieldsMap.TryGet(Read(code, registers, key), out _)))
                                pc = Branch(
                                    code,
                                    function,
                                    operands[0],
                                    new ErlangException(ErlangErrorReasons.FunctionClause)
                                );
                            break;
                        case BeamGeneralOpcodeNames.MapAssociate:
                            registers.CheckLive((int)operands[3].Value);
                            if (Read(code, registers, operands[1]) is not MapTerm sourceMap)
                                throw new InvalidDataException(BeamLinkDiagnostics.OperandRole);
                            var entries = sourceMap.Entries.ToList();
                            for (int pair = 5; pair < operands.Count; pair += 2)
                                entries.Add(new(Read(code, registers, operands[pair]), Read(code, registers, operands[pair + 1])));
                            registers.Write(operands[2], new MapTerm(entries));
                            break;
                        case BeamGeneralOpcodeNames.BinaryBif:
                            BeamExternalImport binaryImport = BeamRegisterValidation.BinaryImport(code, (int)operands[1].Value);
                            Term[] binaryArguments = [Read(code, registers, operands[2]), Read(code, registers, operands[3])];
                            try
                            {
                                Term binaryValue = await BeamExternalImports.Invoke(context, binaryImport, binaryArguments);
                                registers.Write(operands[4], binaryValue);
                            }
                            catch (ErlangException error)
                            {
                                pc = Branch(
                                    code,
                                    function,
                                    operands[0],
                                    error
                                );
                            }
                            break;
                        case BeamGeneralOpcodeNames.UnaryBif:
                        case BeamGeneralOpcodeNames.UnaryGcBif:
                            bool unaryGc = instruction.Definition.Name == BeamGeneralOpcodeNames.UnaryGcBif;
                            int unaryIndex = unaryGc ? 2 : 1;
                            if (unaryGc)
                                registers.CheckLive((int)operands[1].Value);
                            BeamExternalImport unaryImport = BeamRegisterValidation.UnaryImport(code, (int)operands[unaryIndex].Value);
                            try
                            {
                                Term unaryValue = await BeamExternalImports.Invoke(context, unaryImport, [Read(code, registers, operands[unaryIndex + 1])]);
                                registers.Write(operands[unaryIndex + 2], unaryValue);
                            }
                            catch (ErlangException error)
                            {
                                pc = Branch(
                                    code,
                                    function,
                                    operands[0],
                                    error
                                );
                            }
                            break;
                        case BeamGeneralOpcodeNames.CaseEnd:
                            throw new ErlangException(Term.Tuple(Term.A(BeamGeneralOpcodeNames.CaseClause), Read(code, registers, operands[0])));
                        case BeamTryNames.Install:
                            BeamHandlerTag installed = registers.InstallHandlerY(
                                (int)operands[0].Value,
                                new(
                                    function,
                                    code.Labels[(int)operands[1].Value],
                                    continuations.Count,
                                    callFrames.Count,
                                    functionFrames.Count,
                                    registers.FrameDepth
                                )
                            );
                            handlers.Push(installed);
                            break;
                        case BeamTryNames.Case:
                        case BeamTryNames.End:
                            BeamHandlerTag active = registers.ReadHandlerY((int)operands[0].Value);
                            if (!handlers.TryPeek(out BeamHandlerTag? nearest) || !ReferenceEquals(active, nearest)
                                || !ReferenceEquals(active.Checkpoint.Function, function))
                                throw new InvalidDataException(BeamRegisterProtocolNames.Handler);
                            if (instruction.Definition.Name == BeamTryNames.Case)
                            {
                                if (!ReferenceEquals(pendingHandler, active))
                                    throw new InvalidDataException(BeamRegisterProtocolNames.Handler);
                                registers.RequireExceptionMarker(BeamTryParameters.ExceptionMarkerRegister, active);
                                BeamSavedTrace caughtTrace = registers.ReadSavedTrace(BeamTryParameters.SavedTraceRegister);
                                registers.Write(BeamTryParameters.CaughtClassRegister, Term.A(caughtTrace.ExceptionClass));
                                registers.ClearXExcept(
                                    BeamTryParameters.CaughtClassRegister,
                                    BeamTryParameters.ReasonRegister,
                                    BeamTryParameters.SavedTraceRegister
                                );
                                pendingHandler = null;
                            }
                            else if (pendingHandler is not null)
                                throw new InvalidDataException(BeamRegisterProtocolNames.Handler);
                            registers.RemoveHandlerY((int)operands[0].Value, active);
                            handlers.Pop();
                            break;
                        case BeamTryNames.BuildStacktrace:
                            BeamSavedTrace cooked = registers.ReadSavedTrace(BeamTryParameters.CookedTraceRegister);
                            registers.Write(BeamTryParameters.CookedTraceRegister, cooked.StackTraceTerm);
                            registers.ClearXExcept(BeamTryParameters.CookedTraceRegister);
                            break;
                        case BeamTryNames.CaseEnd:
                            throw new ErlangException(Term.Tuple(Term.A(ErlangErrorReasons.TryClause), Read(code, registers, operands[0])));
                        case BeamTryNames.Raise:
                            throw BeamTryExecution.Raise(
                                registers.ReadSlot(operands[0]).ReadSavedTrace(),
                                Read(code, registers, operands[1])
                            );
                        case BeamTryNames.RawRaise:
                            Term raisedClass = registers.Read(BeamTryParameters.RawRaiseClassRegister);
                            Term raisedReason = registers.Read(BeamTryParameters.RawRaiseReasonRegister);
                            BeamSavedTrace raisedTrace = registers.ReadSavedTrace(BeamTryParameters.RawRaiseTraceRegister);
                            if (raisedClass is Atom { Name: ErlangExceptionClasses.Error or ErlangExceptionClasses.Exit or ErlangExceptionClasses.Throw } validClass)
                                throw BeamTryExecution.Raise(raisedTrace, raisedReason, validClass.Name);
                            registers.Write(BeamTryParameters.RawRaiseClassRegister, Term.A(ErlangErrorReasons.BadArgument));
                            break;
                        case BeamNifNames.Start:
                        case BeamLinkNames.OnLoad:
                            break;
                        case BeamOnLoadNames.InitY:
                            foreach (BeamOperand operand in operands.Skip(BeamFrameParameters.TupleCountPrefix))
                                registers.InitializeY((int)operand.Value);
                            break;
                        case BeamOnLoadNames.BadMatch:
                            throw new ErlangException(Term.Tuple(Term.A(BeamOnLoadNames.BadMatchReason), Read(code, registers, operands[0])));
                        case BeamOnLoadNames.PidTest:
                            if (Read(code, registers, operands[1]) is not Pid)
                                pc = Branch(
                                    code,
                                    function,
                                    operands[0],
                                    new ErlangException(ErlangErrorReasons.FunctionClause)
                                );
                            break;
                        case BeamOnLoadNames.TaggedTupleTest:
                            if (Read(code, registers, operands[1]) is not TupleTerm tuple
                                || tuple.Items.Count != operands[2].Value
                                || tuple.Items.Count == 0
                                || !tuple.Items[0].Equals(Read(code, registers, operands[3])))
                                pc = Branch(
                                    code,
                                    function,
                                    operands[0],
                                    new ErlangException(ErlangErrorReasons.FunctionClause)
                                );
                            break;
                        case BeamOnLoadNames.TupleElement:
                            registers.Write(operands[2], ((TupleTerm)Read(code, registers, operands[0])).Items[(int)operands[1].Value]);
                            break;
                        case BeamLinkNames.ExternalCall:
                        case BeamOnLoadNames.ExternalLast:
                            BeamExternalImport import = BeamExternalImports.Resolve(code, (int)operands[1].Value);
                            registers.CheckLive(import.Arity);
                            Term[] importedArguments = Enumerable.Range(0, import.Arity).Select(registers.Read).ToArray();
                            BeamCallFrame? externalLastFrame = null;
                            bool sourceLoadNif = BeamExternalImports.IsSourceLoadNif(import);
                            if (instruction.Definition.Name == BeamOnLoadNames.ExternalLast)
                            {
                                if (!callFrames.TryPeek(out externalLastFrame) || externalLastFrame.FunctionEntryLabel != function.EntryLabel
                                    || externalLastFrame.ContinuationDepth != continuations.Count || externalLastFrame.Slots != operands[2].Value)
                                    throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);
                                if (!sourceLoadNif)
                                {
                                    callFrames.Pop();
                                    registers.Deallocate(externalLastFrame.Slots);
                                }
                            }
                            if (instruction.Definition.Name == BeamOnLoadNames.ExternalLast && !BeamExternalImports.IsNativePrimitive(import))
                            {
                                functionFrame?.Dispose();
                                functionFrame = null;
                            }
                            if (instruction.Definition.Name == BeamLinkNames.ExternalCall)
                                functionFrame!.SetContinuation(code, pc);
                            Term imported = await BeamExternalImports.Invoke(context, import, importedArguments);
                            if (instruction.Definition.Name == BeamLinkNames.ExternalCall)
                                functionFrame!.ClearContinuation();
                            if (sourceLoadNif && externalLastFrame is not null)
                            {
                                callFrames.Pop();
                                registers.Deallocate(externalLastFrame.Slots);
                            }
                            registers.Write(0, imported);
                            if (instruction.Definition.Name == BeamOnLoadNames.ExternalLast)
                            {
                                if (!ReturnToCaller())
                                    return imported;
                            }
                            break;
                        case BeamLinkNames.Label:
                            break;
                        case BeamLinkNames.Line:
                            if (code.SourceLocations.Count != 0)
                            {
                                if (operands[0].Value >= code.SourceLocations.Count)
                                    throw new InvalidDataException(BeamLineNames.Invalid);
                                functionFrame!.SetLocation(code.SourceLocations[(int)operands[0].Value]);
                            }
                            break;
                        case BeamLinkNames.Allocate:
                        case BeamLinkNames.AllocateHeap:
                            registers.CheckLive((int)operands[instruction.Definition.Name == BeamLinkNames.AllocateHeap ? 2 : 1].Value);
                            continuations.TryPeek(out BeamCallContinuation? savedContinuation);
                            callFrames.Push(new(
                                function.EntryLabel,
                                continuations.Count,
                                savedContinuation,
                                (int)operands[0].Value
                            ));
                            registers.Allocate((int)operands[0].Value);
                            break;
                        case BeamLinkNames.Deallocate:
                            if (!callFrames.TryPop(out BeamCallFrame? frame) || frame.FunctionEntryLabel != function.EntryLabel || frame.ContinuationDepth != continuations.Count || frame.Slots != operands[0].Value)
                                throw new InvalidDataException(BeamReceiveNames.InvalidFrame);
                            registers.Deallocate(frame.Slots);
                            if (frame.SavedContinuation is not null)
                            {
                                _ = continuations.Pop();
                                continuations.Push(frame.SavedContinuation);
                            }
                            break;
                        case BeamLambdaNames.Create:
                            Term[] captured = operands.Skip(BeamLambdaNames.EnvironmentPrefixOperands).Select(operand => Read(code, registers, operand)).ToArray();
                            FunctionTerm closure = BeamClosureFactory.Create(
                                code,
                                (int)operands[0].Value,
                                captured,
                                execution
                            );
                            registers.Write(operands[1], closure);
                            break;
                        case BeamGeneralOpcodeNames.DynamicCall:
                        case BeamLambdaNames.Call:
                            bool dynamicCall = instruction.Definition.Name == BeamGeneralOpcodeNames.DynamicCall;
                            int arity = (int)operands[dynamicCall ? 0 : 1].Value;
                            registers.CheckLive(arity);
                            Term callee = dynamicCall ? registers.Read(arity) : Read(code, registers, operands[2]);
                            if (!dynamicCall && operands[0].Kind == BeamOperandParameters.Unsigned)
                                BeamClosureFactory.RequireKnownTarget(callee, code, (int)operands[0].Value);
                            if (callee is not FunctionTerm callable)
                                throw new ErlangException(Term.Tuple(Term.A(ErlangErrorReasons.BadFunction), callee));
                            Term[] funArguments = Enumerable.Range(0, arity).Select(registers.Read).ToArray();
                            bool tailFun = BeamFunTailProtocol.TryDeallocation(
                                code,
                                function,
                                pc,
                                out int funSlots
                            ) && callable.Arity == arity;
                            if (tailFun)
                            {
                                if (!callFrames.TryPeek(out BeamCallFrame? funFrame) || funFrame.FunctionEntryLabel != function.EntryLabel
                                    || funFrame.ContinuationDepth != continuations.Count || funFrame.Slots != funSlots)
                                    throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);
                                registers.Deallocate(funFrame.Slots);
                                callFrames.Pop();
                                if (funFrame.SavedContinuation is not null)
                                {
                                    continuations.Pop();
                                    continuations.Push(funFrame.SavedContinuation);
                                }
                                functionFrame?.Dispose();
                                functionFrame = null;
                            }
                            else
                                functionFrame!.SetContinuation(code, pc);
                            Term funResult = await callable.Invoke(context, Array.AsReadOnly(funArguments));
                            functionFrame?.ClearContinuation();
                            registers.Write(0, funResult);
                            if (tailFun && !ReturnToCaller())
                                return funResult;
                            break;
                        case BeamLinkNames.Bif:
                            BeamRegisterValidation.SelfImport(code, (int)operands[0].Value);
                            registers.Write(operands[1], await context.Runtime.Modules.Call(context, ErlangModuleNames.Module, ErlangModuleNames.Self));
                            break;
                        case BeamLinkNames.Send:
                            {
                                Term recipient = registers.Read(0);
                                Term sentMessage = registers.Read(1);
                                await ErlangOperatorValues.TrySendAsync(context, recipient, sentMessage);
                                registers.Write(0, sentMessage);
                                break;
                            }
                        case BeamLinkNames.LoopReceive:
                            BeamReceivePlan plan = BeamReceivePlanner.Build(code, function, pc - 1);
                            BeamRegisterState before = registers.Clone();
                            BeamReceiveSelection? selected = await context.ReceiveAsync(message => BeamReceiveMatcher.Select(
                                code,
                                plan,
                                before,
                                message
                            ), plan.Timeout);
                            if (selected is null)
                                pc = plan.TimeoutInstructionIndex + 1;
                            else
                            {
                                registers = selected.Registers;
                                pc = selected.NextInstructionIndex;
                            }
                            break;
                        case BeamLinkNames.Move:
                            if (operands[0].Kind is BeamOperandParameters.X or BeamOperandParameters.Y)
                                registers.CopyRegister(operands[0], operands[1]);
                            else
                                registers.Write(operands[1], Read(code, registers, operands[0]));
                            break;
                        case BeamLinkNames.Return:
                            Term result = registers.Read(0);
                            if (!ReturnToCaller())
                                return result;
                            break;
                        case BeamRegisterNames.Call:
                        case BeamLinkNames.LocalCall:
                        case BeamGeneralOpcodeNames.LocalLast:
                            registers.CheckLive((int)operands[0].Value);
                            if (instruction.Definition.Name == BeamGeneralOpcodeNames.LocalLast)
                            {
                                if (!callFrames.TryPop(out BeamCallFrame? lastFrame) || lastFrame.FunctionEntryLabel != function.EntryLabel
                                    || lastFrame.ContinuationDepth != continuations.Count || lastFrame.Slots != operands[2].Value)
                                    throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);
                                registers.Deallocate(lastFrame.Slots);
                                if (lastFrame.SavedContinuation is not null)
                                {
                                    continuations.Pop();
                                    continuations.Push(lastFrame.SavedContinuation);
                                }
                            }
                            if (instruction.Definition.Name == BeamRegisterNames.Call)
                            {
                                functionFrame!.SetContinuation(code, pc);
                                continuations.Push(new(function, pc));
                                functionFrames.Push(functionFrame!);
                            }
                            else
                            {
                                functionFrame?.Dispose();
                            }
                            functionFrame = null;
                            entering = true;
                            function = code.Functions.Single(target => target.EntryLabel == operands[1].Value);
                            pc = function.FirstInstructionIndex;
                            break;
                        case BeamLinkNames.IntegerTest:
                            if (Read(code, registers, operands[1]) is not Integer)
                            {
                                pc = Branch(
                                    code,
                                    function,
                                    operands[0],
                                    new ErlangException(ErlangErrorReasons.FunctionClause)
                                );
                            }
                            break;
                        case BeamLinkNames.EqualityTest:
                            if (!Read(code, registers, operands[1]).Equals(Read(code, registers, operands[2])))
                            {
                                pc = Branch(
                                    code,
                                    function,
                                    operands[0],
                                    new ErlangException(ErlangErrorReasons.FunctionClause)
                                );
                            }
                            break;
                        case BeamLinkNames.ExternalTailCall:
                            registers.CheckLive((int)operands[0].Value);
                            BeamExternalImport tailImport = BeamExternalImports.Resolve(code, (int)operands[1].Value);
                            Term[] tailArguments = Enumerable.Range(0, tailImport.Arity).Select(registers.Read).ToArray();
                            if (!BeamExternalImports.IsNativePrimitive(tailImport))
                            {
                                functionFrame?.Dispose();
                                functionFrame = null;
                            }
                            Term externalResult = await BeamExternalImports.Invoke(context, tailImport, tailArguments);
                            registers.Write(0, externalResult);
                            if (!ReturnToCaller())
                                return externalResult;
                            break;
                        case BeamLinkNames.GuardBif:
                            registers.CheckLive((int)operands[1].Value);
                            string arithmetic = BeamRegisterValidation.ArithmeticImport(code, (int)operands[2].Value);
                            try
                            {
                                Term value = await context.Runtime.Modules.Call(
                                    context,
                                    BeamRegisterNames.Erlang,
                                    arithmetic,
                                    Read(code, registers, operands[3]),
                                    Read(code, registers, operands[4])
                                );
                                registers.Write(operands[5], value);
                            }
                            catch (ErlangException error)
                            {
                                pc = Branch(
                                    code,
                                    function,
                                    operands[0],
                                    error
                                );
                            }
                            break;
                        case BeamLinkNames.HeapTest:
                            registers.CheckLive((int)operands[1].Value);
                            break;
                        case BeamLinkNames.PutList:
                            Term head = Read(code, registers, operands[0]);
                            Term tail = Read(code, registers, operands[1]);
                            registers.Write(operands[2], new Cons(head, tail));
                            break;
                        case BeamLinkNames.PutTuple:
                            Term[] items = operands.Skip(BeamLinkParameters.TupleListPrefixOperands).Select(operand => Read(code, registers, operand)).ToArray();
                            registers.Write(operands[0], new TupleTerm(items));
                            break;
                        default:
                            throw new NotSupportedException(BeamRegisterNames.Unsupported);
                    }
                }
                catch (ErlangException error) when (handlers.Count != 0)
                {
                    // Capture before disposing any visible source frame. Handler execution
                    // must never recapture or truncate a previously saved trace.
                    ErlangException capturedError = context.CaptureSourceFailure(
                        error,
                        error.Reason is Atom { Name: ErlangErrorReasons.FunctionClause } ? functionFrame?.Arguments : null
                    );
                    var savedTrace = new BeamSavedTrace(capturedError);
                    BeamHandlerTag target = handlers.Peek();
                    BeamHandlerCheckpoint checkpoint = target.Checkpoint;
                    if (continuations.Count < checkpoint.ContinuationDepth
                        || callFrames.Count < checkpoint.CallFrameDepth
                        || functionFrames.Count < checkpoint.FunctionScopeDepth)
                        throw new InvalidDataException(BeamRegisterProtocolNames.Handler);
                    registers.UnwindToHandler(target);
                    while (functionFrames.Count > checkpoint.FunctionScopeDepth)
                    {
                        functionFrame?.Dispose();
                        functionFrame = functionFrames.Pop();
                    }
                    if (functionFrame is null)
                        throw new InvalidDataException(BeamRegisterProtocolNames.Handler);
                    functionFrame.ClearContinuation();
                    while (continuations.Count > checkpoint.ContinuationDepth)
                        continuations.Pop();
                    while (callFrames.Count > checkpoint.CallFrameDepth)
                        callFrames.Pop();
                    function = checkpoint.Function;
                    pc = checkpoint.HandlerInstructionIndex;
                    entering = false;
                    registers.ClearXExcept();
                    registers.WriteExceptionMarkerX(BeamTryParameters.ExceptionMarkerRegister, target);
                    registers.Write(BeamTryParameters.ReasonRegister, savedTrace.Reason);
                    registers.WriteSavedTrace(BeamTryParameters.SavedTraceRegister, savedTrace);
                    registers.Write(BeamTryParameters.EntryClassRegister, Term.A(savedTrace.ExceptionClass));
                    pendingHandler = target;
                }
            }
        }
        catch (ErlangException error)
        {
            throw context.CaptureSourceFailure(error, error.Reason is Atom { Name: ErlangErrorReasons.FunctionClause } ? functionFrame?.Arguments : null);
        }
        finally
        {
            functionFrame?.Dispose();
            while (functionFrames.TryPop(out var suspendedFrame))
                suspendedFrame.Dispose();
        }
    }

    private static int Branch(
        BeamLinkedCode code,
        BeamLinkedFunction function,
        BeamOperand target,
        ErlangException error
    )
    {
        if (target.Kind == BeamOperandParameters.Failure)
        {
            throw error;
        }
        if (target.Value == function.InfoLabel)
        {
            throw new ErlangException(ErlangErrorReasons.FunctionClause);
        }

        return target.Value == function.EntryLabel ? function.FirstInstructionIndex : code.Labels[(int)target.Value];
    }

    internal static Term Read(BeamLinkedCode code, BeamRegisterState registers, BeamOperand operand) => operand.Kind switch
    {
        BeamOperandParameters.X => registers.Read((int)operand.Value),
        BeamOperandParameters.Y => registers.ReadY((int)operand.Value),
        BeamOperandParameters.Integer => new Integer(operand.Value),
        BeamOperandParameters.Atom => Term.A(code.Structure.Atoms[(int)operand.Value]!),
        BeamOperandParameters.Nil => Nil.Value,
        BeamOperandParameters.LiteralValue => code.Structure.Literals[(int)operand.Value],
        _ => throw new NotSupportedException(BeamRegisterNames.Unsupported)
    };
}
