namespace Erlang;

internal static class BeamNoReturnAnalysis
{
    internal static bool Import(BeamLinkedCode code, int index)
    {
        BeamImport import = code.Structure.Imports[index];
        if (code.Structure.Atoms[import.ModuleAtomIndex] != ErlangModuleNames.Module)
            return false;
        string? name = code.Structure.Atoms[import.FunctionAtomIndex];

        return (name is ErlangModuleNames.Throw or ErlangModuleNames.Exit) && import.Arity == 1
            || name == ErlangModuleNames.Error && import.Arity is 1 or 2;
    }

    internal static bool Local(BeamLinkedCode code, int entryLabel)
    {
        BeamLinkedFunction target = code.Functions.Single(function => function.EntryLabel == entryLabel);
        // Only prove a straight-line forwarding body. Other local control flow
        // remains conservative; an ordinary return must never reach try_case.
        for (int pc = target.FirstInstructionIndex; pc < target.EndInstructionIndex; pc++)
        {
            BeamInstruction instruction = code.Instructions[pc];
            switch (instruction.Definition.Name)
            {
                case BeamLinkNames.Label:
                case BeamLinkNames.Line:
                case BeamLinkNames.Move:
                    continue;
                case BeamLinkNames.ExternalTailCall:
                    return Import(code, (int)instruction.Operands[1].Value);
                default:
                    return false;
            }
        }

        return false;
    }
}
