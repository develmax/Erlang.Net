namespace Erlang;

internal static class BeamGeneralOpcodeNames
{
    internal const string BinaryBif = "bif2";
    internal const string DynamicCall = "call_fun";
    internal const string MapFields = "has_map_fields";
    internal const string MapAssociate = "put_map_assoc";
    internal const string ArithmeticEqual = "is_eq";
    internal const string ExactNotEqual = "is_ne_exact";
    internal const string FloatTest = "is_float";
    internal const string NilTest = "is_nil";
    internal const string NonemptyListTest = "is_nonempty_list";
    internal const string ListTest = "is_list";
    internal const string TupleTest = "is_tuple";
    internal const string AtomTest = "is_atom";
    internal const string FunctionTest = "is_function2";
    internal const string TupleArity = "test_arity";
    internal const string GetList = "get_list";
    internal const string GetHead = "get_hd";
    internal const string GetTail = "get_tl";
    internal const string UnaryBif = "bif1";
    internal const string UnaryGcBif = "gc_bif1";
    internal const string Jump = "jump";
    internal const string Trim = "trim";
    internal const string Swap = "swap";
    internal const string SelectValue = "select_val";
    internal const string CaseEnd = "case_end";
    internal const string GreaterOrEqual = "is_ge";
    internal const string Less = "is_lt";
    internal const string LocalLast = "call_last";
    internal const string CaseClause = "case_clause";
}
