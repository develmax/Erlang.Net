using System.Numerics;
namespace Erlang;

internal static class BeamFrameValidation
{
    internal static void Validate(BeamLinkedCode code, BeamLinkedFunction function, IReadOnlyDictionary<int, BeamReceivePlan> receives)
    {
        if (code.Instructions.Skip(function.FirstInstructionIndex)
            .Take(function.EndInstructionIndex - function.FirstInstructionIndex)
            .Any(instruction => instruction.Definition.Name is BeamTryNames.Install
                or BeamTryNames.Case or BeamTryNames.End or BeamTryNames.BuildStacktrace
                or BeamTryNames.Raise or BeamTryNames.RawRaise or BeamTryNames.CaseEnd))
        {
            ValidateExceptional(code, function, receives);

            return;
        }

        var work = new Stack<(int Pc, int Slots, BigInteger Initialized)>();
        var seen = new Dictionary<int, (int Slots, BigInteger Initialized)>();
        work.Push((function.FirstInstructionIndex, BeamFrameParameters.NoFrame, BigInteger.Zero));

        void Next(int pc, int slots, BigInteger initialized)
        {
            if (pc < function.FirstInstructionIndex || pc >= function.EndInstructionIndex)
                throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);
            work.Push((pc, slots, initialized));
        }
        while (work.TryPop(out var current))
        {
            int slots = current.Slots;
            BigInteger initialized = current.Initialized;
            if (seen.TryGetValue(current.Pc, out var previous))
            {
                if (slots != previous.Slots)
                    throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);
                initialized &= previous.Initialized;
                if (initialized == previous.Initialized)
                    continue;
            }
            seen[current.Pc] = (slots, initialized);
            BeamInstruction instruction = code.Instructions[current.Pc];
            var operands = instruction.Operands;

            void Y(BeamOperand operand, bool source)
            {
                if (operand.Kind != BeamOperandParameters.Y)
                    return;
                int index = (int)operand.Value;
                if (index < 0 || index >= slots || source && (initialized & (BigInteger.One << index)) == 0)
                    throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);
            }

            void Write(BeamOperand operand)
            {
                Y(operand, false);
                if (operand.Kind == BeamOperandParameters.Y)
                    initialized |= BigInteger.One << (int)operand.Value;
            }

            void Fail(BeamOperand target)
            {
                if (target.Kind == BeamOperandParameters.Label && target.Value != function.InfoLabel)
                    Next(target.Value == function.EntryLabel ? function.FirstInstructionIndex : code.Labels[(int)target.Value], slots, initialized);
            }
            switch (instruction.Definition.Name)
            {
                case BeamGeneralOpcodeNames.Trim:
                    if (slots == BeamFrameParameters.NoFrame || operands[0].Value + operands[1].Value != slots)
                        throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);
                    slots = (int)operands[1].Value;
                    initialized >>= (int)operands[0].Value;
                    break;
                case BeamGeneralOpcodeNames.Swap:
                    Y(operands[0], true);
                    Y(operands[1], true);
                    Write(operands[0]);
                    Write(operands[1]);
                    break;
                case BeamGeneralOpcodeNames.GetList:
                    Y(operands[0], true);
                    Write(operands[1]);
                    Write(operands[2]);
                    break;
                case BeamGeneralOpcodeNames.GetHead:
                case BeamGeneralOpcodeNames.GetTail:
                    Y(operands[0], true);
                    Write(operands[1]);
                    break;
                case BeamGeneralOpcodeNames.NilTest:
                case BeamGeneralOpcodeNames.NonemptyListTest:
                case BeamGeneralOpcodeNames.ListTest:
                case BeamGeneralOpcodeNames.TupleTest:
                case BeamGeneralOpcodeNames.FloatTest:
                case BeamGeneralOpcodeNames.AtomTest:
                case BeamGeneralOpcodeNames.TupleArity:
                    Y(operands[1], true);
                    Fail(operands[0]);
                    break;
                case BeamGeneralOpcodeNames.FunctionTest:
                case BeamGeneralOpcodeNames.ArithmeticEqual:
                case BeamGeneralOpcodeNames.ExactNotEqual:
                case BeamGeneralOpcodeNames.GreaterOrEqual:
                case BeamGeneralOpcodeNames.Less:
                    Y(operands[1], true);
                    Y(operands[2], true);
                    Fail(operands[0]);
                    break;
                case BeamGeneralOpcodeNames.Jump:
                    Fail(operands[0]);
                    continue;
                case BeamGeneralOpcodeNames.SelectValue:
                    Y(operands[0], true);
                    Fail(operands[1]);
                    for (int target = 4; target < operands.Count; target += 2)
                        Fail(operands[target]);
                    continue;
                case BeamGeneralOpcodeNames.BinaryBif:
                    Y(operands[2], true);
                    Y(operands[3], true);
                    Fail(operands[0]);
                    Write(operands[4]);
                    break;
                case BeamGeneralOpcodeNames.MapFields:
                    Y(operands[1], true);
                    foreach (BeamOperand key in operands.Skip(3))
                        Y(key, true);
                    Fail(operands[0]);
                    break;
                case BeamGeneralOpcodeNames.MapAssociate:
                    if (slots != BeamFrameParameters.NoFrame && initialized != (BigInteger.One << slots) - BigInteger.One)
                        throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);
                    Y(operands[1], true);
                    foreach (BeamOperand value in operands.Skip(5))
                        Y(value, true);
                    Write(operands[2]);
                    break;
                case BeamGeneralOpcodeNames.UnaryBif:
                    Y(operands[2], true);
                    Fail(operands[0]);
                    Write(operands[3]);
                    break;
                case BeamGeneralOpcodeNames.UnaryGcBif:
                    Y(operands[3], true);
                    Fail(operands[0]);
                    Write(operands[4]);
                    break;
                case BeamGeneralOpcodeNames.LocalLast:
                    if (slots != operands[2].Value)
                        throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);
                    continue;
                case BeamGeneralOpcodeNames.CaseEnd:
                    Y(operands[0], true);
                    continue;
                case BeamLinkNames.Allocate:
                case BeamLinkNames.AllocateHeap:
                    if (slots != BeamFrameParameters.NoFrame)
                        throw new NotSupportedException(BeamOnLoadDiagnostics.Frame);
                    slots = (int)operands[0].Value;
                    initialized = BigInteger.Zero;
                    break;
                case BeamLinkNames.Deallocate:
                    if (slots != operands[0].Value)
                        throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);
                    slots = BeamFrameParameters.NoFrame;
                    initialized = BigInteger.Zero;
                    break;
                case BeamOnLoadNames.InitY:
                    foreach (BeamOperand operand in operands.Skip(BeamFrameParameters.TupleCountPrefix))
                    {
                        Y(operand, false);
                        initialized |= BigInteger.One << (int)operand.Value;
                    }
                    break;
                case BeamLinkNames.Move:
                    Y(operands[0], true);
                    Write(operands[1]);
                    break;
                case BeamLinkNames.Bif:
                    Write(operands[1]);
                    break;
                case BeamLinkNames.PutTuple:
                    foreach (BeamOperand operand in operands.Skip(BeamLinkParameters.TupleListPrefixOperands))
                        Y(operand, true);
                    Write(operands[0]);
                    break;
                case BeamLinkNames.PutList:
                    Y(operands[0], true);
                    Y(operands[1], true);
                    Write(operands[2]);
                    break;
                case BeamOnLoadNames.TupleElement:
                    Y(operands[0], true);
                    Write(operands[2]);
                    break;
                case BeamLinkNames.LoopReceive:
                    BeamReceivePlan plan = receives[current.Pc];
                    foreach (int node in plan.MatcherInstructions)
                    {
                        BeamInstruction matcher = code.Instructions[node];
                        foreach (BeamOperand operand in matcher.Operands)
                            Y(operand, true);
                        if (matcher.Definition.Name == BeamLinkNames.RemoveMessage)
                            Next(node + 1, slots, initialized);
                    }
                    Next(plan.TimeoutInstructionIndex + 1, slots, initialized);
                    continue;
                case BeamRegisterNames.Call:
                case BeamGeneralOpcodeNames.DynamicCall:
                case BeamLambdaNames.Call:
                case BeamLinkNames.ExternalCall:
                    if (slots == BeamFrameParameters.NoFrame)
                        throw new NotSupportedException(BeamOnLoadDiagnostics.Frame);
                    if (instruction.Definition.Name == BeamLambdaNames.Call)
                        Y(operands[2], true);
                    break;
                case BeamLinkNames.GuardBif:
                    Y(operands[3], true);
                    Y(operands[4], true);
                    Fail(operands[0]);
                    Write(operands[5]);
                    break;
                case BeamLinkNames.IntegerTest:
                case BeamOnLoadNames.PidTest:
                case BeamOnLoadNames.TaggedTupleTest:
                    Y(operands[1], true);
                    Fail(operands[0]);
                    break;
                case BeamLinkNames.EqualityTest:
                    Y(operands[1], true);
                    Y(operands[2], true);
                    Fail(operands[0]);
                    break;
                case BeamOnLoadNames.BadMatch:
                    Y(operands[0], true);
                    continue;
                case BeamOnLoadNames.ExternalLast:
                    if (slots != operands[2].Value)
                        throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);
                    continue;
                case BeamLinkNames.Return:
                case BeamLinkNames.LocalCall:
                case BeamLinkNames.ExternalTailCall:
                    if (slots != BeamFrameParameters.NoFrame)
                        throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);
                    continue;
            }
            Next(current.Pc + 1, slots, initialized);
        }
    }

    private sealed record Handler(
        int Installation,
        int Slot,
        int Target,
        Handler? Parent
    );

    private sealed record ExceptionalState(
        int Pc,
        int Slots,
        BigInteger TermY,
        BigInteger RawY,
        BigInteger TermX,
        BigInteger RawX,
        BigInteger ClassY,
        BigInteger ClassX,
        Handler? Handler,
        int Pending
    );

    private static void ValidateExceptional(
        BeamLinkedCode code,
        BeamLinkedFunction function,
        IReadOnlyDictionary<int, BeamReceivePlan> receives
    )
    {
        // The receive planner currently describes matcher terms, not typed opaque values.
        // Refuse this combination until its exceptional transfer has a separate proof.
        if (receives.Count != 0)
            throw new NotSupportedException(BeamOnLoadDiagnostics.Frame);

        const int NoPendingHandler = -1;
        var handlerTargets = new HashSet<int>();
        for (int index = function.FirstInstructionIndex; index < function.EndInstructionIndex; index++)
        {
            BeamInstruction candidate = code.Instructions[index];
            if (candidate.Definition.Name == BeamTryNames.Install)
                handlerTargets.Add(code.Labels[(int)candidate.Operands[1].Value]);
        }
        var work = new Stack<ExceptionalState>();
        var seen = new Dictionary<int, ExceptionalState>();
        work.Push(new(
            function.FirstInstructionIndex,
            BeamFrameParameters.NoFrame,
            BigInteger.Zero,
            BigInteger.Zero,
            Mask(function.Arity),
            BigInteger.Zero,
            BigInteger.Zero,
            BigInteger.Zero,
            null,
            NoPendingHandler
        ));
        while (work.TryPop(out ExceptionalState? state))
        {
            if (seen.TryGetValue(state.Pc, out ExceptionalState? prior))
            {
                if (state.Slots != prior.Slots || state.Handler != prior.Handler || state.Pending != prior.Pending)
                    throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);
                state = state with
                {
                    TermY = state.TermY & prior.TermY,
                    RawY = state.RawY & prior.RawY,
                    TermX = state.TermX & prior.TermX,
                    RawX = state.RawX & prior.RawX,
                    ClassY = state.ClassY & prior.ClassY,
                    ClassX = state.ClassX & prior.ClassX
                };
                if (state == prior)
                    continue;
            }
            seen[state.Pc] = state;
            BeamInstruction instruction = code.Instructions[state.Pc];
            var operands = instruction.Operands;
            string name = instruction.Definition.Name;
            if (state.Pending != NoPendingHandler
                && name is not (BeamLinkNames.Label or BeamLinkNames.Line or BeamTryNames.Case))
                throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);

            void Enqueue(int pc, ExceptionalState next, bool exceptional = false)
            {
                if (pc < function.FirstInstructionIndex || pc >= function.EndInstructionIndex
                    || !exceptional && handlerTargets.Contains(pc))
                    throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);
                work.Push(next with { Pc = pc });
            }

            int Index(BeamOperand operand)
            {
                int index = (int)operand.Value;
                if (index < 0 || operand.Kind == BeamOperandParameters.Y && index >= state.Slots
                    || operand.Kind == BeamOperandParameters.X && index >= BeamOperandParameters.MaximumRegister)
                    throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);

                return index;
            }

            bool Raw(BeamOperand operand)
            {
                int index = Index(operand);

                return operand.Kind == BeamOperandParameters.Y
                    ? (state.RawY & Bit(index)) != 0
                    : operand.Kind == BeamOperandParameters.X && (state.RawX & Bit(index)) != 0;
            }

            void Read(BeamOperand operand, bool transport = false)
            {
                if (operand.Kind is not (BeamOperandParameters.X or BeamOperandParameters.Y))
                    return;
                int index = Index(operand);
                BigInteger terms = operand.Kind == BeamOperandParameters.X ? state.TermX : state.TermY;
                if ((terms & Bit(index)) == 0 && !(transport && Raw(operand)))
                    throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);
            }

            bool Class(BeamOperand operand)
            {
                if (operand.Kind == BeamOperandParameters.Atom)
                    return code.Structure.Atoms[(int)operand.Value] is ErlangExceptionClasses.Error
                        or ErlangExceptionClasses.Exit or ErlangExceptionClasses.Throw;
                if (operand.Kind is not (BeamOperandParameters.X or BeamOperandParameters.Y))
                    return false;
                int index = Index(operand);

                return ((operand.Kind == BeamOperandParameters.X ? state.ClassX : state.ClassY) & Bit(index)) != 0;
            }

            void Write(BeamOperand operand, bool raw = false, bool validClass = false)
            {
                int index = Index(operand);
                if (operand.Kind == BeamOperandParameters.Y)
                {
                    for (Handler? tag = state.Handler; tag is not null; tag = tag.Parent)
                        if (tag.Slot == index)
                            throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);
                    state = state with
                    {
                        TermY = raw ? state.TermY & ~Bit(index) : state.TermY | Bit(index),
                        RawY = raw ? state.RawY | Bit(index) : state.RawY & ~Bit(index),
                        ClassY = validClass ? state.ClassY | Bit(index) : state.ClassY & ~Bit(index)
                    };
                }
                else if (operand.Kind == BeamOperandParameters.X)
                    state = state with
                    {
                        TermX = raw ? state.TermX & ~Bit(index) : state.TermX | Bit(index),
                        RawX = raw ? state.RawX | Bit(index) : state.RawX & ~Bit(index),
                        ClassX = validClass ? state.ClassX | Bit(index) : state.ClassX & ~Bit(index)
                    };
                else
                    throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);
            }

            void Roots()
            {
                BigInteger initialized = state.TermY | state.RawY;
                for (Handler? tag = state.Handler; tag is not null; tag = tag.Parent)
                    initialized |= Bit(tag.Slot);
                if (state.Slots != BeamFrameParameters.NoFrame && initialized != Mask(state.Slots))
                    throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);
            }

            void Live(int count, bool arguments = false)
            {
                if (count < 0 || count > BeamOperandParameters.MaximumRegister)
                    throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);
                BigInteger valid = arguments ? state.TermX : state.TermX | state.RawX;
                if ((valid & Mask(count)) != Mask(count))
                    throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);
            }

            void Exception()
            {
                Roots();
                if (state.Handler is { } handler)
                    Enqueue(
                        handler.Target,
                        state with
                        {
                            TermX = BigInteger.Zero,
                            RawX = BigInteger.Zero,
                            ClassX = BigInteger.Zero,
                            Pending = handler.Installation
                        },
                        exceptional: true
                    );
            }

            void Branch(BeamOperand target)
            {
                if (target.Kind == BeamOperandParameters.Failure || target.Value == function.InfoLabel)
                {
                    Exception();

                    return;
                }
                int pc = target.Value == function.EntryLabel
                    ? function.FirstInstructionIndex : code.Labels[(int)target.Value];
                Enqueue(pc, state);
            }

            void Bif(BeamOperand target, BeamOperand destination)
            {
                Branch(target);
                Write(destination);
            }

            void Prune(int count)
            {
                Live(count);
                state = state with
                {
                    TermX = state.TermX & Mask(count),
                    RawX = state.RawX & Mask(count),
                    ClassX = state.ClassX & Mask(count)
                };
            }

            void Arguments(int count)
            {
                Live(count, arguments: true);
                Exception();
            }

            void NoTags()
            {
                if (state.Handler is not null)
                    throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);
            }

            switch (name)
            {
                case BeamTryNames.Install:
                    int slot = Index(operands[0]);
                    if (state.Handler is { } enclosing && slot >= enclosing.Slot)
                        throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);
                    state = state with
                    {
                        Handler = new Handler(
                            state.Pc,
                            slot,
                            code.Labels[(int)operands[1].Value],
                            state.Handler
                        ),
                        TermY = state.TermY & ~Bit(slot),
                        RawY = state.RawY & ~Bit(slot),
                        ClassY = state.ClassY & ~Bit(slot)
                    };
                    break;
                case BeamTryNames.Case:
                case BeamTryNames.End:
                    Handler tag = state.Handler ?? throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);
                    if (tag.Slot != Index(operands[0])
                        || name == BeamTryNames.Case && state.Pending != tag.Installation
                        || name == BeamTryNames.End && state.Pending != NoPendingHandler)
                        throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);
                    state = state with
                    {
                        Handler = tag.Parent,
                        TermY = state.TermY | Bit(tag.Slot),
                        RawY = state.RawY & ~Bit(tag.Slot),
                        Pending = NoPendingHandler,
                        ClassY = state.ClassY & ~Bit(tag.Slot)
                    };
                    if (name == BeamTryNames.Case)
                        state = state with { TermX = Mask(2), RawX = Bit(2), ClassX = Bit(0) };
                    break;
                case BeamTryNames.BuildStacktrace:
                    Roots();
                    if ((state.RawX & Bit(0)) == 0)
                        throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);
                    state = state with { TermX = Bit(0), RawX = BigInteger.Zero, ClassX = BigInteger.Zero };
                    break;
                case BeamTryNames.Raise:
                    Read(operands[0], transport: true);
                    if (!Raw(operands[0]))
                        throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);
                    Read(operands[1]);
                    Exception();
                    continue;
                case BeamTryNames.CaseEnd:
                    Read(operands[0]);
                    Exception();
                    continue;
                case BeamTryNames.RawRaise:
                    var classRegister = new BeamOperand(BeamOperandParameters.X, BigInteger.Zero);
                    var reasonRegister = new BeamOperand(BeamOperandParameters.X, BigInteger.One);
                    var traceRegister = new BeamOperand(BeamOperandParameters.X, new BigInteger(2));
                    Read(classRegister);
                    Read(reasonRegister);
                    Read(traceRegister, transport: true);
                    if (!Raw(traceRegister))
                        throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);
                    bool definitelyValidClass = Class(classRegister);
                    Exception();
                    if (definitelyValidClass)
                        continue;
                    // Native raw_raise returns badarg only for an invalid class.
                    // Other registers, including the saved trace, remain intact.
                    Write(classRegister);
                    break;
                case BeamLinkNames.Label:
                case BeamLinkNames.Line:
                case BeamLinkNames.OnLoad:
                case BeamNifNames.Start:
                    break;
                case BeamLinkNames.Move:
                    Read(operands[0], transport: true);
                    bool movedRaw = (operands[0].Kind is BeamOperandParameters.X or BeamOperandParameters.Y) && Raw(operands[0]);
                    bool movedClass = Class(operands[0]);
                    Write(operands[1], movedRaw, movedClass);
                    break;
                case BeamGeneralOpcodeNames.Swap:
                    Read(operands[0], transport: true);
                    Read(operands[1], transport: true);
                    bool leftRaw = Raw(operands[0]);
                    bool rightRaw = Raw(operands[1]);
                    bool leftClass = Class(operands[0]);
                    bool rightClass = Class(operands[1]);
                    Write(operands[0], rightRaw, rightClass);
                    Write(operands[1], leftRaw, leftClass);
                    break;
                case BeamLinkNames.Allocate:
                case BeamLinkNames.AllocateHeap:
                    if (state.Slots != BeamFrameParameters.NoFrame)
                        throw new NotSupportedException(BeamOnLoadDiagnostics.Frame);
                    Prune((int)operands[name == BeamLinkNames.Allocate ? 1 : 2].Value);
                    state = state with { Slots = (int)operands[0].Value, TermY = BigInteger.Zero, RawY = BigInteger.Zero, ClassY = BigInteger.Zero };
                    break;
                case BeamLinkNames.HeapTest:
                    Roots();
                    Prune((int)operands[1].Value);
                    break;
                case BeamOnLoadNames.InitY:
                    foreach (BeamOperand operand in operands.Skip(BeamFrameParameters.TupleCountPrefix))
                        Write(operand);
                    break;
                case BeamGeneralOpcodeNames.Trim:
                    int removed = (int)operands[0].Value;
                    int remaining = (int)operands[1].Value;
                    if (state.Slots == BeamFrameParameters.NoFrame || removed + remaining != state.Slots)
                        throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);
                    state = state with
                    {
                        Slots = remaining,
                        TermY = state.TermY >> removed,
                        RawY = state.RawY >> removed,
                        ClassY = state.ClassY >> removed,
                        Handler = Shift(state.Handler, removed)
                    };
                    break;
                case BeamLinkNames.Deallocate:
                    NoTags();
                    if (state.Slots != operands[0].Value)
                        throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);
                    state = state with { Slots = BeamFrameParameters.NoFrame, TermY = BigInteger.Zero, RawY = BigInteger.Zero, ClassY = BigInteger.Zero };
                    break;
                case BeamGeneralOpcodeNames.Jump:
                    Branch(operands[0]);
                    continue;
                case BeamGeneralOpcodeNames.SelectValue:
                    Read(operands[0]);
                    Branch(operands[1]);
                    for (int target = 4; target < operands.Count; target += 2)
                        Branch(operands[target]);
                    continue;
                case BeamGeneralOpcodeNames.NilTest:
                case BeamGeneralOpcodeNames.NonemptyListTest:
                case BeamGeneralOpcodeNames.ListTest:
                case BeamGeneralOpcodeNames.TupleTest:
                case BeamGeneralOpcodeNames.FloatTest:
                case BeamGeneralOpcodeNames.AtomTest:
                case BeamGeneralOpcodeNames.TupleArity:
                case BeamLinkNames.IntegerTest:
                case BeamOnLoadNames.PidTest:
                case BeamOnLoadNames.TaggedTupleTest:
                    Read(operands[1]);
                    Branch(operands[0]);
                    break;
                case BeamGeneralOpcodeNames.FunctionTest:
                case BeamGeneralOpcodeNames.ArithmeticEqual:
                case BeamGeneralOpcodeNames.ExactNotEqual:
                case BeamGeneralOpcodeNames.GreaterOrEqual:
                case BeamGeneralOpcodeNames.Less:
                case BeamLinkNames.EqualityTest:
                    Read(operands[1]);
                    Read(operands[2]);
                    Branch(operands[0]);
                    break;
                case BeamGeneralOpcodeNames.GetList:
                    Read(operands[0]);
                    Write(operands[1]);
                    Write(operands[2]);
                    break;
                case BeamGeneralOpcodeNames.GetHead:
                case BeamGeneralOpcodeNames.GetTail:
                    Read(operands[0]);
                    Write(operands[1]);
                    break;
                case BeamOnLoadNames.TupleElement:
                    Read(operands[0]);
                    Write(operands[2]);
                    break;
                case BeamLinkNames.PutList:
                    Read(operands[0]);
                    Read(operands[1]);
                    Write(operands[2]);
                    break;
                case BeamLinkNames.PutTuple:
                    foreach (BeamOperand operand in operands.Skip(BeamLinkParameters.TupleListPrefixOperands))
                        Read(operand);
                    Write(operands[0]);
                    break;
                case BeamLinkNames.Bif:
                    Write(operands[1]);
                    break;
                case BeamGeneralOpcodeNames.UnaryBif:
                    Read(operands[2]);
                    Bif(operands[0], operands[3]);
                    break;
                case BeamGeneralOpcodeNames.BinaryBif:
                    Read(operands[2]);
                    Read(operands[3]);
                    Bif(operands[0], operands[4]);
                    break;
                case BeamGeneralOpcodeNames.UnaryGcBif:
                    Roots();
                    Live((int)operands[1].Value);
                    Read(operands[3]);
                    Prune((int)operands[1].Value);
                    Bif(operands[0], operands[4]);
                    break;
                case BeamLinkNames.GuardBif:
                    Roots();
                    Live((int)operands[1].Value);
                    Read(operands[3]);
                    Read(operands[4]);
                    Prune((int)operands[1].Value);
                    Bif(operands[0], operands[5]);
                    break;
                case BeamGeneralOpcodeNames.MapFields:
                    Read(operands[1]);
                    foreach (BeamOperand key in operands.Skip(3))
                        Read(key);
                    Branch(operands[0]);
                    break;
                case BeamGeneralOpcodeNames.MapAssociate:
                    Roots();
                    Live((int)operands[3].Value);
                    Read(operands[1]);
                    foreach (BeamOperand value in operands.Skip(5))
                        Read(value);
                    Exception();
                    Prune((int)operands[3].Value);
                    Write(operands[2]);
                    break;
                case BeamLambdaNames.Create:
                    Roots();
                    foreach (BeamOperand value in operands.Skip(BeamLambdaNames.EnvironmentPrefixOperands))
                        Read(value);
                    Write(operands[1]);
                    break;
                case BeamRegisterNames.Call:
                case BeamLinkNames.ExternalCall:
                case BeamGeneralOpcodeNames.DynamicCall:
                case BeamLambdaNames.Call:
                    if (state.Slots == BeamFrameParameters.NoFrame)
                        throw new NotSupportedException(BeamOnLoadDiagnostics.Frame);
                    if (name == BeamLambdaNames.Call)
                    {
                        Read(operands[2]);
                        Arguments((int)operands[1].Value);
                    }
                    else if (name == BeamGeneralOpcodeNames.DynamicCall)
                    {
                        Live((int)operands[0].Value + 1, arguments: true);
                        Exception();
                    }
                    else
                        Arguments((int)operands[0].Value);
                    if (name == BeamLinkNames.ExternalCall && BeamNoReturnAnalysis.Import(code, (int)operands[1].Value)
                        || name == BeamRegisterNames.Call && BeamNoReturnAnalysis.Local(code, (int)operands[1].Value))
                        continue;
                    state = state with { TermX = Bit(0), RawX = BigInteger.Zero, ClassX = BigInteger.Zero };
                    break;
                case BeamLinkNames.Send:
                    Arguments(2);
                    state = state with { TermX = Bit(0), RawX = BigInteger.Zero, ClassX = BigInteger.Zero };
                    break;
                case BeamGeneralOpcodeNames.LocalLast:
                case BeamOnLoadNames.ExternalLast:
                    NoTags();
                    if (state.Slots != operands[2].Value)
                        throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);
                    Arguments((int)operands[0].Value);
                    continue;
                case BeamLinkNames.LocalCall:
                case BeamLinkNames.ExternalTailCall:
                    NoTags();
                    if (state.Slots != BeamFrameParameters.NoFrame)
                        throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);
                    Arguments((int)operands[0].Value);
                    continue;
                case BeamLinkNames.Return:
                    NoTags();
                    if (state.Slots != BeamFrameParameters.NoFrame)
                        throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);
                    Live(1, arguments: true);
                    continue;
                case BeamOnLoadNames.BadMatch:
                case BeamGeneralOpcodeNames.CaseEnd:
                    Read(operands[0]);
                    Exception();
                    continue;
                default:
                    throw new NotSupportedException(BeamOnLoadDiagnostics.Frame);
            }
            Enqueue(state.Pc + 1, state, exceptional: state.Pending != NoPendingHandler);
        }
    }

    private static BigInteger Bit(int index) => BigInteger.One << index;

    private static BigInteger Mask(int count) => (BigInteger.One << count) - BigInteger.One;

    private static Handler? Shift(Handler? tag, int removed)
    {
        if (tag is null)
            return null;
        if (tag.Slot < removed)
            throw new InvalidDataException(BeamOnLoadDiagnostics.Frame);

        return tag with { Slot = tag.Slot - removed, Parent = Shift(tag.Parent, removed) };
    }
}
