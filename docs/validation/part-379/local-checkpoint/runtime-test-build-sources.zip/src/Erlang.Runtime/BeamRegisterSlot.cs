namespace Erlang;

internal readonly struct BeamRegisterSlot
{
    private readonly object? value;

    private BeamRegisterSlot(object value) => this.value = value;

    internal BeamRegisterSlotKind Kind => value switch
    {
        null => BeamRegisterSlotKind.Uninitialized,
        Term => BeamRegisterSlotKind.Term,
        BeamHandlerTag => BeamRegisterSlotKind.Handler,
        BeamSavedTrace => BeamRegisterSlotKind.SavedTrace,
        _ => throw new InvalidDataException(BeamRegisterProtocolNames.TypedValue)
    };

    internal static BeamRegisterSlot FromTerm(Term value)
        => new(value ?? throw new ArgumentNullException(nameof(value)));

    internal static BeamRegisterSlot FromHandler(BeamHandlerTag value)
        => new(value ?? throw new ArgumentNullException(nameof(value)));

    internal static BeamRegisterSlot FromSavedTrace(BeamSavedTrace value)
        => new(value ?? throw new ArgumentNullException(nameof(value)));

    internal Term ReadTerm() => Kind switch
    {
        BeamRegisterSlotKind.Term => (Term)value!,
        BeamRegisterSlotKind.Uninitialized => throw new InvalidDataException(BeamRegisterNames.Uninitialized),
        _ => throw new InvalidDataException(BeamRegisterProtocolNames.TypedValue)
    };

    internal BeamHandlerTag ReadHandler()
        => Kind == BeamRegisterSlotKind.Handler ? (BeamHandlerTag)value!
            : throw new InvalidDataException(BeamRegisterProtocolNames.Handler);

    internal BeamSavedTrace ReadSavedTrace()
        => Kind == BeamRegisterSlotKind.SavedTrace ? (BeamSavedTrace)value!
            : throw new InvalidDataException(BeamRegisterProtocolNames.Trace);

    internal void RequireMovable()
    {
        if (Kind == BeamRegisterSlotKind.Uninitialized)
            throw new InvalidDataException(BeamRegisterNames.Uninitialized);
        if (Kind == BeamRegisterSlotKind.Handler)
            throw new InvalidDataException(BeamRegisterProtocolNames.Handler);
    }
}
