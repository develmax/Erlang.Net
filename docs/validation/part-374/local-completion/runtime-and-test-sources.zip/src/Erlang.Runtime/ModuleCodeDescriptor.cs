using System.Security.Cryptography;

namespace Erlang;

public sealed class ModuleCodeDescriptor
{
    public IReadOnlyList<(string Name, int Arity)> Functions { get; }
    public IReadOnlyList<(string Name, int Arity)> Exports { get; }
    public BitString Fingerprint { get; }
    public Term Compilation { get; }
    public Term? Attributes { get; }
    public ModuleAttributePolicy AttributePolicy { get; }
    public object? SourceOwner { get; }
    public IReadOnlyList<NativeRecordDefinition> NativeRecords { get; }

    private IReadOnlyList<(string Name, int Arity)>? declaredNifs;
    public IReadOnlyList<(string Name, int Arity)>? DeclaredNifs
    {
        get => declaredNifs;
        init => declaredNifs = value is null ? null : Array.AsReadOnly(ObservedPayloadStorage.Code(value.Distinct().ToArray()));
    }


    public ModuleCodeDescriptor(
        IEnumerable<(string Name, int Arity)> functions,
        IEnumerable<(string Name, int Arity)> exports,
        BitString fingerprint,
        Term compilation,
        Term? attributes = null,
        object? sourceOwner = null,
        IEnumerable<NativeRecordDefinition>? nativeRecords = null,
        ModuleAttributePolicy attributePolicy = ModuleAttributePolicy.AddDefaultVersion
    )
    {
        if (!fingerprint.IsBinary || fingerprint.ToArray().Length != MD5.HashSizeInBytes)
            throw new ErlangException(ErlangErrorReasons.BadArgument);
        if (!Enum.IsDefined(attributePolicy))
            throw new ArgumentOutOfRangeException(nameof(attributePolicy));
        AttributePolicy = attributePolicy;
        Functions = Array.AsReadOnly(ObservedPayloadStorage.Code(functions.ToArray()));
        Exports = Array.AsReadOnly(ObservedPayloadStorage.Code(exports.ToArray()));
        Fingerprint = fingerprint;
        Compilation = compilation;
        Attributes = attributes;
        SourceOwner = sourceOwner;
        NativeRecords = Array.AsReadOnly(ObservedPayloadStorage.Code((nativeRecords ?? []).ToArray()));
    }
}
