using System.Collections.Frozen;

namespace Erlang;

public sealed partial class ModuleRegistry
{
    internal IReadOnlyDictionary<(string Function, int Arity), ErlangFunction> CaptureBeamPrimitives(BeamLinkedCode code)
    {
        var primitives = new Dictionary<(string Function, int Arity), ErlangFunction>();
        lock (gate)
        {
            foreach (BeamLinkedFunction function in code.Functions.Where(function => BeamNativePrimitives.IsStub(code, function)))
            {
                var signature = (function.Module, function.Name, function.Arity);
                if (!sourceOwners.ContainsKey(signature) && IsNativeEntry(signature.Module, signature.Name, signature.Arity))
                    primitives.Add((function.Name, function.Arity), functions[signature]);
                else if (sourceOwners.GetValueOrDefault(signature) is PreparedBeamImage previous
                    && ReferenceEquals(codeImages.GetValueOrDefault(signature.Module), previous.ExecutionIdentity.Image)
                    && previous.ExecutionIdentity.NativePrimitives.TryGetValue((function.Name, function.Arity), out ErlangFunction? primitive))
                    primitives.Add((function.Name, function.Arity), primitive);
                else
                    throw new NotSupportedException(BeamRegisterNames.Unsupported);
            }
        }

        return primitives.ToFrozenDictionary();
    }
}
